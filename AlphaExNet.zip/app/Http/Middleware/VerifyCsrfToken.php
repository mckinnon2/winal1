<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as BaseVerifier;

class VerifyCsrfToken extends BaseVerifier {
	/**
	 * The URIs that should be excluded from CSRF verification.
	 *
	 * @var array
	 */
	protected $except = [
		//
		'ajax/exchange_chart','ajax/mytradehistory','ajax/openorders', 'ajax/verify_otp', 'ajax/checkphone', 'ajax/registerotp', 'ajax/refresh_capcha', 'ajax/address_validation', 'ajax/limit_balance', 'ajax/get_instant_buy_form', 'ajax/get_instant_sell_form', 'ajax/openorders','ajax/cancel_order','cron/getdata', 'swap', 'ajax/getfee', 'ajax/min_withdrawal',
        'api/*',
        'api2/*',
		'change_password',
		'migration/changeid',
		'migration/findid',
		'migration/getdata'
	];
}
