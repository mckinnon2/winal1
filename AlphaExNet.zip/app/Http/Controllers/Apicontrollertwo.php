<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use ReallySimpleJWT\Token;
use App\model\Balance;
use App\model\Cms;
use App\model\Country;
use App\model\Enquiry;
use App\model\Faq;
use App\model\OTP;
use App\model\Pair;
use App\model\PairStats;
use App\model\Profit;
use App\model\SiteSettings;
use App\model\Tokenusers;
use App\model\Trade;
use App\model\Transaction;
use App\model\UserBalance;
use App\model\UserCurrencyAddresses;
use App\model\Users;
use App\model\Verification;
use App\model\Currencies;
use App\model\UserBalancesNew;
use App\model\TradeMapping;
use Cache;
use DB;
use function GuzzleHttp\Psr7\_caseless_remove;
use Hash;
use Mockery\Exception;
use PragmaRX\Google2FA\Google2FA;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Session;
use Validator;

class Apicontrollertwo extends Controller
{
    function login(Request $request)
    {
        try {
            $response = array();
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                    'login_mail' => 'required|email',
                    'password' => 'required',
                ], [
                    'login_mail.required' => 'Email id is required',
                    'login_mail.email' => 'Enter valid email id',
                    'password.required' => 'Password is required',
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error)
                    {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $remember_me = $request['remember_me'];
                $email = strtolower($request['login_mail']);
                $password = $request['password'];
                $ip = \Request::ip();
                $res = $this->user_login_check($email, $password);
                switch ($res) {
                    case '1':
//                        if($email == 'nodeman01@yopmail.com')
                        //send login status mail
                        $to = [$email];
                        $subject = get_template('17', 'subject');
                        $message = get_template('17', 'template');
                        $mailarr = array(
                            '###EMAIL###' => $email,
                            '###OS###' => getOS(),
                            '###BROWSER###' => getBrowser(),
                            '###IP###' => $ip,
                            '###TIME###' => date('Y-m-d H:i:s'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);
                        if ($remember_me == 'on') {
                            $hour = time() + 3600 * 24 * 30;
                            setcookie('email', $email, $hour);
                            setcookie('password', $password, $hour);
                        }
                        $user_id = Session::get('alphauserid');
                        $exptime=time() + 3600 * 24 * 30;
                        $token = Token::getToken($user_id, env('JWT_SECRET'), $exptime, env('token_issuer'));
                        setcookie('token',$token,time()+1800,"/");
                        Session::put('JWT_TOKEN',$token);
                        $response['status'] = '1';
                        $response['message'] = 'Welcome To AlphaEx Exchange.';
                        $response['user_id'] = $user_id;
                        $response['tfa_status'] = '0';
                        Session::flash('info', 'Welcome To AlphaEx Exchange');
                        return redirect('trade');
                        break;
                    case '5':
                        $tfa_key = Session::get('tfa_key');
                        $response['status'] = '1';
                        $response['message'] = 'Welcome To AlphaEx Exchange.';
                        $response['tfa_status'] = 1;
                        $response['tfa_key'] = $tfa_key;
                        return json_encode($response);
                        break;
                    case '2':
                        $response['status'] = '0';
                        $response['message'] = 'Email or password is wrong.';
                        return json_encode($response);
                        break;
                    case '3':
                        $response['status'] = '0';
                        $response['message'] = 'Your account is deactivated.';
                        return json_encode($response);
                        break;
                    case '4':
                        $response['status'] = '0';
                        $response['message'] = "Email or password is wrong / User doesn't exist.";
                        return json_encode($response);
                        break;
                    case '6':
                        $response['status'] = '0';
                        $response['message'] = 'Please Verify your email address to Login.';
                        return json_encode($response);
                        break;
                    case '7':
                        $response['status'] = '0';
                        $response['message'] = 'Please Verify your email address to Login.';
                        return json_encode($response);
                        break;

                    default:
                        $response['status'] = '0';
                        $response['message'] = 'Please Verify your email address to Login.';
                        return json_encode($response);
                        break;
                }
            }
            else{
                $response['status'] = '0';
                $response['message'] = 'Server Error.';
                return json_encode($response);
            }
        }
        catch(\Exception $e)
        {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';

            return json_encode($response);
        }
    }

    function user_login_check($email, $password)
    {
        try {
            $spl = explode("@", $email);
            $user1 = $spl[0];
            $user2 = $spl[1];
            $res = $this->checking($user1, $user2);
            /*$xdclogin = login_xdc_fun($email, $password);
                if ($xdclogin->status != 'SUCCESS') {
                    return "4";exit();
            */

            if ($res) {
                foreach ($res as $val) {
                    $recordid = $val->id;
                    $recordpass = $val->pass_code;
                    if (Hash::check($password, $recordpass)) {
                        if ($val->status == '1' && ($val->tfa_status == 'disable' || $val->tfa_status == '')) {
                            //log
                            last_activity(get_usermail($recordid), 'Login', $recordid);
                            $sess = array('alphauserid' => $recordid, 'alphausername' => $val->enjoyer_name, 'xinfinpass' => $password);
                            Session::put($sess);
                            return "1";
                        } elseif ($val->status == '1' && $val->tfa_status == 'enable') {
                            //log
                            last_activity(get_usermail($recordid), 'Login', $recordid);
                            Session::put('tfa_key', ownencrypt($recordid));
                            return "5";
                        } elseif ($val->verify_status == '2') {
                            return "6";
                        }
// elseif ($val->mobile_status == '0') {
//                        return "7";
//                    }
                        else {
                            return "3";
                        }

                    } else {
                        return "2";
                    }

                }
            } else {
                return "4";
            }
        }
        catch(\Exception $e)
        {
            echo $e->getFile().' '.$e->getLine().' '.$e->getMessage();
        }
    }

    function checking($end_user1, $end_user2)
    {
        try {
            $items = Users::all()->filter(function ($record) use ($end_user1, $end_user2) {
                if (decrypt($record->end_user1) == $end_user1 && decrypt($record->end_user2) == $end_user2) {
                    return $record;
                } else {
                    return false;
                }
            });

            return $items;
        }
        catch(\Exception $e)
        {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }
}
