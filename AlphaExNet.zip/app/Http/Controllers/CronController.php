<?php

namespace App\Http\Controllers;

use App\model\Admin;
use App\model\Balance;
use App\model\Node;
use App\model\ClosingBalance;
use App\model\Marketprice;
use App\model\OpeningBalance;
use App\model\SiteSettings;
use App\model\Trade;
use App\model\Transaction;
use App\model\UserBalance;
use App\model\Users;
use App\model\Wallettrans;
use App\model\UserCurrencyAddresses;
use App\model\Xdce_transfer;
use App\model\PairStats;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Monolog\Handler\SyslogUdp\UdpSocket;
use Pusher\Pusher;
use Psy\Exception\ErrorException;

class CronController extends Controller
{
    //

    function index()
    {
        abort('404');
    }

    function update_prices()
    {
        try {
            //BTC
//            $btc_usd = $this->get_live_estusd_price('tBTCUSD');
            $btc_usd = $this->get_live_estusd_price('bitcoin');
            echo "BTC-USD  : " . $btc_usd;
            echo "<br>";

            if ($btc_usd != '' || $btc_usd != null) {
                $lobjMarket = Marketprice::where('id', '1')->first();
                $lobjMarket->USD = $btc_usd;
                $lobjMarket->save();
            }

            echo "<br>";
            //ETH
//            $eth_usd = $this->get_live_estusd_price('tETHUSD');
            $eth_usd = $this->get_live_estusd_price('ethereum');
            echo "ETH-USD  : " . $eth_usd;
            echo "<br>";

            if ($eth_usd != '' || $eth_usd != null) {
                $lobjMarket = Marketprice::where('id', '2')->first();
                $lobjMarket->USD = $eth_usd;
                $lobjMarket->save();
            }

            echo "<br>";
            //XRP
//            $xrp_usd = $this->get_live_estusd_price('tXRPUSD');
            $xrp_usd = $this->get_live_estusd_price('ripple');
            echo "XRP-USD  : " . $xrp_usd;
            echo "<br>";

            if ($xrp_usd != '' || $xrp_usd != null) {
                $lobjMarket = Marketprice::where('id', '3')->first();
                $lobjMarket->USD = $xrp_usd;
                $lobjMarket->save();
            }

//            echo "<br>";
            //XDC
//            $res = PairStats::where('pair_id',4)->first();
//            $xdc_usd = number_format($eth_usd * $res->last,10,'.','');
//            echo "XDC-USD  : " . $xdc_usd;
//            echo "<br>";
//
//            if($xdc_usd != '' || $xdc_usd != null) {
//                $lobjMarket = Marketprice::where('id', '4')->first();
//                $lobjMarket->USD = $xdc_usd;
//                $lobjMarket->save();
//            }

            echo "<br>";
            //BCH
//            $bch_usd = $this->get_live_estusd_price('tBCHUSD');
            $bch_usd = $this->get_live_estusd_price('bitcoin-cash');
            echo "BCH-USD  : " . $bch_usd;
            echo "<br>";

            if ($bch_usd != '' || $bch_usd != null) {
                $lobjMarket = Marketprice::where('id', '5')->first();
                $lobjMarket->USD = $bch_usd;
                $lobjMarket->save();
            }

            echo "<br>";
            //XDCE and XDC
            $xdce_usd = $this->get_live_estusd_price('xinfin-network');
            echo "XDCE-USD  : " . $xdce_usd;
            echo "<br>";

            if ($xdce_usd != '' || $xdce_usd != null) {
                $lobjMarket = Marketprice::where('id', '6')->first();
                $lobjMarket->USD = $xdce_usd;
                $lobjMarket->save();

                $lobjMarket = Marketprice::where('id', '4')->first();
                $lobjMarket->USD = $xdce_usd;
                $lobjMarket->save();
            }

            echo "<br>";
            //USDT
            $usdt_usd = $this->get_live_estusd_price('tether');
            echo "USDT-USD  : " . $usdt_usd;
            echo "<br>";

            if ($usdt_usd != '' || $usdt_usd != null) {
                $lobjMarket = Marketprice::where('id', '8')->first();
                $lobjMarket->USD = $usdt_usd;
                $lobjMarket->save();
                echo "<br>";
            }

            //USDC
            $usdc_usd = $this->get_live_estusd_price('usd-coin');
            echo "USDC-USD  : " . $usdc_usd;
            echo "<br>";

            if ($usdc_usd != '' || $usdc_usd != null) {
                $lobjMarket = Marketprice::where('id', '10')->first();
                $lobjMarket->USD = $usdc_usd;
                $lobjMarket->save();
                echo "<br>";
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function get_market_prices($cur1, $cur2)
    {
        try {
            $currency = $cur1 . '-' . $cur2;
            $url = "https://api.cryptonator.com/api/ticker/" . $currency;
            $result = file_get_contents($url);
            $res = json_decode($result);
            $out = $res->ticker;
            return $out->price;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function get_live_estusd_price($cur)
    {
        try {
//            $url = "https://api.bitfinex.com/v2/ticker/" . $cur;
//            $result = file_get_contents($url);
//            $res = json_decode($result);
//            $price = $res[6];
//            return $price;
            $url = "https://api.coinmarketcap.com/v1/ticker/" . $cur;
            $result = file_get_contents($url);
            $res = json_decode($result);
            $price = $res[0]->price_usd;
            return $price;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function eth_deposit_process()
    {
        try {
            $admin = SiteSettings::where('id', 1)->first();
            $last_block = $admin->mined_block;
            $last_block = $last_block + 1;

            $recent_block = get_recent_block();

            if ($recent_block > 0) {
                for ($i = $last_block; $i <= $recent_block; $i++) {


                    $block_number = dechex($i);

                    $eurl = 'https://api.etherscan.io/api?module=proxy&action=eth_getBlockByNumber&tag=' . $block_number . '&boolean=true';

                    $cObj = curl_init();
                    curl_setopt($cObj, CURLOPT_URL, $eurl);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                    $output = curl_exec($cObj);
                    $curlinfos = curl_getinfo($cObj);

                    $result = json_decode($output);

                    if ($result) {
                        $transactionList = $result->result->transactions;

                    } else {
                        $transactionList = '';
                    }

                    //iterating transaction lists
                    foreach ($transactionList as $transaction) {
                        $to_address = $transaction->to;
                        $user = Users::where('ETH_addr', '=', $to_address)->first();
                        if ($user != null && $to_address != null) {
                            $dep_id = $transaction->hash;
                            $ether_balance = hexdec($transaction->value) / 1000000000000000000;
                            $dep_already = $this->eth_checkdepositalready($user->id, $dep_id);
                            if ($dep_already === true && (float)$ether_balance > 0) {

                                $ether_balance = sprintf('%.10f', $ether_balance);

                                $fetchbalance = get_userbalance($user->id, 'ETH');
                                $finalbalance = $fetchbalance + $ether_balance;

                                $adminethaddr = decrypt(get_config('eth_address'));
                                $transid = 'TXD' . $user->id . time();

//                                $hash = eth_transfer_fun($to_address, $ether_balance, $adminethaddr, $user->id);
                                $hash = eth_transfer_fun_api($to_address, $ether_balance, $adminethaddr, $user->id);

                                if ($hash != "") {
                                    if ($hash != 'error') {
                                        $instr = new Wallettrans;
                                        $instr->adtras_id = $transid;
                                        $instr->currency = 'ETH';
                                        $instr->address = $to_address;
                                        $instr->hash = $hash;
                                        $instr->amount = $ether_balance;
                                        $instr->save();
                                    }

                                    $upt = Balance::where('user_id', $user->id)->first();
                                    $upt->ETH = $finalbalance;
                                    $upt->save();

                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $user->id;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'ETH';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $ether_balance;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $to_address;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = '0';
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $dep_id;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = $i;
                                    if ($ins->save()) {

                                        $this->deposit_mail($user->id, $ether_balance, $transid, 'ETH');

                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                        $pusher->trigger('private-transaction_' . $user->id, 'deposit-event', array('User_id' => $user->id, 'Transaction_id' => $transid, 'Currency' => 'ETH', 'Amount' => $ether_balance, 'Status' => 'Completed', 'Time' => $today));

                                    }
                                }
                            }
                        }
//                        else {
//                            $txhash = $transaction->hash;
//
//                            $url = "https://api.etherscan.io/api?module=account&action=txlistinternal&txhash=".$txhash."&apikey=YourApiKeyToken";
//
//                            $cObj = curl_init();
//                            curl_setopt($cObj, CURLOPT_URL, $url);
//                            curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
//                            curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
//                            curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
//                            $output = curl_exec($cObj);
//                            $curlinfos = curl_getinfo($cObj);
//
//                            $result = json_decode($output);
//
//                            if($result)
//                            {
//                                $list = $result->result;
//                            }
//                            else
//                            {
//                                $list = '';
//                            }
//
//                            if(isset($list[0]))
//                            {
//                                foreach($list as $internaltx) {
//                                    $intl_to = $internaltx->to;
//                                    $user = Users::where('ETH_addr', $intl_to)->first();
//                                    if ($user != null && $intl_to != null) {
//                                        $eth_balance = $internaltx->value / 1000000000000000000;
//                                        $check_deposit = $this->eth_checkdepositalready($user->id, $txhash);
//
//                                        if ($check_deposit === true && (float)$eth_balance > 0) {
//
//                                            $eth_balance = sprintf('%.10f', $eth_balance);
//
//                                            $fetchbalance = get_userbalance($user->id, 'ETH');
//                                            $finalbalance = $fetchbalance + $eth_balance;
//
//                                            $adminethaddr = decrypt(get_config('eth_address'));
//                                            $transid = 'TXD' . $user->id . time();
//
////                                $hash = eth_transfer_fun($to_address, $ether_balance, $adminethaddr, $user->id);
//                                            $hash = eth_transfer_fun_api($to_address, $eth_balance, $adminethaddr, $user->id);
//
//                                            if ($hash != "") {
//                                                if ($hash != 'error') {
//                                                    $instr = new Wallettrans;
//                                                    $instr->adtras_id = $transid;
//                                                    $instr->currency = 'ETH';
//                                                    $instr->address = $intl_to;
//                                                    $instr->hash = $hash;
//                                                    $instr->amount = $eth_balance;
//                                                    $instr->save();
//                                                }
//
//                                                $upt = Balance::where('user_id', $user->id)->first();
//                                                $upt->ETH = $finalbalance;
//                                                $upt->save();
//
//                                                $today = date('Y-m-d H:i:s');
//                                                $ip = \Request::ip();
//                                                $ins = new Transaction;
//                                                $ins->user_id = $user->id;
//                                                $ins->payment_method = 'Cryptocurrency Account';
//                                                $ins->transaction_id = $transid;
//                                                $ins->currency_name = 'ETH';
//                                                $ins->type = 'Deposit';
//                                                $ins->transaction_type = '1';
//                                                $ins->amount = $eth_balance;
//                                                $ins->updated_at = $today;
//                                                $ins->crypto_address = $to_address;
//                                                $ins->transfer_amount = '0';
//                                                $ins->fee = '0';
//                                                $ins->tax = '0';
//                                                $ins->verifycode = '1';
//                                                $ins->order_id = '0';
//                                                $ins->status = 'Completed';
//                                                $ins->cointype = '2';
//                                                $ins->payment_status = 'Paid';
//                                                $ins->paid_amount = '0';
//                                                $ins->wallet_txid = $txhash;
//                                                $ins->ip_address = $ip;
//                                                $ins->verify = '1';
//                                                $ins->blocknumber = $i;
//                                                if ($ins->save()) {
//
//                                                    $this->deposit_mail($user->id, $eth_balance, $transid, 'ETH');
//
//                                                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
//
//                                                    $pusher->trigger('private-transaction_' . $user->id, 'deposit-event', array('User_id' => $user->id, 'Transaction_id' => $transid, 'Currency' => 'ETH', 'Amount' => $eth_balance, 'Status' => 'Completed', 'Time' => $today));
//
//                                                }
//                                            }
//                                        }
//                                    }
//                                }
//                            }
//                        }

                    }
                    if ($last_block < $i) {
                        $admin->mined_block = $i;
                        $admin->save();
                    }
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    function eth_deposit_process_user($id)
    {
        try {
            $verifyBal = verifyEther($id);
            $jsonresult = [];
            if ($verifyBal != '' && $verifyBal > 0) {
                $userslist[] = Users::orderBy('id', 'asc')->where('ETH_addr', $id)->first();

                if ($userslist) {
                    foreach ($userslist as $userval) {
                        $userid = $userval->id;
                        $ethaddress = $userval->ETH_addr;
                        $blocknum = Transaction::max('blocknumber');

                        if ($blocknum == "") {
                            $blocknum = "3500000";
                        }
                        $blocknum = "4500000";
                        if ($ethaddress != "") {

                            $eurl = 'https://api.etherscan.io/api?module=account&action=txlist&address=' . $ethaddress . '&startblock=' . $blocknum . '&endblock=latest';

                            $cObj = curl_init();
                            curl_setopt($cObj, CURLOPT_URL, $eurl);
                            curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                            curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                            curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                            $output = curl_exec($cObj);
                            $curlinfos = curl_getinfo($cObj);

                            $result = json_decode($output);

                            if ($result->message == 'OK') {
                                $transaction = $result->result;
                                for ($tr = 0; $tr < count($transaction); $tr++) {

                                    $block_number = $transaction[$tr]->blockNumber;
                                    $address = $transaction[$tr]->to;
                                    $txid = $transaction[$tr]->hash;
                                    $value = $transaction[$tr]->value;

                                    $dep_id = $txid;
                                    $eth_balance = $value;
                                    $ether_balance = ($eth_balance / 1000000000000000000);

                                    $dep_already = $this->eth_checkdepositalready($userid, $dep_id);
                                    if ($dep_already === TRUE && (float)$ether_balance > 0) {
                                        if ($ethaddress == $address) {

                                            $ether_balance = sprintf('%.10f', $ether_balance);

                                            $fetchbalance = get_userbalance($userid, 'ETH');
                                            $finalbalance = $fetchbalance + $ether_balance;

                                            $adminethaddr = decrypt(get_config('eth_address'));
                                            $transid = 'TXD' . $userid . time();
//                                            $hash = eth_transfer_fun($ethaddress, $ether_balance, $adminethaddr, $userid);
                                            $hash = eth_transfer_fun_api($ethaddress, $ether_balance, $adminethaddr, $userid);

                                            if ($hash != '') {
                                                if ($hash != 'error') {
                                                    //wallet record generation
                                                    $instr = new Wallettrans;
                                                    $instr->adtras_id = $transid;
                                                    $instr->currency = 'ETH';
                                                    $instr->address = $ethaddress;
                                                    $instr->hash = $hash;
                                                    $instr->amount = $ether_balance;
                                                    $instr->save();
                                                }

                                                //update userbalance
                                                $upt = Balance::where('user_id', $userid)->first();
                                                $upt->ETH = $finalbalance;
                                                $upt->save();

                                                //generate transcation record
                                                $today = date('Y-m-d H:i:s');
                                                $ip = \Request::ip();
                                                $ins = new Transaction;
                                                $ins->user_id = $userid;
                                                $ins->payment_method = 'Cryptocurrency Account';
                                                $ins->transaction_id = $transid;
                                                $ins->currency_name = 'ETH';
                                                $ins->type = 'Deposit';
                                                $ins->transaction_type = '1';
                                                $ins->amount = $ether_balance;
                                                $ins->updated_at = $today;
                                                $ins->crypto_address = $address;
                                                $ins->transfer_amount = '0';
                                                $ins->fee = '0';
                                                $ins->tax = '0';
                                                $ins->verifycode = '1';
                                                $ins->order_id = '0';
                                                $ins->status = 'Completed';
                                                $ins->cointype = '2';
                                                $ins->payment_status = 'Paid';
                                                $ins->paid_amount = '0';
                                                $ins->wallet_txid = $dep_id;
                                                $ins->ip_address = $ip;
                                                $ins->verify = '1';
                                                $ins->blocknumber = $block_number;

                                                //sent mail to enduser
                                                if ($ins->save()) {
                                                    $this->deposit_mail($userid, $ether_balance, $transid, 'ETH');

                                                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                                    $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'ETH', 'Amount' => $ether_balance, 'Status' => 'Completed', 'Time' => $today));

                                                }
                                                $jsonresult[$tr] = array('status' => 'Ok', 'message' => 'Transfer Completed', 'Block_number' => $block_number, 'TransactionId' => $txid, 'Value' => $value);

                                            } //if block of ether block transaction
                                            elseif ($hash == 'Error') {
                                                $jsonresult[$tr] = array('Status' => 'Error');
                                            }

                                        }
                                    }
                                }

                            } //for internal transactions
                            else {
                                $eurl = 'https://api.etherscan.io/api?module=account&action=txlistinternal&address=' . $ethaddress . '&startblock=' . $blocknum . '&endblock=latest';

                                $cObj = curl_init();
                                curl_setopt($cObj, CURLOPT_URL, $eurl);
                                curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                                curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                                curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                                $output = curl_exec($cObj);
                                $curlinfos = curl_getinfo($cObj);

                                $result = json_decode($output);

                                if ($result->message == 'OK') {
                                    $transaction = $result->result;
                                    for ($tr = 0; $tr < count($transaction); $tr++) {

                                        $block_number = $transaction[$tr]->blockNumber;
                                        $address = $transaction[$tr]->to;
                                        $txid = $transaction[$tr]->hash;
                                        $value = $transaction[$tr]->value;

                                        $dep_id = $txid;
                                        $eth_balance = $value;
                                        $ether_balance = ($eth_balance / 1000000000000000000);

                                        $dep_already = $this->eth_checkdepositalready($userid, $dep_id);
                                        if ($dep_already === TRUE && (float)$ether_balance > 0) {
                                            if ($ethaddress == $address) {

                                                $ether_balance = sprintf('%.10f', $ether_balance);

                                                $fetchbalance = get_userbalance($userid, 'ETH');
                                                $finalbalance = $fetchbalance + $ether_balance;

                                                $adminethaddr = decrypt(get_config('eth_address'));
                                                $transid = 'TXD' . $userid . time();
//                                                $hash = eth_transfer_fun($ethaddress, $ether_balance, $adminethaddr, $userid);
                                                $hash = eth_transfer_fun_api($ethaddress, $ether_balance, $adminethaddr, $userid);

                                                if ($hash != '') {
                                                    if ($hash != 'error') {
                                                        //wallet record generation
                                                        $instr = new Wallettrans;
                                                        $instr->adtras_id = $transid;
                                                        $instr->currency = 'ETH';
                                                        $instr->address = $ethaddress;
                                                        $instr->hash = $hash;
                                                        $instr->amount = $ether_balance;
                                                        $instr->save();
                                                    }

                                                    //update userbalance
                                                    $upt = Balance::where('user_id', $userid)->first();
                                                    $upt->ETH = $finalbalance;
                                                    $upt->save();

                                                    //generate transcation record
                                                    $today = date('Y-m-d H:i:s');
                                                    $ip = \Request::ip();
                                                    $ins = new Transaction;
                                                    $ins->user_id = $userid;
                                                    $ins->payment_method = 'Cryptocurrency Account';
                                                    $ins->transaction_id = $transid;
                                                    $ins->currency_name = 'ETH';
                                                    $ins->type = 'Deposit';
                                                    $ins->transaction_type = '1';
                                                    $ins->amount = $ether_balance;
                                                    $ins->updated_at = $today;
                                                    $ins->crypto_address = $address;
                                                    $ins->transfer_amount = '0';
                                                    $ins->fee = '0';
                                                    $ins->tax = '0';
                                                    $ins->verifycode = '1';
                                                    $ins->order_id = '0';
                                                    $ins->status = 'Completed';
                                                    $ins->cointype = '2';
                                                    $ins->payment_status = 'Paid';
                                                    $ins->paid_amount = '0';
                                                    $ins->wallet_txid = $dep_id;
                                                    $ins->ip_address = $ip;
                                                    $ins->verify = '1';
                                                    $ins->blocknumber = $block_number;

                                                    //sent mail to enduser
                                                    if ($ins->save()) {
                                                        $this->deposit_mail($userid, $ether_balance, $transid, 'ETH');
                                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                                        $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'ETH', 'Amount' => $ether_balance, 'Status' => 'Completed', 'Time' => $today));

                                                    }
                                                    $jsonresult[$tr] = array('status' => 'Ok', 'message' => 'Transfer Completed', 'Block_number' => $block_number, 'TransactionId' => $txid, 'Value' => $value);

                                                } //if block of ether block transaction
                                                elseif ($hash == 'Error') {
                                                    $jsonresult[$tr] = array('Status' => 'Error');
                                                }

                                            }
                                        }
                                    }

                                }
                            }

                        }

                    }
                }

                return $jsonresult;

            } //verify balance if block
            else {
                $jsonresult[] = array('status' => 'Failed', 'message' => 'Insuffficient Balnce');
                return json_encode($jsonresult);
            } //verify blance else block
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    //xdc withdrawal console
    function xdc_withdrawal_check(Request $request)
    {
        try {
            $xdc_withdrawal_transactions = Transaction::where('status', 'Processing')->where('type', 'Withdraw')->
            where('currency_name', 'XDC')->get();
            $count = 0;
            foreach ($xdc_withdrawal_transactions as $xdc_transaction) {
                $tx_hash = $xdc_transaction->wallet_txid;
                $status = getting_xdc_status($tx_hash);
                if ($status == '0x1') {
                    $xdc_transaction->status = 'Completed';
                    $xdc_transaction->save();
                    $count++;
                }
                return ("Updated Count==" . $count);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //eth deposit console
    function eth_deposit_console_user(Request $request)
    {
        try {
            $hash = $request['hash'];
            $id = $request['id'];
            $amount = $request['amount'];
            $fetchbalance = get_userbalance($id, 'ETH');
            $finalbalance = $fetchbalance + $amount;
            $transid = 'TXD' . $id . time();
            $block_number = $request['block'];
            $dep_id = $request['txid'];
            $userslist = Users::orderBy('id', 'asc')->where('id', $id)->first();

            if ($hash != '' && $hash != 'Error') {
                //wallet record generation
                $instr = new Wallettrans;
                $instr->adtras_id = $transid;
                $instr->currency = 'ETH';
                $instr->address = $userslist->ETH_addr;
                $instr->hash = $hash;
                $instr->amount = $amount;
                $instr->save();

                //update userbalance
                $upt = Balance::where('user_id', $id)->first();
                $upt->ETH = $finalbalance;
                $upt->save();

                //generate transcation record
                $today = date('Y-m-d H:i:s');
                $ip = \Request::ip();
                $ins = new Transaction;
                $ins->user_id = $id;
                $ins->payment_method = 'Cryptocurrency Account';
                $ins->transaction_id = $transid;
                $ins->currency_name = 'ETH';
                $ins->type = 'Deposit';
                $ins->transaction_type = '1';
                $ins->amount = $amount;
                $ins->updated_at = $today;
                $ins->crypto_address = $userslist->ETH_addr;
                $ins->transfer_amount = '0';
                $ins->fee = '0';
                $ins->tax = '0';
                $ins->verifycode = '1';
                $ins->order_id = '0';
                $ins->status = 'Completed';
                $ins->cointype = '2';
                $ins->payment_status = 'Paid';
                $ins->paid_amount = '0';
                $ins->wallet_txid = $dep_id;
                $ins->ip_address = $ip;
                $ins->verify = '1';
                $ins->blocknumber = $block_number;

                //sent mail to enduser
                if ($ins->save()) {
                    $this->deposit_mail($id, $amount, $transid, 'ETH');
                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                    $pusher->trigger('private-transaction_' . $id, 'deposit-event', array('User_id' => $id, 'Transaction_id' => $transid, 'Currency' => 'ETH', 'Amount' => $amount, 'Status' => 'Completed', 'Time' => $today));

                }
                $jsonresult = array('status' => 'Ok', 'message' => 'Transfer Completed', 'Block_number' => $block_number, 'TransactionId' => $txid, 'Value' => $value);
                return json_encode($jsonresult);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function eth_checkdepositalready($user_id, $txd_id)
    {
        try {
            $check = Transaction::where('user_id', $user_id)->where('type', 'Deposit')->where('wallet_txid', $txd_id)->count();
            if ($check > 0) {
                return false;
            } else {
                return true;
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function deposit_mail($userid, $amount, $txid, $currency)
    {
        try {
            $to = get_usermail($userid);
            $username = get_user_details($userid, 'enjoyer_name');
            $subject = get_template('6', 'subject');
            $message = get_template('6', 'template');
            $mailarr = array(
                '###USERNAME###' => $username,
                '###CURRENCY###' => $currency,
                '###AMOUNT###' => $amount,
                '###TXD###' => $txid,
                '###STATUS###' => 'Completed',
                '###SITENAME###' => get_config('site_name'),
            );
            $message = strtr($message, $mailarr);
            $subject = strtr($subject, $mailarr);
            sendmail($to, $subject, ['content' => $message]);
            return true;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for latest mined node difference
    function last_mined_block_difference()
    {
        try {
            $get_currency_list = Node::all();
            if ($get_currency_list) {
                foreach ($get_currency_list as $currency) {
                    $name = $currency->currency_name;
                    $ip = ($currency->ip_address);
                    $port = ($currency->port_no);

                    $get_last_block = get_last_block($ip, $port);

                    $get_live_block = get_recent_block();

                    if ($get_live_block > $get_last_block) {
                        $diff = $get_live_block - $get_last_block;
                        if ($diff > 100) {
                            sendBlocklagMail($name, $diff);
                            $currency->save();

                        }
                    }

                }

            }

        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function deposit_admin_mail($messageid, $amount, $txid, $currency)
    {
        try {
            $to = 'support@alphaex.net';
            $subject = get_template($messageid, 'subject');
            $message = get_template($messageid, 'template');
            $mailarr = array(
                '###CURRENCY###' => $currency,
                '###AMOUNT###' => $amount,
                '###TXD###' => $txid,
                '###STATUS###' => 'Completed',
                '###SITENAME###' => get_config('site_name'),
            );
            $message = strtr($message, $mailarr);
            $subject = strtr($subject, $mailarr);
            sendmail($to, $subject, ['content' => $message]);
            return true;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function btc_deposit_process()
    {
        try {
            $date = date('Y-m-d');
            $time = date('h:i:s');
            $bitcoin = get_btc_transactionlist();
            $bitcoin_isvalid = $bitcoin->listtransactions();

            if ($bitcoin_isvalid) {
                for ($i = 0; $i < count($bitcoin_isvalid); $i++) {
                    $account = $bitcoin_isvalid[$i]['account'];
                    $address = $bitcoin_isvalid[$i]['address'];
                    $category = $bitcoin_isvalid[$i]['category'];
                    $btctxid = $bitcoin_isvalid[$i]['txid'];
                    if ($category == 'receive') {
                        $isvalid = $bitcoin->gettransaction($btctxid);
                        $det_category = $isvalid['details'][0]['category'];
                        if ($det_category == "receive") {
                            $btcaccount = $isvalid['details'][0]['account'];
                            $btcaddress = $isvalid['details'][0]['address'];
                            $bitcoin_balance = $isvalid['details'][0]['amount'];
                            $btcconfirmations = $isvalid['confirmations'];
                        } else {
                            $btcaccount = $isvalid['details'][1]['account'];
                            $btcaddress = $isvalid['details'][1]['address'];
                            $bitcoin_balance = $isvalid['details'][1]['amount'];
                            $btcconfirmations = $isvalid['confirmations'];
                        }
                        $amount = $bitcoin_balance;
                        if ($btcconfirmations >= 3) {
                            $userid = get_userid_btcaddr($btcaddress);
                            if (is_numeric($userid)) {
                                $checktrans = Transaction::where('type', 'Deposit')->where('wallet_txid', $btctxid)->first();
                                if (count($checktrans) == 0) {
                                    $fetchbalance = get_userbalance($userid, 'BTC');
                                    $finalbalance = $fetchbalance + $bitcoin_balance;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->BTC = $finalbalance;
                                    $upt->save();

                                    $transid = 'TXD' . $userid . time();
                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $userid;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'BTC';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $bitcoin_balance;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $btcaddress;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = '0';
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $btctxid;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = '';
                                    if ($ins->save()) {
                                        $this->deposit_mail($userid, $bitcoin_balance, $transid, 'BTC');
                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                        $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'BTC', 'Amount' => $bitcoin_balance, 'Status' => 'Completed', 'Time' => $today));

                                    }
                                }
                            }

                        }
                    }
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    //usdt deposit
    function usdt_deposit_process()
    {
        try {
            $date = date('Y-m-d');
            $time = date('h:i:s');
            $bitcoin_isvalid = get_usdt_transactionlist();

            if ($bitcoin_isvalid) {
                for ($i = 0; $i < count($bitcoin_isvalid); $i++) {
                    $propertyid = $bitcoin_isvalid[$i]['propertyid'];
                    $mine_flag = $bitcoin_isvalid[$i]['ismine'];

                    if ($propertyid == 31 && $mine_flag == true) {
                        $isvalid = $bitcoin_isvalid[$i]['txid'];
                        $checktrans = Transaction::where('type', 'Deposit')->where('wallet_txid', $isvalid)->first();
                        $reference_address = $bitcoin_isvalid[$i]['referenceaddress'];
                        $user_check = get_userid_usdtaddr($reference_address);
                        if ($user_check != 'no' && count($checktrans) == 0) {
                            $userid = $user_check;
                            $btcconfirmations = $bitcoin_isvalid[$i]['confirmations'];
                            $sendaddress = $bitcoin_isvalid[$i]['sendingaddress'];

                            if ($btcconfirmations >= 3) {
                                if (is_numeric($userid)) {
                                    $usdt_balance = $bitcoin_isvalid[$i]['amount'];
                                    $fee = $bitcoin_isvalid[$i]['fee'];
                                    $blocknumber = $bitcoin_isvalid[$i]['block'];
                                    $fetchbalance = get_userbalance($userid, 'USDT');
                                    $finalbalance = $fetchbalance + $usdt_balance;
//                                    $upt = Balance::where('user_id', $userid)->first();
//                                    $upt->BTC = $finalbalance;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->USDT = $finalbalance;
                                    $upt->save();

                                    $transid = 'TXD' . $userid . time();
                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $userid;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'USDT';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $usdt_balance;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $sendaddress;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = $fee;
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $isvalid;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = $blocknumber;
                                    if ($ins->save()) {
                                        $this->deposit_mail($userid, $usdt_balance, $transid, 'USDT');
                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                        $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'USDT', 'Amount' => $usdt_balance, 'Status' => 'Completed', 'Time' => $today));

                                    }

                                }

                            }
                        }

                    }
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return $e->getMessage() . '<br>' . $e->getLine() . '<br>' . $e->getFile();
        }
    }


    //bch deposit
    function bch_deposit_process()
    {
        try {
            $date = date('Y-m-d');
            $time = date('h:i:s');
            $bitcoin = get_bch_transactionlist();
            $bitcoin_isvalid = $bitcoin->listtransactions();

            if ($bitcoin_isvalid) {
                for ($i = 0; $i < count($bitcoin_isvalid); $i++) {
                    $account = $bitcoin_isvalid[$i]['account'];
                    $address = $bitcoin_isvalid[$i]['address'];
                    $category = $bitcoin_isvalid[$i]['category'];
                    $btctxid = $bitcoin_isvalid[$i]['txid'];
                    if ($category == 'receive') {
                        $isvalid = $bitcoin->gettransaction($btctxid);
                        $det_category = $isvalid['details'][0]['category'];
                        if ($det_category == "receive") {
                            $btcaccount = $isvalid['details'][0]['account'];
                            $btcaddress = $isvalid['details'][0]['address'];
                            $bitcoin_balance = $isvalid['details'][0]['amount'];
                            $btcconfirmations = $isvalid['confirmations'];
                        } else {
                            $btcaccount = $isvalid['details'][1]['account'];
                            $btcaddress = $isvalid['details'][1]['address'];
                            $bitcoin_balance = $isvalid['details'][1]['amount'];
                            $btcconfirmations = $isvalid['confirmations'];
                        }
                        $amount = $bitcoin_balance;
                        if ($btcconfirmations >= 3) {
                            $userid = get_userid_bchaddr($btcaddress);
                            if (is_numeric($userid)) {
                                $checktrans = Transaction::where('type', 'Deposit')->where('wallet_txid', $btctxid)->first();
                                if (count($checktrans) == 0) {
                                    $fetchbalance = get_userbalance($userid, 'BCHABC');
                                    $finalbalance = $fetchbalance + $bitcoin_balance;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->BCHABC = $finalbalance;
                                    $upt->save();

                                    $transid = 'TXD' . $userid . time();
                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $userid;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'BCHABC';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $bitcoin_balance;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $btcaddress;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = '0';
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $btctxid;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = '';
                                    if ($ins->save()) {
                                        $this->deposit_mail($userid, $bitcoin_balance, $transid, 'BCHABC');
                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                        $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'BCHABC', 'Amount' => $bitcoin_balance, 'Status' => 'Completed', 'Time' => $today));

                                    }
                                }
                            }

                        }
                    }
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    function xrp_deposit_process()
    {
        try {
            $ripple_address = decrypt(get_config('xrp_address'));
            $max_ledgerversion = Transaction::max('ledgerversion');
            if ($max_ledgerversion == "" || $max_ledgerversion == '0') {
                $max_ledgerversion = "3776014";
            }
            $output = array();
            $return_var = -1;
            $result = exec('cd /var/www/html/public/crypto; node ripple_transaction.js ' . trim($max_ledgerversion), $output, $return_var);
            $result = json_decode($result);
            if ($result) {
                foreach ($result as $res) {
                    $txid = $res->id;
                    $checktrans = Transaction::where('type', 'Deposit')->where('wallet_txid', $txid)->where('currency_name', 'XRP')->first();
                    if (count($checktrans) == 0) {
                        $address = $res->specification->destination->address;
                        $amount = $res->specification->destination->amount->value;
                        $ledgerversion = $res->outcome->ledgerVersion;
                        try {
                            $tag = $res->specification->destination->tag;
                        } catch (\Exception $exception) {
                            $tag = "";
                            $transid = 'TXD' . 00 . time();
                            $today = date('Y-m-d H:i:s');
                            $ip = \Request::ip();
                            $ins = new Transaction;
                            $ins->user_id = "";
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;
                            $ins->currency_name = 'XRP';
                            $ins->type = 'Deposit_without_tag';
                            $ins->transaction_type = '1';
                            $ins->amount = $amount;
                            $ins->updated_at = $today;
                            $ins->crypto_address = $address;
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Admin';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = $txid;
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '0';
                            $ins->xrp_desttag = $tag;
                            $ins->ledgerversion = $ledgerversion;
                            if ($ins->save()) {
                                $this->deposit_admin_mail('10', $amount, $txid, 'XRP');
                            }
                        }

                        if ($address == $ripple_address) {
                            if ($tag != "") {
                                $userdetails = get_dest_userid($tag);
                                if ($userdetails) {
                                    $userid = $userdetails;

                                    $fetchbalance = get_userbalance($userid, 'XRP');
                                    $finalbalance = $fetchbalance + $amount;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->XRP = $finalbalance;
                                    $upt->save();

                                    $transid = 'TXD' . $userid . time();
                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $userid;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'XRP';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $amount;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $address;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = '0';
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $txid;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = '0';
                                    $ins->xrp_desttag = $tag;
                                    $ins->ledgerversion = $ledgerversion;
                                    if ($ins->save()) {
                                        $this->deposit_mail($userid, $amount, $transid, 'XRP');
                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                        $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'XRP', 'Amount' => $amount, 'Status' => 'Completed', 'Time' => $today));

                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //opening balance
    function opening_balance()
    {
        try {
            $userslist = UserBalance::orderBy('user_id', 'asc')
                ->get();

            foreach ($userslist as $user) {
                $i = 0;
                $User_id = $user->user_id;
                $XDC = $user->XDC;
                $XDCE = $user->XDCE;
                $BTC = $user->BTC;
                $ETH = $user->ETH;
                $XRP = $user->XRP;
                $BCHABC = $user->BCHABC;
                $BCHSV = $user->BCHSV;
                $USDC = $user->USDC;
                $USDT = $user->USDT;

                $opening_bal = new OpeningBalance();
                $opening_bal->user_id = $User_id;
                $opening_bal->XDC = $XDC;
                $opening_bal->BTC = $BTC;
                $opening_bal->XDCE = $XDCE;
                $opening_bal->ETH = $ETH;
                $opening_bal->XRP = $XRP;
                $opening_bal->BCHABC = $BCHABC;
                $opening_bal->BCHSV = $BCHSV;
                $opening_bal->USDC = $USDC;
                $opening_bal->USDT = $USDT;
                $opening_bal->save();
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //closing Balance
    function closing_balance()
    {
        try {
            $userslist = UserBalance::orderBy('user_id', 'asc')
                ->get();

            foreach ($userslist as $user) {
                $i = 0;
                $User_id = $user->user_id;
                $XDC = $user->XDC;
                $XDCE = $user->XDCE;
                $BTC = $user->BTC;
                $ETH = $user->ETH;
                $XRP = $user->XRP;
                $BCHABC = $user->BCHABC;
                $BCHSV = $user->BCHSV;
                $USDC = $user->USDC;
                $USDT = $user->USDT;

                $closing_bal = new ClosingBalance();
                $closing_bal->user_id = $User_id;
                $closing_bal->XDC = $XDC;
                $closing_bal->BTC = $BTC;
                $closing_bal->XDCE = $XDCE;
                $closing_bal->ETH = $ETH;
                $closing_bal->XRP = $XRP;
                $closing_bal->BCHABC = $BCHABC;
                $closing_bal->BCHSV = $BCHSV;
                $closing_bal->USDC = $USDC;
                $closing_bal->USDT = $USDT;
                $closing_bal->save();
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    //xdc deposit
    function xdc_deposit_process()
    {
        try {
            $admin = SiteSettings::where('id', 1)->first();
            $last_block = $admin->xdc_block;
            $last_block = $last_block + 1;
            $latest_xdc_block_number = get_last_block('18.188.115.125', 22001);

            if ($latest_xdc_block_number > 0) {
                for ($i = $last_block; $i <= $latest_xdc_block_number; $i++) {


                    $block_number = $i;

                    $eurl = 'http://xinfin.info/api/blocknumber/' . $block_number . '_0_0';

                    $cObj = curl_init();
                    curl_setopt($cObj, CURLOPT_URL, $eurl);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                    $output = curl_exec($cObj);
                    $curlinfos = curl_getinfo($cObj);

                    $result = json_decode($output);

                    if ($result && $result->status == 'SUCCESS') {
                        $transactionList = $result->message;

                    } else {
                        $transactionList = '';
                    }

                    //iterating transaction lists
                    foreach ($transactionList as $transaction) {
                        $to_address = $transaction->args->_to;
                        $user = Users::where('XDC_addr', '=', $to_address)->first();
                        if ($user != null && $to_address != null) {
                            $dep_id = $transaction->transactionHash;
                            $ether_balance = $transaction->args->_value;
                            $dep_already = $this->eth_checkdepositalready($user->id, $dep_id);
                            if ($dep_already === TRUE && (float)$ether_balance > 0) {


                                $email = get_usermail($user->id);
                                //$pass = Session::get('xinfinpass');
                                $pass = get_user_details($user->id, 'xinpass');
                                login_xdc_fun($email, owndecrypt($pass));


                                $adminethaddr = decrypt(get_config('xdc_address'));
                                $res = transfer_xdctoken($to_address, $ether_balance, $adminethaddr, $user->id, owndecrypt($pass));
                                $userid = $user->id;
                                if ($res->status == 'SUCCESS') {
                                    $fetchbalance = get_userbalance($userid, 'XDC');
                                    $uptbal = $fetchbalance + $ether_balance;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->XDC = $uptbal;
                                    $upt->save();

                                    $transid = 'TXD' . $userid . time();
                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $userid;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'XDC';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $ether_balance;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $to_address;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = '0';
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $dep_id;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = $transaction->blockNumber;
                                    $ins->save();
                                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                    $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'XDC', 'Amount' => $ether_balance, 'Status' => 'Completed', 'Time' => $today));

                                }
                            }
                        }


                    }
                    if ($last_block < $i) {
                        $admin->xdc_block = $i;
                        $admin->save();
                    }

                }
            }

        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //et deposit
    function et_deposit_process()
    {
        try {
            $admin = SiteSettings::where('id', 1)->first();
            $last_block = $admin->et_block;
            $last_block = $last_block + 1;
            $latest_et_block_number = get_last_block_et('78.129.229.73', 8545);

            if ($latest_et_block_number > 0) {
                for ($i = $last_block; $i <= $latest_et_block_number; $i++) {


                    $block_number = $i;

                    $eurl = 'http://explorer.energyecochain.com/api/blocknumber/' . $block_number . '_0_0';

                    $cObj = curl_init();
                    curl_setopt($cObj, CURLOPT_URL, $eurl);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                    $output = curl_exec($cObj);
                    $curlinfos = curl_getinfo($cObj);

                    $result = json_decode($output);

                    if ($result && $result->status == 'SUCCESS') {
                        $transactionList = $result->message;

                    } else {
                        $transactionList = '';
                    }

                    //iterating transaction lists
                    foreach ($transactionList as $transaction) {
                        $to_address = $transaction->args->_to;
                        $user = Users::where('ET_addr', '=', $to_address)->first();
                        if ($user != null && $to_address != null) {
                            $dep_id = $transaction->transactionHash;
                            $ether_balance = $transaction->args->_value;
                            $dep_already = $this->eth_checkdepositalready($user->id, $dep_id);
                            if ($dep_already === TRUE && (float)$ether_balance > 0) {


                                $email = get_usermail($user->id);
                                //$pass = Session::get('xinfinpass');
                                $pass = get_user_details($user->id, 'xinpass');
                                login_et_fun($email, owndecrypt($pass));


                                $adminethaddr = decrypt(get_config('et_address'));
                                $res = transfer_ettoken($to_address, $ether_balance, $adminethaddr, $user->id, owndecrypt($pass));
                                $userid = $user->id;
                                if ($res->status == 'SUCCESS') {
                                    $fetchbalance = get_userbalance($userid, 'ET');
                                    $uptbal = $fetchbalance + $ether_balance;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->ET = $uptbal;
                                    $upt->save();

                                    $transid = 'TXD' . $userid . time();
                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $userid;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'ET';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $ether_balance;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $to_address;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = '0';
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $dep_id;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = $transaction->blockNumber;
                                    $ins->save();
                                }
                            }
                        }

                    }
                    if ($last_block < $i) {
                        $admin->xdc_block = $i;
                        $admin->save();
                    }

                }
            }

        } catch (\Exception $e) {

        }
    }

    //xdce deposit block wise
    function xdce_deposit_process1()
    {
        try {
            $admin = SiteSettings::where('id', 1)->first();
            $last_block = $admin->xdce_block;
            $last_block = $last_block + 1;
            $latest_xdc_block_number = get_last_block('78.129.229.18', 8545);

            if ($latest_xdc_block_number > 0) {
                for ($i = $last_block; $i <= $latest_xdc_block_number; $i++) {


                    $block_number = $i;

                    $eurl = 'http://xinfin.info/api/blocknumber/' . $block_number . '_0_0';

                    $cObj = curl_init();
                    curl_setopt($cObj, CURLOPT_URL, $eurl);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                    $output = curl_exec($cObj);
                    $curlinfos = curl_getinfo($cObj);

                    $result = json_decode($output);

                    if ($result && $result->status == 'SUCCESS') {
                        $transactionList = $result->message;

                    } else {
                        $transactionList = '';
                    }

                    //iterating transaction lists
                    foreach ($transactionList as $transaction) {
                        $to_address = $transaction->args->_to;
                        $user = Users::where('XDC_addr', '=', $to_address)->first();
                        if ($user != null && $to_address != null) {
                            $dep_id = $transaction->transactionHash;
                            $ether_balance = $transaction->args->_value;
                            $dep_already = $this->eth_checkdepositalready($user->id, $dep_id);
                            if ($dep_already === TRUE && (float)$ether_balance > 0) {


                                $email = get_usermail($user->id);
                                //$pass = Session::get('xinfinpass');
                                $pass = get_user_details($user->id, 'xinpass');
                                login_xdc_fun($email, owndecrypt($pass));


                                $adminethaddr = decrypt(get_config('xdc_address'));
                                $res = transfer_xdctoken($to_address, $ether_balance, $adminethaddr, $user->id, owndecrypt($pass));
                                $userid = $user->id;
                                if ($res->status == 'SUCCESS') {
                                    $fetchbalance = get_userbalance($userid, 'XDC');
                                    $uptbal = $fetchbalance + $ether_balance;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->XDC = $uptbal;
                                    $upt->save();

                                    $transid = 'TXD' . $userid . time();
                                    $today = date('Y-m-d H:i:s');
                                    $ip = \Request::ip();
                                    $ins = new Transaction;
                                    $ins->user_id = $userid;
                                    $ins->payment_method = 'Cryptocurrency Account';
                                    $ins->transaction_id = $transid;
                                    $ins->currency_name = 'XDC';
                                    $ins->type = 'Deposit';
                                    $ins->transaction_type = '1';
                                    $ins->amount = $ether_balance;
                                    $ins->updated_at = $today;
                                    $ins->crypto_address = $to_address;
                                    $ins->transfer_amount = '0';
                                    $ins->fee = '0';
                                    $ins->tax = '0';
                                    $ins->verifycode = '1';
                                    $ins->order_id = '0';
                                    $ins->status = 'Completed';
                                    $ins->cointype = '2';
                                    $ins->payment_status = 'Paid';
                                    $ins->paid_amount = '0';
                                    $ins->wallet_txid = $dep_id;
                                    $ins->ip_address = $ip;
                                    $ins->verify = '1';
                                    $ins->blocknumber = $transaction->blockNumber;
                                    $ins->save();
                                }
                            }
                        }


                    }
                    if ($last_block < $i) {
                        $admin->mined_block = $i;
                        $admin->save();
                    }
                }
            }

        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    //end class
    function xdce_deposit_process()
    {
        try {
            $userslist = Users::orderBy('id', 'asc')->get();

            foreach ($userslist as $user) {
                $id = $user->id;
                $xdceaddr = $user->XDCE_addr;
                if ($xdceaddr == '') {
                    $xdcebal = 0;
                } else {
                    $xdcebal = get_livexdce_bal($xdceaddr);
                }
                $xdce_contract_address = '0x41AB1b6fcbB2fA9DCEd81aCbdeC13Ea6315F2Bf2';

                if ($xdcebal > 1) {
                    $xdceTransactionList = get_xdce_transactions($xdceaddr, $xdce_contract_address);

                    try {
                        if ($xdceTransactionList->status == '1') {
                            $transaction = $xdceTransactionList->result;
                            for ($tr = 0; $tr < count($transaction); $tr++) {

                                $block_number = $transaction[$tr]->blockNumber;
                                $address = $transaction[$tr]->to;
                                $txid = $transaction[$tr]->hash;
                                $value = $transaction[$tr]->value;

                                $dep_id = $txid;
                                $eth_balance = (float)$value;
                                $ether_balance = $eth_balance / 1000000000000000000;

                                $dep_already = xdce_checkdepositalready($id, $dep_id);
                                if ($dep_already === TRUE && (float)$ether_balance > 1) {
                                    if ($xdceaddr == $address) {

                                        $ether_balance = sprintf('%.10f', $ether_balance);

                                        //deposit transaction
                                        $transid = 'TXD' . $id . time();
                                        $today = date('Y-m-d H:i:s');
                                        $ip = \Request::ip();
                                        $ins = new Transaction;
                                        $ins->user_id = $id;
                                        $ins->payment_method = 'Cryptocurrency Account';
                                        $ins->transaction_id = $transid;
                                        $ins->currency_name = 'XDCE';
                                        $ins->type = 'Deposit';
                                        $ins->transaction_type = '1';
                                        $ins->amount = $ether_balance;
                                        $ins->updated_at = $today;
                                        $ins->crypto_address = $xdceaddr;
                                        $ins->transfer_amount = '0';
                                        $ins->fee = '0';
                                        $ins->tax = '0';
                                        $ins->verifycode = '1';
                                        $ins->order_id = '0';
                                        $ins->status = 'Completed';
                                        $ins->cointype = '2';
                                        $ins->payment_status = 'Paid';
                                        $ins->paid_amount = '0';
                                        $ins->wallet_txid = $dep_id;
                                        $ins->ip_address = $ip;
                                        $ins->verify = '1';
                                        $ins->blocknumber = '';
                                        if ($ins->save()) {
                                            //update user
                                            $fetchbalance = get_userbalance($id, 'XDCE');
                                            $finalbalance = $fetchbalance + $ether_balance;
                                            $upt = Balance::where('user_id', $id)->first();
                                            $upt->XDCE = $finalbalance;
                                            $upt->save();
                                            deposit_mail($id, $ether_balance, $transid, 'XDCE');
                                            $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                            $pusher->trigger('private-transaction_' . $id, 'deposit-event', array('User_id' => $id, 'Transaction_id' => $transid, 'Currency' => 'XDCE', 'Amount' => $ether_balance, 'Status' => 'Completed', 'Time' => $today));

                                        }
                                    }
                                }
                            }

                        }
                    } catch (\Exception $e) {
                        continue;
                    }
                }

            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    //for each user xdce deposit
    function xdce_deposit_process_user($id)
    {
        try {
            $userslist[] = Users::orderBy('id', 'asc')->where('XDCE_addr', $id)->first();
            foreach ($userslist as $user) {
                $id = $user->id;
                $xdceaddr = $user->XDCE_addr;
                $xdcebal = get_livexdce_bal($xdceaddr);
                $xdce_contract_address = '0x41AB1b6fcbB2fA9DCEd81aCbdeC13Ea6315F2Bf2';

                if ($xdcebal > 1) {
                    $xdceTransactionList = get_xdce_transactions($xdceaddr, $xdce_contract_address);

                    try {
                        if ($xdceTransactionList->status == '1') {
                            $transaction = $xdceTransactionList->result;
                            for ($tr = 0; $tr < count($transaction); $tr++) {

                                $block_number = $transaction[$tr]->blockNumber;
                                $address = $transaction[$tr]->to;
                                $txid = $transaction[$tr]->hash;
                                $value = $transaction[$tr]->value;

                                $dep_id = $txid;
                                $eth_balance = (float)$value;
                                $ether_balance = $eth_balance / 1000000000000000000;

                                $dep_already = xdce_checkdepositalready($id, $dep_id);
                                if ($dep_already === TRUE && (float)$ether_balance > 1) {
                                    if ($xdceaddr == $address) {

                                        $ether_balance = sprintf('%.10f', $ether_balance);

                                        //deposit transaction
                                        $transid = 'TXD' . $id . time();
                                        $today = date('Y-m-d H:i:s');
                                        $ip = \Request::ip();
                                        $ins = new Transaction;
                                        $ins->user_id = $id;
                                        $ins->payment_method = 'Cryptocurrency Account';
                                        $ins->transaction_id = $transid;
                                        $ins->currency_name = 'XDCE';
                                        $ins->type = 'Deposit';
                                        $ins->transaction_type = '1';
                                        $ins->amount = $ether_balance;
                                        $ins->updated_at = $today;
                                        $ins->crypto_address = $xdceaddr;
                                        $ins->transfer_amount = '0';
                                        $ins->fee = '0';
                                        $ins->tax = '0';
                                        $ins->verifycode = '1';
                                        $ins->order_id = '0';
                                        $ins->status = 'Completed';
                                        $ins->cointype = '2';
                                        $ins->payment_status = 'Paid';
                                        $ins->paid_amount = '0';
                                        $ins->wallet_txid = $dep_id;
                                        $ins->ip_address = $ip;
                                        $ins->verify = '1';
                                        $ins->blocknumber = '';
                                        if ($ins->save()) {
                                            //update user
                                            $fetchbalance = get_userbalance($id, 'XDCE');
                                            $finalbalance = $fetchbalance + $ether_balance;
                                            $upt = Balance::where('user_id', $id)->first();
                                            $upt->XDCE = $finalbalance;
                                            $upt->save();
                                            deposit_mail($id, $ether_balance, $transid, 'XDCE');
                                            $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                            $pusher->trigger('private-transaction_' . $id, 'deposit-event', array('User_id' => $id, 'Transaction_id' => $transid, 'Currency' => 'XDCE', 'Amount' => $ether_balance, 'Status' => 'Completed', 'Time' => $today));

                                            echo "Deposit of " . $ether_balance . " XDCE completed for user id " . $id . ".";
                                        } else {
                                            echo "Database entry not successful";
                                        }
                                    } else {
                                        echo "Address not matching";
                                    }
                                } else {
                                    echo "Deposit already completed or Insufficient balance.";
                                }
                            }

                        } else {
                            echo $xdceTransactionList->status;
                        }
                    } catch (\Exception $e) {
                        echo $e->getMessage();
                        continue;
                    }
                } else {
                    echo "No pending XDCE deposit for user id " . $id . ".";
                }

//            if($)

            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for updating duplicate_record
    function duplicate_record()
    {
        try {
            $lObjTrades = DB::select("SELECT *,
COUNT(1) as CNT
FROM		xdc_trade_order
GROUP BY	updated_at,Amount,Price,Type
HAVING		COUNT(1) > 1  
ORDER BY xdc_trade_order.id ASC");

            foreach ($lObjTrades as $lObjTrade) {

                $lObjDuplicateTrade = Trade::where('id', $lObjTrade->id)->first();
                $lObjDuplicateTrade->duplicate = 1;
                $lObjDuplicateTrade->save();
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function btc_records()
    {
        try {
            $bitcoin = get_btc_transactionlist();
            $bitcoin_isvalid = $bitcoin->listtransactions();
            echo json_encode($bitcoin_isvalid);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //erc20 coin deposit script
    function getdata(Request $request)
    {
        try {
            $new = $request['result'];
            $currency = $request['currency'];
            $contractaddr = $request['contract'];
            $count = Users::where('USDC_addr', $new['to_address'])->first();
            if (count($count) > 0) {
                $user_id = $count->id;
                $adminethaddr = decrypt(get_config('eth_address'));
                $toaddress = decrypt(get_config('eth_address'));
//                $adminethaddr = "0x90d1028a543412169946Ee34d384A6d0A450ef82";
//                $toaddress = "0x6b524C043A04Cb52B3709C4C8a47F2b2e0DBe979";
//                $contractaddr = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";
                $dep_already = xdce_checkdepositalready($user_id, $new['tx_hash']);
                if ($dep_already === TRUE) {
                    $transid = 'TXD' . $user_id . time();
                    $today = date('Y-m-d H:i:s');
                    $ip = \Request::ip();
                    $ins = new Transaction;
                    $ins->user_id = $user_id;
                    $ins->payment_method = 'Cryptocurrency Account';
                    $ins->transaction_id = $transid;
                    $ins->currency_name = $currency;
                    $ins->type = 'Deposit';
                    $ins->transaction_type = '1';
                    $ins->amount = $new['without_decimal_value'];
                    $ins->updated_at = $today;
                    $ins->crypto_address = $new['to_address'];
                    $ins->transfer_amount = '0';
                    $ins->fee = '0';
                    $ins->tax = '0';
                    $ins->verifycode = '1';
                    $ins->order_id = '0';
                    $ins->status = 'Completed';
                    $ins->cointype = '2';
                    $ins->payment_status = 'Paid';
                    $ins->paid_amount = '0';
                    $ins->wallet_txid = $new['tx_hash'];
                    $ins->ip_address = $ip;
                    $ins->verify = '1';
                    $ins->blocknumber = '';
                    if ($ins->save()) {
                        //update user
                        $fetchbalance = get_userbalance($user_id, $currency);
                        $finalbalance = $fetchbalance + $new['without_decimal_value'];
                        $upt = Balance::where('user_id', $user_id)->first();
                        $upt->$currency = $finalbalance;
//                        $upt = UserBalancesNew::where('user_id',$user_id)->where('currency_name',$currency)->first();
//                        $upt->balance = $finalbalance;
                        $upt->save();
                        deposit_mail($user_id, $new['without_decimal_value'], $transid, $currency);
//                        $pusher = new Pusher('4162fbd4714c00179c5b', '6de63b4ce5c518b0f336', '562436', array('cluster' => 'ap1'));
//
//                        $pusher->trigger('private-transaction_' . $user_id, 'deposit-event', array('User_id' => $user_id, 'Transaction_id' => $transid, 'Currency' => 'XDCE', 'Amount' => $new['without_decimal_value'], 'Status' => 'Completed', 'Time' => $today));

                    }
                }

                $bal = getting_eth_balance_api($count->USDC_addr);
                $tokendecimal = $new['tokendecimal'];
                $token_bal = get_token_balance_api($count->USDC_addr, $contractaddr, $tokendecimal);

                if ($token_bal >= 10) {
                    $estimate_gas = get_estimate_gas_api($count->USDC_addr, $adminethaddr, $token_bal);
                    if ($bal < $estimate_gas) {
                        $estimate_gas = $estimate_gas - $bal;
                        $check = eth_transfer_erc20_admin_api($adminethaddr, $estimate_gas * 1.1, $count->USDC_addr);
                        $status = check_tx_status_eth_api($check);
                        while ($status != "0x1") {
                            $status = check_tx_status_eth_api($check);
                            sleep(10);
                        }
                        $bal1 = getting_eth_balance_api($count->USDC_addr);
                        while ($bal1 == $bal) {
                            $bal1 = getting_eth_balance_api($count->USDC__addr);
                            sleep(10);
                        }
                    }
                    $hash = transfer_erc20_api($count->USDC_addr, $token_bal, $toaddress, $contractaddr, $tokendecimal);
                    if ($hash) {
                        $block = SiteSettings::where('id', 1)->first();
                        $block->xdce_block = $new['block_number'];
                        $block->save();
                        $record = new Xdce_transfer;
                        $record->from_address = $new['to_address'];
                        $record->hash = $hash;
                        $record->in_hash = $new['tx_hash'];
                        $record->amount = $token_bal;
                        $status = check_tx_status_eth_api($hash);
                        while ($status != "0x1") {
                            $status = check_tx_status_eth_api($hash);
                            sleep(10);
                        }
                        $record->remaining_balance = getting_eth_balance_api($new['to_address']);
                        $record->user_id = $count->id;
                        $record->status = 'Completed';
                        $record->save();
                    }
                } else {
                    $record = new Xdce_transfer;
                    $record->from_address = $new['to_address'];
                    $record->in_hash = $new['tx_hash'];
                    $record->amount = $token_bal;
                    $record->user_id = $count->id;
                    $record->status = 'Incomplete';
                    $record->save();
                }

//                $dep_already = xdce_checkdepositalready($user_id, $new['tx_hash']);
//                if($dep_already === TRUE)
//                {
//                    $transid = 'TXD' . $user_id . time();
//                    $today = date('Y-m-d H:i:s');
//                    $ip = \Request::ip();
//                    $ins = new Transaction;
//                    $ins->user_id = $user_id;
//                    $ins->payment_method = 'Cryptocurrency Account';
//                    $ins->transaction_id = $transid;
//                    $ins->currency_name = 'XDCE';
//                    $ins->type = 'Deposit';
//                    $ins->transaction_type = '1';
//                    $ins->amount = $new['without_decimal_value'];
//                    $ins->updated_at = $today;
//                    $ins->crypto_address = $new['to_address'];
//                    $ins->transfer_amount = '0';
//                    $ins->fee = '0';
//                    $ins->tax = '0';
//                    $ins->verifycode = '1';
//                    $ins->order_id = '0';
//                    $ins->status = 'Completed';
//                    $ins->cointype = '2';
//                    $ins->payment_status = 'Paid';
//                    $ins->paid_amount = '0';
//                    $ins->wallet_txid = $new['tx_hash'];
//                    $ins->ip_address = $ip;
//                    $ins->verify = '1';
//                    $ins->blocknumber = '';
//                    if ($ins->save()) {
//                        //update user
//                        $fetchbalance = get_userbalance($user_id, 'XDCE');
//                        $finalbalance = $fetchbalance + $new['without_decimal_value'];
////                                            $upt = Balance::where('user_id', $id)->first();
////                                            $upt->XDCE = $finalbalance;
//                        $upt = UserBalancesNew::where('user_id',$user_id)->where('currency_name','XDCE')->first();
//                        $upt->balance = $finalbalance;
//                        $upt->save();
//                        deposit_mail($user_id, $new['without_decimal_value'], $transid, 'XDCE');
//                        $pusher = new Pusher('4162fbd4714c00179c5b', '6de63b4ce5c518b0f336', '562436', array('cluster' => 'ap1'));
//
//                        $pusher->trigger('private-transaction_' . $user_id, 'deposit-event', array('User_id' => $user_id, 'Transaction_id' => $transid, 'Currency' => 'XDCE', 'Amount' => $new['without_decimal_value'], 'Status' => 'Completed', 'Time' => $today));
//
//                    }
//                }
            } else {
                $block = SiteSettings::where('id', 1)->first();
                $block->xdce_block = $new['block_number'];
                $block->save();
            }
//            return json_encode($hash);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }


    //bitfinex order status
    function bitfinex_order_status(Request $request)
    {
        try {
            $open_orders = Trade::where(function ($query) {
                $query->where('status', '=', 'active')->orWhere('status', '=', 'partially');
            })->where('bitfinex_id', '>', 0)->get();
            //   \Log::info(['open_orders',$open_orders]);
            if ($open_orders != null) {
                foreach ($open_orders as $open_order) {
                    $bitfinex_id = (floatval($open_order->bitfinex_id));
                    $updated_qty = $open_order->updated_qty;
                    $updated_total = $open_order->updated_total;


                    if ($open_order->pair == 'ETH-USDT') {
                        $order_info = json_decode(bitfinex_order_status_check($bitfinex_id));
                        $price = $order_info->avg_execution_price;
                        $remaining_amount = $order_info->remaining_amount;
                        $type = $order_info->type;
                    } else if ($open_order->pair == 'BTC-USDC') {
                        $order_info = json_decode(liquid_order_status_check($bitfinex_id));
                        $price = $order_info->average_price;
                        $remaining_amount = $order_info->quantity - $order_info->filled_quantity;
                        $type = $order_info->side;

                    }

                    if ($remaining_amount == 0) {
                        $open_order->status = 'completed';
                        $open_order->updated_qty = $remaining_amount;
                        $difference = $updated_qty - $remaining_amount;
                        $get_txn_fee = get_trade_fee($type, $open_order->pair);
                        $trade_fee = $price * $difference * $get_txn_fee;
                        $trade_fee = number_format($trade_fee, 12, '.', '');


                        if (strtolower($type) == 'buy') {
                            $currency = $open_order->firstCurrency;
                            $user_balance = get_userbalance($open_order->user_id, $currency) + $difference;
                            $total = $price * $difference + $trade_fee;
                        } else {
                            $currency = $open_order->secondCurrency;
                            $total = $price * $difference - $trade_fee;
                            $user_balance = get_userbalance($open_order->user_id, $currency) + $total;
                        }
                        $user_bal = UserBalance::where('user_id', $open_order->user_id)->first();
                        $user_bal->$currency = $user_balance;
                        $user_bal->save();
                        $open_order->updated_total = $updated_total + $total;
                        \Log::info(['trade_fee', $trade_fee, 'total', $total]);
                        \Log::info(['open_orders', $open_order]);
                        $open_order->save();

                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                        //for alphaex pusher
                        $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $open_order->pair, 'user_id' => $open_order->user_id, 'trade_id' => 0, 'Type' => $open_order->type,
                            'Amount' => number_format($difference, 4, '.', ''),
                            'Price' => number_format($price, 8, '.', ''),
                            'Total' => number_format($total, 4, '.', ''),
                            'Fee' => number_format($trade_fee, '9', '.', '')));
                    }
                    return json_encode($order_info);
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function indodax_order_status(Request $request)
    {
        try {
            $open_orders = Trade::where(function ($query) {
                $query->where('status', '=', 'active')->orWhere('status', '=', 'partially');
            })->where('bitfinex_id', '>', 0)->get();
            // \Log::info(['open_orders',$open_orders]);
            if ($open_orders != null) {
                foreach ($open_orders as $open_order) {
                    $bitfinex_id = (floatval($open_order->bitfinex_id));
                    $updated_qty = $open_order->updated_qty;
                    $updated_total = $open_order->updated_total;
                    $idr_qty = $open_order->idr_qty;
                    $idr_price = $open_order->idr_price;
                    $indo_price = $open_order->indo_price;

                    // \Log::info(['open_orders',$open_order->pair]);

                    if ($open_order->pair == 'XDC-XRP') {
                        $order_info = json_decode(indodax_order_status_check($bitfinex_id, $open_order->pair));
                        \Log::info(["Order status", $order_info->return->order->price]);

//                        $price = $order_info->return->order->price;
                        $type = $order_info->return->order->type;
                        if ($type == 'buy') {
                            $type = 'Buy';
                        } elseif ($type == 'sell') {
                            $type = 'Sell';
                        }
                        $price = $open_order->price;

                        if ($type == "Buy") {
                            $remaining_amount = $order_info->return->order->remain_rp;
                            $remaining_amount = $remaining_amount / $idr_price;
//                            $conversion = $price * (1 / $indo_price);
//                            $price = $conversion;
                        } else if ($type == "Sell") {
                            $remaining_amount = $order_info->return->order->remain_xdce;
//                            $conversion = $price * (1 / $indo_price);
//                            $price = $conversion;
                        }
                        $remaining_amount = number_format($remaining_amount, '0', '.', '');
                        \Log::info(['indodax_details', $idr_price, $idr_qty, $indo_price, $remaining_amount, $price]);

                        if ($remaining_amount == 0 && $remaining_amount != NULL) {
                            $open_order->status = 'completed';
                            $open_order->updated_qty = $remaining_amount;
                            $difference = $updated_qty - $remaining_amount;
                            $get_txn_fee = get_trade_fee($type, $open_order->pair);
                            $trade_fee = $price * $difference * $get_txn_fee;
                            $trade_fee = number_format($trade_fee, 12, '.', '');

                            if ($type == 'Buy') {
                                $currency = $open_order->firstCurrency;
                                $user_balance = get_userbalance($open_order->user_id, $currency) + $difference;
                                $total = $price * $difference + $trade_fee;
                                $Reciever_type = 'Sell';
                            } else {
                                $currency = $open_order->secondCurrency;
                                $total = $price * $difference - $trade_fee;
                                $user_balance = get_userbalance($open_order->user_id, $currency) + $total;
                                $Reciever_type = 'Buy';
                            }

                            $reciever_user_id = 12971;
                            $reciever_txid = 'IND' . $bitfinex_id;

                            bitfinex_order_mapping($open_order->type, $Reciever_type, $updated_qty, $price, $reciever_user_id, $reciever_txid, $open_order->id, $open_order->pair_id, $open_order->pair, $open_order->bitfinex_id);

                            $user_bal = UserBalance::where('user_id', $open_order->user_id)->first();
                            $user_bal->$currency = $user_balance;
                            $user_bal->save();
                            $open_order->updated_total = $updated_total + $total;
                            \Log::info(['trade_fee', $trade_fee, 'total', $total]);
                            \Log::info(['open_orders', $open_order]);
                            $open_order->save();

                            $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                            //for alphaex pusher
                            $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $open_order->pair, 'user_id' => $open_order->user_id, 'trade_id' => 0, 'Type' => $open_order->type,
                                'Amount' => number_format($difference, 4, '.', ''),
                                'Price' => number_format($price, 8, '.', ''),
                                'Total' => number_format($total, 4, '.', ''),
                                'Fee' => number_format($trade_fee, '9', '.', '')));
                        }
                        return json_encode($order_info);
                    }
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    //update_price ticker of liquid
    function liquid_ticker()
    {
        try {
            $result = json_decode(get_liquid_ticker());
//              return $result;
            \Log::info(["error", $result]);

            $pair = PairStats::where('pair_id', '18')->first();
            $last_price = $pair->last;
            if ($last_price != $result->last_traded_price) {

            }
            $pair->volume = $result->volume_24h;
            $pair->low = $result->low_market_bid;
            $pair->high = $result->high_market_ask;
            $pair->last = $result->last_traded_price;

            if ($last_price > $result->last_traded_price) {
                $change = $last_price - $result->last_traded_price;
                $color = 'RED';

            } else {
                $change = $result->last_traded_price - $last_price;
                $color = 'GREEN';
            }
            $percent = ($change / $last_price) * 100;
            $pair->percent_change = $percent;
            $pair->colour = $color;
            $pair->change = $change;
            $pair->save();
            return json_encode($result);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function xdcxrp(Request $request)
    {
        try {
            if ($request->isMethod('get')) {
                // \Log::info(['request']);
                $url = "https://indodax.com/api/xdce_idr/trades";
                $data = '' ;
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(
                        
                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                    ));
                $response = curl_exec($curl);
                $err = curl_error($curl);
                $result = json_decode($response);
                curl_close($curl);

                $convert_price = json_decode(get_indodax_price('xrp_idr'));
                $convert = $convert_price->ticker->last;
                foreach($result as $res){
                    
                
                $pair = "XDC-XRP";
                $amount = $res->amount;
                $time = $res->date;
                $time = gmdate('Y-m-d H:i:s', $time);
                $type = $res->type;
                $tx_id =$res->tid;
                $price =$res->price;

                \Log::info(['request', $amount, $time, $type, $tx_id, $price]);

                    $trade_map = TradeMapping::where('unique_id', $tx_id)->first();
                    if ($trade_map == null) {
                        $trade_mapping = new TradeMapping();
                        $trade_mapping->unique_id = $tx_id;
                        $trade_mapping->pair = $pair;
                        $trade_mapping->buy_trade_order_id = 'ITX' . $tx_id;
                        $trade_mapping->sell_trade_order_id = 'ITX' . $tx_id;
                        $trade_mapping->type = $type;
                        $trade_mapping->triggered_price = $price*(1/$convert);
                        $trade_mapping->triggered_qty = $amount;
                        if ($type == 'Buy') {
                            $trade_mapping->total = ($price*(1/$convert))* $amount;
                        } else {
                            $trade_mapping->total = ($price*(1/$convert)) * $amount;
                        }
                        $trade_mapping->created_at = $time;
                        $trade_mapping->updated_at = $time;
                        $trade_mapping->save();
                        trade_chart($pair);
                        
                    }
                }
                // return $result;

            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return 0;
        }
    }


}


