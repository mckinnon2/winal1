<?php

/**
 * This controller includes trade mapping functions .
 * @developer Balakumaran
 * @ver 1.00 03/11/2017
 * @company Osiz technologies
 * @platform laravel 5.4
 **/

namespace App\Http\Controllers;

use App\model\Balance;
use App\model\Charts;
use App\model\Currencies;
use App\model\Favorite;
use App\model\Pair;
use App\model\PairStats;
use App\model\Profit;
use App\model\ReferralEarning;
use App\model\ReferralExtra;
use App\model\ExtraBonus;
use App\model\Trade;
use App\model\TradeMapping;
use App\model\Tradingfee;
use App\model\ICOTrade;
use App\model\Transaction;
use App\model\UserBalance;
use App\model\Users;
use Faker\Provider\DateTime;
use Psy\Exception\Exception;
use Pusher\Pusher;
use DB;
use Illuminate\Http\Request;
use Session;
use Carbon\Carbon;

class TradeController extends Controller
{
    //
    public function __construct()
    {
        //cons;
        $ip = \Request::ip();
        blockip_list($ip);
    }

    function index($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            $userid = Session::get('alphauserid');
            $pair = $pair ? $pair : 'XDC-ETH';

            $checkpair = Pair::where(['type' => 'trade', 'pair' => $pair])->count();
            if ($checkpair == 0) {
                abort(404);
            }
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];

            $min_amount = min_trade($first_currency);

            $first_cur_balance = 0;
            $second_cur_balance = 0;

            if ($second_currency == 'XDCE') {
                $buy_rate = 1;
                $sell_rate = 1;
                $trading_fee = 0;

                $active_orders = "";

            } else {

                $buy_rate = get_buy_market_rate($first_currency, $second_currency);
                $sell_rate = get_sell_market_rate($first_currency, $second_currency);
                $volume = get_trading_volume($first_currency, $second_currency, $userid);
                $trading_fee = get_trade_fee('Buy', $pair);

                $active_orders = "";
            }
            if($pair == 'XDC-XRP' || $pair == 'XDC-USDT'|| $pair == 'XDC-BTC') {
                $buy_order_list = "";
                $sell_order_list = "";
            } 
            else{
                $buy_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Sell'])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->groupBy('price')->orderBy('price', 'asc')->limit(5)->get();
                /*$buy_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Sell' AND (status='active' or status='partially') ORDER BY id DESC"));*/

                $sell_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Buy'])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->groupBy('price')->orderBy('price', 'desc')->limit(5)->get();

                /*$sell_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Buy' AND (status='active' or status='partially') ORDER BY id DESC"));*/

            }
            
            /*	$active_orders = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE user_id='$userid' and pair='$pair' AND (status='active' or status='partially')"));*/

            $stop_orders = Trade::where(['pair' => $pair, 'user_id' => $userid, 'status' => 'stop'])->orderBy('id', 'desc')->get();
            $trade_history = TradeMapping::where('pair', $pair)->orderBy('updated_at', 'desc')->limit(16)->get();

            $currencies = Currencies::all();


            $fav = "";
            $favarr = "";

            if (isset($favarr[0])) {
                $get_fav_pairs = Pair::whereIn('id', $favarr)->get();
                if ($get_fav_pairs) {
                    foreach ($get_fav_pairs as $get_fav_pair) {

                        $get_pair_stat = PairStats::where('pair_id', $get_fav_pair->id)->first();
                        $explode = explode('-', $get_fav_pair->pair);
                        $first_currency1 = $explode[0];
                        $currency = $explode[1];
                        $pair1 = $get_fav_pair->pair;
                        $id = $get_pair_stat->id;
                        $pair_id = $get_pair_stat->pair_id;
                        $vol = $get_pair_stat->volume;
                        $low = $get_pair_stat->low;
                        $high = $get_pair_stat->high;
                        $last = $get_pair_stat->last;
                        $percentage_change = $get_pair_stat->percent_change . '%';
                        $change = $get_pair_stat->change;
                        $color = strtolower($get_pair_stat->colour);

                        $array = array('id' => $id, 'pair_id' => $pair_id, 'first_currency' => $first_currency1, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                        $fav_pair[] = $array;

                    }
                }
            } else {
                $fav_pair = array();
            }

            if (isset($favarr[0])) {
                $get_remain_pairs = Pair::wherenotIn('id', $favarr)->get();
            } else {
                $get_remain_pairs = Pair::all();
            }
            if ($get_remain_pairs) {
                foreach ($get_remain_pairs as $get_remain_pair) {

                    $get_pair_stat = PairStats::where('pair_id', $get_remain_pair->id)->first();
                    $explode = explode('-', $get_remain_pair->pair);
                    $first_currency1 = $explode[0];
                    $currency = $explode[1];
                    $pair1 = $get_remain_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);

                    $array = array('id' => $id, 'pair_id' => $pair_id, 'first_currency' => $first_currency1, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $result_pair[] = $array;

                }
            }

            $get_all_pairs = Pair::all();
            if ($get_all_pairs) {
                foreach ($get_all_pairs as $get_all_pair) {
                    if ($get_all_pair->id != 7) {
                        $this->update_pairstats($get_all_pair->id);
                    } else {
                        $this->update_XDC_XDCE($get_all_pair->id);
                    }
                    $get_pair_stat = PairStats::where('pair_id', $get_all_pair->id)->first();
                    $explode = explode('-', $get_all_pair->pair);
                    $first_currency1 = $explode[0];
                    $currency = $explode[1];
                    $pair1 = $get_all_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);

                    $array = array('id' => $id, 'pair_id' => $pair_id, 'first_currency' => $first_currency1, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $all_pair[] = $array;

                }
            }

            $user_trade = "";

            $data = ['currency' => $currencies, 'pair' => $pair, 'first_currency' => $first_currency, 'second_currency' => $second_currency, 'first_cur_balance' => $first_cur_balance, 'second_cur_balance' => $second_cur_balance, 'buy_rate' => (float)$buy_rate, 'sell_rate' => (float)$sell_rate, 'trading_fee' => $trading_fee, 'buy_order_list' => $buy_order_list, 'sell_order_list' => $sell_order_list, 'active_orders' => $active_orders, 'stop_orders' => $stop_orders, 'trade_history' => $trade_history, 'fav_pairs' => $fav_pair, 'remain_pairs' => $result_pair, 'user_trade' => $user_trade, 'user_id' => $userid, 'fav' => $fav, 'pairs' => $all_pair, 'min_trade' => $min_amount];

            return view('front.trade', $data);

        } else {

            $userid = Session::get('alphauserid');

//            if (get_user_details($userid, 'document_status') != '1') {
//                // Session::flash('error','Please Complete your KYC process');
//                // return redirect('profile');
//            }
            $transid = 'TXD' . $userid . time();

            $xdcaddr = get_user_details($userid, 'XDC_addr');
            $xdceaddr = get_user_details($userid, 'XDCE_addr');
            $xdcbal = get_livexdc_bal($xdcaddr);
            //$xdcbal = 0;
            if ($xdcbal > 0) {
                $email = get_usermail($userid);
                //$pass = Session::get('xinfinpass');
                $pass = get_user_details($userid, 'xinpass');
                login_xdc_fun($email, owndecrypt($pass));
                $adminxdcaddr = decrypt(get_config('xdc_address'));
                $res = transfer_xdctoken($xdcaddr, $xdcbal, $adminxdcaddr, $userid, owndecrypt($pass));
                try {
                    if ($res->status == 'SUCCESS') {
                        $fetchbalance = get_userbalance($userid, 'XDC');
                        $uptbal = $fetchbalance + $xdcbal;
                        $upt = Balance::where('user_id', $userid)->first();
                        $upt->XDC = $uptbal;
                        $upt->save();

                        $transid = 'TXD' . $userid . time();
                        $today = date('Y-m-d H:i:s');
                        $ip = \Request::ip();
                        $ins = new Transaction;
                        $ins->user_id = $userid;
                        $ins->payment_method = 'Cryptocurrency Account';
                        $ins->transaction_id = $transid;
                        $ins->currency_name = 'XDC';
                        $ins->type = 'Deposit';
                        $ins->transaction_type = '1';
                        $ins->amount = $xdcbal;
                        $ins->updated_at = $today;
                        $ins->crypto_address = $xdcaddr;
                        $ins->transfer_amount = '0';
                        $ins->fee = '0';
                        $ins->tax = '0';
                        $ins->verifycode = '1';
                        $ins->order_id = '0';
                        $ins->status = 'Completed';
                        $ins->cointype = '2';
                        $ins->payment_status = 'Paid';
                        $ins->paid_amount = '0';
                        $ins->wallet_txid = '';
                        $ins->ip_address = $ip;
                        $ins->verify = '1';
                        $ins->blocknumber = '';
                        $ins->save();
                    }
                } catch (\Exception $e) {

                }

            }
            $pair = $pair ? $pair : 'XDC-ETH';

            $fav = Favorite::where('user_id', $userid)->get();
            if (count($fav) > 0) {
                foreach ($fav as $key => $favs)
                    $favarr[$key] = $favs->pair_id;
            }

            $checkpair = Pair::where(['type' => 'trade', 'pair' => $pair])->count();
            if ($checkpair == 0) {
                abort(404);
            }
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];

            $min_amount = min_trade($first_currency);

            $first_cur_balance = get_userbalance($userid, $first_currency);
            $second_cur_balance = get_userbalance($userid, $second_currency);

            if ($second_currency == 'XDCE') {
                $buy_rate = 1;
                $sell_rate = 1;
                $trading_fee = 0;

                $active_orders = "";

            } else {
                $buy_rate = get_buy_market_rate($first_currency, $second_currency);
                $sell_rate = get_sell_market_rate($first_currency, $second_currency);
                $volume = get_trading_volume($first_currency, $second_currency, $userid);
                $trading_fee = get_trade_fee('Buy', $pair);

                $active_orders = Trade::where(['user_id' => $userid, 'pair' => $pair])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->orderBy('id', 'desc')->limit(10)->get();
            }

            $buy_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Sell'])->where(function ($query) {
                $query->where('status', 'active')->Orwhere('status', 'partially');
            })->groupBy('price')->orderBy('price', 'asc')->limit(5)->get();

            /*$buy_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Sell' AND (status='active' or status='partially') ORDER BY id DESC"));*/

            $sell_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Buy'])->where(function ($query) {
                $query->where('status', 'active')->Orwhere('status', 'partially');
            })->groupBy('price')->orderBy('price', 'desc')->limit(5)->get();

            /*$sell_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Buy' AND (status='active' or status='partially') ORDER BY id DESC"));*/


            /*	$active_orders = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE user_id='$userid' and pair='$pair' AND (status='active' or status='partially')"));*/

            $stop_orders = Trade::where(['pair' => $pair, 'user_id' => $userid, 'status' => 'stop'])->orderBy('id', 'desc')->get();
            $trade_history = TradeMapping::where('pair', $pair)->orderBy('updated_at', 'desc')->limit(16)->get();

            $currencies = Currencies::all();

            if (isset($favarr[0])) {
                $get_fav_pairs = Pair::whereIn('id', $favarr)->get();
                if ($get_fav_pairs) {
                    foreach ($get_fav_pairs as $get_fav_pair) {

                        $get_pair_stat = PairStats::where('pair_id', $get_fav_pair->id)->first();
                        $explode = explode('-', $get_fav_pair->pair);
                        $first_currency1 = $explode[0];
                        $currency = $explode[1];
                        $pair1 = $get_fav_pair->pair;
                        $id = $get_pair_stat->id;
                        $pair_id = $get_pair_stat->pair_id;
                        $vol = $get_pair_stat->volume;
                        $low = $get_pair_stat->low;
                        $high = $get_pair_stat->high;
                        $last = $get_pair_stat->last;
                        $percentage_change = $get_pair_stat->percent_change . '%';
                        $change = $get_pair_stat->change;
                        $color = strtolower($get_pair_stat->colour);

                        $array = array('id' => $id, 'pair_id' => $pair_id, 'first_currency' => $first_currency1, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                        $fav_pair[] = $array;

                    }
                }
            } else {
                $fav_pair = array();
            }

            if (isset($favarr[0])) {
                $get_remain_pairs = Pair::wherenotIn('id', $favarr)->get();
            } else {
                $get_remain_pairs = Pair::all();
            }
            if (isset($get_remain_pairs[0])) {
                foreach ($get_remain_pairs as $get_remain_pair) {

                    $get_pair_stat = PairStats::where('pair_id', $get_remain_pair->id)->first();
                    $explode = explode('-', $get_remain_pair->pair);
                    $first_currency1 = $explode[0];
                    $currency = $explode[1];
                    $pair1 = $get_remain_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);

                    $array = array('id' => $id, 'pair_id' => $pair_id, 'first_currency' => $first_currency1, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $result_pair[] = $array;

                }
            } else {
                $result_pair = array();
            }

            $get_all_pairs = Pair::all();
            if ($get_all_pairs) {
                foreach ($get_all_pairs as $get_all_pair) {
                    if ($get_all_pair->id != 7) {
                        $this->update_pairstats($get_all_pair->id);
                    } else {
                        $this->update_XDC_XDCE($get_all_pair->id);
                    }
                    $get_pair_stat = PairStats::where('pair_id', $get_all_pair->id)->first();
                    $explode = explode('-', $get_all_pair->pair);
                    $first_currency1 = $explode[0];
                    $currency = $explode[1];
                    $pair1 = $get_all_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);


                    $array = array('id' => $id, 'pair_id' => $pair_id, 'first_currency' => $first_currency1, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $all_pair[] = $array;

                }
            }

            $user_trade = Trade::where(['pair' => $pair, 'user_id' => $userid])->whereIn('status', ['completed', 'partially'])->orderBy('updated_at', 'desc')->limit(10)->get();

            $data = ['currency' => $currencies, 'pair' => $pair, 'first_currency' => $first_currency, 'second_currency' => $second_currency, 'first_cur_balance' => $first_cur_balance, 'second_cur_balance' => $second_cur_balance, 'buy_rate' => (float)$buy_rate, 'sell_rate' => (float)$sell_rate, 'trading_fee' => $trading_fee, 'buy_order_list' => $buy_order_list, 'sell_order_list' => $sell_order_list, 'active_orders' => $active_orders, 'stop_orders' => $stop_orders, 'trade_history' => $trade_history, 'fav_pairs' => $fav_pair, 'remain_pairs' => $result_pair, 'user_trade' => $user_trade, 'user_id' => $userid, 'fav' => $fav, 'pairs' => $all_pair, 'min_trade' => $min_amount];


            return view('front.trade', $data);

//            return view('front.construction');
        }
    }

//    function get_trading_fee($vol, $second_currency)
//    {
//        $result = Tradingfee::where('currency', $second_currency)->first();
//        if ($result) {
//            if ($vol < 20000) {
//                return $result->lessthan_20000;
//            } elseif ($vol < 100000) {
//                return $result->lessthan_100000;
//            } elseif ($vol < 200000) {
//                return $result->lessthan_200000;
//            } elseif ($vol < 400000) {
//                return $result->lessthan_400000;
//            } elseif ($vol < 600000) {
//                return $result->lessthan_600000;
//            } elseif ($vol < 1000000) {
//                return $result->lessthan_1000000;
//            } elseif ($vol < 2000000) {
//                return $result->lessthan_2000000;
//            } elseif ($vol < 4000000) {
//                return $result->lessthan_4000000;
//            } elseif ($vol < 20000000) {
//                return $result->lessthan_20000000;
//            } else {
//                return $result->greaterthan_20000000;
//            }
//
//        }
//    }

    function update_pairstats($pairid)
    {
        try {
            $date = date('Y-m-d H:i:s', strtotime("-1 days"));
            $get_pair = Pair::where('id', $pairid)->first();
            $get_pair_name = $get_pair->pair;

            $pair_stats = PairStats::where('pair_id', $pairid)->first();

            $volume = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->sum('triggered_qty');
            $quotevolume = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->sum('total');
            $low = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->min('triggered_price');

            if ($low == null || $low == "") {
                $low = 0;
            }

            $high = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->max('triggered_price');

            if ($high == null || $high == "") {
                $high = 0;
            }

            $last_executed = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->first();
            if ($last_executed != null || $last_executed != "") {
                $triggered_price = $last_executed->triggered_price;
            } else {
                $triggered_price = 0;
            }

            $first_executed = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'asc')->first();
            if ($first_executed != null || $first_executed != "") {
                $first_executed_price = $first_executed->triggered_price;
            } else {
                $first_executed_price = 0;
            }

            $pair_stats->volume = $volume;
            $pair_stats->quotevolume = $quotevolume;
            $pair_stats->low = $low;
            $pair_stats->high = $high;
            if ($triggered_price != 0) {
                $pair_stats->last = $triggered_price;
            }

            if ($first_executed_price != 0) {
                $percent_change = (($triggered_price - $first_executed_price) / $first_executed_price) * 100;
            } else {
                $percent_change = 0;
            }

            if ($percent_change < 0) {
                $color = 'red';
            } else {
                $color = 'green';
            }

            if ($first_executed_price >= $triggered_price) {
                $change = $first_executed_price - $triggered_price;
                $change = number_format($change, 8, '.', '');
            } else {
                $change = $triggered_price - $first_executed_price;
                $change = number_format($change, 8, '.', '');
            }

            $pair_stats->percent_change = $percent_change;
            $pair_stats->colour = $color;
            $pair_stats->change = $change;
            $pair_stats->save();
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function update_XDC_XDCE($pairid)
    {
        try {
            $date = date('Y-m-d H:i:s', strtotime("-1 days"));
            $get_pair = Pair::where('id', $pairid)->first();
            $get_pair_name = $get_pair->pair;

            $pair_stats = PairStats::where('pair_id', $pairid)->first();

            $volume = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->sum('original_qty');
            $quotevolume = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->sum('total');
            $low = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->min('price');

            if ($low == null || $low == "") {
                $low = 0;
            }

            $high = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->max('price');

            if ($high == null || $high == "") {
                $high = 0;
            }

            $last_executed = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->first();
            if ($last_executed != null || $last_executed != "") {
                $triggered_price = $last_executed->price;
            } else {
                $triggered_price = 0;
            }

            $first_executed = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'asc')->first();
            if ($first_executed != null || $first_executed != "") {
                $first_executed_price = $first_executed->price;
            } else {
                $first_executed_price = 0;
            }

            $pair_stats->volume = $volume;
            $pair_stats->quotevolume = $quotevolume;
            $pair_stats->low = $low;
            $pair_stats->high = $high;
            if ($triggered_price != 0) {
                $pair_stats->last = $triggered_price;
            }

            if ($first_executed_price != 0) {
                $percent_change = (($triggered_price - $first_executed_price) / $first_executed_price) * 100;
            } else {
                $percent_change = 0;
            }

            if ($percent_change < 0) {
                $color = 'red';
            } else {
                $color = 'green';
            }

            if ($first_executed_price >= $triggered_price) {
                $change = $first_executed_price - $triggered_price;
                $change = number_format($change, 8, '.', '');
            } else {
                $change = $triggered_price - $first_executed_price;
                $change = number_format($change, 8, '.', '');
            }

            $pair_stats->percent_change = $percent_change;
            $pair_stats->colour = $color;
            $pair_stats->change = $change;
            $pair_stats->save();
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    //limit order
    function trade_orders(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                if ($request->isMethod('post')) {
                    $type = $request['type'];
                    if ($type == 'Buy')
                        $pair = $request['pair-buy'];
                    else
                        $pair = $request['pair-sell'];

                    if ($pair == 'BTC-USDT' || $pair == 'ETH-USDT' || $pair == 'BTC-USDC') {
                        $user_id = Session::get('alphauserid');
                        if ($pair == 'BTC-USDT') {
                            $symbol = 'BTCUST';
                        }

                        if ($pair == 'ETH-USDT') {
                            $symbol = 'ETHUST';
                        }
                        if ($type == 'Buy') {
                            $amount = $request['buy_amount'];
                            $price = $request['buy_price'];
                            $extype = 'buy';
                            $nonce = $request['buy_nonce'];
                        } else {
                            $amount = $request['sell_amount'];
                            $price = $request['sell_price'];
                            $extype = 'sell';
                            $nonce = $request['sell_nonce'];
                        }


                        if (!($price > 0)) {
                            $data['status'] = '4';
                            $data['message'] = 'Price should be greater than 0.';
                            return json_encode($data);
                        } else {

                            $cur = explode("-", $pair);
                            $first_currency = $cur[0];
                            $second_currency = $cur[1];

                            $min_amount = min_trade($first_currency);
                            $max_amount = 10;

                            if ($amount < $min_amount) {
                                $data['status'] = 0;
                                $data['message'] = 'Minimum ' . $min_amount . ' ' . $first_currency . '.';
                                return json_encode($data);
                            }

                            if ($amount > $max_amount) {
                                $data['status'] = 0;
                                $data['message'] = 'Maximum ' . $max_amount . ' ' . $first_currency . '.';
                                return json_encode($data);
                            }

                            $first_cur_balance = get_userbalance($user_id, $first_currency);
                            $second_cur_balance = get_userbalance($user_id, $second_currency);

                            $get_pair_id = Pair::where('pair', $pair)->first();
                            $amount = number_format($amount, 8, '.', '');
                            $price = number_format($price, 8, '.', '');

                            $total = $amount * $price;

                            if ($type == 'Buy') {
                                $get_txn_fee = get_trade_fee($type, $pair);
                                if ($user_id == '29' || $user_id == '30') {
                                    $get_txn_fee = 0;
                                }
                                $trade_fee = $total * $get_txn_fee;
                                $trade_fee = number_format($trade_fee, 12, '.', '');
                                $total = $total + $trade_fee;

                                $deduct_bal = $total;
                                $available_bal = $second_cur_balance;
                                $currency = $second_currency;
                                $update_bal = $amount + $first_cur_balance;
                                $update_currency = $first_currency;
                                $update_balance = $second_cur_balance - $deduct_bal;
                                $txd_id = 'BTX' . time();
                            } else {
                                $get_txn_fee = get_trade_fee($type, $pair);
                                if ($user_id == '29' || $user_id == '30') {
                                    $get_txn_fee = 0;
                                }
                                $trade_fee = $total * $get_txn_fee;
                                $trade_fee = number_format($trade_fee, 12, '.', '');
                                $total = $total - $trade_fee;
                                $deduct_bal = $amount;
                                $available_bal = $first_cur_balance;
                                $currency = $first_currency;
                                $update_bal = $total + $second_cur_balance;
                                $update_currency = $second_currency;
                                $update_balance = $first_cur_balance - $amount;
                                $txd_id = 'STX' . time();
                            }
                            if ($pair == 'BTC-USDC') {
                                if ($deduct_bal <= $available_bal) {
                                    $result = json_decode(liquid_order_place($amount, $price, $type));
                                    \Log::info(["liquid UserCntrlr data", $result]);
                                    try {
                                        if ($result->id != 0) {
                                            if ($result->status == 'live') {
                                                $data['status'] = '2';
                                                $data['message'] = 'Your Order placed';
                                                $status = 'active';
                                                $updated_total = 0;
                                                $qty = $amount;
                                                $price = $price;
                                                $total = $total;
                                            } else {
                                                $order_result = json_decode(liquid_order_status_check($result->id));
                                                $data['status'] = '2';
                                                $data['message'] = 'Your Order Completed';
                                                $status = 'Completed';
                                                $price = $order_result->average_price;
                                                $qnty = $order_result->filled_quantity;
                                                if ($type == 'Sell') {
                                                    $total = $price * $qnty;
                                                    $trade_fee = $total * $get_txn_fee;
                                                    $trade_fee = number_format($trade_fee, 12, '.', '');
                                                    $total = $total - $trade_fee;
                                                    $deduct_bal = $amount;
                                                    $available_bal = $first_cur_balance;
                                                    $currency = $first_currency;
                                                    $update_bal = $total + $second_cur_balance;
                                                    $update_currency = $second_currency;
                                                    $update_balance = $first_cur_balance - $amount;
                                                } else {
                                                    $total = $price * qnty;
                                                    $trade_fee = $total * $get_txn_fee;
                                                    $trade_fee = number_format($trade_fee, 12, '.', '');
                                                    $total = $total + $trade_fee;

                                                    $deduct_bal = $total;
                                                    $available_bal = $second_cur_balance;
                                                    $currency = $second_currency;
                                                    $update_bal = $amount + $first_cur_balance;
                                                    $update_currency = $first_currency;
                                                    $update_balance = $second_cur_balance - $deduct_bal;
                                                }
                                                $updated_total = $total;
                                                $qty = 0;
                                            }
                                            $trade = new Trade();
                                            $trade->unique_id = $txd_id;
                                            $trade->trade_id = $txd_id;
                                            $trade->trade_type = 'limit_order';
                                            $trade->user_id = $user_id;
                                            $trade->pair_id = $get_pair_id->id;
                                            $trade->pair = $pair;
                                            $trade->firstCurrency = $first_currency;
                                            $trade->secondCurrency = $second_currency;
                                            $trade->price = $price;
                                            $trade->total = $total;
                                            $trade->updated_total = $updated_total;
                                            $trade->type = $type;
                                            $trade->process = '0';
                                            $trade->bitfinex_id = $result->id;
                                            $trade->fee = $trade_fee;
                                            $trade->original_qty = $amount;
                                            $trade->updated_qty = $qty;
                                            $trade->status = $status;

                                            if ($trade->save()) {
                                                if ($status == 'active') {
                                                    $user_bal = UserBalance::where('user_id', $user_id)->first();
                                                    $user_bal->$currency = $update_balance;
                                                    $user_bal->save();
                                                } else {
                                                    $user_bal = UserBalance::where('user_id', $user_id)->first();
                                                    $user_bal->$currency = $update_balance;
                                                    $user_bal->$update_currency = $update_bal;
                                                    $user_bal->save();
                                                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                                                    //for alphaex pusher
                                                    $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $pair, 'user_id' => $user_id, 'trade_id' => 0, 'Type' => $type,
                                                        'Amount' => number_format($amount, 4, '.', ''),
                                                        'Price' => number_format($price, 8, '.', ''),
                                                        'Total' => number_format($total, 4, '.', ''),
                                                        'Fee' => number_format($trade_fee, '9', '.', '')));
                                                }
                                                last_activity(get_usermail($user_id), 'Limit Buy order', $user_id);
                                                $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                                $pusher->trigger('demo1', 'demo-event', array('User_id' => $user_id, 'Pair' => $pair, 'Total' => $total, 'Amount' => number_format($amount, 4, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type));
                                            }
                                        }
                                    } catch (\Exception $e) {
                                        $data['status'] = '0';
                                        $data['message'] = 'Oops something went wrong';
                                    }
                                } else {
                                    $data['status'] = '0';
                                    $data['message'] = 'Insufficient Balance of ' . $currency;
                                }
                            } else if ($pair == 'BTC-USDT' || $pair == 'ETH-USDT') {
                                $body = json_encode(array("request" => '/v1/order/new', "nonce" => $nonce, "symbol" => $symbol, "amount" => $amount, "price" => $price, "exchange" => 'bitfinex', "side" => $extype, "type" => "exchange limit"));
                                \Log::info(["bitfinex body", $body]);
                                $data['apikey'] = 'hWduQ4g8ZOpIHaskwzYEZnmZVmjNO6zw39u20kVIKF4'; //live

                                $data['payload'] = base64_encode($body);
                                $data['signature'] = hash_hmac('sha384', $data['payload'], 'zrZiskcp2xzvOuYIdopRAiYQqWlW4ZgU7sBEY7pLVsd');//live

                                //new order in bitfinex

                                $ch = curl_init();
                                curl_setopt($ch, CURLOPT_URL, "https://api.bitfinex.com/v1/order/new");
                                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                    'X-BFX-APIKEY:' . $data['apikey'],
                                    'X-BFX-PAYLOAD:' . $data['payload'],
                                    'X-BFX-SIGNATURE:' . $data['signature'],
                                ));
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                                curl_setopt($ch, CURLOPT_HEADER, FALSE);
                                curl_setopt($ch, CURLOPT_POST, TRUE);
                                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
                                $result = curl_exec($ch);
                                \Log::info(["bitfinex response", $result]);
                                $datacurl = json_decode($result);
                                if (curl_errno($ch)) {
                                    $isError = true;
                                    $errorMessage = curl_error($ch);
                                    return response()->json(['status' => 0, 'message' => 'Error in place order => ' . $errorMessage, 'data' => []]);
                                }
                                curl_close($ch);
                                try {
                                    if (strpos($datacurl->message, 'Invalid') !== false) {
                                        $data['status'] = '4';
                                        $data['message'] = 'Insufficient Balance';
                                    }
                                } catch (\Exception $exception) {
                                    if ($datacurl->is_live == true) {
                                        \Log::info(["bitfinex order placed", $datacurl->order_id]);
                                        $data['status'] = '2';
                                        $data['message'] = 'Your Order placed';
                                        if ($deduct_bal <= $available_bal) {
                                            $trade = new Trade();
                                            $trade->unique_id = $txd_id;
                                            $trade->trade_id = $txd_id;
                                            $trade->trade_type = 'limit_order';
                                            $trade->user_id = $user_id;
                                            $trade->pair_id = $get_pair_id->id;
                                            $trade->pair = $pair;
                                            $trade->firstCurrency = $first_currency;
                                            $trade->secondCurrency = $second_currency;
                                            $trade->price = $price;
                                            $trade->total = $total;
                                            $trade->type = $type;
                                            $trade->process = '0';
                                            $trade->bitfinex_id = $datacurl->order_id;
                                            $trade->fee = $trade_fee;
                                            $trade->original_qty = $amount;
                                            $trade->updated_qty = $amount;
                                            $trade->status = 'active';

                                            if ($trade->save()) {
                                                $user_bal = UserBalance::where('user_id', $user_id)->first();
                                                $user_bal->$currency = $update_balance;
                                                $user_bal->save();
                                                last_activity(get_usermail($user_id), 'Limit Buy order', $user_id);

                                            }
                                        } else {
                                            $data['status'] = '0';
                                            $data['message'] = 'Insufficient Balance of ' . $currency;
                                        }
                                    } else {
                                        $data['status'] = '2';
                                        $data['message'] = 'Your Order completed';
                                    }
                                }
                                $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                                $pusher->trigger('demo1', 'demo-event', array('User_id' => $user_id, 'Pair' => $pair, 'Total' => $total, 'Amount' => number_format($amount, 4, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type));
                            }
                            return json_encode($data);
                        }
                    }
                    if ($pair != 'XDC-BCH') {
                        $user_id = Session::get('alphauserid');
                        $trade_type = $request['tradetype'];
                        if ($type == 'Buy') {
                            $amount = $request['buy_amount'];
                            $price = $request['buy_price'];
                            $matching_type = 'Sell';
                            $matching_trade = Trade::where('user_id', $user_id)
                                ->where('type', $matching_type)->where('price', '<=', $price)
                                ->where('pair', $pair)
                                ->where(function ($query) {
                                    $query->where('status', 'active')->orWhere('status', 'partially');
                                })->count();
                            $message = 'You have already a Sell order less than or equal to buy price';
                        } else {
                            $amount = $request['sell_amount'];
                            $price = $request['sell_price'];
                            $matching_type = 'Buy';
                            $matching_trade = Trade::where('user_id', $user_id)
                                ->where('type', $matching_type)->where('price', '>=', $price)
                                ->where('pair', $pair)
                                ->where(function ($query) {
                                    $query->where('status', '=', 'active')->orWhere('status', '=', 'partially');
                                })->count();
                            $message = 'You have already a Buy order greater than or equal to sell price';
                        }

                        if (!($price > 0)) {
                            $data['status'] = '4';
                            $data['message'] = 'Price should be greater than 0.';
                            return json_encode($data);
                        }

                        if ($matching_trade > 0) {
                            $data['status'] = '4';
                            $data['message'] = $message;
                            return json_encode($data);
                        } else {

                            $cur = explode("-", $pair);
                            $first_currency = $cur[0];
                            $second_currency = $cur[1];

                            $min_amount = min_trade($first_currency);

                            if ($amount < $min_amount) {
                                $data['status'] = 0;
                                $data['message'] = 'Minimum ' . $min_amount . ' ' . $first_currency . '.';
                                return json_encode($data);
                            }

                            $first_cur_balance = get_userbalance($user_id, $first_currency);
                            $second_cur_balance = get_userbalance($user_id, $second_currency);

                            $get_pair_id = Pair::where('pair', $pair)->first();
                            $amount = number_format($amount, 8, '.', '');
                            $price = number_format($price, 8, '.', '');

                            $total = $amount * $price;

                            if ($type == 'Buy') {
                                $get_txn_fee = get_trade_fee($type, $pair);
                                if ($user_id == '29' || $user_id == '30') {
                                    $get_txn_fee = 0;
                                }
                                $trade_fee = $total * $get_txn_fee;
                                $trade_fee = number_format($trade_fee, 12, '.', '');
                                $total = $total + $trade_fee;
                                $deduct_bal = $total;
                                $available_bal = $second_cur_balance;
                                $currency = $second_currency;
                                $update_balance = $second_cur_balance - $deduct_bal;
                                $txd_id = 'BTX' . time();
                            } else {
                                $get_txn_fee = get_trade_fee($type, $pair);
                                if ($user_id == '29' || $user_id == '30') {
                                    $get_txn_fee = 0;
                                }
                                $trade_fee = $total * $get_txn_fee;
                                $trade_fee = number_format($trade_fee, 12, '.', '');
                                $total = $total - $trade_fee;
                                $deduct_bal = $amount;
                                $available_bal = $first_cur_balance;
                                $currency = $first_currency;
                                $update_balance = $first_cur_balance - $amount;
                                $txd_id = 'STX' . time();
                            }

                            if ($deduct_bal <= $available_bal) {

                                if ($pair == 'XDC-XRP') {

                                    $convert_price = json_decode(get_indodax_price('xrp_idr'));
                                    $convert = $convert_price->ticker->last;
                                    $get_price = number_format(floatval($price * $convert), '0', '.', '');
                                    $idr = floatval($get_price * $amount);
                                    if ($idr >= 50000) {
                                        $indodax_data['nonce'] = (string)round(microtime(true) * 1000);
                                        $indodax_data['pair'] = 'xdce_idr';
                                        $indodax_data['method'] = 'trade';
                                        $indodax_data['type'] = strtolower($type);
                                        $indodax_data['xdce'] = floatval($amount);
                                        $indodax_data['idr'] = $idr;
                                        $indodax_data['price'] = $get_price;

                                        \Log::info(['Indodax data', $indodax_data]);

                                        $data['apikey'] = 'IXMEHSLV-EXI19ALG-JBDAHWEO-T8KVL126-ZZOZZHQQ';//live
                                        $data['secret'] = '64300bcc4022ad5b07fcc49592a66287e7a729ff056c00a2ce3137297dca1a44b6a3830071f7d6c3';//live
                                        // generate the POST data string
                                        $data['payload'] = http_build_query($indodax_data, '', '&');
                                        $data['signature'] = hash_hmac('sha512', $data['payload'], $data['secret']);//live
                                        //new order in bitfinex
                                        $ch = curl_init();
                                        curl_setopt($ch, CURLOPT_URL, "https://indodax.com/tapi/");
                                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                            'Sign:' . $data['signature'],
                                            'Key:' . $data['apikey'],
                                        ));
                                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                                        curl_setopt($ch, CURLOPT_HEADER, FALSE);
                                        curl_setopt($ch, CURLOPT_POST, TRUE);
                                        curl_setopt($ch, CURLOPT_POSTFIELDS, $data['payload']);
                                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
                                        $result = curl_exec($ch);
                                        $datacurl = json_decode($result, true);
                                        \Log::info(["datacurl", $datacurl]);
                                        if (curl_errno($ch)) {
                                            $errorMessage = curl_error($ch);
                                            return response()->json(['status' => 0, 'message' => 'Error in place order => ' . $errorMessage, 'data' => []]);
                                        }
                                        curl_close($ch);
                                        try {
                                            \Log::info(["datacurl", $datacurl['success']]);
                                            if ($datacurl['success'] == 1) {
                                                \Log::info(["Indodax order placed", $datacurl['return']['order_id']]);
                                                $data['status'] = '1';
                                                $data['message'] = 'Your Order placed';
                                                $trade = new Trade();
                                                $trade->unique_id = $txd_id;
                                                $trade->trade_id = $txd_id;
                                                $trade->trade_type = 'limit_order';
                                                $trade->user_id = $user_id;
                                                $trade->pair_id = $get_pair_id->id;
                                                $trade->pair = $pair;
                                                $trade->firstCurrency = $first_currency;
                                                $trade->secondCurrency = $second_currency;
                                                $trade->price = $price;
                                                $trade->idr_price = $get_price;
                                                $trade->idr_qty = $idr;
                                                $trade->indo_price = $convert;
                                                $trade->total = $total;
                                                $trade->type = $type;
                                                $trade->process = '0';
                                                $trade->bitfinex_id = $datacurl['return']['order_id'];
                                                $trade->fee = $trade_fee;
                                                $trade->original_qty = $amount;
                                                $trade->updated_qty = $amount;
                                                $trade->status = 'active';

                                                \Log::info(["Trade Save data", $trade]);

                                                if ($trade->save()) {
                                                    $user_bal = UserBalance::where('user_id', $user_id)->first();
                                                    $user_bal->$currency = $update_balance;
                                                    $user_bal->save();
                                                    last_activity(get_usermail($user_id), 'Limit Buy order', $user_id);

                                                }

                                            } else {
                                                $data['status'] = '1';
                                                $data['message'] = 'Your Order completed';
                                            }
                                        } catch (\Exception $exception) {
                                            echo $exception->getMessage();
                                            \Log::error([$exception->getMessage(), $exception->getLine(), $exception->getFile()]);

                                        }
                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                        $pusher->trigger('demo1', 'demo-event', array('User_id' => $user_id, 'Pair' => $pair, 'Total' => $total, 'Amount' => number_format($amount, 4, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type, 'Trade_id' => $trade->id));
                                        return json_encode($data);
                                    } else {
                                        $get_xdc = floatval($idr / $get_price);
                                        $data['status'] = '0';
                                        $data['message'] = 'Order should be greater than ' . $get_xdc . ' for price ' . $price;
                                        return json_encode($data);
                                    }
                                }
                                else if($pair == 'XDC-USDT'){
                                    $convert_price = json_decode(get_indodax_price('xrp_idr'));
                                    $convert = $convert_price->ticker->last;
                                    $get_price = number_format(floatval($price * $convert), '0', '.', '');
                                    $idr = floatval($get_price * $amount);
                                    if ($idr >= 50000) {
                                        $indodax_data['nonce'] = (string)round(microtime(true) * 1000);
                                        $indodax_data['pair'] = 'xdce_idr';
                                        $indodax_data['method'] = 'trade';
                                        $indodax_data['type'] = strtolower($type);
                                        $indodax_data['xdce'] = floatval($amount);
                                        $indodax_data['idr'] = $idr;
                                        $indodax_data['price'] = $get_price;

                                        \Log::info(['Indodax data', $indodax_data]);

                                        $data['apikey'] = 'IXMEHSLV-EXI19ALG-JBDAHWEO-T8KVL126-ZZOZZHQQ';//live
                                        $data['secret'] = '64300bcc4022ad5b07fcc49592a66287e7a729ff056c00a2ce3137297dca1a44b6a3830071f7d6c3';//live
                                        // generate the POST data string
                                        $data['payload'] = http_build_query($indodax_data, '', '&');
                                        $data['signature'] = hash_hmac('sha512', $data['payload'], $data['secret']);//live
                                        //new order in bitfinex
                                        $ch = curl_init();
                                        curl_setopt($ch, CURLOPT_URL, "https://indodax.com/tapi/");
                                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                            'Sign:' . $data['signature'],
                                            'Key:' . $data['apikey'],
                                        ));
                                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                                        curl_setopt($ch, CURLOPT_HEADER, FALSE);
                                        curl_setopt($ch, CURLOPT_POST, TRUE);
                                        curl_setopt($ch, CURLOPT_POSTFIELDS, $data['payload']);
                                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
                                        $result = curl_exec($ch);
                                        $datacurl = json_decode($result, true);
                                        \Log::info(["datacurl", $datacurl]);
                                        if (curl_errno($ch)) {
                                            $errorMessage = curl_error($ch);
                                            return response()->json(['status' => 0, 'message' => 'Error in place order => ' . $errorMessage, 'data' => []]);
                                        }
                                        curl_close($ch);
                                        try {
                                            \Log::info(["datacurl", $datacurl['success']]);
                                            if ($datacurl['success'] == 1) {
                                                \Log::info(["Indodax order placed", $datacurl['return']['order_id']]);
                                                $data['status'] = '1';
                                                $data['message'] = 'Your Order placed';
                                                $trade = new Trade();
                                                $trade->unique_id = $txd_id;
                                                $trade->trade_id = $txd_id;
                                                $trade->trade_type = 'limit_order';
                                                $trade->user_id = $user_id;
                                                $trade->pair_id = $get_pair_id->id;
                                                $trade->pair = $pair;
                                                $trade->firstCurrency = $first_currency;
                                                $trade->secondCurrency = $second_currency;
                                                $trade->price = $price;
                                                $trade->idr_price = $get_price;
                                                $trade->idr_qty = $idr;
                                                $trade->indo_price = $convert;
                                                $trade->total = $total;
                                                $trade->type = $type;
                                                $trade->process = '0';
                                                $trade->bitfinex_id = $datacurl['return']['order_id'];
                                                $trade->fee = $trade_fee;
                                                $trade->original_qty = $amount;
                                                $trade->updated_qty = $amount;
                                                $trade->status = 'active';

                                                \Log::info(["Trade Save data", $trade]);

                                                if ($trade->save()) {
                                                    $user_bal = UserBalance::where('user_id', $user_id)->first();
                                                    $user_bal->$currency = $update_balance;
                                                    $user_bal->save();
                                                    last_activity(get_usermail($user_id), 'Limit Buy order', $user_id);

                                                }

                                            } else {
                                                $data['status'] = '1';
                                                $data['message'] = 'Your Order completed';
                                            }
                                        } catch (\Exception $exception) {
                                            echo $exception->getMessage();
                                            \Log::error([$exception->getMessage(), $exception->getLine(), $exception->getFile()]);

                                        }
                                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                        $pusher->trigger('demo1', 'demo-event', array('User_id' => $user_id, 'Pair' => $pair, 'Total' => $total, 'Amount' => number_format($amount, 4, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type, 'Trade_id' => $trade->id));
                                        return json_encode($data);
                                    } else {
                                        $get_xdc = floatval($idr / $get_price);
                                        $data['status'] = '0';
                                        $data['message'] = 'Order should be greater than ' . $get_xdc . ' for price ' . $price;
                                        return json_encode($data);
                                    }
                                }


                                $trade = new Trade();
                                if ($trade_type == 'stop_limit') {
                                    $stop_limit = $request['stop'];
                                    $trade->stoporderprice = $stop_limit;
                                }


                            //    $trade->unique_id = $txd_id;
                            //    $trade->trade_id = $txd_id;
                            //    $trade->trade_type = $trade_type;
                            //    $trade->user_id = $user_id;
                            //    $trade->pair_id = $get_pair_id->id;
                            //    $trade->pair = $pair;
                            //    $trade->firstCurrency = $first_currency;
                            //    $trade->secondCurrency = $second_currency;
                            //    $trade->price = $price;
                            //    $trade->total = $total;
                            //    $trade->type = $type;
                            //    $trade->process = '0';
                            //    $trade->fee = $trade_fee;
                            //    $trade->original_qty = $amount;
                            //    $trade->updated_qty = $amount;

                            //    $trade->status = 'active';

                            //    if ($trade->save()) {
                                $time = date('Y-m-d H:i:s');
                                $check = DB::select(DB::raw('CALL AddBuySellOrder("' . $txd_id . '","' . $txd_id . '","' . $trade_type . '","' . $user_id . '",
                                "' . $get_pair_id->id . '","' . $pair . '","' . $first_currency . '","' . $second_currency . '","' . $price . '","' . $total . '",
                                "' . $type . '","' . $trade_fee . '","' . $amount . '","' . $amount . '","' . $time . '","' . $time . '");'));
                                \Log::info(['SP>>>', $check]);
                                if ($check) {
                                    $user_bal = UserBalance::where('user_id', $user_id)->first();
                                    $user_bal->$currency = $update_balance;
                                    $user_bal->save();

//                                    crypto_compare_ob();

                                    //user activity
                                    last_activity(get_usermail($user_id), 'Limit Buy order', $user_id);

                                    //id
                                    $active_id = $check[0]->id;

                                    //find trade now

                                    $this->find_trades($active_id, $type, $price, $amount, $pair);
                                    $trade_status = Trade::where('id', $active_id)->first();
                                    $status = $trade_status->status;
                                    if ($status == 'completed') {
                                        $data['status'] = '1';
                                        $data['id'] = $user_id;
                                        $data['message'] = 'Order is been Completed';
                                    } else if ($status == 'active' || $status == 'partially') {
                                        $amount = $trade_status->updated_qty;
                                        $price = $trade_status->price;
                                        $pusher_total = $amount * $price;
                                        $trade_fee = $pusher_total * $get_txn_fee;
                                        if ($type == 'Buy') {
                                            $pusher_total = number_format($pusher_total + $trade_fee, 2, '.', '');
                                        } else {
                                            $pusher_total = number_format($pusher_total - $trade_fee, 2, '.', '');
                                        }

                                        if ($pair != 'XDC-XRP') {
                                            $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                                            $pusher->trigger('demo1', 'demo-event', array('User_id' => $user_id, 'Pair' => $pair, 'Total' => $pusher_total, 'Amount' => number_format($amount, 4, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type));
                                        }

                                        $data['status'] = '2';
                                        $data['message'] = 'Your Order placed';
                                    } else {
                                        $data['status'] = '3';
                                        $data['message'] = 'Your order is partially executed';
                                    }

                                    $this->update_pairstats($get_pair_id->id);
                                    return json_encode($data);
                                } else {
                                    $data['status'] = '0';
                                    $data['message'] = 'Some error occured while placing trade';
                                    return json_encode($data);
                                }

                            } else {
                                $data['status'] = '0';
                                $data['message'] = 'Insufficient Balance of ' . $currency;
                                return json_encode($data);
                            }
                        }
                    } //post method
                    else {
                        $data['status'] = '0';
                        $data['message'] = 'Invalid Pair.';
                        return json_encode($data);
                    }
                }
            }
        } catch (\Exception $exception) {
            echo $exception->getMessage();
            \Log::error([$exception->getMessage(), $exception->getLine(), $exception->getFile()]);
            return view('front.error');
        }

    }

    function market_orders(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $pair = $request['pair'];
            }
        } catch (\Exception $exception) {
            $message = $exception->getLine() . '<br>' . $exception->getMessage() . '<br>' . $exception->getFile();
            $data['status'] = 500;
            $data['message'] = 'Server Error';
            return json_encode($data);
        }
    }

    //find trades
    function find_trades($active_id, $type, $price, $amount, $pair)
    {
        try {
            $find_trade_type = ($type == 'Buy') ? 'Sell' : 'Buy';
            $trade_user_id = $this->single_trade_details($active_id, 'user_id');
            if ($type == 'Buy') {

                $findorders = Trade::where('user_id', '<>', $trade_user_id)->where('price', '<=', $price)->where(['pair' => $pair, 'type' => $find_trade_type])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->orderBy('price', 'asc')->orderBy('created_at', 'asc')->get();

            } else {
                $findorders = Trade::where('user_id', '<>', $trade_user_id)->where('price', '>=', $price)->where(['pair' => $pair, 'type' => $find_trade_type])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->orderBy('price', 'desc')->orderBy('created_at', 'asc')->get();
            }

            $order_process_result = 0;

            //iterating each record
            foreach ($findorders as $foundorder) {
                $found_order_amount = $foundorder->updated_qty;
                $pairid = $foundorder->pair_id;
                if ($found_order_amount > $amount) {
                    $active_status = 'completed';
                    $found_status = 'partially';
                    $executed_price = $foundorder->price;


                    //active order completed
                    $order_process_result = $this->order_process($active_status, $found_status, $active_id, $foundorder->id, $amount, $executed_price);
                    $this->update_pairstats($pairid);

                    break;
                } else if ($found_order_amount == $amount) {
                    $active_status = 'completed';
                    $found_status = 'completed';
                    $executed_price = $foundorder->price;


                    //active order completed
                    $order_process_result = $this->order_process($active_status, $found_status, $active_id, $foundorder->id, $amount, $executed_price);
                    $this->update_pairstats($pairid);

                    break;
                } else {
                    $active_status = 'partially';
                    $found_status = 'completed';
                    $executed_price = $foundorder->price;


                    //active order completed
                    $order_process_result = $this->order_process($active_status, $found_status, $active_id, $foundorder->id, $found_order_amount, $executed_price);
                    $this->update_pairstats($pairid);


                    $amount = $amount - $found_order_amount;
                    if ($amount == 0) {
                        $order_process_result = 1;
                        break;
                    }

                }
            }
            return $order_process_result;
        } catch (\Exception $exception) {
            return $exception->getMessage() . ' ' . $exception->getFile() . ' ' . $exception->getLine();

        }
    }

    //order completed
    function order_process($user_status, $trader_status, $user_trade_id, $trader_id, $amount, $executed_price)
    {
        try {

            DB::transaction(function () use ($user_status, $trader_status, $user_trade_id, $trader_id, $amount, $executed_price) {
                $trade = Trade::where('id', $trader_id)->first();

                $up_amt = $trade->updated_qty;
                if ($up_amt >= $amount) {
                    $trader_user_id = $trade->user_id;
                    $trader_type = $trade->type;
                    $pair = $trade->pair;
                    $cur = explode("-", $pair);
                    $first_currency = $cur[0];
                    $second_currency = $cur[1];
                    $trader_total = ($amount * $executed_price);

                    $trader_expected_total = ($amount * $trade->price);
                    if ($trader_type == 'Buy') {

                        $trading_fee = get_trade_fee('Buy', $pair);
                        if ($trader_user_id == '29' || $trader_user_id == '30') {
                            $trading_fee = 0;
                        }
                        $trader_fee_charged = $trader_expected_total * $trading_fee;
                        $trader_expected_fee = $trader_total * $trading_fee;
                    } else {
                        $trading_fee = get_trade_fee('Sell', $pair);
                        if ($trader_user_id == '29' || $trader_user_id == '30') {
                            $trading_fee = 0;
                        }
                        $trader_fee_charged = $trader_expected_total * $trading_fee;
                        $trader_expected_fee = $trader_total * $trading_fee;
                    }


                    $trade->status = $trader_status;
                    $upt_qty = $trade->updated_qty - $amount;
                    $trade->updated_qty = $trade->updated_qty - $amount;


                    if ($trader_type == 'Buy') {
                        $trade->updated_total = $trade->updated_total + $trader_total + $trader_expected_fee;

                        $trade->total = ($upt_qty * $trade->price) + ($upt_qty * $trade->price * $trading_fee);
                    } else {
                        $trade->updated_total = $trade->updated_total + $trader_total - $trader_expected_fee;
                        $trade->total = ($upt_qty * $trade->price) - ($upt_qty * $trade->price * $trading_fee);
                    }

                    $trade->save();

                    $trader_user_balance = UserBalance::where('user_id', $trader_user_id)->first();
                    if ($trader_type == 'Buy') {
                        if ($executed_price < $trade->price) {

                            $return_total = ($trader_expected_total - $trader_total) + ($trader_fee_charged - $trader_expected_fee);
                        } else {
                            $return_total = 0;
                        }

                        $trader_user_balance->$first_currency = $trader_user_balance->$first_currency + $amount;
                        $trader_user_balance->$second_currency = $trader_user_balance->$second_currency + $return_total;
                        $trader_user_balance->save();


                    } else {
                        $updated_total = $trader_total - $trader_expected_fee;
                        $trader_user_balance->$second_currency = $trader_user_balance->$second_currency + $updated_total;
                        $trader_user_balance->save();

                    }

                    //user trade process
                    $user_trade = Trade::where('id', $user_trade_id)->first();
                    $user_user_id = $user_trade->user_id;
                    $user_trade_type = $user_trade->type;

                    $user_trade_expected_total = ($amount * $user_trade->price);

                    if ($user_trade_type == 'Buy') {
                        $trading_fee = get_trade_fee('Buy', $pair);
                        if ($user_user_id == '29' || $user_user_id == '30') {
                            $trading_fee = 0;
                        }
                        $user_trade_fee_charged = $trader_expected_total * $trading_fee;
                        $user_trader_expected_fee = $trader_total * $trading_fee;
                    } else {
                        $trading_fee = get_trade_fee('Sell', $pair);
                        if ($user_user_id == '29' || $user_user_id == '30') {
                            $trading_fee = 0;
                        }
                        $user_trade_fee_charged = $trader_expected_total * $trading_fee;
                        $user_trader_expected_fee = $trader_total * $trading_fee;
                    }

                    $user_trade->status = $user_status;
                    $user_updated_qty = $user_trade->updated_qty - $amount;
                    $user_trade->updated_qty = $user_trade->updated_qty - $amount;

                    if ($user_trade_type == 'Buy') {
                        $user_trade->updated_total = $user_trade->updated_total + $trader_total + $user_trader_expected_fee;
                        $user_trade->total = ($user_updated_qty * $user_trade->price) + ($user_updated_qty * $user_trade->price * $trading_fee);
                    } else {
                        $user_trade->updated_total = $user_trade->updated_total + $trader_total - $user_trader_expected_fee;
                        $user_trade->total = ($user_updated_qty * $user_trade->price) - ($user_updated_qty * $user_trade->price * $trading_fee);
                    }

                    $user_trade->save();

                    $user_user_balance = UserBalance::where('user_id', $user_user_id)->first();
                    if ($user_trade_type == 'Buy') {

                        if ($executed_price < $user_trade->price) {
                            $return_total = ($user_trade_expected_total - $trader_total) + ($user_trade_fee_charged - $user_trader_expected_fee);
                        } else {
                            $return_total = 0;
                        }

                        $user_user_balance->$first_currency = $user_user_balance->$first_currency + $amount;
                        $user_user_balance->$second_currency = $user_user_balance->$second_currency + $return_total;
                        $user_user_balance->save();


                    } else {

                        $updated_total = $trader_total - $user_trader_expected_fee;
                        $user_user_balance->$second_currency = $user_user_balance->$second_currency + $updated_total;
                        $user_user_balance->save();

                    }

                    //admin  trade profit
                    $Trader_admin_coin_teft = new Profit();
                    $Trader_admin_coin_teft->userId = $trader_user_id;
                    $Trader_admin_coin_teft->type = 'Trd-' . $trade->type;
                    $Trader_admin_coin_teft->record_id = $trader_id;
                    $Trader_admin_coin_teft->theftAmount = $trader_expected_fee;
                    $Trader_admin_coin_teft->theftCurrency = $second_currency;
                    $Trader_admin_coin_teft->date = date('Y-m-d');
                    $Trader_admin_coin_teft->time = date('H:i:s');
                    $Trader_admin_coin_teft->save();

                    //admin  trade profit
                    $user_admin_coin_teft = new Profit();
                    $user_admin_coin_teft->userId = $user_user_id;
                    $user_admin_coin_teft->type = 'Trd-' . $user_trade->type;
                    $user_admin_coin_teft->record_id = $user_trade_id;
                    $user_admin_coin_teft->theftAmount = $user_trader_expected_fee;
                    $user_admin_coin_teft->theftCurrency = $second_currency;
                    $user_admin_coin_teft->date = date('Y-m-d');
                    $user_admin_coin_teft->time = date('H:i:s');
                    $user_admin_coin_teft->save();

                    //trade history


                    //trade mapping

                    if ($user_trade_type == 'Buy') {
                        $buy_id = $user_trade_id;
                        $sell_id = $trader_id;
                    } else {
                        $buy_id = $trader_id;
                        $sell_id = $user_trade_id;
                    }
                    $trade_mapping = new TradeMapping();
                    $trade_mapping->unique_id = 'MTX' . time();
                    $trade_mapping->pair = $pair;
                    $trade_mapping->buy_trade_order_id = $buy_id;
                    $trade_mapping->sell_trade_order_id = $sell_id;
                    $trade_mapping->type = $user_trade_type;
                    $trade_mapping->triggered_price = $executed_price;
                    $trade_mapping->triggered_qty = $amount;
                    if ($user_trade_type == 'Buy') {
                        $trade_mapping->total = $trader_total + $user_trader_expected_fee;
                    } else {
                        $trade_mapping->total = $trader_total - $user_trader_expected_fee;
                    }
                    $trade_mapping->save();

                    $this->trade_chart($pair);

//                    crypto_compare_tu();

                    $trade_mapping_data = TradeMapping::where('id', $trade_mapping->id)->first();

                    $date = $trade_mapping_data->created_at->format('Y-m-d H:i:s');
                    //for alphaex trade history
                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));


                    $pusher->trigger('trade', 'trade-history', array('Pair' => $pair, 'Time' => $date, 'Type' => $user_trade_type, 'Amount' => number_format($amount, 4, '.', ''), 'Price' => number_format($executed_price, 8, '.', ''), 'Total' => number_format($trade_mapping_data->total, 2, '.', '')));


                    //for alphaex pusher
                    $pusher->trigger('order', 'order-history', array('trade_status' => $trader_status, 'Pair' => $pair, 'user_id' => $user_user_id, 'trade_id' => $trader_user_id, 'Type' => $user_trade_type,
                        'Amount' => number_format($amount, 4, '.', ''),
                        'Price' => number_format($executed_price, 8, '.', ''),
                        'Total' => number_format($trade_mapping_data->total, 4, '.', ''),
                        'Fee' => number_format($trading_fee, '9', '.', '')));

                    return 1;

                } else {

                    return 0;
                }

            });
        } catch (\Exception $exception) {

            return 0;
        }


    }

    function market_order(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $user_id = Session::get('alphauserid');
                $pair = $request['pair'];
                $amount = $request['amount'];
                $type = $request['type'];

                $find_trade_type = ($type == 'Buy') ? 'Sell' : 'Buy';

                if ($type == 'Buy') {

                    $findorders = Trade::where('user_id', '<>', $user_id)->where(['pair' => $pair, 'type' => $find_trade_type])->where(function ($query) {
                        $query->where('status', 'active')->Orwhere('status', 'partially');
                    })->orderBy('price', 'asc')->get();

                } else {
                    $findorders = Trade::where('user_id', '<>', $user_id)->where(['pair' => $pair, 'type' => $find_trade_type])->where(function ($query) {
                        $query->where('status', 'active')->Orwhere('status', 'partially');
                    })->orderBy('price', 'desc')->get();
                }
            }
        } catch (\Exception $exception) {
            $data['status'] = '500';
            $data['message'] = 'Server Error';
            return json_encode($data);
        }
    }


    function cancel_order($id)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $tradeid = base64_decode($id);
                $result = Trade::where('id', $tradeid)->whereIn('status', ['active', 'partially'])->first();
                if ($result) {
                    $amount = $result->updated_qty;
                    $price = $result->price;
                    $total = $amount * $price;
                    if ($result->type == 'Buy') {
                        $fee = get_trade_fee('Buy', $result->pair);
                    } else {
                        $fee = get_trade_fee('Sell', $result->pair);
                    }


                    if ($result->bitfinex_id != 0) {

                        $bitfinex_id = (floatval($result->bitfinex_id));
                        $order_info = json_decode(bitfinex_order_status_check($bitfinex_id));
                        $price = $order_info->avg_execution_price;
                        $difference = $amount - $order_info->remaining_amount;
                        if ($price == 0 || $difference == 0) {
                            $cancel_order = bitfinex_order_cancel($bitfinex_id);
                            \Log::info(['canceled_orders_result', $cancel_order]);
                        } else {
                            $result->updated_qty = $order_info->remaining_amount;
                            $get_txn_fee = get_trade_fee($result->type, $result->pair);
                            $trade_fee = $price * $difference * $get_txn_fee;
                            $trade_fee = number_format($trade_fee, 12, '.', '');

                            if ($result->type == 'Buy') {
                                $currency = $result->firstCurrency;
                                $user_balance = get_userbalance($result->user_id, $currency) + $difference;
                                $total = $price * $difference + $trade_fee;
                            } else {
                                $currency = $result->secondCurrency;
                                $total = $price * $difference - $trade_fee;
                                $user_balance = get_userbalance($result->user_id, $currency) + $total;
                            }
                            $user_bal = UserBalance::where('user_id', $result->user_id)->first();
                            $user_bal->$currency = $user_balance;
                            $user_bal->save();
                            $result->updated_total = $result->updated_total + $total;
                            \Log::info(['cancel_trade_fee', $trade_fee, 'total', $total]);
                            \Log::info(['cancel_open_orders', $result]);
                            if ($order_info->remaining_amount == 0) {
                                $result->status = 'completed';
                                $result->save();
                                $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                                //for alphaex pusher
                                $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $result->pair, 'user_id' => $result->user_id, 'trade_id' => 0, 'Type' => $result->type,
                                    'Amount' => number_format($difference, 4, '.', ''),
                                    'Price' => number_format($price, 8, '.', ''),
                                    'Total' => number_format($total, 4, '.', ''),
                                    'Fee' => number_format($trade_fee, '9', '.', '')));
                                Session::flash('error', 'Your order is already completed');
                                return redirect()->back();
                            } else {
                                $result->status = 'partially';
                                $result->save();
                                $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                                //for alphaex pusher
                                $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $result->pair, 'user_id' => $result->user_id, 'trade_id' => 0, 'Type' => $result->type,
                                    'Amount' => number_format($difference, 4, '.', ''),
                                    'Price' => number_format($price, 8, '.', ''),
                                    'Total' => number_format($total, 4, '.', ''),
                                    'Fee' => number_format($trade_fee, '9', '.', '')));
                                $cancel_order = bitfinex_order_cancel($result->bitfinex_id);
                                \Log::info(['canceled_orders_result', $cancel_order]);
                            }

                        }

                    }
                    $trade_fee = $total * $fee;

                    $userid = $result->user_id;
                    $second_currency = $result->secondCurrency;
                    $first_currency = $result->firstCurrency;
                    $second_cur_balance = get_userbalance($userid, $second_currency);
                    $first_cur_balance = get_userbalance($userid, $first_currency);
                    if ($result->status == 'active') {
                        $refnd_amount = $result->updated_qty;
                        $refnd_total = $result->total;
                    } else if ($result->status == 'partially') {
                        $refnd_amount = $result->updated_qty;
                        $refnd_total = $total + $trade_fee;
                    }
                    if ($result->type == 'Buy') {
                        if ($result->status == 'active') {
                            $result->status = 'cancelled';
                            if ($result->save()) {
                                $finalbalance = $second_cur_balance + $refnd_total;
                                $upt = Balance::where('user_id', $userid)->first();
                                $upt->$second_currency = $finalbalance;
                                $upt->save();
                            }
                        } else {
                            $new = new Trade;
                            $tx_id = 'BTX' . time();
                            $new->unique_id = $tx_id;
                            $new->trade_id = $tx_id;
                            $new->trade_type = $result->trade_type;
                            $new->user_id = $result->user_id;
                            $new->pair_id = $result->pair_id;
                            $new->pair = $result->pair;
                            $new->firstCurrency = $result->firstCurrency;
                            $new->secondCurrency = $result->secondCurrency;
                            $new->price = $result->price;
                            $new->total = $result->total;
                            $new->type = 'Buy';
                            $new->process = '1';
                            $new->fee = $result->fee;
                            $new->original_qty = $result->updated_qty;
                            $new->status = 'cancelled';
                            $new->save();
                            $result->original_qty = ($result->original_qty - $result->updated_qty);
                            $result->status = 'completed';
                            if ($result->save()) {
                                $finalbalance = $second_cur_balance + $refnd_total;
                                $upt = Balance::where('user_id', $userid)->first();
                                $upt->$second_currency = $finalbalance;
                                $upt->save();
                            }
                        }
                    } else {
                        if ($result->status == 'active') {
                            $result->status = 'cancelled';
                            if ($result->save()) {
                                $finalbalance = $first_cur_balance + $refnd_amount;
                                $upt = Balance::where('user_id', $userid)->first();
                                $upt->$first_currency = $finalbalance;
                                $upt->save();
                            }
                        } else {
                            $new = new Trade;
                            $tx_id = 'STX' . time();
                            $new->unique_id = $tx_id;
                            $new->trade_id = $tx_id;
                            $new->trade_type = $result->trade_type;
                            $new->user_id = $result->user_id;
                            $new->pair_id = $result->pair_id;
                            $new->pair = $result->pair;
                            $new->firstCurrency = $result->firstCurrency;
                            $new->secondCurrency = $result->secondCurrency;
                            $new->price = $result->price;
                            $new->total = $result->total;
                            $new->type = 'Sell';
                            $new->process = '1';
                            $new->fee = $result->fee;
                            $new->original_qty = $result->updated_qty;
                            $new->status = 'cancelled';
                            $new->save();
                            $result->original_qty = ($result->original_qty - $result->updated_qty);
                            $result->status = 'completed';
                            if ($result->save()) {
                                $finalbalance = $first_cur_balance + $refnd_amount;
                                $upt = Balance::where('user_id', $userid)->first();
                                $upt->$first_currency = $finalbalance;
                                $upt->save();
                            }
                        }
                    }
//                    crypto_compare_ob();
                    Session::flash('success', 'Your order is been cancelled successfully');
                    return redirect()->back();
                }
            }
        } catch (\Exception $exception) {
            Session::flash('error', 'Server Error');
            return redirect()->back();
        }
    }

    function cancel_multiple($id)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $orders = json_decode($id);
            for ($i = 0; $i < count($orders); $i++) {
                $tradeid = $orders[$i];
                $result = Trade::where('id', $tradeid)->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->first();
                if ($result) {
                    $refnd_amount = $result->Total;
                    $sell_refnd_amount = $result->Amount;
                    $userid = $result->user_id;
                    $second_currency = $result->secondCurrency;
                    $first_currency = $result->firstCurrency;
                    $second_cur_balance = get_userbalance($userid, $second_currency);
                    $first_cur_balance = get_userbalance($userid, $first_currency);
                    if ($result->Type == 'Buy') {
                        $finalbalance = $second_cur_balance + $refnd_amount;
                        $upt = Balance::where('user_id', $userid)->first();
                        $upt->$second_currency = $finalbalance;
                        if ($upt->save()) {
                            $result->status = 'cancelled';
                            $result->save();
                        }
                    } else {
                        $finalbalance = $first_cur_balance + $sell_refnd_amount;
                        $upt = Balance::where('user_id', $userid)->first();
                        $upt->$first_currency = $finalbalance;
                        if ($upt->save()) {
                            $result->status = 'cancelled';
                            $result->save();
                        }
                    }
                }
            }
            Session::flash('success', 'Selected orders cancelled successfully');
            return redirect()->back();
        }
    }


    function single_trade_details($tradid, $key)
    {
        $result = Trade::where('id', $tradid)->first();
        return $result->$key;
    }

    function update_trade_details($tradid, $key, $value)
    {
        $upt = Trade::where('id', $tradid)->first();
        $upt->$key = $value;
        $upt->save();
        return true;
    }

    function user_balance_update($userid, $currency, $amount)
    {
        $paiduserbalance = get_userbalance($userid, $currency);
        $finbalance = $amount + $paiduserbalance;
        $upt = Balance::where('user_id', $userid)->first();
        $upt->$currency = $finbalance;
        $upt->save();
        return true;
    }


    function trade_chart($pair)
    {

        $pair = $pair ? $pair : 'XDC-ETH';
        //high value
        $charts = Charts::where('pair', $pair)->orderBy('datetime', 'desc')->first();
        if ($charts != '' || $charts != null) {
            $startdate = $charts->datetime;
        } else {
            $startdate = '2017-11-15';
        }
        $high = "SELECT DATE(updated_at) as dateval, SUM(triggered_qty) as volume, MAX(triggered_price) as total FROM XDC_trade_mapping where pair='$pair' AND DATE(updated_at) >= DATE('$startdate')  GROUP BY YEAR(updated_at), MONTH(updated_at), DATE(updated_at) ORDER BY DATE(updated_at) ASC";

        $result = DB::select(DB::raw($high));
        $arr = "";
        if ($result) {
            $arr .= "[";
            foreach ($result as $key => $val) {
                $vdate = $val->dateval;
                $high = $val->total;
                $millsec = strtotime($vdate) * 1000;
                $open = $this->trade_open_value($vdate, $pair);
                $close = $this->trade_close_value($vdate, $pair);
                $low = $this->trade_min_value($vdate, $pair);
                $volume = $val->volume;

                $check = Charts::where('pair', $pair)->whereDate('datetime', '=', $vdate)->first();

                if (count($check) > 0) {
                    $xdc_charts = $check;
                } else {
                    //xdc charts
                    $xdc_charts = new Charts();
                }

                $xdc_charts->datetime = $vdate;
                $xdc_charts->high = $high;
                $xdc_charts->millsec = strtotime($vdate) * 1000;
                $xdc_charts->open = $open;
                $xdc_charts->low = $low;
                $xdc_charts->volume = $volume;
                $xdc_charts->close = $close;
                $xdc_charts->pair = $pair;

                $xdc_charts->save();
                $arr .= "[" . $millsec . "," . $open . "," . $high . "," . $low . "," . $close . "," . $volume . "]";
                if (count($result) != ($key + 1)) {
                    $arr .= ",";
                }

            }
            $arr .= "]";
        } else {
            $vdate = date('Y-m-d');
            $millsec = strtotime($vdate) * 1000;
            $eval = 0;
            $arr .= "[[" . $millsec . "," . $eval . "," . $eval . "," . $eval . "," . $eval . "," . $eval . "]]";
        }
//        echo $arr;

    }

    function chart_history($pair)
    {
        try {
            $pair = $pair ? $pair : 'XDC-ETH';
            $time = Charts::where('pair', $pair)->get();
            $t = array();
            $c = array();
            $o = array();
            $h = array();
            $l = array();
            $v = array();
            foreach ($time as $key => $res) {
                $res['millsec'] = strtotime($res['datetime']);
                array_push($t, number_format($res['millsec'], 0, '.', ''));
                array_push($c, number_format($res['close'], 8, '.', ''));
                array_push($o, number_format($res['open'], 8, '.', ''));
                array_push($h, number_format($res['high'], 8, '.', ''));
                array_push($l, number_format($res['low'], 8, '.', ''));
                array_push($v, number_format($res['volume'], 0, '.', ''));
            }
            $data = array(
                's' => "ok",
                't' => $t,
                'c' => $c,
                'o' => $o,
                'h' => $h,
                'l' => $l,
                'v' => $v
            );
            return json_encode($data);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function charts($pair)
    {
        try {
            $pair = $pair ? $pair : 'XDC-ETH';

            $trade_chart = Charts::where('pair', $pair)
                ->orderBy('datetime', 'asc')->get();
            $trade_chart = $trade_chart->toJson();
            echo $trade_chart;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function chart_config()
    {
        try {
            $config = array(
                'supports_search' => true,
                'supports_group_request' => true,
                'supports_marks' => true,
                'supports_timescale_marks' => true,
                'supports_time' => true,
                'exchanges' =>
                    array(
                        0 =>
                            array(
                                'value' => '',
                                'name' => 'All Exchanges',
                                'desc' => '',
                            ),
                        1 =>
                            array(
                                'value' => 'XDC-ETH',
                                'name' => 'XDC-ETH',
                                'desc' => 'XDC-ETH',
                            )
                    ),
                'symbols_types' =>
                    array(
                        0 =>
                            array(
                                'name' => 'All types',
                                'value' => '',
                            ),
                        1 =>
                            array(
                                'name' => 'Stock',
                                'value' => 'stock',
                            ),
                        2 =>
                            array(
                                'name' => 'Index',
                                'value' => 'index',
                            ),
                    ),
                'supported_resolutions' =>
                    array(
                        0 => 'D',
                        1 => '2D',
                        2 => '3D',
                        3 => 'W',
                        4 => '3W',
                        5 => 'M',
                        6 => '6M',
                    ),
            );

            return json_encode($config);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function chart_time()
    {
        try {
            return Carbon::now()->timestamp;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function symbol_info()
    {
        try {
//            $symbols = array("XDC-ETH", "AAPL", "FB", "GOOG");
//            $desc = array("Microsoft corp.", "Apple Inc", "Facebook", "Google");
//            $data= array('symbols'=>$symbols,'min_price_move'=>1,'description'=>$desc);
            $data = array(
                'symbol' => array("XDC-ETH", "XDC-BTC", "XDC-BCHABC", "XDC-XRP", "XDC-XDCE", "XDC-BCHSV", "XDC-USDT", "XDC-USDC", "BTC-USDC", "ETH-USDT", "XRP-USDT"),
                'description' => array("XDC-ETH", "XDC-BTC", "XDC-BCHABC", "XDC-XRP", "XDC-XDCE", "XDC-BCHSV", "XDC-USDT", "XDC-USDC", "BTC-USDC", "ETH-USDT", "XRP-USDT"),
                'exchange-listed' => "AlphaEx",
                'exchange-traded' => "AlphaEx",
                'minmovement' => 1,
                'minmovement2' => 0,
                'pricescale' => array(100000000, 100000000, 100000000, 100000000, 100000000, 100000000, 100000000, 100000000, 100000000, 100000000, 100000000),
                'has_dwm' => true,
                'has_intraday' => false,
                'has-no-volume' => array(false, false, false, false, false, false, false, false, false, false, false),
                'type' => array('bitcoin', 'bitcoin', 'bitcoin', 'bitcoin', 'bitcoin', 'bitcoin', 'bitcoin', 'bitcoin', 'bitcoin', 'bitcoin', 'bitcoin'),
                'ticker' => array("XDC-ETH", "XDC-BTC", "XDC-BCHABC", "XDC-XRP", "XDC-XDCE", "XDC-BCHSV", "XDC-USDT", "XDC-USDC", "BTC-USDC", "ETH-USDT", "XRP-USDT"),
                'timezone' => "UTC",
                'session-regular' => "24x7",
            );
            return json_encode($data);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function trade_open_value($date, $pair)
    {
        try {
            $res = TradeMapping::select('triggered_price')->whereDate('updated_at', '=', $date)->where(['pair' => $pair])->orderBy('id', 'asc')->limit(1)->first();
            //$value = ($res->Type == 'Buy') ? $res->Price : $res->opt_price;
            //return $value;
            return $res->triggered_price;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function trade_close_value($date, $pair)
    {
        try {
            $res = TradeMapping::select('triggered_price')->whereDate('updated_at', '=', $date)->where(['pair' => $pair])->orderBy('id', 'desc')->limit(1)->first();
            //$value = ($res->Type == 'Buy') ? $res->Price : $res->opt_price;
            //return $value;
            return $res->triggered_price;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function trade_min_value($date, $pair)
    {
        try {
            $res = TradeMapping::whereDate('updated_at', '=', $date)->where(['pair' => $pair])->min('triggered_price');
            return $res;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function trade_max_value($date, $pair)
    {
        try {
            $res = TradeMapping::whereDate('updated_at', '=', $date)->where(['pair' => $pair])->max('triggered_price');
            return $res;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function stop_order(Request $request)
    {

        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $ip = \Request::ip();
            $userid = Session::get('alphauserid');
            if ($request->isMethod('post')) {
                $data = array();
                $pair = $request['pair'];

                $trade_fee = $request['trade_fee'];
                $type = $request['type'];
                $cur = explode("-", $pair);
                $first_currency = $cur[0];
                $second_currency = $cur[1];
                $first_cur_balance = get_userbalance($userid, $first_currency);
                $second_cur_balance = get_userbalance($userid, $second_currency);

                $current_buy_rate = get_buy_market_rate($first_currency, $second_currency);
                $current_sell_rate = get_sell_market_rate($first_currency, $second_currency);

                $volume = get_trading_volume($first_currency, $second_currency, $userid);
                $trade_fee = $this->get_trading_fee(round($volume), $second_currency);

                if ($type == 'Buy') {
                    $sell_rate = $request['buy_stop_price'];
                    $buyamount = $request['buy_stop_' . $first_currency];
                    /*$feeamount = $request['buy_fee_amount'];
                    $priceamount = $request['buy_price_amount'];*/

                    $bprice = $buyamount * $sell_rate;
                    $feeamount = $bprice * ($trade_fee / 100);
                    $priceamount = $bprice + $feeamount;

                    if ($priceamount <= $second_cur_balance) {

                        $ins = new Trade;
                        $ins->user_id = $userid;
                        $ins->ip = $ip;
                        $ins->firstCurrency = $first_currency;
                        $ins->secondCurrency = $second_currency;
                        $ins->Amount = $buyamount;
                        $ins->Price = $sell_rate;
                        $ins->Type = $type;
                        $ins->Process = '';
                        $ins->Fee = $feeamount;
                        $ins->Total = $priceamount;
                        $ins->orderTime = date('H:i:s');
                        $ins->datetime = date('Y-m-d');
                        $ins->pair = $pair;
                        $ins->status = 'stop';
                        $ins->fee_per = $trade_fee;
                        if ($ins->save()) {
                            $finalbalance = $second_cur_balance - $priceamount;
                            $upt = Balance::where('user_id', $userid)->first();
                            $upt->$second_currency = $finalbalance;
                            $upt->save();
                            last_activity(get_usermail($userid), 'Stop Buy order', $userid);
                        }
                        $last_orderid = $ins->id;

                        $data['status'] = '1';
                        $data['message'] = 'Stop order placed';
                        echo json_encode($data);
                        die();

                    } else {
                        $data['status'] = '0';
                        $data['message'] = 'Insufficient Balance of ' . $second_currency;
                        echo json_encode($data);
                        die();
                    }
                } elseif ($type == 'Sell') {
                    $buy_rate = $request['sell_stop_price'];
                    $sellamount = $request['sell_stop_' . $first_currency];
                    /*$feeamount = $request['sell_fee_amount'];
                    $priceamount = $request['sell_price_amount'];*/

                    $sprice = $sellamount * $buy_rate;
                    $feeamount = $sprice * ($trade_fee / 100);
                    $priceamount = $sprice - $feeamount;

                    if ($sellamount <= $first_cur_balance) {

                        $ins = new Trade;
                        $ins->user_id = $userid;
                        $ins->ip = $ip;
                        $ins->firstCurrency = $first_currency;
                        $ins->secondCurrency = $second_currency;
                        $ins->Amount = $sellamount;
                        $ins->Price = $buy_rate;
                        $ins->Type = $type;
                        $ins->Process = '';
                        $ins->Fee = $feeamount;
                        $ins->Total = $priceamount;
                        $ins->orderTime = date('H:i:s');
                        $ins->datetime = date('Y-m-d');
                        $ins->pair = $pair;
                        $ins->status = 'stop';
                        $ins->fee_per = $trade_fee;
                        if ($ins->save()) {
                            $finalbalance = $first_cur_balance - $sellamount;
                            $upt = Balance::where('user_id', $userid)->first();
                            $upt->$first_currency = $finalbalance;
                            $upt->save();
                            last_activity(get_usermail($userid), 'Stop Buy order', $userid);
                        }
                        $last_orderid = $ins->id;

                        $data['status'] = '1';
                        $data['message'] = 'Stop order placed';
                        echo json_encode($data);
                        die();

                    } else {
                        $data['status'] = '0';
                        $data['message'] = 'Insufficient Balance of ' . $first_currency;
                        echo json_encode($data);
                        die();
                    }
                }
            }
        }

    }

    function check_market_price($curr_price, $user_price, $type)
    {
        if ($type == 'Buy') {
            $min_price = $curr_price * (30 / 100);
            $min_price = $curr_price - $min_price;
            return ($min_price > $user_price) ? 'ok' : 'false';
        } else {
            $max_price = $curr_price * (30 / 100);
            $max_price = $curr_price + $max_price;
            return ($max_price < $user_price) ? 'ok' : 'false';
        }
    }

    function stop_cancel_order($id)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $tradeid = base64_decode($id);
            $result = Trade::where(['id' => $tradeid, 'status' => 'stop'])->first();
            if ($result) {
                $refnd_amount = $result->Total;
                $sell_refnd_amount = $result->Amount;
                $userid = $result->user_id;
                $second_currency = $result->secondCurrency;
                $first_currency = $result->firstCurrency;
                $second_cur_balance = get_userbalance($userid, $second_currency);
                $first_cur_balance = get_userbalance($userid, $first_currency);
                if ($result->Type == 'Buy') {
                    $finalbalance = $second_cur_balance + $refnd_amount;
                    $upt = Balance::where('user_id', $userid)->first();
                    $upt->$second_currency = $finalbalance;
                    if ($upt->save()) {
                        $result->status = 'cancelled';
                        $result->save();
                    }
                } else {

                    $finalbalance = $first_cur_balance + $sell_refnd_amount;
                    $upt = Balance::where('user_id', $userid)->first();
                    $upt->$first_currency = $finalbalance;
                    if ($upt->save()) {
                        $result->status = 'cancelled';
                        $result->save();
                    }

                }
                Session::flash('success', 'Stop order cancelled successfully');
                return redirect()->back();
            }
        }
    }

    function check_stop_orders($price, $type)
    {
        $ftype = ($type == 'Buy') ? 'Sell' : 'Buy';
        $upt = Trade::where(['Type' => $ftype, 'Price' => $price, 'status' => 'stop'])->get();
        if (count($upt) > 0) {
            $uptdata = ['status' => 'active'];
            $res = Trade::where(['Type' => $ftype, 'Price' => $price, 'status' => 'stop'])->update($uptdata);
        }
        return true;

    }

//fpr swap history
    function swap_history()
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');


            $trade_history = Trade::where(['user_id' => $userid])->whereIn('pair', ['XDC-XDCE'])->whereIn('status', ['completed'])->orderBy('created_at', 'desc')->paginate(10);
            return view('front.trade_history', ['result' => $trade_history, 'getpair' => 'XDC-XDCE', 'getstatus' => 'completed']);
        }
    }

// end class
//fpr ico history
    function ico_history()
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');

            $trade_history = ICOTrade::where('user_id', $userid)->orderBy('id', 'desc')->paginate(10);
            return view('front.trade_history', ['result' => $trade_history, 'getpair' => 'XDC-ICO', 'getstatus' => 'completed']);
        }

    }

    function demo(Request $request)
    {
        $data = $request['id'];
        $b = $request['type'];
        $c = $request['amt'];
        $d = $request['p'];
        $e = $request['pair'];

        $this->find_trades($data, $b, $d, $c, $e);
    }

    function test1($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            $userid = Session::get('alphauserid');
            $pair = $pair ? $pair : 'XDC-ETH';

            $checkpair = Pair::where(['type' => 'trade', 'pair' => $pair])->count();
            if ($checkpair == 0) {
                abort(404);
            }
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];

            $first_cur_balance = "";
            $second_cur_balance = "";

            if ($second_currency == 'XDCE') {
                $buy_rate = 1;
                $sell_rate = 1;
                $trading_fee = 0;

                $active_orders = "";

            } else {

                $buy_rate = get_buy_market_rate($first_currency, $second_currency);
                $sell_rate = get_sell_market_rate($first_currency, $second_currency);
                $volume = get_trading_volume($first_currency, $second_currency, $userid);
                $trading_fee = get_trade_fee('Buy', $pair);

                $active_orders = "";
            }

//            $buy_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Sell'])->where(function ($query) {
//                $query->where('status', 'active')->Orwhere('status', 'partially');
//            })->groupBy('price')->orderBy('price', 'asc')->limit(5)->get();

            $buy_order_list = "";

            /*$buy_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Sell' AND (status='active' or status='partially') ORDER BY id DESC"));*/

//            $sell_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Buy'])->where(function ($query) {
//                $query->where('status', 'active')->Orwhere('status', 'partially');
//            })->groupBy('price')->orderBy('price', 'desc')->limit(5)->get();

            $sell_order_list = "";

            /*$sell_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Buy' AND (status='active' or status='partially') ORDER BY id DESC"));*/


            /*	$active_orders = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE user_id='$userid' and pair='$pair' AND (status='active' or status='partially')"));*/

            $stop_orders = Trade::where(['pair' => $pair, 'user_id' => $userid, 'status' => 'stop'])->orderBy('id', 'desc')->get();
//            $trade_history = TradeMapping::where('pair', $pair)->orderBy('updated_at', 'desc')->limit(16)->get();
            $trade_history = "";
            $currencies = Currencies::all();


            $fav = "";
            $favarr = "";

            if (isset($favarr[0])) {
                $get_fav_pairs = Pair::whereIn('id', $favarr)->get();
                if ($get_fav_pairs) {
                    foreach ($get_fav_pairs as $get_fav_pair) {

                        $get_pair_stat = PairStats::where('pair_id', $get_fav_pair->id)->first();
                        $explode = explode('-', $get_fav_pair->pair);
                        $currency = $explode[1];
                        $pair1 = $get_fav_pair->pair;
                        $id = $get_pair_stat->id;
                        $pair_id = $get_pair_stat->pair_id;
                        $vol = $get_pair_stat->volume;
                        $low = $get_pair_stat->low;
                        $high = $get_pair_stat->high;
                        $last = $get_pair_stat->last;
                        $percentage_change = $get_pair_stat->percent_change . '%';
                        $change = $get_pair_stat->change;
                        $color = strtolower($get_pair_stat->colour);

                        $array = array('id' => $id, 'pair_id' => $pair_id, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                        $fav_pair[] = $array;

                    }
                }
            } else {
                $fav_pair = array();
            }

            if (isset($favarr[0])) {
                $get_remain_pairs = Pair::wherenotIn('id', $favarr)->get();
            } else {
                $get_remain_pairs = Pair::all();
            }
            if ($get_remain_pairs) {
                foreach ($get_remain_pairs as $get_remain_pair) {

                    $get_pair_stat = PairStats::where('pair_id', $get_remain_pair->id)->first();
                    $explode = explode('-', $get_remain_pair->pair);
                    $currency = $explode[1];
                    $pair1 = $get_remain_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);

                    $array = array('id' => $id, 'pair_id' => $pair_id, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $result_pair[] = $array;

                }
            }

            $get_all_pairs = Pair::all();
            if ($get_all_pairs) {
                foreach ($get_all_pairs as $get_all_pair) {

                    $get_pair_stat = PairStats::where('pair_id', $get_all_pair->id)->first();
                    $explode = explode('-', $get_all_pair->pair);
                    $currency = $explode[1];
                    $pair1 = $get_all_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);

                    $array = array('id' => $id, 'pair_id' => $pair_id, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $all_pair[] = $array;

                }
            }

            $user_trade = "";

            $data = ['currency' => $currencies, 'pair' => $pair, 'first_currency' => $first_currency, 'second_currency' => $second_currency, 'first_cur_balance' => $first_cur_balance, 'second_cur_balance' => $second_cur_balance, 'buy_rate' => (float)$buy_rate, 'sell_rate' => (float)$sell_rate, 'trading_fee' => $trading_fee, 'buy_order_list' => $buy_order_list, 'sell_order_list' => $sell_order_list, 'active_orders' => $active_orders, 'stop_orders' => $stop_orders, 'trade_history' => $trade_history, 'fav_pairs' => $fav_pair, 'remain_pairs' => $result_pair, 'user_trade' => $user_trade, 'user_id' => $userid, 'fav' => $fav, 'pairs' => $all_pair];

        } else {
//            $userid = 30;
            $userid = Session::get('alphauserid');
//            if (get_user_details($userid, 'document_status') != '1') {
//                // Session::flash('error','Please Complete your KYC process');
//                // return redirect('profile');
//            }
            $transid = 'TXD' . $userid . time();

            $xdcaddr = get_user_details($userid, 'XDC_addr');
            $xdceaddr = get_user_details($userid, 'XDCE_addr');
            $xdcbal = get_livexdc_bal($xdcaddr);
            //$xdcbal = 0;
            if ($xdcbal > 0) {
                $email = get_usermail($userid);
                //$pass = Session::get('xinfinpass');
                $pass = get_user_details($userid, 'xinpass');
                login_xdc_fun($email, owndecrypt($pass));
                $adminxdcaddr = decrypt(get_config('xdc_address'));
                $res = transfer_xdctoken($xdcaddr, $xdcbal, $adminxdcaddr, $userid, owndecrypt($pass));
                try {
                    if ($res->status == 'SUCCESS') {
                        $fetchbalance = get_userbalance($userid, 'XDC');
                        $uptbal = $fetchbalance + $xdcbal;
                        $upt = Balance::where('user_id', $userid)->first();
                        $upt->XDC = $uptbal;
                        $upt->save();

                        $transid = 'TXD' . $userid . time();
                        $today = date('Y-m-d H:i:s');
                        $ip = \Request::ip();
                        $ins = new Transaction;
                        $ins->user_id = $userid;
                        $ins->payment_method = 'Cryptocurrency Account';
                        $ins->transaction_id = $transid;
                        $ins->currency_name = 'XDC';
                        $ins->type = 'Deposit';
                        $ins->transaction_type = '1';
                        $ins->amount = $xdcbal;
                        $ins->updated_at = $today;
                        $ins->crypto_address = $xdcaddr;
                        $ins->transfer_amount = '0';
                        $ins->fee = '0';
                        $ins->tax = '0';
                        $ins->verifycode = '1';
                        $ins->order_id = '0';
                        $ins->status = 'Completed';
                        $ins->cointype = '2';
                        $ins->payment_status = 'Paid';
                        $ins->paid_amount = '0';
                        $ins->wallet_txid = '';
                        $ins->ip_address = $ip;
                        $ins->verify = '1';
                        $ins->blocknumber = '';
                        $ins->save();
                    }
                } catch (\Exception $e) {

                }

            }
            $pair = $pair ? $pair : 'XDC-ETH';

            $fav = Favorite::where('user_id', $userid)->get();
            if (count($fav) > 0) {
                foreach ($fav as $key => $favs)
                    $favarr[$key] = $favs->pair_id;
            }

            $checkpair = Pair::where(['type' => 'trade', 'pair' => $pair])->count();
            if ($checkpair == 0) {
                abort(404);
            }
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];

            $first_cur_balance = get_userbalance($userid, $first_currency);
            $second_cur_balance = get_userbalance($userid, $second_currency);

            if ($second_currency == 'XDCE') {
                $buy_rate = 1;
                $sell_rate = 1;
                $trading_fee = 0;

                $active_orders = "";

            } else {
                $buy_rate = get_buy_market_rate($first_currency, $second_currency);
                $sell_rate = get_sell_market_rate($first_currency, $second_currency);
                $volume = get_trading_volume($first_currency, $second_currency, $userid);
                $trading_fee = get_trade_fee('Buy', $pair);

//                $active_orders = Trade::where(['user_id' => $userid, 'pair' => $pair])->where(function ($query) {
//                    $query->where('status', 'active')->Orwhere('status', 'partially');
//                })->orderBy('id', 'desc')->limit(5)->get();
                $active_orders = "";
            }

//            $buy_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Sell'])->where(function ($query) {
//                $query->where('status', 'active')->Orwhere('status', 'partially');
//            })->groupBy('price')->orderBy('price', 'asc')->limit(5)->get();

            $buy_order_list = "";

            /*$buy_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Sell' AND (status='active' or status='partially') ORDER BY id DESC"));*/

//            $sell_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Buy'])->where(function ($query) {
//                $query->where('status', 'active')->Orwhere('status', 'partially');
//            })->groupBy('price')->orderBy('price', 'desc')->limit(5)->get();

            $sell_order_list = "";

            /*$sell_order_list = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE pair='$pair' AND Type='Buy' AND (status='active' or status='partially') ORDER BY id DESC"));*/


            /*	$active_orders = DB::select(DB::raw("SELECT * FROM `XDC_trade_order` WHERE user_id='$userid' and pair='$pair' AND (status='active' or status='partially')"));*/

            $stop_orders = Trade::where(['pair' => $pair, 'user_id' => $userid, 'status' => 'stop'])->orderBy('id', 'desc')->get();
//            $trade_history = TradeMapping::where('pair', $pair)->orderBy('updated_at', 'desc')->limit(16)->get();

            $trade_history = "";

            $currencies = Currencies::all();

            if (isset($favarr[0])) {
                $get_fav_pairs = Pair::whereIn('id', $favarr)->get();
                if ($get_fav_pairs) {
                    foreach ($get_fav_pairs as $get_fav_pair) {

                        $get_pair_stat = PairStats::where('pair_id', $get_fav_pair->id)->first();
                        $explode = explode('-', $get_fav_pair->pair);
                        $currency = $explode[1];
                        $pair1 = $get_fav_pair->pair;
                        $id = $get_pair_stat->id;
                        $pair_id = $get_pair_stat->pair_id;
                        $vol = $get_pair_stat->volume;
                        $low = $get_pair_stat->low;
                        $high = $get_pair_stat->high;
                        $last = $get_pair_stat->last;
                        $percentage_change = $get_pair_stat->percent_change . '%';
                        $change = $get_pair_stat->change;
                        $color = strtolower($get_pair_stat->colour);

                        $array = array('id' => $id, 'pair_id' => $pair_id, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                        $fav_pair[] = $array;

                    }
                }
            } else {
                $fav_pair = array();
            }

            if (isset($favarr[0])) {
                $get_remain_pairs = Pair::wherenotIn('id', $favarr)->get();
            } else {
                $get_remain_pairs = Pair::all();
            }
            if (isset($get_remain_pairs[0])) {
                foreach ($get_remain_pairs as $get_remain_pair) {

                    $get_pair_stat = PairStats::where('pair_id', $get_remain_pair->id)->first();
                    $explode = explode('-', $get_remain_pair->pair);
                    $currency = $explode[1];
                    $pair1 = $get_remain_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);

                    $array = array('id' => $id, 'pair_id' => $pair_id, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $result_pair[] = $array;

                }
            } else {
                $result_pair = array();
            }

            $get_all_pairs = Pair::all();
            if ($get_all_pairs) {
                foreach ($get_all_pairs as $get_all_pair) {

                    $get_pair_stat = PairStats::where('pair_id', $get_all_pair->id)->first();
                    $explode = explode('-', $get_all_pair->pair);
                    $currency = $explode[1];
                    $pair1 = $get_all_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);


                    $array = array('id' => $id, 'pair_id' => $pair_id, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => $vol, 'Low' => $low, 'High' => $high, 'Percentage' => $percentage_change, 'Change' => $change, 'Colour' => $color, 'Last' => $last);
                    $all_pair[] = $array;

                }
            }

            $user_trade = Trade::where(['pair' => $pair, 'user_id' => $userid])->whereIn('status', ['completed', 'partially'])->orderBy('updated_at', 'desc')->limit(10)->get();

            $data = ['currency' => $currencies, 'pair' => $pair, 'first_currency' => $first_currency, 'second_currency' => $second_currency, 'first_cur_balance' => $first_cur_balance, 'second_cur_balance' => $second_cur_balance, 'buy_rate' => (float)$buy_rate, 'sell_rate' => (float)$sell_rate, 'trading_fee' => $trading_fee, 'buy_order_list' => $buy_order_list, 'sell_order_list' => $sell_order_list, 'active_orders' => $active_orders, 'stop_orders' => $stop_orders, 'trade_history' => $trade_history, 'fav_pairs' => $fav_pair, 'remain_pairs' => $result_pair, 'user_trade' => $user_trade, 'user_id' => $userid, 'fav' => $fav, 'pairs' => $all_pair];

//            return view('front.construction');
        }
        return view('front.test', $data);
    }

    function transfer_xdcetokenadmin()
    {
        try {
            $output = array();
            $return_var = -1;
            $wallet_ip = "78.129.229.18";
            $wallet_port = "8545";
            $password = "alphaex";
            $sever_path = $_SERVER["DOCUMENT_ROOT"];
            $fromaddress = "0x3a7ebdEBaCa6393BA2B6B99b6b8c176De8cA237F";
            $toaddr = "0x3a7ebdEBaCa6393BA2B6B99b6b8c176De8cA237F";
            $amount = '100';
            $contractaddress = "0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2";

            $result = exec('cd ' . $sever_path . '/erc20; node send_erc20_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddress . ' ' . $toaddr . ' ' . $amount . ' ' . $password . ' ' . $contractaddress, $output, $return_var);

            /*echo "<pre>";
                print_r($result);
                echo "<br>";
                print_r($output);
                echo "<br>";
                print_r($return_var);
            */

            $out = json_decode($result);
            return $out->hash;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function trades(Request $request)
    {
        try {
            $pair = $request['pair'];
            if ($pair != 'XDC-XDCE') {
                $trades = TradeMapping::where('pair', $pair)->orderBy('updated_at', 'desc')->limit(100)->get();
                if (isset($trades[0])) {
                    foreach ($trades as $trade) {
                        $id = $trade->id;
                        $timestamp = strtotime($trade->created_at);
                        $price = number_format($trade->triggered_price, '8', '.', '');
                        $amount = number_format($trade->triggered_qty, '0', '.', '');
                        $type = $trade->type;
                        $array = array('id' => $id, 'timestamp' => $timestamp, 'price' => $price, 'amount' => $amount, 'type' => $type);
                        $result[] = $array;
                    }
                } else {
                    $result = [];
                }
            } else {
                $trades = Trade::where('pair', $pair)->where('status', 'completed')->orderBy('updated_at', 'desc')->limit(100)->get();
                if (isset($trades[0])) {
                    foreach ($trades as $trade) {
                        $id = $trade->id;
                        $timestamp = strtotime($trade->created_at);
                        $price = number_format($trade->price, '8', '.', '');
                        $amount = number_format($trade->original_qty, '0', '.', '');
                        $type = $trade->type;
                        $array = array('id' => $id, 'timestamp' => $timestamp, 'price' => $price, 'amount' => $amount, 'type' => $type);
                        $result[] = $array;
                    }
                } else {
                    $result = [];
                }
            }
            return json_encode($result);
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    //bitfinex websockets
    function bitfinex_websocket(Request $request)
    {
        try {

        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }

    }

}
