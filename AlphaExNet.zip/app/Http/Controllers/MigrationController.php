<?php

namespace App\Http\Controllers;

//use App\Jobs\MoveKey;
use App\model\Admin;
use App\model\Balance;
use App\model\Cms;
use App\model\Enquiry;
use App\model\Erc20Details;
use App\model\Erc20Requests;
use App\model\Currencies;
use App\model\Country;
use App\model\ExtraBonus;
use App\model\Faq;
use App\model\Fees;
use App\model\ico;
use App\model\icodetails;
use App\model\ICORate;
use App\model\Marketprice;
use App\model\Metacontent;
use App\model\Node;
use App\model\OpeningBalance;
use App\model\OTP;
use App\model\ICOTrade;
use App\model\Pair;
use App\model\PairStats;
use App\model\Profit;
use App\model\ReferralExtra;
use App\model\ReserveBalances;
use App\model\SiteSettings;
use App\model\Template;
use App\model\Trade;
use App\model\Tokenusers;
use App\model\TradeMapping;
use App\model\Tradingfee;
use App\model\Transaction;
use App\model\Transactionfee;
use App\model\UserBalance;
use App\model\UserBalancesNew;
use App\model\UserCurrencyAddresses;
use App\model\Useractivity;
use App\model\Users;
use App\model\Verification;
use App\model\Wallettrans;
use App\model\Whitelist;
use App\model\XDCChart;
use App\model\Wallet;
use App\model\DeletedUsers;
use App\model\ReferralEarning;
use App\model\ReferralBonus;
use App\model\XdcePass;
use App\model\Xdce_transfer;
use App\model\Favorite;

use Cache;
use DateTime;
use DB;
use Hash;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Session;
use Carbon\Carbon;
use Pusher\Pusher;
use Maatwebsite\Excel\Facades\Excel;
use Validator;
use File;

//use Barryvdh\DomPDF\Facade as PDF;

class MigrationController extends Controller
{
    //
    public function __construct()
    {
        try {
            //$this->middleware('Adminlogin');
            $ip = \Request::ip();
            blockip_list($ip);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function index(Request $request)
    {
        echo "view";
    }

    function getmail(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $mail=[];
                $users_details=Users::where("email",NULL)->Orwhere("email"," ")->paginate($request['limit']);
                for($i = 0;$i<count($users_details);$i++)
                {
                    $email=decrypt($users_details[$i]->end_user1) .'@'. decrypt($users_details[$i]->end_user2);
                    array_push($mail,[$email]);
                    $users_details[$i]->email = $email;
                    $users_details[$i]->save();

                }  
                if($mail==Null){
                    $result = array();
                    $result['status'] = '0';
                    $result['message'] = 'All emails are updated.';
                    return json_encode($result);
                }
                else{
                    $result = array();
                    $result['status'] = '1';
                    $result['result']=$mail;
                    return json_encode($result);
                }
               
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function getcountry(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $country=[];
                $users_details=Users::where('countryName',NULL)->orwhere('countryName','')->paginate($request['limit']);
                $country_name = Country::get();
                
                foreach($users_details as $res){
                    foreach($country_name as $data){
                        $country_id = $res->country;
                        $countryid = $data->id;
                        if($country_id == $countryid){
                            array_push($country,$data->name);
                            $res->countryName = $data->name;
                            $res->save();

                        }
                    }
                }                
                
                // return $country;
                if($country==Null){
                    $result = array();
                    $result['status'] = '0';
                    $result['message'] = 'All Country Names are updated.';
                    return json_encode($result);
                }
                else{
                    $result = array();
                    $result['status'] = '1';
                    $result['result']=$country;
                    return json_encode($result);
                }
               
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function country(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
               $country = Country::get();
            //    return $country;
                
                $result = array();
                $result['status'] = '1';
                $result['result']=$country;
                return json_encode($result);
                
               
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function getpass(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $pass=[];
                $users_details=Users::where("password",NULL)->limit(30)->get();
                for($i = 0;$i<count($users_details);$i++)
                {
                    $password=owndecrypt($users_details[$i]->xinpass);
                    array_push($pass,[$password]);
                    $users_details[$i]->password = $password;
                    $users_details[$i]->save();

                }  
                if($pass==Null){
                    $result = array();
                    $result['status'] = '0';
                    $result['message'] = 'All passwords are updated.';
                    return json_encode($result);
                }
                else{
                    $result = array();
                    $result['status'] = '1';
                    $result['result']=$pass;
                    return json_encode($result);
                }
               
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function getmobile_no(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $mobile_no=[];
                $users_details=Users::where("mobileNo",NULL)->limit(30)->get();
                for($i = 0;$i<count($users_details);$i++)
                {
                    \Log::info(['mobileNo',$users_details[$i]->mobile_no ]);
                    if($users_details[$i]->mobile_no == ''){
                        $email=$users_details[$i]->email;
                        $mob_isd=$users_details[$i]->mob_isd;
                        array_push($mobile_no,["email"=>$email,"ISD"=>$mob_isd,"Mobile Number"=>$users_details[$i]->mobile_no]);
                        $users_details[$i]->mobileNo = $users_details[$i]->mobile_no;
                        $users_details[$i]->update();
                        \Log::info(['Blank',$mobile_no]);
                    }
                    else{
                        $mobileNo=owndecrypt($users_details[$i]->mobile_no);
                        $email=$users_details[$i]->email;
                        $mob_isd=$users_details[$i]->mob_isd;
                        array_push($mobile_no,["email"=>$email,"ISD"=>$mob_isd,"Mobile Number"=>$mobileNo]);
                        $users_details[$i]->mobileNo = $mobileNo;
                        $users_details[$i]->update();
                        \Log::info(['Filled',$mobile_no]);
                    }
                }
                if($mobile_no==Null){
                    $result = array();
                    $result['status'] = '0';
                    $result['message'] = 'All mobile numbers are updated.';
                    return json_encode($result);
                }
                else{
                    $result = array();
                    $result['status'] = '1';
                    $result['result']=$mobile_no;
                    return json_encode($result);
                }
               
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }
    function getmobile(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $mobile_no=$request['mobile_no'];
                
                
                    
                $mobileNo=owndecrypt($mobile_no);
                
                \Log::info(['Filled',$mobileNo]);
                    
                return $mobileNo;
                
               
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }
    function gettfa_details(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $tfa_stats=[];
                $tfa_disabled=[];
                $tfa_null=[];
                $users_details=Users::get();
                for($i = 0;$i<count($users_details);$i++)
                {
                    $tfa_stat=$users_details[$i]->tfa_status;
                   
                    if($tfa_stat=='enable'){
                        $tfaCode=$users_details[$i]->tfa_code;
                        $email=$users_details[$i]->email;
                        array_push($tfa_stats,["email"=>$email,"status"=>$tfa_stat,"tfa details"=>$tfaCode]);
                        // \Log::info(['status',$tfa_stats]);
                    }
                    elseif($tfa_stat=='disable'){
                        $email=$users_details[$i]->email;
                        array_push($tfa_disabled,["email"=>$email,"status"=>$tfa_stat]);
                    }
                    else{
                        $email=$users_details[$i]->email;
                        array_push($tfa_null,["email"=>$email,"status"=>$tfa_stat]);
                    }
                }  
                
                $result = array();
                $result['status'] = 'Enabled TFA';
                $result['message'] = 'Details of enabled TFA users';
                $result['Enabled details'] = $tfa_stats;
                $result['Disabled details'] = $tfa_disabled;
                $result['No TFA details'] = $tfa_null;
                return json_encode($result);
                

                
               
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function getuser(Request $request)
    {
        try{
            
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $validator = Validator::make($request->all(), [
                    'limit' => ''                   
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $mail=[];
                if($request['limit']){
                    $users_details=Users::paginate($request['limit']);
                }
                else{
                    $users_details=Users::paginate(200);
                }
                
                \Log::info(["<<<",$users_details]);
                return $users_details;
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }


    function changeid(Request $request)
    {
        try{
            if ($request->isMethod('get')) {
                //  echo "okay"; exit;
                $mail=[];
                $users_details=Users::limit(30)->get();
                for($i = 0;$i<count($users_details);$i++)
                {
                    $email=$users_details[$i]->email;
                    $id=$users_details[$i]->id;
                    $unique_id=$users_details[$i]->unique_id;
                    array_push($mail,["email"=>$email,"id"=>$id,"unique_id"=>$unique_id]);
                    

                }  
                    return json_encode($mail);
            }
            elseif($request->isMethod('post')){
               
                $validator = Validator::make($request->all(), [
                    'email' => 'required|email',
                    'id' => 'required',
                    'unique_id' => 'required'                    
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $email = $request['email'];
                $id = $request['id'];
                $unique_id = $request['unique_id'];
                
                $upt = Users::where('id', $id)->where('email',$email)->first();
                
                if($upt->unique_id==NULL || $upt->unique_id==" "){
                    $upt->unique_id = $unique_id;
                    $upt->save();
                    $data['status'] = 1;
                    $data['message'] = 'Unique Id Successfully Updated';
                    return json_encode($data);
                    
                }
                else{
                    $data['status'] = 0;
                    $data['message'] = 'Can not change exsisting Unique Id';
                    return json_encode($data);
                }
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e->getMessage());
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function findid(Request $request)
    {
        try{
            if($request->isMethod('post')){
               
                $validator = Validator::make($request->all(), [
                    'data' => 'required',                 
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                // \Log::info(["data"=>$request['data']]);
                $data1 = $request['data'];
                foreach($data1 as $result ){
                    $email = $result['email'];
                    $uniqueid = $result['id'];
                    
                        // \Log::info(["email"=>$email,"id"=>$uniqueid]);
                        $Updated = []; 
                        $upt1 = Users::where('email',$email)->first();
                        $upt = Users::where('email',$email)->update(array('unique_id'=>$uniqueid));
                        
                        $transaction = Transaction::where('user_id',$upt1->id)->update(array('unique_id'=>$uniqueid));
                        // $coin = Profit::where('userId',$upt->id)->get();
                        // $tokenuser = Tokenusers::where('user_id',$upt1->id)->update(array('unique_id'=>$uniqueid));
                        $tradeorder = Trade::where('user_id',$upt1->id)->update(array('uniqueid'=>$uniqueid));
                        $userbal = UserBalance::where('user_id',$upt1->id)->update(array('unique_id'=>$uniqueid));
                        // $userbalnew = UserBalancesNew::where('user_id',$upt1->id)->update(array('unique_id'=>$uniqueid));
                        // $usercurr = UserCurrencyAddresses::where('user_id',$upt1->id)->update(array('unique_id'=>$uniqueid));
                        // $useractivity = Useractivity::where('user_id',$upt1->id)->update(array('unique_id'=>$uniqueid));
                        $verification = Verification::where('user_id',$upt1->id)->update(array('unique_id'=>$uniqueid));
                        // \Log::info(["email",$upt,$upt1,$transaction,$coin,$tokenuser,$userbal,$userbalnew,$usercurr,$useractivity,$verification]);
                        
                }
                    $data['status'] = 1;
                    $data['message'] = 'Unique Id Successfully Updated';
                    // $data['Updates']=$Updated;
                    return json_encode($data);
            }
            
        }
        catch (\Exception $e) {
            \Log::error(["<<<",$e->getMessage()]);
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function getdata(Request $request)
    {
        try{
            if($request->isMethod('post')){
               
                $validator = Validator::make($request->all(), [
                    'id' => 'required' ,
                    'table_name' => 'required'                  
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $id = $request['id'];
                $table_name = $request['table_name'];

                $Updated = []; 

                switch($request['table_name'])
                {
                    case "users":
                        $upt = Users::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['User details',$upt]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "transaction":
                        $transaction = Transaction::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['Transactions',$transaction]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "cointheft":
                        $coin = Profit::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['Coin Theft',$coin]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "tokenuser":
                        $tokenuser = Tokenusers::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['Token Users',$tokenuser]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "tradeorder":
                        $tradeorder = Trade::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['Trade',$tradeorder]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "userbalance":
                        $userbal = UserBalance::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['User Balance',$userbal]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "userbalancenew":
                        $userbalnew = UserBalancesNew::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['User Balance New',$userbalnew]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "usercurrency":
                        $usercurr = UserCurrencyAddresses::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['User Currency',$usercurr]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "useractivity":
                        $useractivity = Useractivity::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['User Activity',$useractivity]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    case "verification":
                        $verification = Verification::where('unique_id',$id)->paginate($request['limit']);
                        array_push($Updated,['Verification',$verification]);
                        $data['status'] = 1;
                        $data['message'] = 'Data of Unique Id '.$id.'from table '.$table_name;
                        $data['Updates']=$Updated;
                        return json_encode($data);
                    break;
                    default:
                        $data['status'] = 0;
                        $data['message'] = 'Data table or unique id does not exists.';
                        return json_encode($data);
                    break;

                }
                
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e);
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function update_verification(Request $request)
    {
        try{
            if($request->isMethod('get')){
               
                $mail=[];
                $users_details=Users::get();
                // \Log::info(['id',$users_details]);
                // $verification =Verification::where('user_id',$users_details)->get();

                for($i=0;$i<count($users_details);$i++){
                    \Log::info(['id',]);
                    $id=$users_details[$i]->id;
                    $email=$users_details[$i]->email;
                    $unique_id=$users_details[$i]->unique_id;
                    $verification =Verification::where('user_id',$id)->get();
                    for($j=0;$j<count($verification);$j++){
                        $user_id = $verification[$j]->user_id;
                        \Log::info(['id',$user_id]);
                        if($id == $user_id){
                            $verification[$j]->email = $email;
                            $verification[$j]->unique_id = $unique_id; 
                            \Log::info(['email'=>$verification[$j]->email,'unique'=>$verification[$j]->unique_id]); 
                            $verification[$j]->save();
                        }
                    }
                }
                $result['status'] = '1';
                $result['message'] = 'Successfully updated details';
                return $result;
                
            }
        }
        catch (\Exception $e) {
            \Log::error("<<<",$e);
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    //changes by rahul for tablewise migration
    function getTableWiseData(Request $request){
        try{
            $table_name = $request['tableName'];
            $Updated = []; 
            switch($table_name)
                {
                    case "users":
                        $upt = Users::paginate($request['limit']);
                        // array_push($Updated,$upt);
                        $data['status'] = 1;
                        $data['message'] = 'Data from table '.$table_name;
                        $data['data']=$upt;
                        return json_encode($data);
                    break;
                    case "transaction":
                        $transaction = Transaction::paginate($request['limit']);
                        // array_push($Updated,$transaction);
                        $data['status'] = 1;
                        $data['message'] = 'Data of table '.$table_name;
                        $data['data']=$transaction;
                        return json_encode($data);
                    break;
                    case "cointheft":
                        $coin = Profit::paginate($request['limit']);
                        // array_push($Updated,$coin);
                        $data['status'] = 1;
                        $data['message'] = 'Data of table '.$table_name;
                        $data['data']=$coin;
                        return json_encode($data);
                    break;
                    case "tokenuser":
                        $tokenuser = Tokenusers::paginate($request['limit']);
                        // array_push($Updated,$tokenuser);
                        $data['status'] = 1;
                        $data['message'] = 'Data of table '.$table_name;
                        $data['data']=$tokenuser;
                        return json_encode($data);
                    break;
                    case "tradeorder":
                        $tradeorder = Trade::paginate($request['limit']);
                        // array_push($Updated,$tradeorder);
                        $data['status'] = 1;
                        $data['message'] = 'Data of table '.$table_name;
                        $data['data']=$tradeorder;
                        return json_encode($data);
                    break;
                    case "userbalance":
                        $userbal = UserBalance::paginate($request['limit']);
                        // array_push($Updated,$userbal);
                        $data['status'] = 1;
                        $data['message'] = 'Data of table '.$table_name;
                        $data['data']=$userbal;
                        return json_encode($data);
                    break;
                    case "userbalancenew":
                        $userbalnew = UserBalancesNew::paginate($request['limit']);
                        // array_push($Updated,$userbalnew);
                        $data['status'] = 1;
                        $data['message'] = 'Data of table '.$table_name;
                        $data['data']=$userbalnew;
                        return json_encode($data);
                    break;
                    case "usercurrency":
                        $usercurr = UserCurrencyAddresses::paginate($request['limit']);
                        // array_push($Updated,$usercurr);
                        $data['status'] = 1;
                        $data['message'] = 'Data of table '.$table_name;
                        $data['data']=$usercurr;
                        return json_encode($data);
                    break;
                    case "useractivity":
                        $useractivity = Useractivity::paginate($request['limit']);
                        // array_push($Updated,$useractivity);
                        $data['status'] = 1;
                        $data['message'] = 'Data of  table '.$table_name;
                        $data['data']=$useractivity;
                        return json_encode($data);
                    break;
                    case "verification":
                        $verification = Verification::paginate($request['limit']);
                        // array_push($Updated,$verification);
                        $data['status'] = 1;
                        $data['message'] = 'Data of  table '.$table_name;
                        $data['data']=$verification;
                        return json_encode($data);
                    break;
                    case "trademapping":
                        $tradeMappings = TradeMapping::paginate($request['limit']);
                        $data['status'] = 1;
                        $data['message'] = 'Data of  table '.$table_name;
                        $data['data']=$tradeMappings;
                        return json_encode($data);
                    case "fav":
                        $fav = Favorite::all();
                        $data['status'] = 1;
                        $data['message'] = 'Data of  table '.$table_name;
                        $data['data']=$fav;
                        return json_encode($data);
                    default:
                        $data['status'] = 0;
                        $data['message'] = 'Data table or unique id does not exists.';
                        return json_encode($data);
                    break;

                }
                
            }
            catch (\Exception $e) {
                \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
                $response = array();
                $response['status'] = '0';
                $response['message'] = 'Server Error.';
                return json_encode($response);
            }        
    }

    function tradeMappingData(Request $request){
    try{
        $page = $request['limit'];
        $tradeMappingDatas = TradeMapping::where('lastUpdated',0)->orderBy('id')->paginate($page);
        foreach($tradeMappingDatas as $tradeMapping){
            try{
                $getBuyTradeId = Trade::where('id',$tradeMapping->buy_trade_order_id)->first();
            }catch(\Exception $e){
                $getBuyTradeId = null;
                $getBuyer =null;
            }
            try{
                $getSellTradeId = Trade::where('id',$tradeMapping->sell_trade_order_id)->first();
            }catch(\Exception $e){
                $getSellTradeId = null;
                $getSeller = null;
            }
            try{
                if($getBuyTradeId != null){
                    $getBuyer = Users::where('id',$getBuyTradeId->user_id)->first();
                } 
                else{
                    $getBuyer = null;
                } 
            }catch(\Exception $e){
                $getBuyer = null;
            }
            try{
                if($getSellTradeId != null){
                    $getSeller = Users::where('id',$getSellTradeId->user_id)->first();
                }else{
                    $getSeller = null;
                }   
            }catch(\Exception $e){
                $getSeller = null;
            }
            
            // $responses = array();
            // $responses['status'] = '200';
            // $responses['buy'] = $getBuyTradeId;
            // $responses['sell'] = $getSellTradeId;
            // $responses['buyer'] = $getBuyer;
            // $responses['seller'] = $getSeller;
            // return json_encode($responses);
            if($getBuyTradeId == null){
                $tradeMapping->buyOrder = 'N.A';
            }else{
                $tradeMapping->buyOrder = $getBuyTradeId->trade_id;
            }
            if($getSellTradeId == null){
                $tradeMapping->sellOrder = 'N.A';
            }else{
                $tradeMapping->sellOrder = $getSellTradeId->trade_id;
            }
            if($getBuyer == null){
                $tradeMapping->buyerEmail = 'N.A';
            }else{
                $tradeMapping->buyerEmail = $getBuyer->email;
            }
            if($getSeller == null){
                $tradeMapping->sellerEmail = 'N.A';
            }else{
                $tradeMapping->sellerEmail = $getSeller->email;
            }
            $tradeMapping->lastUpdated = 1;
            $tradeMapping->update();
        }
        $response = array();
                $response['status'] = '200';
                $response['message'] = 'Success.';
        return json_encode($response);
    }catch (\Exception $e) {
                \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
                $response = array();
                $response['status'] = '0';
                $response['message'] = 'Server Error.';
                return json_encode($response);
            } 
    }

    function tradeMappingByData(Request $request){
        try{
            $limit = $request['limit'];
            $tradeMappings = TradeMapping::paginate($limit);


        }catch (\Exception $e) {
                \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
                $response = array();
                $response['status'] = '0';
                $response['message'] = 'Server Error.';
                return json_encode($response);
            } 
    }

    function favpair(Request $request){
        try{
            $getAllPairs = Favorite::all();
            foreach($getAllPairs as $getPair){
                $user_id = $getPair->user_id;
                $pair_id = $getPair->pair_id;
                $getUser = Users::where('id',$user_id)->first();
                $getPairs = Pair::where('id',$pair_id)->first();
                $response = array();
                // $response['status'] = $getUser;
                // $response['message'] = $getPairs;
                // $response['pair'] = $getPair;
                // return json_encode($response);
                if($getPairs != null && $getUser != null){
                    $getPair->email = $getUser->email;
                    $getPair->pair = $getPairs->pair;
                    $getPair->uniqueId = $getUser->unique_id;
                    $getPair->update();
                }
            }
            $response = array();
                $response['status'] = '200';
                $response['message'] = 'successfully migrated.';
                return json_encode($response);
        }catch (\Exception $e) {
                \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
                $response = array();
                $response['status'] = '0';
                $response['message'] = 'Server Error.';
                return json_encode($response);
            } 
    }
    //changes by rahul for tablewise migration
}
