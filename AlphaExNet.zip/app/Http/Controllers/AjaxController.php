<?php

namespace App\Http\Controllers;

use App\model\ICORate;
use App\model\OTP;
use App\model\Trade;
use App\model\UserBalance;
use App\model\Users;
use App\model\XDCChart;
use App\model\Balance;
use App\model\Transaction;
use App\model\Favorite;
use App\model\Pair;
use App\model\PairStats;
use App\model\Currencies;
use App\model\Transactionfee;
use App\model\TradeMapping;
use http\Env\Response;
use Pusher\Pusher;
use App\model\ReferralEarning;
use App\model\ReferralExtra;
use App\model\ExtraBonus;
use Hash;
use Illuminate\Http\Request;
use Session;
use DB;

class AjaxController extends Controller
{
    //

    function index()
    {
        abort(404);
    }

    function checkemail(Request $request)
    {

        if ($request->isMethod('post')) {
            $email = $request['email_id'];
            $spl = explode("@", $email);
            $user1 = $spl[0];
            $user2 = $spl[1];
            $res = $this->checking($user1, $user2);
            echo $res;

        }
    }

    //for user verification
    function user_verification($id)
    {
        if (Session::get('alpha_id') == "") {
            return redirect('prashaasak');
        } else {
            $get_user = Users::where('id', $id)->first();

            if ($get_user->user_verified == 0) {
                $get_user->user_verified = 1;
            } else {
                $get_user->user_verified = 0;
            }
            if ($get_user->save()) {
                return 1;

            } else {
                return 0;
            }
        }

    }


    function checking($end_user1, $end_user2)
    {
        $items = Users::all()->filter(function ($record) use ($end_user1, $end_user2) {
            if (decrypt($record->end_user1) == $end_user1 && decrypt($record->end_user2) == $end_user2) {
                echo "false";
            } else {
                echo "true";
            }
        });

    }

    function checkphone(Request $request)
    {
        if ($request->isMethod('post')) {
            $mobile_no = $request['mobile_no'];
            if ($request['user_id']) {
                $user_id = $request['user_id'];
                $user = Users::where('id', '=', $user_id)->first();
                $user->mobile_no = ownencrypt($mobile_no);
                if ($user->isDirty('mobile_no')) {
                    $numbers = Users::where('mobile_no', '=', $user->mobile_no)->first();
                    if ($numbers == null) {
                        $data['message'] = 0;
                    } else {
                        $data['message'] = 1;
                        Session::flash('error', 'The Phone Number Already Exsits.');
                    }
                } else {
                    $data['message'] = 0;
                }
            } else {
                $numbers = Users::where('mobile_no', '=', ownencrypt($mobile_no))->first();
                if ($numbers == null) {
                    $data['message'] = 0;
                } else {
                    $data['message'] = 1;
                }
            }
            echo json_encode($data);
        }
    }

    function registerotp(Request $request)
    {
        if ($request->isMethod('post')) {
            $isdcode = $request['isdcode'];
            $phone = $request['phone'];
            $email = $request['reg_email'];
            $type = $request['type'];
            $otp = get_otpnumber('0', $isdcode, $phone, $type, 'sms');
            if (is_numeric($otp)) {
                $to = '+' . $isdcode . $phone;
                $text = "Alphaex authentication code is " . $otp;
                send_sms($to, $text);
                $ansurl = url('ticker/getxmlres/' . $otp);
//				voiceotp($to, $ansurl);

                $to = $email;
                $subject = get_template('9', 'subject');
                $message = get_template('9', 'template');
                $mailarr = array(
                    '###OTP###' => $otp,
                    '###SITENAME###' => get_config('site_name'),
                    '###SITELINK###' => url('/'),
                );
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                //sendmail($to, $subject, ['content' => $message]);
                $res = array('status' => 1, 'sms' => 'send', 'message' => 'OTP has been successfully sent to your registered mobile number.');
            } else {
                $res = array('status' => 0, 'sms' => 'notsend', 'message' => 'OTP failed.');
            }
            //echo Response::json($res);
            $var = json_encode($res);
            return $var;
//            echo $var;
//            echo json_encode($res);
        }
    }

    function otp_call($id)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $mobile = get_user_details($id, 'mobile_no');
            $isd_code = get_user_details($id, 'mob_isd');
            $check = OTP::where('mobile_no', $mobile)->orderBy('id', 'desc')->limit(1)->first();

            $otp = owndecrypt($check->otp);
            $to = '+' . $isd_code . owndecrypt($mobile);
            $ansurl = url('https://alphaex.net/ticker/getxmlres/' . $otp);
            $result = voiceotp($to, $ansurl);

            if ($result == true) {
                $res = array('status' => 1, 'sms' => 'Call Sent');
            } else {
                $res = array('status' => 0, 'sms' => 'Call not sent contact Support to verify your issue');
            }
        }
    }

    function otpcall(Request $request)
    {
        $mobile = $request['mobile'];
        $isd_code = $request['isdcode'];
        $check = OTP::where('mobile_no', ownencrypt($mobile))->orderBy('id', 'desc')->first();
        $otp = owndecrypt($check->otp);
        $to = '+' . $isd_code . $mobile;
        $ansurl = url('https://alphaex.net/ticker/getxmlres/' . $otp);
        $result = voiceotp($to, $ansurl);
        if ($result == true) {
            $res = array('status' => 1, 'sms' => 'Call Sent');
        } else {
            $res = array('status' => 0, 'sms' => 'Call not sent contact Support to verify your issue');
        }
        echo json_encode($res);
    }

    function verify_otp(Request $request)
    {
        if ($request->isMethod('post')) {
            $code = $request['verify_code'];
            $mobile = $request['mobile'];
            $user_id = $request['user_id'];
            $vcode = ownencrypt($code);
            /*$check = OTP::where('mobile_no', ownencrypt($mobile))->where('otp', ownencrypt($code))->orderBy('id', 'desc')->limit(1)->first();*/
            $check = OTP::where('mobile_no', ownencrypt($mobile))->orderBy('id', 'desc')->limit(1)->first();
            if (count($check) > 0 && $check->otp == $vcode) {

                $data['message'] = "Mobile verified successfully";
                $data['status'] = 1;
                $data['key'] = encrypt($mobile . '#' . $check->otp);
                $check->delete();
                if ($user_id != 0) {
                    $user = Users::where('id', $user_id)->first();
                    if ($user_id != 0) {
                        $user = Users::where('id', $user_id)->first();
                        $user->mobile_no = ownencrypt($mobile);
                        if ($user->mobile_status != 1) {
                            $user->mobile_status = 1;
                            Session::flash('success', 'Your Mobile verification has been completed.');
                        }
                        $user->save();
                    }
                }

            } else {
                $data['message'] = "Enter valid code";
                $data['status'] = 0;
                $data['key'] = encrypt('wrong');
            }
            echo json_encode($data);
        }
    }

    function refresh_capcha()
    {
        return captcha_img();
    }

    function get_currency_address(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            }
            if (!Session::get('JWT_TOKEN') == $request->header('JWT_TOKEN')) {
                Session::flush();
                return redirect('logout');

            } else {
                if ($request->isMethod('post')) {
                    $userid = Session::get('alphauserid');
                    $oldpass = $request['currency'];
                    if ($oldpass == 'XRP_addr') {
                        $recordpass = get_user_details($userid, 'xrp_desttag');

                    } else {
                        $recordpass = get_user_details($userid, $oldpass);
                    }

                    if ($recordpass) {
                        echo $recordpass;
                    } else {
                        echo "error";
                    }

                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }

    }

//    particular open order record
    function openorders(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            }
//            if(!Session::get('JWT_TOKEN')==$request->header('JWT_TOKEN'))
//            {
//                Session::flush();
//                return redirect('logout');
//
//            }
            else {
                if ($request->isMethod('post')) {
                    $user_id = $request['user_id'];
                    $pair = $request['pair'];
                    if ($user_id == Session::get('alphauserid')) {

                        $active_orders = Trade::select('id', 'created_at', 'type', 'updated_qty', 'price', 'total', 'updated_total', 'status')->where(['user_id' => $user_id, 'pair' => $pair])->where(function ($query) {
                            $query->where('status', 'active')->Orwhere('status', 'partially');
                        })->orderBy('id', 'desc')->limit(10)->get()->toJson();
                        return $active_orders;
                    } else {
                        return 0;
                    }

                }

            }
        } catch (\Exception $exception) {
            return 0;
        }
    }

    // USER TRADE HISTORY
    function mytradehistory(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            }
            if (!Session::get('JWT_TOKEN') == $request->header('JWT_TOKEN')) {
                Session::flush();
                return redirect('logout');

            } else {
                if ($request->isMethod('post')) {
                    $user_id = $request['user_id'];
                    $pair = $request['pair'];
                    if ($user_id == Session::get('alphauserid')) {

                        $active_orders = Trade::where(['pair' => $pair, 'user_id' => $user_id])
                            ->whereIn('status', ['completed', 'partially'])->orderBy('updated_at', 'desc')->limit(10)->get()->toJson();
                        return $active_orders;
                    } else {
                        return 0;
                    }

                }

            }
        } catch (\Exception $exception) {
            return 0;
        }

    }

    //market_order_availability
    function available_market_data(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            }
            if (!Session::get('JWT_TOKEN') == $request->header('JWT_TOKEN')) {
                Session::flush();
                return redirect('logout');

            } else {
                if ($request->isMethod('post')) {
                    $user_id = Session::get('alphauserid');
                    $pair = $request['pair'];

                    $findorders = Trade::where('user_id', '<>', $user_id)->where(['pair' => $pair, 'type' => 'Sell'])->where(function ($query) {
                        $query->where('status', 'active')->Orwhere('status', 'partially');
                    })->orderBy('price', 'asc')->sum('updated_qty');
                    $find_buy_orders = number_format($findorders, 0, '.', '');

                    $findorders = Trade::where('user_id', '<>', $user_id)->where(['pair' => $pair, 'type' => 'Buy'])->where(function ($query) {
                        $query->where('status', 'active')->Orwhere('status', 'partially');
                    })->orderBy('price', 'desc')->sum('updated_qty');
                    $find_sell_orders = number_format($findorders, 0, '.', '');

                    if ($find_buy_orders > 0 && $find_sell_orders > 0) {
                        $data['status'] = 200;
                        $data['total'] = $find_buy_orders;
                        $data['amount'] = $find_sell_orders;
                        return json_encode($data);
                    } else {
                        if ($find_buy_orders == 0 && $find_sell_orders == 0) {
                            $data['status'] = 401;
                            $data['message'] = 'No active orders available';
                            return json_encode($data);
                        } elseif ($find_buy_orders == 0) {
                            $data['status'] = 422;
                            $data['message'] = 'No active buy orders available';
                            $data['total'] = $find_buy_orders;
                            $data['amount'] = $find_sell_orders;
                            return json_encode($data);
                        } elseif ($find_sell_orders == 0) {
                            $data['status'] = 422;
                            $data['message'] = 'No active sell orders available';
                            $data['total'] = $find_buy_orders;
                            $data['amount'] = $find_sell_orders;
                            return json_encode($data);
                        }

                    }
                }
            }

        } catch (\Exception $exception) {
            $data['status'] = '500';
            $data['message'] = 'Server Error';
            return json_encode($data);
        }
    }

    function checkoldpass(Request $request)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            if ($request->isMethod('post')) {
                $userid = Session::get('alphauserid');
                $oldpass = $request['old_password'];
                $recordpass = get_user_details($userid, 'pass_code');
                if (Hash::check($oldpass, $recordpass)) {
                    echo "true";
                } else {
                    echo "false";
                }

            }
        }
    }

    function verifyotp(Request $request)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            if ($request->isMethod('post')) {
                $userid = Session::get('alphauserid');
                $isdcode = $request['isdcode'];
                $phone = $request['phone'];
                $type = $request['type'];
                if ($type == 'Update') {
                    $check = Users::where('id', $userid)->where('mobile_no', ownencrypt($phone))->count();
                    if ($check > 0) {
                        $res = array('status' => 0, 'sms' => 'This Current mobile number');
                        echo json_encode($res);
                        exit;
                    }
                }
                $otp = get_otpnumber($userid, $isdcode, $phone, $type, 'sms');
                if (is_numeric($otp)) {
                    $to = '+' . $isdcode . $phone;
                    $text = "Alphaex authentication code is " . $otp;
                    send_sms($to, $text);
                    $ansurl = url('ticker/getxmlres/' . $otp);
//                    voiceotp($to, $ansurl);
                    $res = array('status' => 1, 'sms' => 'send', 'message' => 'OTP has been successfully sent to your registered mobile number.');
                } else {
                    $res = array('status' => 0, 'sms' => 'notsend', 'message' => 'OTP failed.');
                }
                //echo Response::json($res);
                echo json_encode($res);
            }
        }

    }

    function limit_balance(Request $request)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        }
//        if(!Session::get('JWT_TOKEN')==$request->header('JWT_TOKEN'))
//        {
//            Session::flush();
//            return redirect('logout');
//
//        }
//        else {
        if ($request->isMethod('post')) {
            $userid = Session::get('alphauserid');
            $amount = $request['to_amount'];
            $curr = $request['curr'];
            $getuserbal = get_userbalance($userid, $curr);
            if ($amount <= $getuserbal) {
                $data = "true";
            } else {
                $data = "false";
            }
            if ($data == 'true') {
                $response['status'] = '1';
                $response['message'] = 'Success';
                return json_encode($response);
            } else {
                $response['status'] = '0';
                $response['message'] = 'Insufficient Balance';
                return json_encode($response);
            }
        }
//        }
    }

    function generate_otp(Request $request)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            if ($request->isMethod('post')) {
                $userid = Session::get('alphauserid');
                $type = $request['type'];
                $mob = get_user_details($userid, 'mobile_no');
                $phone = owndecrypt($mob);
                $isdcode = get_user_details($userid, 'mob_isd');
                $otp = get_otpnumber($userid, $isdcode, $phone, $type, 'call');
                $to = '+' . $isdcode . $phone;
                $text = "Alphaex OTP code is " . $otp . " Please dont share your otp";
                //send_sms($to, $text);
                $ansurl = url('/ticker/getxmlres/' . $otp);
                voiceotp($to, $ansurl);
                echo "sent";
            }
        }
    }

    function generate_email_otp(Request $request)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            if ($request->isMethod('post')) {
                $userid = Session::get('alphauserid');
                $type = $request['type'];
                $isdcode = get_user_details($userid, 'mob_isd');
                $mob = get_user_details($userid, 'mobile_no');
                $phone = owndecrypt($mob);
                $email = get_usermail($userid);
                $otp = get_otpnumber($userid, $isdcode, $phone, $type, 'email');

                $to = $email;
                $subject = 'Withdrawal OTP';
                $message = get_template('9', 'template');
                $mailarr = array(

                    '###OTP###' => $otp,
                    '###SITENAME###' => get_config('site_name'),
                );
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                sendmail($to, $subject, ['content' => $message]);
                $data['status'] = '1';
                $data['message'] = 'Please check your email address for the OTP';
                return json_encode($data);
            }
        }
    }

    function otp_test(Request $request)
    {
        $to = $request['num'];
        $ans = $request['url'];
        voiceotp($to, $ans);
        echo "sent";
    }

    function exchange_chart($pair)
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $pair = $pair ? $pair : 'XDC-ETH';
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $result = XDCChart::select($second_currency, 'created_at')->orderBy('id', 'desc')->limit(15)->get();
            $chart = "";
            foreach ($result as $val) {
                $date1 = date('Y-m-d', strtotime($val->created_at));
                $dat = strtotime($date1) * 1000;
                $chart .= "[" . $dat . ',' . $val->$second_currency . "],";

            }
            echo "[" . trim($chart, ",") . "]";

        }
    }

    function address_validation(Request $request)
    {
        if ($request->isMethod('post')) {
            $currency = $request['curr'];
            $toaddr = $request['to_addr'];
            if ($currency == 'BTC') {
                $url = "https://blockchain.info/rawaddr/" . $toaddr;

                $cObj = curl_init();
                curl_setopt($cObj, CURLOPT_URL, $url);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                $btc = json_decode(curl_exec($cObj));
                $curlinfos = curl_getinfo($cObj);
                $data = (count($btc) > 0) ? 'true' : 'false';
            } else if ($currency == 'BCH') {
                $url = "https://blockchain.info/rawaddr/" . $toaddr;

                $cObj = curl_init();
                curl_setopt($cObj, CURLOPT_URL, $url);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                $bch = json_decode(curl_exec($cObj));
                $curlinfos = curl_getinfo($cObj);
                $data = (count($bch) > 0) ? 'true' : 'false';
            } else if ($currency == 'XDC') {

                if (strlen($toaddr) == 43) {
                    if (substr($toaddr, 0, 3) != 'xdc') {
                        $data = 'false';
                    } else {
                        $data = 'true';
                    }
                } else {
                    $data = 'false';
                }
//                //$toaddr = strtolower($toaddr);
////                $res = verify_xdc_addr($toaddr);
//                $data = ($res->status == 'SUCCESS') ? 'true' : 'false';
            } elseif ($currency == 'XRP') {
                $url = "https://data.ripple.com/v2/accounts/" . $toaddr . "/balances?currency=XRP";

                $cObj = curl_init();
                curl_setopt($cObj, CURLOPT_URL, $url);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                $xrp = json_decode(curl_exec($cObj));
                $curlinfos = curl_getinfo($cObj);
                $data = ($xrp->result == 'error' && @$xrp->message == 'invalid ripple address') ? 'false' : 'true';
            } else {
                $data = "true";
            }
            if ($data == 'true') {
                $response['status'] = '1';
                $response['message'] = 'Success';
                return json_encode($response);
            } else {
                $response['status'] = '0';
                $response['message'] = 'Invalid Address';
                return json_encode($response);
            }
        }
    }

    function get_instant_buy_form($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $second_cur_balance = get_userbalance($userid, $second_currency);
            return view('trade.inst_buy', ['first_currency' => $first_currency, 'second_currency' => $second_currency, 'second_cur_balance' => $second_cur_balance]);
        }
    }

    function get_instant_sell_form($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $first_cur_balance = get_userbalance($userid, $first_currency);
            return view('trade.inst_sell', ['first_currency' => $first_currency, 'second_currency' => $second_currency, 'first_cur_balance' => $first_cur_balance]);
        }
    }

    function get_limit_buy_form($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $second_cur_balance = get_userbalance($userid, $second_currency);
            $first_cur_balance = get_userbalance($userid, $first_currency);

            $buy_rate = get_buy_market_rate($first_currency, $second_currency);
            $sell_rate = get_sell_market_rate($first_currency, $second_currency);

            return view('trade.limit_buy', ['first_currency' => $first_currency, 'second_currency' => $second_currency, 'second_cur_balance' => $second_cur_balance, 'first_cur_balance' => $first_cur_balance, 'buy_rate' => $buy_rate, 'sell_rate' => $sell_rate]);
        }
    }


    function get_limit_sell_form($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $second_cur_balance = get_userbalance($userid, $second_currency);
            $first_cur_balance = get_userbalance($userid, $first_currency);

            $buy_rate = get_buy_market_rate($first_currency, $second_currency);
            $sell_rate = get_sell_market_rate($first_currency, $second_currency);

            return view('trade.limit_sell', ['first_currency' => $first_currency, 'second_currency' => $second_currency, 'second_cur_balance' => $second_cur_balance, 'first_cur_balance' => $first_cur_balance, 'buy_rate' => $buy_rate, 'sell_rate' => $sell_rate]);
        }
    }

    function get_stop_buy_form($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $second_cur_balance = get_userbalance($userid, $second_currency);
            $first_cur_balance = get_userbalance($userid, $first_currency);

            $buy_rate = get_buy_market_rate($first_currency, $second_currency);
            $sell_rate = get_sell_market_rate($first_currency, $second_currency);

            return view('trade.stop_buy', ['first_currency' => $first_currency, 'second_currency' => $second_currency, 'second_cur_balance' => $second_cur_balance, 'first_cur_balance' => $first_cur_balance, 'buy_rate' => $buy_rate, 'sell_rate' => $sell_rate]);
        }
    }

    function get_stop_sell_form($pair = "")
    {
        if (Session::get('alphauserid') == "") {
            return redirect('logout');
        } else {
            $userid = Session::get('alphauserid');
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $second_cur_balance = get_userbalance($userid, $second_currency);
            $first_cur_balance = get_userbalance($userid, $first_currency);

            $buy_rate = get_buy_market_rate($first_currency, $second_currency);
            $sell_rate = get_sell_market_rate($first_currency, $second_currency);

            return view('trade.stop_sell', ['first_currency' => $first_currency, 'second_currency' => $second_currency, 'second_cur_balance' => $second_cur_balance, 'first_cur_balance' => $first_cur_balance, 'buy_rate' => $buy_rate, 'sell_rate' => $sell_rate]);
        }
    }

    function get_buy_tradeorders($pair = "")
    {

        $buy_order_list = Trade::where(['pair' => $pair, 'Type' => 'Sell'])->where(function ($query) {
            $query->where('status', 'active')->Orwhere('status', 'partially');
        })->orderBy('id', 'desc')->get();
        return view('trade.autobuyorders', ['buy_order_list' => $buy_order_list]);
    }

    function get_sell_tradeorders($pair = "")
    {

        $sell_order_list = Trade::where(['pair' => $pair, 'Type' => 'Buy'])->where(function ($query) {
            $query->where('status', 'active')->Orwhere('status', 'partially');
        })->orderBy('id', 'desc')->get();
        return view('trade.autosellorders', ['sell_order_list' => $sell_order_list]);
    }

    function get_estimatme_usdbalance(Request $request)
    {
        if ($request->isMethod('get')) {
            $currency = $request['currency'];
            //$amount = $request['amount'];
            $amount = 1;
            $price = $request['price'];
            $cur_price = get_estusd_price($currency, $amount);
            echo $cur_price * $price;
        }
    }

    function btc_deposit_process_user($user_addr)
    {
        $date = date('Y-m-d');
        $time = date('h:i:s');
        $bitcoin = get_btc_transactionlist();
        $bitcoin_isvalid = $bitcoin->listtransactions();

        if ($bitcoin_isvalid) {
            for ($i = 0; $i < count($bitcoin_isvalid); $i++) {
                if ($bitcoin_isvalid[$i]['address'] == $user_addr)
                    break;
            }
            $account = $bitcoin_isvalid[$i]['account'];
            $address = $bitcoin_isvalid[$i]['address'];
            $category = $bitcoin_isvalid[$i]['category'];
            $btctxid = $bitcoin_isvalid[$i]['txid'];
            if ($category == 'receive') {
                $isvalid = $bitcoin->gettransaction($btctxid);
                $det_category = $isvalid['details'][0]['category'];
                if ($det_category == "receive") {
                    $btcaccount = $isvalid['details'][0]['account'];
                    $btcaddress = $isvalid['details'][0]['address'];
                    $bitcoin_balance = $isvalid['details'][0]['amount'];
                    $btcconfirmations = $isvalid['confirmations'];
                } else {
                    $btcaccount = $isvalid['details'][1]['account'];
                    $btcaddress = $isvalid['details'][1]['address'];
                    $bitcoin_balance = $isvalid['details'][1]['amount'];
                    $btcconfirmations = $isvalid['confirmations'];
                }
                $amount = $bitcoin_balance;
                if ($btcconfirmations >= 3) {
                    $userid = get_userid_btcaddr($btcaddress);
                    if (is_numeric($userid)) {
                        $checktrans = Transaction::where('type', 'Deposit')->where('wallet_txid', $btctxid)->first();
                        if (count($checktrans) == 0) {
                            $fetchbalance = get_userbalance($userid, 'BTC');
                            $finalbalance = $fetchbalance + $bitcoin_balance;
                            $upt = Balance::where('user_id', $userid)->first();
                            $upt->BTC = $finalbalance;
                            $upt->save();

                            $transid = 'TXD' . $userid . time();
                            $today = date('Y-m-d H:i:s');
                            $ip = \Request::ip();
                            $ins = new Transaction;
                            $ins->user_id = $userid;
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;
                            $ins->currency_name = 'BTC';
                            $ins->type = 'Deposit';
                            $ins->transaction_type = '1';
                            $ins->amount = $bitcoin_balance;
                            $ins->updated_at = $today;
                            $ins->crypto_address = $btcaddress;
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = $btctxid;
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';
                            if ($ins->save()) {
                                $this->deposit_mail($userid, $bitcoin_balance, $transid, 'BTC');
                                $pusher = new Pusher('427b3e2b5664f25aa88f', '5a2be92b0e6a4cc90024', '606412', array('cluster' => 'ap2'));

                                $pusher->trigger('private-transaction_' . $userid, 'deposit-event', array('User_id' => $userid, 'Transaction_id' => $transid, 'Currency' => 'BTC', 'Amount' => $bitcoin_balance, 'Status' => 'Completed', 'Time' => $today));

                            }
                        }
                    }
                }
            }
        }
    }

    function geticorate(Request $request)
    {
        try {
            $first_currency = $request['first_currency'];
            $second_currency = $request['second_currency'];
            $ico_rate = ICORate::where('FirstCurrency', $first_currency)->where('SecondCurrency', $second_currency)->first();
            $price = $ico_rate->Amount;
            return $price;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function add_fav(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['user_id']) {
                    $user_id = $request['user_id'];
                    $pair_id = $request['pair_id'];
                    $check = Favorite::where('user_id', $user_id)->where('pair_id', $pair_id)->first();
                    if (count($check) > 0) {
                        $data['status'] = '0';
                        $data['message'] = 'Pair already added as favourite.';
                    } else {
                        $fav = new Favorite;
                        $fav->user_id = $user_id;
                        $fav->pair_id = $pair_id;
                        if ($fav->save()) {
                            $data['status'] = '1';
                            $data['message'] = 'Pair added as favourite.';
                        } else {
                            $data['status'] = '0';
                            $data['message'] = 'Server Error.';
                        }
                    }
                    $data = json_encode($data);
                    return $data;
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function remove_fav(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['user_id']) {
                    $user_id = $request['user_id'];
                    $pair_id = $request['pair_id'];
                    $fav = Favorite::where('user_id', $user_id)->where('pair_id', $pair_id)->first();
                    if (isset($fav)) {
                        if ($fav->delete()) {
                            $data['status'] = '1';
                            $data['message'] = 'Pair deleted from favourites.';
                        } else {
                            $data['status'] = '0';
                            $data['message'] = 'Server Error';
                        }
                        $data = json_encode($data);
                        return $data;
                    } else {
                        $data['status'] = 0;
                        $data['message'] = 'Not a favourite pair.';
                        return json_encode($data);
                    }
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function updateprice()
    {
        try {
            $get_all_pairs = Pair::all();
            if ($get_all_pairs) {
                foreach ($get_all_pairs as $get_all_pair) {
                    $get_pair_stat = PairStats::where('pair_id', $get_all_pair->id)->first();
                    $explode = explode('-', $get_all_pair->pair);
                    $first_currency = $explode[0];
                    $currency = $explode[1];
                    $pair1 = $get_all_pair->pair;
                    $id = $get_pair_stat->id;
                    $pair_id = $get_pair_stat->pair_id;
                    $vol = $get_pair_stat->volume;
                    $low = $get_pair_stat->low;
                    $high = $get_pair_stat->high;
                    $last = $get_pair_stat->last;
                    $percentage_change = $get_pair_stat->percent_change . '%';
                    $change = $get_pair_stat->change;
                    $color = strtolower($get_pair_stat->colour);

                    $array = array('id' => $id, 'pair_id' => $pair_id, 'first_currency' => $first_currency, 'currency' => $currency, 'Pair' => $pair1, 'Volume' => number_format($vol, 4, '.', ''), 'Low' =>
                        number_format($low, 8, '.', ''),
                        'High' => number_format($high, 8, '.', ''), 'Percentage' => $percentage_change, 'Change' => number_format($change, 8, '.', ''), 'Colour' => $color, 'Last' => number_format($last, '8', '.', ''));
                    $all_pair[] = $array;
                }
            }
            $data = $all_pair;
            return $data;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function updaterate(Request $request)
    {
        try {
            $pair = $request['pair'];
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            $buy_rate = get_buy_market_rate($first_currency, $second_currency);
            $sell_rate = get_sell_market_rate($first_currency, $second_currency);
            $data = ['buy_rate' => $buy_rate, 'sell_rate' => $sell_rate];
            return $data;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function updatebalance(Request $request)
    {
        try {
            if (!Session::get('JWT_TOKEN') == $request->header('JWT_TOKEN')) {
                Session::flush();
                return redirect('logout');

            } else {
                $user_id = base64_decode($request['userid']);
                $all_currency = Currencies::all();
                foreach ($all_currency as $currency) {
                    $curr = $currency->currency_symbol;
                    $bal = get_userbalance($user_id, $curr);
                    $array = array('curr' => $curr, 'bal' => $bal);
                    $user_balance[] = $array;
                }
                return $user_balance;
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function getfee(Request $request)
    {
        try {
            $currency = $request['curr'];
            $data = Transactionfee::where('currency', $currency)->first();
            $fee = number_format($data->withdrawal_fee, '8', '.', '');
            return $fee;
        } catch (\Exception $e) {
            return 0;
        }
    }

    function btcusdc()
    {
        try {
            $get_datas = json_decode(get_liquid_history());
            $datas = $get_datas->models;
            foreach ($datas as $getdata) {
                $last_data = Trade::where('pair', 'BTC-USDC')->where('trade_id', $getdata->id)->orderBy('id', 'desc')->first();
                if ($last_data == null) {
                    $txd_id = 'LQD' . $getdata->id;
                    $trade = new Trade();
                    $date = gmdate('Y-m-d H:i:s', $getdata->created_at);
                    $trade->unique_id = $txd_id;
                    $trade->trade_id = $getdata->id;
                    $trade->trade_type = 'limit_order';
                    $trade->user_id = 209;
                    $trade->pair_id = 18;
                    $trade->pair = 'BTC-USDC';
                    $trade->firstCurrency = 'BTC';
                    $trade->secondCurrency = 'USDC';
                    $trade->price = $getdata->price;
                    $trade->total = $getdata->quantity * $getdata->price;
                    if ($getdata->taker_side == 'sell') {
                        $type = 'Sell';
                    } else {
                        $type = 'Buy';
                    }
                    $trade->type = $type;
                    $trade->process = '0';
                    $trade->bitfinex_id = $getdata->id;
                    $trade->fee = 0;
                    $trade->original_qty = $getdata->quantity;
                    $trade->updated_qty = 0;
                    $trade->updated_total = $getdata->quantity * $getdata->price;
                    $trade->status = 'completed';
                    $trade->created_at = $date;
                    $trade->updated_at = $date;
                    if ($trade->save()) {
                        $trade_mapping = new TradeMapping();
                        $trade_mapping->unique_id = 'LQD' . $getdata->id;
                        $trade_mapping->pair = 'BTC-USDC';
                        $trade_mapping->buy_trade_order_id = $trade->id;
                        $trade_mapping->sell_trade_order_id = $trade->id;
                        $trade_mapping->type = $type;
                        $trade_mapping->triggered_price = $getdata->price;
                        $trade_mapping->triggered_qty = $getdata->quantity;
                        if ($type == 'Buy') {
                            $trade_mapping->total = $trade->updated_total;
                        } else {
                            $trade_mapping->total = $trade->updated_total;
                        }
                        $trade_mapping->created_at = $date;
                        $trade_mapping->updated_at = $date;
                        $trade_mapping->save();

                        trade_chart('BTC-USDC');
                    }
                }
            }
            $trade_history = Trade::where('pair', 'BTC-USDC')
                ->whereIn('status', ['completed', 'partially'])->orderBy('updated_at', 'desc')->limit(18)->get()->toJson();
            return $trade_history;
        } catch (\Exception $e) {

            return 0;
        }

    }

    //trade chart data for ethusdt bitfinex data
    function ethusdt(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $pair = $request['pair'];
                $volume = $request['volume'];
                $time = $request['time'];
//                $date = gmdate('Y-m-d H:i:s', $time);
                $type = $request['type'];
                $tx_id = $request['tx_id'];
                $price = $request['price'];

                \Log::info(['request', $pair, $volume, $time, $type, $tx_id, $price]);

                $trade_map = TradeMapping::where('unique_id', $tx_id)->first();
                if ($trade_map == null) {
                    $trade_mapping = new TradeMapping();
                    $trade_mapping->unique_id = $tx_id;
                    $trade_mapping->pair = $pair;
                    $trade_mapping->buy_trade_order_id = 'BTX' . $tx_id;
                    $trade_mapping->sell_trade_order_id = 'BTX' . $tx_id;
                    $trade_mapping->type = $type;
                    $trade_mapping->triggered_price = $price;
                    $trade_mapping->triggered_qty = $volume;
                    if ($type == 'Buy') {
                        $trade_mapping->total = $price * $volume;
                    } else {
                        $trade_mapping->total = $price * $volume;
                    }
                    $trade_mapping->created_at = $time;
                    $trade_mapping->updated_at = $time;
                    $trade_mapping->save();
                    trade_chart($pair);
                    return 1;
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return 0;
        }
    }

    function cancel_order(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                if ($request->isMethod('post')) {
                    $id = $request['id'];
                    $tradeid = base64_decode($id);
                    $result = Trade::where('id', $tradeid)->whereIn('status', ['active', 'partially'])->first();
                    if ($result) {
                        $amount = $result->updated_qty;
                        $price = $result->price;
                        $total = $amount * $price;
                        if ($result->type == 'Buy') {
                            $fee = get_trade_fee('Buy', $result->pair);
                        } else {
                            $fee = get_trade_fee('Sell', $result->pair);
                        }

                        if ($result->bitfinex_id != 0) {
                            $bitfinex_id = (floatval($result->bitfinex_id));
                            if ($result->pair == 'ETH-USDT') {
                                $order_info = json_decode(bitfinex_order_status_check($bitfinex_id));
                                $price = $order_info->avg_execution_price;
                                $remaining_amount = $order_info->remaining_amount;
                                $type = $order_info->type;
                                $reciever_user_id = 12635;
                                $reciever_txid = 'BTC' . $bitfinex_id;
                            } else if ($result->pair == 'BTC-USDC') {
                                $order_info = json_decode(liquid_order_status_check($bitfinex_id));
                                $price = $order_info->average_price;
                                $remaining_amount = $order_info->quantity - $order_info->filled_quantity;
                                $type = $order_info->side;
                                $reciever_user_id = 12677;
                                $reciever_txid = 'LQD' . $bitfinex_id;
                            } else if ($result->pair == 'XDC-XRP') {
                                $order_info = json_decode(indodax_order_status_check($bitfinex_id, $result->pair));
                                $price = $order_info->return->order->price;
                                $type = $order_info->return->order->type;
                                if ($type == 'buy') {
                                    $type = 'Buy';
                                } elseif ($type == 'sell') {
                                    $type = 'Sell';
                                }
                                $idr_price = $result->idr_price;
                                $idr_qty = $result->idr_qty;
                                $indo_price = $result->indo_price;
                                if ($type == "Buy") {
                                    $remaining_amount = $order_info->return->order->remain_rp;
                                    if ($idr_price == $price && $idr_qty == $remaining_amount) {
                                        $remaining_amount = $amount;
//                                        $price = 0;
                                    } else {
                                        $remaining_amount = $remaining_amount / $idr_price;
//                                        $conversion = $price * (1 / $indo_price);
//                                        $price = $conversion;
                                    }
                                } else if ($type == "Sell") {
                                    $remaining_amount = $order_info->return->order->remain_xdce;
                                }
                                $remaining_amount = number_format($remaining_amount, '0', '.', '');
                                $price = $result->price;
                                $reciever_user_id = 12971;
                                $reciever_txid = 'IND' . $bitfinex_id;
                                \Log::info(['indodax_details_cancel', $idr_price, $idr_qty, $indo_price, $remaining_amount, $price]);
                            }

                            $difference = $amount - $remaining_amount;
                            if ($price == 0 || $difference == 0) {
                                if ($result->pair == 'ETH-USDT') {
                                    $cancel_order = bitfinex_order_cancel($bitfinex_id);
                                } else if ($result->pair == 'BTC-USDC') {
                                    $cancel_order = liquid_order_cancel($bitfinex_id);
                                } else if ($result->pair == 'XDC-XRP') {
                                    $cancel_order = indodax_order_cancel($bitfinex_id, $result->pair, strtolower($type));
                                }
                                \Log::info(['canceled_orders_result', $cancel_order]);
                            } else {
                                $result->updated_qty = $remaining_amount;
                                $get_txn_fee = get_trade_fee($result->type, $result->pair);
                                $trade_fee = $price * $difference * $get_txn_fee;
                                $trade_fee = number_format($trade_fee, 12, '.', '');

                                if ($result->type == 'Buy') {
                                    $currency = $result->firstCurrency;
                                    $user_balance = get_userbalance($result->user_id, $currency) + $difference;
                                    $total = $price * $difference + $trade_fee;
                                    $Reciever_type = 'Sell';
                                    if ($result->price != $price) {
                                        $sc = $result->secondCurrency;
                                        $refund = $result->total - $total;
                                        $refund_bal = get_userbalance($result->user_id, $sc) + $refund;
                                        $user_bal = UserBalance::where('user_id', $result->user_id)->first();
                                        $user_bal->$sc = $refund_bal;
                                        $user_bal->save();
                                    }
                                } else {
                                    $currency = $result->secondCurrency;
                                    $total = $price * $difference - $trade_fee;
                                    $user_balance = get_userbalance($result->user_id, $currency) + $total;
                                    $Reciever_type = 'Buy';
                                }
                                $user_bal = Balance::where('user_id', $result->user_id)->first();
                                $user_bal->$currency = $user_balance;
                                $user_bal->save();
                                $result->price = $price;
                                $result->updated_total = $total;
                                \Log::info(['cancel_trade_fee', $trade_fee, 'total', $total]);
                                \Log::info(['cancel_open_orders', $result]);
                                if ($remaining_amount == 0) {
                                    $result->status = 'completed';
                                    $result->save();

                                    //admin  trade profit
                                    $Trader_admin_coin_teft = new Profit();
                                    $Trader_admin_coin_teft->userId = $result->user_id;
                                    $Trader_admin_coin_teft->type = 'Trd-' . $result->type;
                                    $Trader_admin_coin_teft->record_id = $result->id;
                                    $Trader_admin_coin_teft->theftAmount = $trade_fee;
                                    $Trader_admin_coin_teft->theftCurrency = $result->secondCurrency;
                                    $Trader_admin_coin_teft->date = date('Y-m-d');
                                    $Trader_admin_coin_teft->time = date('H:i:s');
                                    $Trader_admin_coin_teft->save();

                                    //transferring profit to user account
                                    $profit_id = '12080';
                                    $profit_bal = get_userbalance($profit_id, $result->secondCurrency);
                                    $profit_bal = $profit_bal + $trade_fee;
                                    update_user_balance($profit_id, $result->secondCurrencyx, $profit_bal);

                                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                                    //for alphaex pusher
                                    $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $result->pair, 'user_id' => $result->user_id, 'trade_id' => 0, 'Type' => $result->type,
                                        'Amount' => number_format($difference, 4, '.', ''),
                                        'Price' => number_format($price, 8, '.', ''),
                                        'Total' => number_format($total, 4, '.', ''),
                                        'Fee' => number_format($trade_fee, '9', '.', '')));
                                    Session::flash('error', 'Your order is already completed');
                                    $data['status'] = '200';
                                    $data['message'] = 'Your order is been already completed';
                                    bitfinex_order_mapping($result->type, $Reciever_type, $order_info->executed_amount, $price, $reciever_user_id, $reciever_txid, $result->id, $result->pair_id, $result->pair, $result->bitfinex_id);
                                    return json_encode($data);
                                } else {
                                    $result->status = 'partially';
                                    $result->save();
                                    $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
                                    //for alphaex pusher
                                    $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $result->pair, 'user_id' => $result->user_id, 'trade_id' => 0, 'Type' => $result->type,
                                        'Amount' => number_format($difference, 4, '.', ''),
                                        'Price' => number_format($price, 8, '.', ''),
                                        'Total' => number_format($total, 4, '.', ''),
                                        'Fee' => number_format($trade_fee, '9', '.', '')));
//                                    $cancel_order = bitfinex_order_cancel($result->bitfinex_id);
                                    bitfinex_order_mapping($result->type, $Reciever_type, $remaining_amount, $price, $reciever_user_id, $reciever_txid, $result->id, $result->pair_id, $result->pair, $result->bitfinex_id);
                                    if ($result->pair == 'ETH-USDT') {
                                        $cancel_order = bitfinex_order_cancel($result->bitfinex_id);
                                    } else if ($result->pair == 'XDC-XRP') {
                                        $cancel_order = indodax_order_cancel($bitfinex_id, $result->pair, $type);
                                    } else {
                                        $cancel_order = liquid_order_cancel($bitfinex_id);
                                    }
                                    \Log::info(['canceled_orders_result', $cancel_order]);
                                }

                            }

                        }

                        $trade_fee = $total * $fee;

                        $userid = $result->user_id;
                        $second_currency = $result->secondCurrency;
                        $first_currency = $result->firstCurrency;
                        $second_cur_balance = get_userbalance($userid, $second_currency);
                        $first_cur_balance = get_userbalance($userid, $first_currency);
                        if ($result->status == 'active') {
                            $refnd_amount = $result->updated_qty;
                            $refnd_total = $result->total;
                        } else if ($result->status == 'partially') {
                            $refnd_amount = $result->updated_qty;


                            $refnd_total = $total + $trade_fee;
                        }
                        if ($result->type == 'Buy') {
                            if ($result->status == 'active') {
                                $result->status = 'cancelled';
                                if ($result->save()) {
                                    $finalbalance = $second_cur_balance + $refnd_total;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$second_currency = $finalbalance;
                                    $upt->save();
                                }
                            } else {
                                $new = new Trade;
                                $tx_id = 'BTX' . time();
                                $new->unique_id = $tx_id;
                                $new->trade_id = $tx_id;
                                $new->trade_type = $result->trade_type;
                                $new->user_id = $result->user_id;
                                $new->pair_id = $result->pair_id;
                                $new->pair = $result->pair;
                                $new->firstCurrency = $result->firstCurrency;
                                $new->secondCurrency = $result->secondCurrency;
                                $new->price = $result->price;
                                $new->total = $result->total;
                                $new->type = 'Buy';
                                $new->process = '1';
                                $new->fee = $result->fee;
                                $new->original_qty = $result->updated_qty;
                                $new->status = 'cancelled';
                                $new->save();

                                $result->original_qty = ($result->original_qty - $result->updated_qty);
                                $result->status = 'completed';
                                if ($result->save()) {
                                    $finalbalance = $second_cur_balance + $refnd_total;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$second_currency = $finalbalance;
                                    $upt->save();
                                }
                            }
                        } else {

                            if ($result->status == 'active') {
                                $result->status = 'cancelled';
                                if ($result->save()) {
                                    $finalbalance = $first_cur_balance + $refnd_amount;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$first_currency = $finalbalance;
                                    $upt->save();
                                }
                            } else {
                                $new = new Trade;
                                $tx_id = 'STX' . time();
                                $new->unique_id = $tx_id;
                                $new->trade_id = $tx_id;
                                $new->trade_type = $result->trade_type;
                                $new->user_id = $result->user_id;
                                $new->pair_id = $result->pair_id;
                                $new->pair = $result->pair;
                                $new->firstCurrency = $result->firstCurrency;
                                $new->secondCurrency = $result->secondCurrency;
                                $new->price = $result->price;
                                $new->total = $result->total;
                                $new->type = 'Sell';
                                $new->process = '1';
                                $new->fee = $result->fee;
                                $new->original_qty = $result->updated_qty;
                                $new->status = 'cancelled';
                                $new->save();
                                $result->original_qty = ($result->original_qty - $result->updated_qty);
                                $result->status = 'completed';
                                if ($result->save()) {
                                    $finalbalance = $first_cur_balance + $refnd_amount;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$first_currency = $finalbalance;
                                    $upt->save();
                                }
                            }
                        }

//                        crypto_compare_ob();

                        $data['status'] = '200';
                        $data['message'] = 'Your order is been cancelled successfully';


                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                        if ($result->pair == 'XDC-BTC') {
                            $pusher->trigger('order', 'order-cancel', array('Pair' => $result->pair, 'Type' => $result->type,
                                'Amount' => number_format($result->updated_qty, 2, '.', ''),
                                'Price' => number_format($result->price, 10, '.', ''),
                                'Total' => number_format($result->total, 2, '.', ''),
                                'Fee' => number_format($trade_fee, 9, '.', ''),
                            ));
                        } else {
                            $pusher->trigger('order', 'order-cancel', array('Pair' => $result->pair, 'Type' => $result->type,
                                'Amount' => number_format($result->updated_qty, 2, '.', ''),
                                'Price' => number_format($result->price, 8, '.', ''),
                                'Total' => number_format($result->total, 2, '.', ''),
                                'Fee' => number_format($trade_fee, 9, '.', ''),
                            ));
                        }

                        return json_encode($data);
                    }
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            $data['status'] = '500';
            $data['message'] = 'Server Error';
            return json_encode($data);
        }
    }

    // function cancel_order_indodax(Request $request)
    // {
    //     try {
    //         if (Session::get('alphauserid') == "") {
    //             return redirect('logout');
    //         } else {
    //             if ($request->isMethod('post')) {
    //                 $id = $request['id'];
    //                 $tradeid = base64_decode($id);
    //                 $result = Trade::where('id', $tradeid)->whereIn('status', ['active', 'partially'])->first();
    //                 if ($result) {
    //                     $amount = $result->updated_qty;
    //                     $price = $result->price;
    //                     $total = $amount * $price;
    //                     if ($result->type == 'Buy') {
    //                         $fee = get_trade_fee('Buy', $result->pair);
    //                     } else {
    //                         $fee = get_trade_fee('Sell', $result->pair);
    //                     }

    //                     if ($result->bitfinex_id != 0) {
    //                         $bitfinex_id = (floatval($result->bitfinex_id));
    //                         if ($result->pair == 'XDC-XRP') {
    //                             $order_info = json_decode(indodax_order_status_check($bitfinex_id));
    //                             $price = $order_info->avg_execution_price;
    //                             $remaining_amount = $order_info->remaining_amount;
    //                             $type = $order_info->type;
    //                         } 

    //                         $difference = $amount - $remaining_amount;
    //                         if ($price == 0 || $difference == 0) {
    //                             if ($result->pair == 'XDC-XRP') {
    //                                 $cancel_order = indodax_order_cancel($bitfinex_id);
    //                             } 
    //                             \Log::info(['canceled_orders_result', $cancel_order]);
    //                         } else {
    //                             $result->updated_qty = $remaining_amount;
    //                             $get_txn_fee = get_trade_fee($result->type, $result->pair);
    //                             $trade_fee = $price * $difference * $get_txn_fee;
    //                             $trade_fee = number_format($trade_fee, 12, '.', '');

    //                             if ($result->type == 'Buy') {
    //                                 $currency = $result->firstCurrency;
    //                                 $user_balance = get_userbalance($result->user_id, $currency) + $difference;
    //                                 $total = $price * $difference + $trade_fee;
    //                             } else {
    //                                 $currency = $result->secondCurrency;
    //                                 $total = $price * $difference - $trade_fee;
    //                                 $user_balance = get_userbalance($result->user_id, $currency) + $total;
    //                             }
    //                             $user_bal = UserBalance::where('user_id', $result->user_id)->first();
    //                             $user_bal->$currency = $user_balance;
    //                             $user_bal->save();
    //                             $result->updated_total = $result->updated_total + $total;
    //                             \Log::info(['cancel_trade_fee', $trade_fee, 'total', $total]);
    //                             \Log::info(['cancel_open_orders', $result]);
    //                             if ($remaining_amount == 0) {
    //                                 $result->status = 'completed';
    //                                 $result->save();
    //                                 $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
    //                                 //for alphaex pusher
    //                                 $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $result->pair, 'user_id' => $result->user_id, 'trade_id' => 0, 'Type' => $result->type,
    //                                     'Amount' => number_format($difference, 4, '.', ''),
    //                                     'Price' => number_format($price, 8, '.', ''),
    //                                     'Total' => number_format($total, 4, '.', ''),
    //                                     'Fee' => number_format($trade_fee, '9', '.', '')));
    //                                 Session::flash('error', 'Your order is already completed');
    //                                 $data['status'] = '200';
    //                                 $data['message'] = 'Your order is been already completed';
    //                                 return json_encode($data);
    //                             } else {
    //                                 $result->status = 'partially';
    //                                 $result->save();
    //                                 $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));
    //                                 //for alphaex pusher
    //                                 $pusher->trigger('order', 'order-history', array('trade_status' => 'completed', 'Pair' => $result->pair, 'user_id' => $result->user_id, 'trade_id' => 0, 'Type' => $result->type,
    //                                     'Amount' => number_format($difference, 4, '.', ''),
    //                                     'Price' => number_format($price, 8, '.', ''),
    //                                     'Total' => number_format($total, 4, '.', ''),
    //                                     'Fee' => number_format($trade_fee, '9', '.', '')));
    //                                 if($result->pair == 'ETH-USDT') {
    //                                     $cancel_order = bitfinex_order_cancel($result->bitfinex_id);
    //                                 }   
    //                                 else{
    //                                     $cancel_order = liquid_order_cancel($bitfinex_id);
    //                                 }

    //                                 \Log::info(['canceled_orders_result', $cancel_order]);
    //                             }

    //                         }

    //                     }

    //                     $trade_fee = $total * $fee;

    //                     $userid = $result->user_id;
    //                     $second_currency = $result->secondCurrency;
    //                     $first_currency = $result->firstCurrency;
    //                     $second_cur_balance = get_userbalance($userid, $second_currency);
    //                     $first_cur_balance = get_userbalance($userid, $first_currency);
    //                     if ($result->status == 'active') {
    //                         $refnd_amount = $result->updated_qty;
    //                         $refnd_total = $result->total;
    //                     } else if ($result->status == 'partially') {
    //                         $refnd_amount = $result->updated_qty;


    //                         $refnd_total = $total + $trade_fee;
    //                     }
    //                     if ($result->type == 'Buy') {
    //                         if ($result->status == 'active') {
    //                             $result->status = 'cancelled';
    //                             if ($result->save()) {
    //                                 $finalbalance = $second_cur_balance + $refnd_total;
    //                                 $upt = Balance::where('user_id', $userid)->first();
    //                                 $upt->$second_currency = $finalbalance;
    //                                 $upt->save();
    //                             }
    //                         } else {
    //                             $new = new Trade;
    //                             $tx_id = 'BTX' . time();
    //                             $new->unique_id = $tx_id;
    //                             $new->trade_id = $tx_id;
    //                             $new->trade_type = $result->trade_type;
    //                             $new->user_id = $result->user_id;
    //                             $new->pair_id = $result->pair_id;
    //                             $new->pair = $result->pair;
    //                             $new->firstCurrency = $result->firstCurrency;
    //                             $new->secondCurrency = $result->secondCurrency;
    //                             $new->price = $result->price;
    //                             $new->total = $result->total;
    //                             $new->type = 'Buy';
    //                             $new->process = '1';
    //                             $new->fee = $result->fee;
    //                             $new->original_qty = $result->updated_qty;
    //                             $new->status = 'cancelled';
    //                             $new->save();

    //                             $result->original_qty = ($result->original_qty - $result->updated_qty);
    //                             $result->status = 'completed';
    //                             if ($result->save()) {
    //                                 $finalbalance = $second_cur_balance + $refnd_total;
    //                                 $upt = Balance::where('user_id', $userid)->first();
    //                                 $upt->$second_currency = $finalbalance;
    //                                 $upt->save();
    //                             }
    //                         }
    //                     } else {

    //                         if ($result->status == 'active') {
    //                             $result->status = 'cancelled';
    //                             if ($result->save()) {
    //                                 $finalbalance = $first_cur_balance + $refnd_amount;
    //                                 $upt = Balance::where('user_id', $userid)->first();
    //                                 $upt->$first_currency = $finalbalance;
    //                                 $upt->save();
    //                             }
    //                         } else {
    //                             $new = new Trade;
    //                             $tx_id = 'STX' . time();
    //                             $new->unique_id = $tx_id;
    //                             $new->trade_id = $tx_id;
    //                             $new->trade_type = $result->trade_type;
    //                             $new->user_id = $result->user_id;
    //                             $new->pair_id = $result->pair_id;
    //                             $new->pair = $result->pair;
    //                             $new->firstCurrency = $result->firstCurrency;
    //                             $new->secondCurrency = $result->secondCurrency;
    //                             $new->price = $result->price;
    //                             $new->total = $result->total;
    //                             $new->type = 'Sell';
    //                             $new->process = '1';
    //                             $new->fee = $result->fee;
    //                             $new->original_qty = $result->updated_qty;
    //                             $new->status = 'cancelled';
    //                             $new->save();
    //                             $result->original_qty = ($result->original_qty - $result->updated_qty);
    //                             $result->status = 'completed';
    //                             if ($result->save()) {
    //                                 $finalbalance = $first_cur_balance + $refnd_amount;
    //                                 $upt = Balance::where('user_id', $userid)->first();
    //                                 $upt->$first_currency = $finalbalance;
    //                                 $upt->save();
    //                             }
    //                         }
    //                     }

    //                     $data['status'] = '200';
    //                     $data['message'] = 'Your order is been cancelled successfully';


    //                     $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

    //                     $pusher->trigger('order', 'order-cancel', array('Pair' => $result->pair, 'Type' => $result->type,
    //                         'Amount' => number_format($result->updated_qty, 2, '.', ''),
    //                         'Price' => number_format($result->price, 8, '.', ''),
    //                         'Total' => number_format($result->total, 8, '.', ''),
    //                         'Fee' => number_format($trade_fee, 9, '.', ''),
    //                         'Trade_id' => $result->id,
    //                     ));

    //                     return json_encode($data);
    //                 }
    //             }
    //         }
    //     } catch (\Exception $exception) {
    //         \Log::error([$exception->getMessage(), $exception->getLine(), $exception->getFile()]);
    //         $data['status'] = '500';
    //         $data['message'] = 'Server Error';
    //         return json_encode($data);
    //     }
    // }
    function pusher_auth(Request $request)
    {
        try {
            if (Session::has('alphauserid')) {
//            $user_id=Session::get('alphauserid');
                $pusher = new Pusher('427b3e2b5664f25aa88f', '5a2be92b0e6a4cc90024', '606412', array('cluster' => 'ap2'));
                echo $pusher->socket_auth($request['channel_name'], $request['socket_id']);
            } else {
                header('', true, 403);
                echo "Forbidden";
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function buy_order_list(Request $request)
    {
        try {
            $pair = $request['pair'];
            $buy_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Buy'])->where(function ($query) {
                $query->where('status', 'active')->Orwhere('status', 'partially');
            })->groupBy('price')->orderBy('price', 'desc')->limit(5)->get();

            return json_encode($buy_order_list);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function sell_order_list(Request $request)
    {
        try {
            $pair = $request['pair'];
            $sell_order_list = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Sell'])->where(function ($query) {
                $query->where('status', 'active')->Orwhere('status', 'partially');
            })->groupBy('price')->orderBy('price', 'asc')->limit(5)->get();
            return json_encode($sell_order_list);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function trade_history_table(Request $request)
    {
        try {
            $pair = $request['pair'];
            $trade_history = TradeMapping::where('pair', $pair)->orderBy('updated_at', 'desc')->limit(16)->get();
            return json_encode($trade_history);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function get_trading_fee(Request $request)
    {
        try {
            $type = $request['type'];
            $pair = $request['pair'];
            $fee = get_trade_fee($type, $pair);
            return json_encode($fee);
        } catch (\Exception $e) {
            return 0;
        }
    }

    function min_withdrawal(Request $request)
    {
        try {
            $currency = $request['currency'];
            $data = number_format(min_withdraw($currency), '8', '.', '');
            return json_encode($data);
        } catch (\Exception $e) {
            return 0;
        }
    }

    function min_trade(Request $request)
    {
        try {
            $currency = $request['currency'];
            $data = min_trade($currency);
            return json_encode($data);
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }

    }

    function max_trade(Request $request)
    {
        try {
            $currency = $request['currency'];
            $pair = $request['pair'];
            if ($pair == 'ETH-USDT') {
                $data = 10;
            } else {
                $data = 0;
            }

            return json_encode($data);
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }

    }

    function trigger_order(Request $request)
    {
        try {

            $pair = $request['pair'];
            $total = $request['total'];
            $amount = $request['amount'];
            $type = $request['type'];
            $price = $request['price'];
            $order_type = $request['order_type'];

            $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

            if ($order_type == 'trade') {
                $pusher->trigger('demo1', 'demo-event', array('User_id' => '', 'Pair' => $pair, 'Total' => number_format($total, 4, '.', ''), 'Amount' => number_format($amount, 0, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type));
            } else {
                $pusher->trigger('order', 'order-cancel', array('Pair' => $pair, 'Type' => $type,
                    'Amount' => number_format($amount, 2, '.', ''),
                    'Price' => number_format($price, 8, '.', ''),
                    'Total' => number_format($total, 8, '.', ''),
                    'Fee' => number_format('0', 9, '.', ''),
                    'Trade_id' => '',
                ));
            }
            return 1;
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }

    function referral()
    {
        try {
//            $user_id = $request['user_id'];

            if (Session::get('alphauserid') != '') {
//                crypto_compare_ob();
//                crypto_compare_tu();
                $user_id = Session::get('alphauserid');

                //checking and giving referral bonus
                $referrer = ReferralEarning::where('referrer_id', $user_id)->get();
                $referred = ReferralEarning::where('referred_id', $user_id)->get();

                //if the user is referred
                if (isset($referred)) {
                    foreach ($referred as $val) {
                        if ($val->referred_status != 1) {
                            $check = Trade::where('user_id', $val->referred_id)->whereIn('status', ['completed', 'partially'])->first();
                            if ($check != null) {
                                $referred_bal = get_userbalance($val->referred_id, $val->currency);
                                $referred_bal = $referred_bal + $val->referred_bonus;
                                $status = update_user_balance($val->referred_id, $val->currency, $referred_bal);
                                if ($status == true) {
                                    $val->referred_status = 1;
                                    $val->save();
                                }
                            }
                        }
                        if ($val->referred_status == 1) {
                            if ($val->referrer_status != 1) {
                                $check = Trade::where('user_id', $val->referrer_id)->whereIn('status', ['completed', 'partially'])->first();
                                if ($check != null) {
                                    $referrer_bal = get_userbalance($val->referrer_id, $val->currency);
                                    $referrer_bal = $referrer_bal + $val->referrer_bonus;
                                    $status = update_user_balance($val->referrer_id, $val->currency, $referrer_bal);
                                    if ($status == true) {
                                        $val->referrer_status = 1;
                                        $val->save();
                                        $user = Users::where('id', $val->referrer_id)->first();
                                        $user->referred_users = $user->referred_users + 1;
                                        $user->save();
                                        $check_referral = ReferralExtra::where('status', '1')->where('users', $user->referred_users)->first();
                                        if (isset($check_referral)) {
                                            $referred_users = $user->referred_users;
                                            $bonus = $check_referral->bonus;
                                            $check1 = ExtraBonus::where('user_id', $val->referrer_id)->where('referred_users', $referred_users)->first();
                                            if ($check1 == null) {
                                                $new_referral = new ExtraBonus();
                                                $new_referral->user_id = $val->referrer_id;
                                                $new_referral->currency = $check_referral->currency;
                                                $new_referral->referred_users = $referred_users;
                                                $new_referral->bonus = $bonus;
                                                if ($new_referral->save()) {
                                                    $bal = get_userbalance($val->referrer_id, $check_referral->currency);
                                                    $bal = $bal + $bonus;
                                                    $stat = update_user_balance($val->referrer_id, $check_referral->currency, $bal);
                                                    if ($stat == true) {
                                                        $new_referral->status = 1;
                                                        $new_referral->save();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                //if the user has referred
                if (isset($referrer)) {
                    foreach ($referrer as $val) {
                        if ($val->referred_status != 1) {
                            $check = Trade::where('user_id', $val->referred_id)->whereIn('status', ['completed', 'partially'])->first();
                            if ($check != null) {
                                $referred_bal = get_userbalance($val->referred_id, $val->currency);
                                $referred_bal = $referred_bal + $val->referred_bonus;
                                $status = update_user_balance($val->referred_id, $val->currency, $referred_bal);
                                if ($status == true) {
                                    $val->referred_status = 1;
                                    $val->save();
                                }
                            }
                        }
                        if ($val->referred_status == 1) {
                            if ($val->referrer_status != 1) {
                                $check = Trade::where('user_id', $val->referrer_id)->whereIn('status', ['completed', 'partially'])->first();
                                if ($check != null) {
                                    $referrer_bal = get_userbalance($val->referrer_id, $val->currency);
                                    $referrer_bal = $referrer_bal + $val->referrer_bonus;
                                    $status = update_user_balance($val->referrer_id, $val->currency, $referrer_bal);
                                    if ($status == true) {
                                        $val->referrer_status = 1;
                                        $val->save();
                                        $user = Users::where('id', $val->referrer_id)->first();
                                        $user->referred_users = $user->referred_users + 1;
                                        $user->save();
                                        $check_referral = ReferralExtra::where('status', '1')->where('users', $user->referred_users)->first();
                                        if (isset($check_referral)) {
                                            $referred_users = $user->referred_users;
                                            $bonus = $check_referral->bonus;
                                            $check1 = ExtraBonus::where('user_id', $val->referrer_id)->where('referred_users', $referred_users)->first();
                                            if ($check1 == null) {
                                                $new_referral = new ExtraBonus();
                                                $new_referral->user_id = $val->referrer_id;
                                                $new_referral->currency = $check_referral->currency;
                                                $new_referral->referred_users = $referred_users;
                                                $new_referral->bonus = $bonus;
                                                if ($new_referral->save()) {
                                                    $bal = get_userbalance($val->referrer_id, $check_referral->currency);
                                                    $bal = $bal + $bonus;
                                                    $stat = update_user_balance($val->referrer_id, $check_referral->currency, $bal);
                                                    if ($stat == true) {
                                                        $new_referral->status = 1;
                                                        $new_referral->save();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return 1;
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }

// end class

    function admin_bal(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return json_encode('Invalid Request.');
            } else {
                $curr = $request['curr'];
            //    $xdc_bal = get_admin_bal('XDC');
            //    $m_xdc_bal = get_admin_bal('M-XDC');
            //    $xdce_bal = get_admin_bal('XDCE');
            //    $eth_bal = get_admin_bal('ETH');
            //    $btc_bal = get_admin_bal('BTC');
            //    $bchabc_bal = get_admin_bal('BCHABC');
            //    $bchsv_bal = get_admin_bal('BCHSV');
            //    $usdt_bal = get_admin_bal('USDT');
            //    $usdc_bal = get_admin_bal('USDC');
            //    $xrp_bal = get_admin_bal('XRP');
            //    $data = array('xdc' => $xdc_bal, 'm_xdc' => $m_xdc_bal, 'xdce' => $xdce_bal, 'eth' => $eth_bal, 'btc' => $btc_bal, 'bchabc' => $bchabc_bal, 'bchsv' => $bchsv_bal, 'usdt' => $usdt_bal, 'usdc' => $usdc_bal, 'xrp' => $xrp_bal);

                $bitfinex = get_admin_bitfinex_bal($curr);
                $liquid = get_admin_liquid_bal($curr);
                $reserve = number_format(get_reserve_balance($curr), 4, '.', '');
                $bal = number_format((get_admin_bal($curr) - $bitfinex - $liquid), '4', '.', '');

                $data = array('bal' => $bal, 'currency' => strtolower($curr), 'bitfinex' => $bitfinex, 'liquid' => $liquid, 'reserve' => $reserve);

                return json_encode($data);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }


    function admin_status(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return json_encode('Invalid Request.');
            } else {
                $curr = $request['curr'];

                if ($curr == 'XDC' || $curr == 'XDCE' || $curr == 'M-XDC') {
                    $xdc_bal = get_admin_bal('XDC');
                    $m_xdc_bal = get_admin_bal('M-XDC');
                    $xdce_bal = get_admin_bal('XDCE');

                    $reserve_XDC = number_format(get_reserve_balance('XDC'), 4, '.', '');
                    $reserve_M_XDC = number_format(get_reserve_balance('M-XDC'), 4, '.', '');
                    $reserve_XDCE = number_format(get_reserve_balance('XDCE'), 4, '.', '');

                    $user_balance_result = DB::table('userbalance')->whereNotIn('user_id', ['12677', '12635'])->get();

                    $pending_withdrwals = Transaction::where('status', '=', 'Pending')->where('type', '=', 'Withdraw')->get();

                    $pending_withdrwals_xdc = $pending_withdrwals->where('currency_name', '=', 'XDC')->sum('amount');
                    $pending_withdrwals_xdce = $pending_withdrwals->where('currency_name', '=', 'XDCE')->sum('amount');

                    $intrade_xdc = get_total_intradebalance('XDC');
                    $intrade_xdce = get_total_intradebalance('XDCE');

                    $user_xdc = number_format($user_balance_result->sum('XDC') + $intrade_xdc + $pending_withdrwals_xdc, '4', '.', '');
                    $user_xdce = number_format($user_balance_result->sum('XDCE') + $intrade_xdce + $pending_withdrwals_xdce, '4', '.', '');

                    $total_xdc = $xdc_bal + $reserve_XDC;
                    $total_xdce = $xdce_bal + $reserve_XDCE;
                    $total_m_xdc = $m_xdc_bal + $reserve_M_XDC;

                    $total_xdc_xdce = $total_xdc + $total_xdce + $total_m_xdc;
                    $user_xdc_xdce = $user_xdc + $user_xdce;

                    if ($total_xdc_xdce >= ($user_xdc_xdce * 0.9999) && $total_xdc_xdce <= ($user_xdc_xdce * 1.0001)) {
                        $status = 1;
                    } else {
                        $status = 0;
                    }

                } else {
                    $curr_bal = get_admin_bal($curr);

                    $reserve_curr = number_format(get_reserve_balance($curr), 4, '.', '');

                    $user_balance_result = DB::table('userbalance')->whereNotIn('user_id', ['12677', '12635'])->get();

                    $pending_withdrwals = Transaction::where('status', '=', 'Pending')->where('type', '=', 'Withdraw')->get();

                    $pending_withdrwals_curr = $pending_withdrwals->where('currency_name', '=', $curr)->sum('amount');

                    $intrade_curr = get_total_intradebalance($curr);

                    $user_curr = number_format($user_balance_result->sum($curr) + $intrade_curr + $pending_withdrwals_curr, '4', '.', '');

                    $total_curr = $curr_bal + $reserve_curr;

                    if ($total_curr >= ($user_curr * 0.999) && $total_curr <= ($user_curr * 1.001)) {
                        $status = 1;
                    } else {
                        $status = 0;
                    }

                }

                $data = array('status' => $status, 'currency' => strtolower($curr));

                return json_encode($data);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }

    function admin_status_new(Request $request)
    {
        try {
            if (Session::get('token') == "") {
                return json_encode('Invalid Request.');
            } else {
                $curr = $request['curr'];
                $admin_total = $request['admin_total'];
                $user_total = $request['user_total'];
                if ($curr == 'XDC' || $curr == 'XDCE' || $curr == 'M-XDC') {
                    $total_xdc_xdce = $admin_total;
                    $user_xdc_xdce = $user_total;
                    // \Log::info(['currency',$total_xdc_xdce,$user_xdc_xdce]);
                    if ($total_xdc_xdce >= ($user_xdc_xdce * 0.9999) && $total_xdc_xdce <= ($user_xdc_xdce * 1.0001)) {
                        $status = 1;
                    } else {
                        $status = 0;
                    }
                } else {
                    $total_curr = $admin_total;
                    $user_curr = $user_total;
                    // \Log::info(['currency',$curr,$total_curr,$user_curr]);
                    if ($total_curr >= ($user_curr * 0.998) && $total_curr <= ($user_curr * 1.002)) {
                        $status = 1;
                    } else {
                        $status = 0;
                    }
                }
                $data = array('status' => $status, 'currency' => strtolower($curr));
                return json_encode($data);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }
    
    function user_bal(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return json_encode('Invalid Request.');
            } else {
                $curr = $request['curr'];

                if ($curr == 'M-XDC') {
                    $user_balance_result = Balance::whereNotIn('user_id', ['12677', '12635'])->get();
                    $bal = number_format($user_balance_result->sum('XDC'), '4', '.', '');
                    $intrade_curr_bal = get_total_intradebalance('XDC');
                } else {
                    $user_balance_result = Balance::whereNotIn('user_id', ['12677', '12635'])->get();
                    $bal = number_format($user_balance_result->sum($curr), '4', '.', '');
                    $intrade_curr_bal = get_total_intradebalance($curr);
                }

                $data = array('bal' => $bal, 'currency' => strtolower($curr), 'intrade_curr_bal' => $intrade_curr_bal);

//                $data = array('xdc' => $user_balance_result->sum('XDC'), 'm_xdc' => $user_balance_result->sum('XDC'),
//                    'xdce' => $user_balance_result->sum('XDCE'), 'eth' => $user_balance_result->sum('ETH'), 'btc' => $user_balance_result->sum('BTC'),
//                    'bchabc' => $user_balance_result->sum('BCHABC'), 'bchsv' => $user_balance_result->sum('BCHSV'),
//                    'xrp' => $user_balance_result->sum('XRP'), 'usdt' => $user_balance_result->sum('USDT'),
//                    'usdc' => $user_balance_result->sum('USDC'), 'intrade_xdc' => get_total_intradebalance('XDC'),
//                    'intrade_m_xdc' => get_total_intradebalance('XDC'), 'intrade_eth' => get_total_intradebalance('ETH'),
//                    'intrade_btc' => get_total_intradebalance('BTC'), 'intrade_bchabc' => get_total_intradebalance('BCHABC'),
//                    'intrade_bchsv' => get_total_intradebalance('BCHSV'), 'intrade_usdt' => get_total_intradebalance('USDT'),
//                    'intrade_usdc' => get_total_intradebalance('USDC'), 'intrade_xrp' => get_total_intradebalance('XRP'));

                return json_encode($data);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }


    function indodax(Request $request)
    {
        try {
            if ($request->isMethod('get')) {
                $convert_pair = $request['convert_pair'];
                $response = get_indodax_price($convert_pair);
                return $response;
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }

    function indodax_orderbook(Request $request)
    {
        try {
            if ($request->isMethod('get')) {

                $url = "https://indodax.com/api/xdce_idr/depth";
                $data = '';
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(

                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                // $result = json_decode($response);
                curl_close($curl);

                return $response;


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }

    function homiex_orderbook(Request $request)
    {
        try {
            if ($request->isMethod('get')) {

                $url = "https://api.homiex.com/openapi/quote/v1/depth?symbol=XDCEUSDT";
                $data = '';
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(

                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                ));
                $response = curl_exec($curl);
                
                $err = curl_error($curl);
                $result = json_decode($response);
                curl_close($curl);
                \Log::info(["XDC-USDT Pair",$response,$err]);
                return $response;
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }

    function p2p_orderbook(Request $request)
    {
        try {
            if ($request->isMethod('get')) {

                $url = "https://api.p2pb2b.io/api/v1/public/book?market=XDCE_BTC&side=buy&offset=0&limit=100";
                $data = '';
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(

                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                ));
                $response = curl_exec($curl);
                
                $err = curl_error($curl);
                // $result = json_decode($response);
                curl_close($curl);
                // \Log::info(["XDC-USDT Pair",$response,$err]);
                //end of buyAPI
                $url = "https://api.p2pb2b.io/api/v1/public/book?market=XDCE_BTC&side=sell&offset=0&limit=100";
                $data = '';
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(

                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                ));
                $res = curl_exec($curl);
                
                $err = curl_error($curl);
                $response = json_decode($response);
                $res = json_decode($res);
                curl_close($curl);
                //end od sellAPI
                $result['buy'] = $response->result->orders;
                $result['sell'] = $res->result->orders;
                return $result;
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }
    //trade chart data for ethusdt bitfinex data

// end class
}
