<?php

namespace App\Http\Controllers;

//use App\Jobs\MoveKey;
use App\model\Admin;
use App\model\Balance;
use App\model\Cms;
use App\model\Enquiry;
use App\model\Erc20Details;
use App\model\Erc20Requests;
use App\model\Currencies;
use App\model\ExtraBonus;
use App\model\Faq;
use App\model\Fees;
use App\model\ico;
use App\model\icodetails;
use App\model\ICORate;
use App\model\Marketprice;
use App\model\Metacontent;
use App\model\Node;
use App\model\OpeningBalance;
use App\model\OTP;
use App\model\ICOTrade;
use App\model\Pair;
use App\model\PairStats;
use App\model\Profit;
use App\model\ReferralExtra;
use App\model\ReserveBalances;
use App\model\SiteSettings;
use App\model\Template;
use App\model\Trade;
use App\model\TradeMapping;
use App\model\Tradingfee;
use App\model\Transaction;
use App\model\Transactionfee;
use App\model\UserBalance;
use App\model\Users;
use App\model\Verification;
use App\model\Wallettrans;
use App\model\Whitelist;
use App\model\XDCChart;
use App\model\Wallet;
use App\model\DeletedUsers;
use App\model\ReferralEarning;
use App\model\ReferralBonus;
use App\model\XdcePass;
use App\model\Xdce_transfer;
use Cache;
use DateTime;
use DB;
use Hash;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Session;
use Carbon\Carbon;
use Pusher\Pusher;
use Maatwebsite\Excel\Facades\Excel;
use Validator;
use File;

//use Barryvdh\DomPDF\Facade as PDF;

class AlphaexadminController extends Controller
{
    //
    public function __construct()
    {
        try {
            //$this->middleware('Adminlogin');
            // $ip = \Request::ip();
            // blockip_list($ip);
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function index(Request $request)
    {
        try {
            if ($request->isMethod('post')) {

                $validator = $this->validate($request, [
                    'email' => 'required|email',
                    'password' => 'required|min:6',
                    // 'pattern' => 'required',
                ], [
                    'email.required' => 'Email is required',
                    'password.required' => 'Password is required',
                    'password.min' => 'Password 6 characters is required',
                ]);


                $url = env('API_URL') . 'exchange_admin/login';
                $data = array('email' => $request['email'], 'password' => $request['password']);
                $data_string = json_encode($data);
                // \Log::info(['XDCE Result>>>>', $data_string, $url, $data]);
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

                $response = curl_exec($ch);
                $result = json_decode($response);

                curl_close($ch);
                \Log::info(['XDCE Result>>>>', $result]);
                if ($result->status === 200) {
                    Session::put('token', $result->token);
                    Session::flash('success', 'Successfully Logged In.');
                    // \Log::info(['LoggedIn>>>>',$result->token]);
                    Session::get('token');
                    return redirect('adminv3/adminhome');
                } elseif ($result->statusCode === 422) {
                    Session::flash('Failed', 'Email Id or Password is Incorrect.');
                    return redirect('adminv3');
                } else {
                    return redirect('adminv3');
                }
            }
            return view('panel1.admin_login');
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            Session::flash('Failed', 'Please enter correct credential.');
            return redirect('adminv3');
        }
    }

    function register(Request $request)
    {
        try {

            if ($request->isMethod('post')) {

                $validator = $this->validate($request, [
                    'email' => 'required|email',
                    'password' => 'required|min:6',
                    'firstName' => 'required',
                    'lastName' => 'required',
                    // 'pattern' => 'required',
                ], [
                    'email.required' => 'Email is required',
                    'password.required' => 'Password is required',
                    'password.min' => 'Password 6 characters is required',
                    'firstName.required' => 'First Name is required',
                    'lastName.required' => 'Last Name is required',
                ]);


                $url = env('API_URL') . 'exchange_admin/register';
                $data = array('email' => $request['email'], 'password' => $request['password'], 'firstName' => $request['firstName'], 'lastName' => $request['lastName'], 'exchange_id' => 'fc00be30-cfb8-11e9-b6c0-c9b14811a625', 'role_id' => 'a0c9f632-f611-4a7a-8d1a-a9a7a39674cd');
                // $data_string = json_encode($data);
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(
                        // "Authorization:".$token,
                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                $result = json_decode($response);
                curl_close($curl);
                \Log::info(['New User Registered', $result]);
                if ($result->status == 200) {
                    // Session::put('token',$result->token);
                    // \Log::info(['New User Registered', $result]);
                    // Session::get('token');
                    Session::flash('success', 'Successfully registered. Please check your mail and verify it.');
                    return redirect('adminv3');
                } else {
                    Session::flash('error', 'Something went wrong or email already exsits');
                    return redirect('adminv3/register');
                }

            }


        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function adminhome(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');
//                    $url = env('API_URL') . 'exchange_admin/currencystats';
//
//                    $data = "";
//                    $data_string = json_encode($data);
//                    $curl = curl_init();
//
//                    curl_setopt_array($curl, array(
//                        CURLOPT_URL => $url,
//                        CURLOPT_RETURNTRANSFER => true,
//                        CURLOPT_CUSTOMREQUEST => "GET",
//                        CURLOPT_POSTFIELDS => $data_string,
//                        CURLOPT_HTTPHEADER => array(
//                            "Authorization:" . $token,
//                            "Cache-Control: no-cache",
//                            "cache-control: no-cache"
//                        ),
//                    ));
//
//                    $response = curl_exec($curl);
//                    $err = curl_error($curl);
//                    $result = json_decode($response);
//                    curl_close($curl);

                    $url = env('API_URL') . 'exchange_admin/getDashboard';

                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response1 = curl_exec($curl);
                    $err = curl_error($curl);
                    $result1 = json_decode($response1);
                    curl_close($curl);

//                    $res['balance'] = $result;
                    $res['dashboard'] = $result1;
                    $tot_xdc = '';
                    $tot_xdce = '';
                    $admin_tot_xdc = '';
                    $admin_tot_xdce = '';
                    if ($res['dashboard']->status == 500) {
                        return view('panel1.adminhome1', ["token" => Session::get('token')]);
                    }
                    // \Log::info(['dashboard'=>$res]);
//                    foreach ($res['dashboard']->result->currencyStats as $dash) {
//                        if ($dash->currency == "XDC") {
//                            $tot_xdc = $dash->total + $dash->profit;
//                            $admin_tot_xdc = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->reserve + $dash->liquid + $dash->auto;
//                        }
//                    }
//                    foreach ($res['dashboard']->result->currencyStats as $dash) {
//                        if ($dash->currency == "XDCE") {
//                            $tot_xdce = $dash->total + $dash->profit;
//                            $admin_tot_xdce = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->reserve + $dash->liquid + $dash->auto;
//                        }
//                    }
                    if ($res['dashboard']->status == 500) {
                        return view('panel1.adminhome1', ["token" => Session::get('token')]);
                    } elseif ($res['dashboard']->status == 200) {
                        // \Log::info(['User Balance',$balm]);
                        $currencies = Currencies::all();
                        return view('panel1.adminhome', ['tot_xdc' => $tot_xdc, 'tot_xdce' => $tot_xdce, 'admin_tot_xdc' => $admin_tot_xdc, 'admin_tot_xdce' => $admin_tot_xdce, 'currencies' => $res, "token" => Session::get('token'), 'currencies_new' => $currencies]);
                    } else {
                        return redirect('adminv3/adminhome1');
                    }
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function dashboard(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');

                    $url = env('API_URL') . 'exchange_admin/currencystats';

                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    $url = env('API_URL') . 'exchange_admin/getDashboard';

                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response1 = curl_exec($curl);
                    $err = curl_error($curl);
                    $result1 = json_decode($response1);
                    curl_close($curl);

                    $res['balance'] = $result1;
                    $res['dashboard'] = $result1;
                    $tot_xdc = '';
                    $tot_xdce = '';
                    $admin_tot_xdc = '';
                    $admin_tot_xdce = '';
                    //  \Log::info(['User Balance',$res]);
                    foreach ($res['dashboard']->result->currencyStats as $dash) {
                        if ($dash->currency == "XDC") {
                            $tot_xdc = $dash->total + $dash->profit;
                            $admin_tot_xdc = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->reserve + $dash->liquid + $dash->auto;
                        }
                    }
                    foreach ($res['dashboard']->result->currencyStats as $dash) {
                        if ($dash->currency == "XDCE") {
                            $tot_xdce = $dash->total + $dash->profit;
                            $admin_tot_xdce = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->reserve + $dash->liquid + $dash->auto;
                        }
                    }
                    if ($res['dashboard']->status == 200) {
                        // \Log::info(['User Balance',$balm]);
                        return ['tot_xdc' => $tot_xdc, 'tot_xdce' => $tot_xdce, 'admin_tot_xdc' => $admin_tot_xdc, 'admin_tot_xdce' => $admin_tot_xdce, 'currencies' => $res, "token" => Session::get('token')];
                    } else {
                        return 0;
                    }
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function adminforgot(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $this->validate($request, [
                    'email' => 'required|email',
                ], [
                    'email.required' => 'Email id is required',
                    'email.email' => 'Enter valid email id']);

                $url = env('API_URL') . 'exchange_admin/forgot_password';
                $data = array('email' => $request['email'], 'exchange_id' => 'fc00be30-cfb8-11e9-b6c0-c9b14811a625');
                $data_string = json_encode($data);
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $response = curl_exec($ch);
                $result = json_decode($response);
                curl_close($ch);
                // \Log::info(['XDCE Result>>>>', $data]);
                if ($result->statusCode == 200) {
                    Session::flash('success', 'We sent password into your email. Check your mail');
                    // \Log::info(['LoggedIn>>>>']);
                    return redirect('adminv3');


                    // return redirect()->back();
                } else {
                    return redirect('adminv3/adminforgot');
                }

            }

        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function logout()
    {
        try {
            Session::flush();
            Cache::flush();
            if (Session::get('token') == "") {
                Session::flash('success', 'Successfully Logged Out.');
                return redirect('adminv3');
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function admin_profile(Request $request)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                if ($request->isMethod('post')) {
                    // $this->validate($request, [
                    //     'email' => 'required|email',
                    //     // 'admin_username' => 'required',
                    //     //'admin_phone' => 'numeric',
                    // ], [
                    //     'email.required' => 'Email is required',
                    //     // 'admin_username.required' => 'Username is required',
                    //     //'admin_phone.required' => 'Phone number must numeric',
                    // ]);
                    // $upt = Admin::find($alpha_id);


                    $url = env('API_URL') . 'exchange_admin/change_password';
                    $data = array('oldPassword' => $request['oldPassword'], 'newPassword' => $request['newPassword'], 'confirmPassword' => $request['confirmPassword']);
                    // $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    // \Log::info(['Data>>>>', $data]);
                    $response = curl_exec($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['XDCE Result>>>>', $result]);
                    if ($result->statusCode == 200) {
                        // \Log::info(['Password Changed Successfully',$result]);
                        return redirect('adminv3/adminhome');
                    } else if ($result->statusCode == 422) {
                        // \Log::info(['Error>>>>']);
                        return view('panel1.adminhome', $result);
                    } else {
                        return redirect('adminv3/adminhome');
                    }


                    // $upt->XDC_username = $request['admin_username'];
                    // $upt->email_id = $request['admin_email'];

                    // $upt->country = $request['admin_country'];
                    // if ($upt->save()) {
                    //     Session::flash('success', 'Successfully Updated');
                    //     return redirect('adminv3/admin_profile');
                    // }
                }
                return view('panel1.admin_profile');
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function user_list(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    if ($request['documentStatus'] != "") {

                        $url = env('API_URL') . 'exchange_admin/users?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']) . '&documentStatus=' . $request['documentStatus'] . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $url = env('API_URL') . 'exchange_admin/users?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }
                    // \Log::info(['URL', $url,rawurlencode($request['search'])]);
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache",
                            'Content_Type: application/x-www-form-urlencoded'
                        ),
                    ));

                    $response = curl_exec($curl);
                    // \Log::info(['User List',$response]);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['User List1',$result]);

                    if ($result->status == 200) {
                        // \Log::info(['User List',$result->result]);
                        return view('panel1.user_list', ['result' => $result->result, 'page' => $page, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function user_auto_flag(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    if ($request['autoFlag'] != "") {

                        $url = env('API_URL') . 'exchange_admin/users?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']) . '&autoFlag=' . $request['autoFlag'] . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $url = env('API_URL') . 'exchange_admin/users?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }
                    // \Log::info(['URL', $url,rawurlencode($request['search'])]);
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache",
                            'Content_Type: application/x-www-form-urlencoded'
                        ),
                    ));

                    $response = curl_exec($curl);
                    // \Log::info(['User List',$response]);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['User List1',$result]);

                    if ($result->status == 200) {
                        // \Log::info(['User List',$result->result]);
                        return view('panel1.user_auto_flag', ['result' => $result->result, 'page' => $page, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function view_user(Request $request, $uniqueId)
    {

        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/user';
                    $data = 'user_id=' . $uniqueId;
                    $curl = curl_init();
                    // \Log::info(['View user details', $data]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View user details', $result]);


                    if ($result->status == 200) {
                        // \Log::info(['view User', $result]);
                        return view('panel1.view_user', ['result' => $result->result, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                } elseif ($request->isMethod('post')) {

                    $url = env('API_URL') . 'exchange_admin/remove_user';
                    $data = 'userId=' . $uniqueId;
                    $curl = curl_init();
                    // \Log::info(['View user details', $data]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View user details', $result]);


                    if ($result->statusCode == 200) {
                        // \Log::info(['view User', $result]);
                        Session::flash('success', 'Successfully deleted the account.');
                        return redirect('adminv3/user_list/1');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/user_list/1');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function status_user(Request $request)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                if ($request->isMethod('post')) {
                    $userVerified = $request['userVerified'];
                    $status;
                    if($userVerified == 1){
                        $status = 0;
                    }
                    else if($userVerified == 0){
                        $status = 1;
                    }
                    $autoFlag;
                    $vs = $request['autoFlag'];
                    if ($vs == '1') {
                        $autoFlag = 0;
                    } else if ($vs == '0') {
                        $autoFlag = 1;
                    } else {
                        $autoFlag = 1;
                    }
                    // \Log::info(['>>>>>', $userVerified,$status]);

                    $url = env('API_URL') . 'exchange_admin/user';
                    $data = array('unique_id' => $request['uniqueId'], 'status' => $status, 'autoFlag' => $autoFlag);
                    // $data_string = json_encode($data);
                    // \Log::info(['data', $data]);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['User Status Changed', $response]);


                    if ($response->status == 200) {
                        // \Log::info(['User Status Changed', $response]);
                        return redirect('adminv3/user_list');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/user_list');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function account_status(Request $request)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                if ($request->isMethod('post')) {
                    $accountStatus = $request['accountStatus'];

                    // \Log::info(['>>>>>', $accountStatus, $request['accountStatus']]);

                    $url = env('API_URL') . 'exchange_admin/block_user';
                    $data = 'unique_id=' . $request['uniqueId'] . '&accountStatus=' . $accountStatus;
                    \Log::info(['data', $data]);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($response->status == 200) {
                        Session::flash('success', 'Successfully updated.');
                        \Log::info(['Account Status Changed', $response]);
                        return redirect('adminv3/user_list');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/user_list');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function admin_kyc_users(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    if ($request['status'] != "") {
                        $url = env('API_URL') . 'exchange_admin/kyc?limit=25&page=' . $page . '&status=' . $request['status'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $url = env('API_URL') . 'exchange_admin/kyc?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['View KYC List', $result]);
                        return view('panel1.admin_kyc_users', ['result' => $result->result, 'page' => $page, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function admin_view_kyc(Request $request, $uniqueId)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/viewkyc?unique_id=' . $uniqueId;
                    $data = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    //    \Log::info(['View KYC', $response]);
                    if ($result->status == 200) {
                        // \Log::info(['View KYC', $result]);

                        return view('panel1.admin_view_kyc', ['result' => $result->result, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                } elseif ($request->isMethod('post')) {

                    $url = env('API_URL') . 'exchange_admin/viewkyc';
                    $data = 'unique_id=' . $uniqueId . "&verify_status=" . $request['verify_status'] . "&description=" . $request['description'];
                    $curl = curl_init();
                    // \Log::info(['KYC Updated',$data]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    //   \Log::info(['KYC Updated',$response]);
                    if ($result->status == 200) {
                        // \Log::info(['KYC Updated',$result->result]);
                        Session::flash('success', 'Successfully updated.');
                        return redirect('adminv3/admin_kyc_users/1');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/admin_kyc_users/1');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function users_balance(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');

                    $url = env('API_URL') . 'exchange_admin/get_all_currency?search=' . $request['search'];
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);


                    $url = env('API_URL') . 'exchange_admin/get_all_user_balance';
                    //TODO category fetch
                    $data = 'limit=25&page=' . $page . '&search=' . rawurlencode($request['search']);
                    // $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $data = json_decode($response);
                    curl_close($curl);
                    //   \Log::info(['User Referral List',$data]);

                    $res['currency'] = $result;
                    $res['user balance'] = $data;

                    $user_currency = $result->data;
                    $user_bal_currency = $data->data;
                    $user_balance_list = [];
                    $user_balance = '';

                    foreach ($user_bal_currency as $resu) {
                        $user_balance = [];
                        $uniqueId = [];
                        foreach ($user_currency as $userCurrency) {
                            $update = 0;
                            foreach ($resu->currency as $userCurrencyBalance) {

                                if ($userCurrency->symbol == $userCurrencyBalance->symbol) {
                                    array_push($user_balance, ['value' => $userCurrencyBalance->balance, 'val' => $userCurrencyBalance->uniqueId]);
                                    array_push($uniqueId, ['val' => $userCurrencyBalance->uniqueId]);
                                    $update = 1;
                                }

                            }
                            if ($update == 0) {

                                array_push($user_balance, ['value' => 0]);

                            }

                        }
                        array_push($user_balance_list, ["email" => $resu->userEmail, "balance" => $user_balance, "uniqueId" => $uniqueId,"userUniqueId"=>$resu->userId]);
                    }


                    // return $user_balance_list;


                    // \Log::info(['currency symbol',$user_balance_list]);

                    if ($res['currency']->statusCode == 200 && $res['user balance']->statusCode == 200) {
                        // \Log::info(['User Balance',$res]);
                        return view('panel1.users_balance', ['result' => $user_balance_list, 'currency' => $res, 'pagination' => $res['user balance']->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function edit_user_balance(Request $request,$id){
        try{
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                $url = env('API_URL') . 'exchange_admin/user_balance';
                //TODO category fetch
                $datas = "userId=" . $id;
                $data_string = json_encode($datas);
                // $data_string = json_encode($data);
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POSTFIELDS => $data_string,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_HTTPHEADER => array(
                        "Authorization:" . $token,
                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                \Log::error(['response in edit user balance',$response]);
                $data = json_decode($response);
                curl_close($curl);
                if($data['status'] == 200){
                    return view('panel1.edit_user_balance',['result'=>$data,'id'=>$id]);
                }else{
                    Session::flash('error', 'No Wallet found or there went some error.');
                    return redirect()->back();
                }

            }

        }catch(\Exception $e){
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function Deposit_transactions(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $request['currencyName']]);
                if ($request->isMethod('get')) {
                    $url = env('API_URL') . 'exchange_admin/get_all_currency';
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response1 = curl_exec($curl);
                    $err = curl_error($curl);
                    $currency = json_decode($response1);

                    if ($request['currencyName'] != "") {
                        $url = env('API_URL') . 'exchange_admin/transactions?limit=25&page=' . $page . '&transactionType=Deposit&currencyName=' . $request['currencyName'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $url = env('API_URL') . 'exchange_admin/transactions?limit=25&page=' . $page . '&transactionType=Deposit&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }

                    // \Log::info(['Token', $url,$request['startDate'],$request['endDate']]);
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    //   \Log::info(['Wallet Transactions',$result->result]);
                    if ($result->status == 200) {
                        // \Log::info(['Wallet Transactions',$result->result]);
                        return view('panel1.deposit_transactions', ['result' => $result->result, 'page' => $page, 'currency' => $currency, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function withdraw_transactions(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {
                    $url = env('API_URL') . 'exchange_admin/get_all_currency?search=' . $request['search'];
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response1 = curl_exec($curl);
                    $err = curl_error($curl);
                    $currency = json_decode($response1);

                    if ($request['currencyName'] != "") {
                        $url = env('API_URL') . 'exchange_admin/transactions?limit=25&page=' . $page . '&transactionType=Withdraw&currencyName=' . $request['currencyName'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $url = env('API_URL') . 'exchange_admin/transactions?limit=25&page=' . $page . '&transactionType=Withdraw&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    // \Log::info(['Wallet Transactions',$result->result]);

                    if ($result->status == 200) {
                        // \Log::info(['Wallet Transactions',$result->result]);
                        return view('panel1.withdraw_transactions', ['result' => $result->result, 'page' => $page, 'currency' => $currency, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function view_transactions(Request $request, $uniqueId)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/withdrawal_by_id';
                    $data = "id=" . $uniqueId;
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    if ($result->status == 200) {
                        // \Log::info(['Withdraw Transactions'=>$result->result]);

                        return view('panel1.view_transactions', ['transactionDetail' => $result->result]);

                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function confirm_withdraw_transactions(Request $request, $uniqueId)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/complete_withdrawal_by_id';
                    $data = "id=" . $uniqueId;
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['Withdraw Transactions'=>$result]);
                    if ($result->status == 200) {
                        // \Log::info(['Withdraw Transactions'=>$result]);
                        Session::flash('success', 'Successfully confirmed withdraw Transaction.');
                        return redirect('adminv3/withdraw_transactions/1');

                    } else {
                        \Log::info(['Withdraw Transactions' => $result]);
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/withdraw_transactions/1');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function cancel_withdraw_transactions(Request $request, $uniqueId)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/cancel_withdrawal_by_id';
                    $data = "id=" . $uniqueId;
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['Withdraw Transactions'=>$result]);
                    if ($result->status == 200) {
                        // \Log::info(['Withdraw Transactions'=>$result]);
                        Session::flash('success', 'Successfully Cancelled withdraw Transaction.');
                        return redirect('adminv3/withdraw_transactions/1');

                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/withdraw_transactions/1');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function updated_transactions(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {
                    $url = env('API_URL') . 'exchange_admin/get_all_currency';
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response1 = curl_exec($curl);
                    $err = curl_error($curl);
                    $currency = json_decode($response1);

                    if ($request['currencyName'] != "") {
                        $url = env('API_URL') . 'exchange_admin/transactions?limit=25&page=' . $page . '&transactionType=Updated&currencyName=' . $request['currencyName'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $url = env('API_URL') . 'exchange_admin/transactions?limit=25&page=' . $page . '&transactionType=Updated&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['Wallet Transactions',$result->result]);
                        return view('panel1.updated_transactions', ['result' => $result->result, 'page' => $page, 'currency' => $currency, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function trade_mappings(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');
                    $url = env('API_URL') . 'exchange_admin/pairs?limit=25&page=1';
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response1 = curl_exec($curl);
                    $err = curl_error($curl);
                    $currency = json_decode($response1);

                    //   \Log::info([">>>",$request['pair']]);

                    $url = env('API_URL') . 'exchange_admin/get_all_trade_mapping';

                    if ($request['pair'] != "") {
                        $data = 'limit=25&page=' . $page . '&pair=' . $request['pair'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $data = 'limit=25&page=' . $page . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }
                    // $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['Trade Mapping',$result]);

                    if ($result->statusCode == 200) {
                        // \Log::info(['Trade Mapping',$result->data]);
                        return view('panel1.trade_mappings', ['result' => $result->data, 'currency' => $currency, 'page' => $page, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function set_trading_fee(Request $request)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/fees';

                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['Trading Fee',$result->result]);
                        return view('panel1.set_trading_fee', ['result' => $result->result]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                } elseif ($request->isMethod('post')) {

                    $url = env('API_URL') . 'exchange_admin/fees';
                    $data = 'currency_id=' . $request['uniqueId'] . "&min_scale=" . $request['min_scale'] . "&max_scale=" . $request['max_scale'] . "&buy_fee=" . $request['buy_fee'] . "&sell_fee=" . $request['sell_fee'] . "&deposit_fee=" . $request['deposit_fee'] . "&withdrawal_normal_fee=" . $request['withdrawal_normal_fee'] . "&withdrawal_fast_fee=" . $request['withdrawal_fast_fee'];
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    if ($result->status == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['Trading Fee Updated',$result->result]);
                        $lObjSiteSettings = SiteSettings::first();
                        if ($lObjSiteSettings) {
                            $xrp_secret = $lObjSiteSettings->xrp_secret;
                            $secret_length = strlen($xrp_secret);

                            if (substr($xrp_secret, -1) == 'e') {
                                $xrp_sec = substr($xrp_secret, 0, -1);
                                Session::flash('success', 'Successfully Updated XRP ');
                            } else {
                                $xrp_sec = $xrp_secret . 'e';
                                Session::flash('error', 'Successfully Updated XRP ');
                            }

                            $lObjSiteSettings->xrp_secret = $xrp_sec;
                            $lObjSiteSettings->save();
                            return redirect('adminv3/set_trading_fee');
                        }
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/set_trading_fee');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function partnership(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/partnership_list?limit=25&page=' . $page;
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['View Partnership List', $result]);
                        return view('panel1.partnership', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function partnership_status(Request $request)
    {
        try {
            // \Log::info(['update']);
            if (Session::get('token') == " ") {
                return redirect('adminv3');

            } else {
                // \Log::info(['update']);
                $token = Session::get('token');
                if ($request->isMethod('post')) {
                    $status;
                    $vs = $request['status'];
                    if ($vs == 1) {
                        $status = 2;
                    } else {
                        $status = 1;
                    }


                    $url = env('API_URL') . 'exchange_admin/partnership_list';
                    $data = 'unique_id=' . $request['uniqueId'] . '&status=' . $status;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($response->status == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['Partnership Status',$result->result]);
                        return redirect('adminv3/partnership');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/partnership');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');

        }
    }

    function view_partnership(Request $request, $uniqueId)
    {

        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/view_partnership';
                    $data = 'unique_id=' . $uniqueId;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View user details', $result]);


                    if ($result->status == 200) {
                        // \Log::info(['View Partnership', $result]);
                        return view('panel1.view_partnership', ['result' => $result->result, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function otc_list(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/otc_list?limit=25&page=' . $page;
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['View OTC List', $result]);
                        return view('panel1.otc_list', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function otc_status(Request $request)
    {
        try {
            // \Log::info(['update']);
            if (Session::get('token') == " ") {
                return redirect('adminv3');

            } else {
                // \Log::info(['update']);
                $token = Session::get('token');
                if ($request->isMethod('post')) {
                    $status;
                    $vs = $request['status'];
                    if ($vs == 1) {
                        $status = 2;
                    } else {
                        $status = 1;
                    }


                    $url = env('API_URL') . 'exchange_admin/otc_list';
                    $data = 'unique_id=' . $request['uniqueId'] . '&status=' . $status;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($response->status == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['OTC Status',$result->result]);
                        return redirect('adminv3/otc_list');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/otc_list');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');

        }
    }

    function view_otc(Request $request, $uniqueId)
    {

        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/view_otc';
                    $data = 'unique_id=' . $uniqueId;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View user details', $result]);


                    if ($result->status == 200) {
                        // \Log::info(['View OTC', $result]);
                        return view('panel1.view_otc', ['result' => $result->result, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function user_activities(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/user_log';
                    $data_string = 'limit=50';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    // \Log::info(['View User Log List', $result]);
                    if ($result->statusCode == 200) {
                        // \Log::info(['View User Log List', $result->data]);
                        return view('panel1.user_activities', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function user_activity(Request $request, $UserId)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/user_log';
                    $data_string = 'UserId=' . $UserId . '&limit=500';
                    $curl = curl_init();
                    // \Log::info(['activity', $data_string]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    // \Log::info(['View User Log List', $result]);
                    if ($result->statusCode == 200) {
                        // \Log::info(['View User Log List', $result->data]);
                        return view('panel1.user_activity', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function subadmin_activities(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/sub_exchange_admin_log';
                    $data_string = 'limit=50';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    // \Log::info(['View User Log List', $result]);
                    if ($result->statusCode == 200) {
                        // \Log::info(['View User Log List', $result->data]);
                        return view('panel1.sub_exchange_log', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function subadmin_activity(Request $request, $ExchangeAdminId)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/sub_exchange_admin_log';
                    $data_string = 'ExchangeAdminId=' . $ExchangeAdminId . '&limit=500';
                    $curl = curl_init();
                    // \Log::info(['activity', $data_string]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    // \Log::info(['View sub exchange Log List', $result]);
                    if ($result->statusCode == 200) {
                        // \Log::info(['View Sub Exchange Log List', $result->data]);
                        return view('panel1.subadmin_activity', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function manage_faq(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/faqs?limit=25&page=' . $page;
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View FAQ List', $result]);
                    if ($result->status == 200) {
                        // \Log::info(['View FAQ List', $result->result]);
                        return view('panel1.manage_faq', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function confirm(Request $request)
    {
        try {
            // $result = Faq::orderBy('id', 'desc')->get();
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/faqs?limit=25&page=1';
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View FAQ List', $result]);
                    if ($result->status == 200) {
                        // \Log::info(['View FAQ List', $result->result]);
                        $flag = $this->ftp();
                        switch ($flag) {
                            case '1' :
                                Session::flash('success', 'FAQ updated.');
                                break;
                            case '2' :
                                Session::flash('error', 'FAQ updated.');
                                break;
                            case '3' :
                                Session::flash('error', 'There was an error in updating the FAQ.');
                                break;
                            case '4' :
                                Session::flash('error', 'Failed to establish the connection.');
                                break;
                            case '5' :
                                Session::flash('error', 'No such file found.');
                                break;
                        }
                        return view('panel1.manage_faq', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }

        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    function ftp()
    {
        try {
            $ftp_server = decrypt(get_config('ftp_server'));
            $ftp_username = decrypt(get_config('ftp_username'));
            $ftp_userpass = decrypt(get_config('ftp_password'));
            $ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");

            if (@ftp_login($ftp_conn, $ftp_username, $ftp_userpass)) {
                ftp_pasv($ftp_conn, true);
                $path = "./";
                $path1 = "./keystore";
                $file = decrypt(get_config('file_name'));
                $file_list = ftp_nlist($ftp_conn, $path);
                $file_list1 = ftp_nlist($ftp_conn, $path1);
                if (in_array($file, $file_list)) {
                    $old_path = "./" . $file;
                    $new_path = "./keystore/" . $file;
                    if (ftp_rename($ftp_conn, $old_path, $new_path)) {
                        //    MoveKey::dispatch(new MoveKey())->delay(Carbon::now()->addMinutes(1));
                        return 1;
                    } else {
                        return 3;
                    }
                } else if (in_array($file, $file_list1)) {
                    $old_path = "./keystore/" . $file;
                    $new_path = "./" . $file;
                    if (ftp_rename($ftp_conn, $old_path, $new_path)) {
                        return 2;
                    } else {
                        return 3;
                    }
                } else {
                    return 5;
                }
            } else {
                return 4;
            }
            // close connection
            ftp_close($ftp_conn);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function ftp_test()
    {
        try {
            $ftp_user_name = 'alphaexftp';
            $ftp_user_pass = 'AlpH$#4dFTP';
            $ftp_server = '78.129.212.213';
            // set up basic connection
            $conn_id = ftp_connect($ftp_server);

            //login with username and password
            $login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

            // check connection
            if ((!$conn_id) || (!$login_result)) {
                echo "FTP connection has failed!";
                echo "Attempted to connect to $ftp_server for user $ftp_user_name";
                exit;
            } else {

                echo "Connected to $ftp_server, for user $ftp_user_name";
            }
            // open some file for reading
            $file = '/home/rahulraj/te.html';
            $fp = fopen($file, 'r');

            // try to upload $file
            if (ftp_put($conn_id, "localfile.txt", $file, FTP_ASCII)) {
                echo "Successfully uploaded $file\n";
            } else {
                echo "There was a problem while uploading $file\n";
            }

            // close the connection and the file handler
            ftp_close($conn_id);
            fclose($fp);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function add_faqs(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $token = Session::get('token');
                $validator = $this->validate($request, [
                    'category' => 'required',
                    'name' => 'required',
                    'title' => 'required',
                    'description' => 'required'
                ], [
                    'category.required' => 'Category is required',
                    'name.required' => 'Sub-Title is required',
                    'title.required' => 'Question is required',
                    'description.required' => 'Answer is required'
                ]);


                $url = env('API_URL') . 'exchange_admin/add_faq';
                //TODO category fetch
                $data = 'request=' . $request['category'] . '&category=' . $request['category'] . '&name=' . $request['name'] . '&title=' . $request['title'] . '&description=' . $request['description'];
                $data_string = json_encode($data);
                // \Log::info(['Data passed',$data_string]);
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $data_string,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization:" . $token,
                        "Cache-Control: no-cache",
                        "cache-control: no-cache"
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                $result = json_decode($response);
                curl_close($curl);


                if ($result->status == 200) {
                    Session::flash('success', 'Successfully added.');
                    // \Log::info(['Add KYC',$result->result]);
                    return redirect('adminv3/manage_faq/1');
                } else {
                    Session::flash('error', 'Something went Wrong.');
                    return redirect('adminv3/manage_faq/1');
                }
            }
            return view('panel1.add_faqs');
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function view_faq(Request $request, $uniqueId)
    {

        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/view_faq';
                    $data = 'unique_id=' . $uniqueId;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View user details', $result]);


                    if ($result->status == 200) {
                        // \Log::info(['View FAQ', $result]);
                        return view('panel1.view_faq', ['result' => $result->result, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                } else if ($request->isMethod('post')) {
                    $token = Session::get('token');


                    $url = env('API_URL') . 'exchange_admin/update_faq';
                    //TODO category fetch
                    $data = 'request=' . $request['category'] . '&unique_id=' . $uniqueId . '&category=' . $request['category'] . '&name=' . $request['name'] . '&title=' . $request['title'] . '&description=' . $request['description'];
                    $data_string = json_encode($data);
                    \Log::info(['Data passed', $data_string]);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    if ($result->status == 200) {
                        // \Log::info(['FAQ Updated',$result->result]);
                        Session::flash('success', 'Successfully updated.');
                        return redirect('adminv3/manage_faq/1');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/manage_faq/1');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function mailing_template(Request $request)
    {
        try {
            if (Session::get('token') == " ") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/get_all_exchage_email_template';
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache",
                            "Content-Length: 0"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View FAQ List', $response]);
                    if ($result->statusCode == 200) {
                        // \Log::info(['View Mailing List', $result]);
                        return view('panel1.mailing_template', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function mail_template(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {

                if ($request->isMethod('post')) {
                    $token = Session::get('token');
                    // \Log::info(['User Referral List',$request]);
                    $validator = $this->validate($request, [
                        'name' => 'required',
                        // 'category' => 'required',
                        'subject' => 'required',
                        'body' => 'required'
                    ], [
                        'name.required' => 'Name is required',
                        // 'category.required' => 'First Name is required',
                        'subject.required' => 'Subject is required',
                        'body.required' => 'Body is required'
                    ]);


                    $url = env('API_URL') . 'exchange_admin/create_exchage_email_template';
                    $data = array("name" => $request['name'], "category" => $request['name'], "subject" => $request['subject'], "body" => $request['body']);

                    $curl = curl_init();
                    // \Log::info(['new Template',$data]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    //   \Log::info(['adding mail Template',$result]);
                    if ($result->statusCode == 200) {
                        Session::flash('success', 'Successfully added.');
                        // \Log::info(['New Mail Template added',$result->data]);
                        return redirect('adminv3/mailing_template');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/mailing_template');
                    }
                }
                return view('panel1.add_faqs');
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function announcements()
    {
        try {

            return view('panel1.mailing_template');

        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function sms_management()
    {
        try {

            return view('panel1.mailing_template');

        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function update_announcements(Request $request, $id)
    {
        try {

            return view('panel1.update_mail_template');

        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function update_sms_management(Request $request, $id)
    {
        try {

            return view('panel1.update_mail_template');

        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function update_mail_template(Request $request, $uniqueId)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/get_exchange_email_template_by_id';
                    $data = 'email_template_id=' . $uniqueId;

                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Cache-Control: no-cache",
                            "Content-Type: application/x-www-form-urlencoded",
                            "authorization:" . $token,
                            "cache-control: no-cache",

                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    // \Log::info(['View FAQ details', $result]);


                    if ($result->statusCode == 200) {
                        // \Log::info(['View Email Template', $result->data]);
                        return view('panel1.update_mail_template', ['result' => $result->data, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                } else if ($request->isMethod('post')) {
                    $token = Session::get('token');


                    $url = env('API_URL') . 'exchange_admin/update_exchage_email_template';
                    //TODO category fetch
                    // \Log::info(['Body',$request['source']]);
                    $data = 'request=' . $uniqueId . '&email_template_id=' . $uniqueId . '&name=' . $request['name'] . '&category=' . $request['name'] . '&subject=' . $request['subject'] . '&body=' . $request['body'];
                    // $data_string = json_encode($data);
                    \Log::info(['Data passed', $data]);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Accept: */*",
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache",
                            "Content-Type: application/x-www-form-urlencoded",
                            "Connection: keep-alive",
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    //   \Log::info(['Mail Updated',$result]);
                    if ($result->statusCode == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['Mail Updated',$result]);
                        return redirect('adminv3/mailing_template');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/mailing_template');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function contact_query_admin(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/contact_us_list?limit=25&page=' . $page;
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    if ($result->status == 200) {
                        // \Log::info(['View Contact Us List', $result]);
                        return view('panel1.contact_query_admin', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function contact_status(Request $request)
    {
        try {
            // \Log::info(['update']);
            if (Session::get('token') == " ") {
                return redirect('adminv3');

            } else {

                $token = Session::get('token');
                if ($request->isMethod('post')) {
                    $status;
                    $vs = $request['status'];
                    if ($vs == 1) {
                        $status = 2;
                    } else {
                        $status = 1;
                    }
                    // \Log::info(['update',$vs,$status]);

                    $url = env('API_URL') . 'exchange_admin/contact_us_list';
                    $data = 'unique_id=' . $request['uniqueId'] . '&status=' . $status;
                    $curl = curl_init();
                    // \Log::info(['update',$data]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($response->status == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['OTC Status',$result->result]);
                        return redirect('adminv3/contact_query_admin');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/contact_query_admin');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');

        }
    }

    function view_contact(Request $request, $uniqueId)
    {

        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/view_contact';
                    $data = 'unique_id=' . $uniqueId;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View user details', $result]);


                    if ($result->status == 200) {
                        // \Log::info(['View Contact Query', $result]);
                        return view('panel1.view_contact', ['result' => $result->result, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function whitelist(Request $request)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/list_exchange_admin_ipwhitelist';
                    $data = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View Whitelist', $result]);


                    if ($result->statusCode == 200) {
                        // \Log::info(['View FAQ', $result]);
                        return view('panel1.whitelists', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                } else if ($request->isMethod('post')) {
                    $token = Session::get('token');


                    $url = env('API_URL') . 'exchange_admin/update_exchange_admin';
                    //TODO category fetch
                    $data = 'firstName=' . $request['firstName'] . '&lastName=' . $request['lastName'] . '&whitelisted_ip=' . $request['whitelisted_ip'] . '&is_whitelist_ip=' . $request['is_whitelist_ip'];
                    // $data_string = json_encode($data);
                    \Log::info(['Data passed', $data]);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    \Log::info(['IP Added', $result]);

                    if ($result->statusCode == 200) {
                        Session::flash('success', 'Successfully added.');
                        // \Log::info(['FAQ Updated',$result]);
                        return redirect('adminv3/whitelist');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/whitelist');
                    }
                }


            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function user_referral(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');

                    $url = env('API_URL') . 'exchange_admin/get_exchange_user_referral';
                    //TODO category fetch
                    $data = "limit=25&page=" . $page."&search=" . rawurlencode($request['search']);
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['User Referral List',$result]);

                    if ($result->statusCode == 200) {
                        // \Log::info(['User Referral List',$result->data]);
                        return view('panel1.user_referral', ['result' => $result->data, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function view_referral_settings(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');

                    $url = env('API_URL') . 'exchange_admin/get_exchange_referral_setting';
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    //   \Log::info(['User Referral List',$result]);

                    if ($result->statusCode == 200) {
                        // \Log::info(['User Referral List',$result->data]);
                        return view('panel1.view_referral_settings', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function edit_referral_settings(Request $request, $currencyId)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('post')) {
                    $token = Session::get('token');
                    $validator = $this->validate($request, [
                        // 'currency_id' => 'required',
                        'referral_amount' => 'required',
                        'referred_amount' => 'required',
                        'status' => 'required'
                    ], [
                        // 'currency_id.required' => 'Category is required',
                        'referral_amount.required' => 'Referral amount is required',
                        'referred_amount.required' => 'Referred amount is required',
                        'status.required' => 'status is required'
                    ]);


                    $url = env('API_URL') . 'exchange_admin/set_exchange_referral_setting';
                    $data = array("currency_id" => $currencyId, "referral_amount" => $request['referral_amount'], "referred_amount" => $request['referred_amount'], "status" => $request['status']);
                    // \Log::info(['User Referral List',$request['currency_id']]);
                    // $data_string = json_encode($data);
                    $curl = curl_init();
                    // \Log::info(['User Referral List',$data_string]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    //   \Log::info(['User Referral List',$result]);
                    if ($result->statusCode == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['User Referral List',$result]);
                        return redirect('adminv3/view_referral_settings');
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/view_referral_settings');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function sub_admin(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {

                if ($request->isMethod('get')) {
                    $token = Session::get('token');
                    $url = env('API_URL') . 'exchange_admin/get_role_list';
                    $data = "";
                    // \Log::info(['User Referral List',$request['currency_id']]);
                    // $data_string = json_encode($data);
                    $curl = curl_init();
                    // \Log::info(['User Referral List',$data_string]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    Session::put('Role Data', $result->data);

                    if ($result->statusCode == 200) {
                        // \Log::info(['Sub Admin Role list',$result->data]);
                        return view('panel1.sub_admin', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/admin_login');
                    }
                } elseif ($request->isMethod('post')) {
                    $token = Session::get('token');
                    $validator = $this->validate($request, [
                        'name' => 'required',
                        'firstName' => 'required',
                        'lastName' => 'required',
                        'email' => 'required|email',
                        'password' => 'required|min:6'
                    ], [
                        'name.required' => 'Role ID is required',
                        'firstName.required' => 'First Name is required',
                        'lastName.required' => 'Last Name is required',
                        'email.required' => 'Email is required',
                        'password.required' => 'Password is required'
                    ]);


                    $roleid = Session::get('Role Data');

                    // \Log::info(['@@@@@',$roleid]);
                    foreach ($roleid as $res) {
                        if ($request['name'] == $res->name) {
                            $roleid = $res->uniqueId;
                            // \Log::info(['@@@@@',$roleid,$request['name'],$res->name]);
                        }
                    }


                    $url = env('API_URL') . 'exchange_admin/create_subexchange_admin';
                    $data = array("role_id" => $roleid, "firstName" => $request['firstName'], "lastName" => $request['lastName'], "email" => $request['email'], "password" => $request['password']);

                    $curl = curl_init();
                    // \Log::info(['User Referral List',$data_string]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    //   \Log::info(['User Referral List',$result]);
                    if ($result->statusCode == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['Sub Admin created',$result->data]);
                        return redirect('adminv3/sub_admin_list');
                    } else {
                        Session::flash('error', 'Something went wrong or email already exsits');
                        return redirect('adminv3/sub_admin_list');
                    }
                }

                return view('panel1.sub_admin');
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function sub_admin_list(Request $request)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');

                    $url = env('API_URL') . 'exchange_admin/list_subexchange_admin';
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    // \Log::info(['User Referral List',$result]);
                    if ($result->statusCode == 200) {
                        // \Log::info(['Sub Admin List',$result->data]);
                        return view('panel1.sub_admin_list', ['result' => $result->data]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function assets(Request $request, $page)
    {
        try {
            if (Session::get('token') == NULL) {
                return redirect('adminv3');
            } else {
                if ($request->isMethod('get')) {
                    $token = Session::get('token');

                    $url = env('API_URL') . 'exchange_admin/get_exchange_asset_requests?limit=25&page=' . $page;
                    //TODO category fetch
                    $data = "search=" . rawurlencode($request['search']);
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->statusCode == 200) {
                        // \Log::info(['Assets',$result->data]);
                        return view('panel1.assets', ['result' => $result->data, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function view_asset(Request $request, $uniqueId)
    {

        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/get_exchange_asset_requests';
                    $data = 'exchange_asset_requests_id=' . $uniqueId;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['View Asset detail', $result->data]);


                    if ($result->statusCode == 200) {
                        // \Log::info(['View Asset Details', $result]);
                        return view('panel1.view_asset', ['result' => $result->data, 'uniqueId' => $uniqueId]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                } elseif ($request->isMethod('post')) {

                    $url = env('API_URL') . 'exchange_admin/edit_exchange_asset_requests';
                    $data = 'exchange_asset_requests_id=' . $uniqueId . "&status=" . $request['status'] . "&reject_reason=" . $request['description'];
                    $curl = curl_init();
                    // \Log::info(['Asset Updated',$data]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    // \Log::info(['Asset Updated',$result]);

                    if ($result->statusCode == 200) {
                        // \Log::info(['Asset Updated',$result]);
                        return redirect('adminv3/assets');
                    } else {
                        return redirect('adminv3/assets');
                    }
                } else {
                    return view('panel1.view_asset', ['result' => $result->$data, 'uniqueId' => $uniqueId]);
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function admin_wallet(Request $request, $page)
    {
        try {
            if (Session::get('token') == " ") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/wallets?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']);

                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['Admin Wallet',$result->result]);
                        return view('panel1.admin_wallet', ['result' => $result->result]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function profit_wallet(Request $request, $page)
    {
        try {
            if (Session::get('token') == " ") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/profit?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']);

                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['Profit Wallet',$result->result]);
                        return view('panel1.profit_wallet', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function brokerage_wallet(Request $request, $page)
    {
        try {
            if (Session::get('token') == " ") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/brokerage?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']);

                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['Brokerage Wallet',$result->result]);
                        return view('panel1.brokerage_wallet', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function trade_orders(Request $request, $page)
    {
        try {
            if (Session::get('token') == " ") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');

                if ($request->isMethod('get')) {
                    $url = env('API_URL') . 'exchange_admin/pairs?limit=25&page=1';
                    //TODO category fetch
                    $data = "";
                    $data_string = json_encode($data);
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data_string,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response1 = curl_exec($curl);
                    $err = curl_error($curl);
                    $currency = json_decode($response1);

                    $pair = $request['pair'];
                    $type = $request['type'];
                    $status = $request['status'];
                    //   \Log::info([">>>",gettype($request['pair']),$request['type']]);
                    if ($pair != "" and $type != "" and $status != "") {
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&pair=' . $request['pair'] . '&type=' . $request['type'] . '&status=' . $request['status'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } elseif ($pair != "" and $type != "") {
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&pair=' . $request['pair'] . '&type=' . $request['type'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } elseif ($pair != "" and $status != "") {
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&pair=' . $request['pair'] . '&status=' . $request['status'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } elseif ($type != "" and $status != "") {
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&type=' . $request['type'] . '&status=' . $request['status'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } elseif ($request['status'] != "") {
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&status=' . $request['status'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } elseif ($request['type'] != "") {
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&type=' . $request['type'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } elseif ($request['pair'] != "") {
                        // \Log::info(">>>");
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&pair=' . $request['pair'] . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    } else {
                        $url = env('API_URL') . 'exchange_admin/orders?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']) . '&startDate=' . $request['startDate'] . '&endDate=' . $request['endDate'];
                    }

                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['Trade Orders',$result->result]);
                        return view('panel1.trade_orders', ['result' => $result->result, 'page' => $page, 'currency' => $currency, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }


    function pair_request(Request $request, $page)
    {
        try {
            if (Session::get('token') == " ") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                // \Log::info(['Token', $token]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/pairs?limit=25&page=' . $page . '&search=' . rawurlencode($request['search']);
                    $data_string = '';
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);


                    if ($result->status == 200) {
                        // \Log::info(['Pairs List',$result->result]);
                        return view('panel1.pair_request', ['result' => $result->result, 'pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }
                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function trading_status(Request $request)
    {
        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $token = Session::get('token');
                if ($request->isMethod('post')) {
                    $trading_flag;
                    $vs = $request['tradingFlag'];
                    if ($vs == false ) {
                        $trading_flag = true;
                    } else {
                        $trading_flag = false;
                    }
                    if ( $vs == 0) {
                        $trading_flag = 1;
                    } else {
                        $trading_flag = 0;
                    }
                    // \Log::info(['>>>>>',$vs, $trading_flag, $request['tradingFlag']]);

                    $url = env('API_URL') . 'exchange_admin/updatepair';
                    $data = 'pairId=' . $request['pair_id'] . '&tradingFlag=' . $trading_flag;
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);

                    if ($result->status == 200) {
                        Session::flash('success', 'Successfully updated.');
                        // \Log::info(['Pair Updated',$result->result]);
                        return redirect('adminv3/pair_request',['pagination' => $result->pagination]);
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return redirect('adminv3/pair_request',['pagination' => $result->pagination]);
                    }
                }

                return view('panel1.pair_request', ['result' => $request]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function user_transactions_detail(Request $request, $uniqueId)
    {

        try {
            if (Session::get('token') == "") {
                return redirect('adminv3');
            } else {
                $type = $request['type'];
                // $uniqueId = $request['user_id'];
                $token = Session::get('token');
                // \Log::info(['Single User Transaction details', $uniqueId]);
                if ($request->isMethod('get')) {

                    $url = env('API_URL') . 'exchange_admin/user_transactions_details';
                    $data = 'user_id=' . $uniqueId;
                    $curl = curl_init();
                    // \Log::info(['Single User Transaction details', $data]);
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization:" . $token,
                            "Cache-Control: no-cache",
                            "cache-control: no-cache"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    $result = json_decode($response);
                    curl_close($curl);
                    $trade_details = [];
                    $amount_buy = '';
                    if ((array)$result->result) {
                        foreach ((array)$result->result->userTradeDetails->buyTrades as $resu) {
                            $amount_buy = [];
                            $uniqueId = [];
                            foreach ((array)$result->result->userBalanceDetails as $res) {
                                $update = 0;


                                if ($res->symbol == $resu->firstCurrency) {
                                    array_push($amount_buy, ['currency' => $resu->firstCurrency, 'value' => $resu->receivedTotal]);
                                    $update = 1;
                                } elseif ($res->symbol == $resu->secondCurrency) {
                                    array_push($amount_buy, ['currency' => $resu->secondCurrency, 'value' => '-' . $resu->updatedTotal]);
                                    $update = 1;
                                }


                                if ($update == 0) {

                                    array_push($amount_buy, ['value' => 0]);

                                }

                            }
                            array_push($trade_details, ['type' => $resu->type, "price" => $resu->price, "fee" => $resu->fee, "status" => $resu->status, "updatedAt" => $resu->updatedAt, "order_id" => $resu->orderId, "balance" => $amount_buy]);
                        }
                        foreach ((array)$result->result->userTradeDetails->sellTrades as $resu) {
                            $amount_buy = [];
                            $uniqueId = [];
                            foreach ((array)$result->result->userBalanceDetails as $res) {
                                $update = 0;


                                if ($res->symbol == $resu->firstCurrency) {
                                    array_push($amount_buy, ['currency' => $resu->firstCurrency, 'value' => '-' . $resu->filledQty]);
                                    $update = 1;
                                } elseif ($res->symbol == $resu->secondCurrency) {
                                    array_push($amount_buy, ['currency' => $resu->secondCurrency, 'value' => $resu->receivedTotal]);
                                    $update = 1;
                                }


                                if ($update == 0) {

                                    array_push($amount_buy, ['value' => 0]);

                                }


                            }
                            array_push($trade_details, ["type" => $resu->type, "price" => $resu->price, "fee" => $resu->fee, "status" => $resu->status, "updatedAt" => $resu->updatedAt, "order_id" => $resu->orderId, "balance" => $amount_buy]);

                        }
                        foreach ((array)$result->result->userTransactionsDetails->deposits as $resu) {
                            $amount_buy = [];
                            $uniqueId = [];
                            foreach ((array)$result->result->userBalanceDetails as $res) {
                                $update = 0;


                                if ($res->symbol == $resu->currencyName) {
                                    array_push($amount_buy, ['currency' => $resu->currencyName, 'value' => $resu->amount]);
                                    $update = 1;
                                }


                                if ($update == 0) {

                                    array_push($amount_buy, ['value' => 0]);

                                }


                            }
                            array_push($trade_details, ["type" => $resu->transactionType, "price" => 0, "fee" => 0, "status" => $resu->status, "updatedAt" => $resu->updatedAt, "order_id" => $resu->transactionId, "balance" => $amount_buy]);

                        }
                        foreach ((array)$result->result->userTransactionsDetails->withdrawals as $resu) {
                            $amount_buy = [];
                            $uniqueId = [];
                            foreach ((array)$result->result->userBalanceDetails as $res) {
                                $update = 0;


                                if ($res->symbol == $resu->currencyName) {
                                    array_push($amount_buy, ['currency' => $resu->currencyName, 'value' => '-' . $resu->amount]);
                                    $update = 1;
                                }


                                if ($update == 0) {

                                    array_push($amount_buy, ['value' => 0]);

                                }


                            }
                            array_push($trade_details, ["type" => $resu->transactionType, "price" => 0, "fee" => 0, "status" => $resu->status, "updatedAt" => $resu->updatedAt, "order_id" => $resu->transactionId, "balance" => $amount_buy]);

                        }
                    }


                    //   return response()->json(krsort ($trade_details));
                    if ($result->status == 200) {
                        // \Log::info(['Single User Transaction details', $result]);
                        if ($type == 'PDF') {


                            return view('panel1.pdfview1', ['result' => $result->result, 'trade' => $trade_details, 'uniqueId' => $uniqueId]);
                        } else {
                            return view('panel1.user_transactions_detail', ['result' => $result->result, 'trade' => $trade_details, 'uniqueId' => $uniqueId]);
                        }
                    } else {
                        Session::flash('error', 'Something went Wrong.');
                        return view('panel1.admin_login');
                    }

                }

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function send_balance_email(Request $request)
    {
        try {
            if ($request->isMethod('get')) {

                //mansi's code

//                $url = env('API_URL') . 'exchange_admin/login';
//                $data = array('email' => "rahul@xinfin.org", 'password' => "Demo@1234");
//                $data_string = json_encode($data);
//                // \Log::info(['XDCE Result>>>>', $data_string, $url, $data]);
//                $ch = curl_init($url);
//                curl_setopt($ch, CURLOPT_POST, true);
//                curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
//                curl_setopt($ch, CURLOPT_HEADER, false);
//                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//                curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
//                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
//                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//
//                $response = curl_exec($ch);
//                $result = json_decode($response);
//
//                curl_close($ch);
//                // \Log::info(['XDCE Result>>>>', $result]);
//                if ($result->status === 200) {
//                    Session::put('token', $result->token);
//                }
//
//                $token = Session::get('token');
//
//                $url = env('API_URL') . 'exchange_admin/getDashboard';
//
//                $data = "";
//                $data_string = json_encode($data);
//                $curl = curl_init();
//
//                curl_setopt_array($curl, array(
//                    CURLOPT_URL => $url,
//                    CURLOPT_RETURNTRANSFER => true,
//                    CURLOPT_CUSTOMREQUEST => "GET",
//                    CURLOPT_POSTFIELDS => $data_string,
//                    CURLOPT_HTTPHEADER => array(
//                        "Authorization:" . $token,
//                        "Cache-Control: no-cache",
//                        "cache-control: no-cache"
//                    ),
//                ));
//
//                $response1 = curl_exec($curl);
//                $err = curl_error($curl);
//                $result1 = json_decode($response1);
//                curl_close($curl);
//
//
//                $res['dashboard'] = $result1;
//                $tot_xdc = '';
//                $tot_xdce = '';
//                $tot_m_xdc = '';
//                $tot_eth = '';
//                $tot_btc = '';
//                $tot_usdt = '';
//                $tot_usdc = '';
//                $tot_bchabc = '';
//                $tot_bchsv = '';
//                $tot_xrp = '';
//                $xdc_bal = "731362343.53";
//                $xdce_bal = "";
//                $m_xdc_bal = "";
//                $eth_bal = "";
//                $btc_bal = "";
//                $bchabc_bal = "";
//                $bchsv_bal = "";
//                $usdt_bal = "";
//                $usdc_bal = "";
//                $xrp_bal = "";
//                $xdc_reserve_bal = "0.00";
//                $xdce_reserve_bal = "";
//                $m_xdc_reserve_bal = "";
//                $eth_reserve_bal = "";
//                $btc_reserve_bal = "";
//                $bchabc_reserve_bal = "";
//                $bchsv_reserve_bal = "";
//                $usdt_reserve_bal = "";
//                $usdc_reserve_bal = "";
//                $xrp_reserve_bal = "";
//                $xdc_total_bal = "731362343.53";
//                $xdce_total_bal = "";
//                $m_xdc_total_bal = "";
//                $eth_total_bal = "";
//                $btc_total_bal = "";
//                $bchabc_total_bal = "";
//                $bchsv_total_bal = "";
//                $usdt_total_bal = "";
//                $usdc_total_bal = "";
//                $xrp_total_bal = "";
//
//                // \Log::info(['dashboard'=>$res['dashboard']]);
//                foreach ($res['dashboard']->result->currencyStats as $dash) {
//                    if ($dash->currency == "XDC") {
//                        $tot_xdc = $dash->total + $dash->profit;
//                        $tot_m_xdc = $tot_xdc;
//                        $m_xdc_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $m_xdc_reserve_bal = $dash->reserve;
//                        $m_xdc_total_bal = $m_xdc_bal + $m_xdc_reserve_bal;
//
//                    } elseif ($dash->currency == "XDCE") {
//                        $tot_xdce = $dash->total + $dash->profit;
//                        $xdce_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $xdce_reserve_bal = $dash->reserve;
//                        $xdce_total_bal = $xdce_bal + $xdce_reserve_bal;
//                    } elseif ($dash->currency == "ETH") {
//                        $tot_eth = $dash->total + $dash->profit;
//                        $eth_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $eth_reserve_bal = $dash->reserve;
//                        $eth_total_bal = $eth_bal + $eth_reserve_bal;
//                    } elseif ($dash->currency == "BTC") {
//                        $tot_btc = $dash->total + $dash->profit;
//                        $btc_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $btc_reserve_bal = $dash->reserve;
//                        $btc_total_bal = $btc_bal + $btc_reserve_bal;
//                    } elseif ($dash->currency == "USDT") {
//                        $tot_usdt = $dash->total + $dash->profit;
//                        $usdt_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $usdt_reserve_bal = $dash->reserve;
//                        $usdt_total_bal = $usdt_bal + $usdt_reserve_bal;
//                    } elseif ($dash->currency == "USDC") {
//                        $tot_usdc = $dash->total + $dash->profit;
//                        $usdc_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $usdc_reserve_bal = $dash->reserve;
//                        $usdc_total_bal = $usdc_bal + $usdc_reserve_bal;
//                    } elseif ($dash->currency == "BCHABC") {
//                        $tot_bchabc = $dash->total + $dash->profit;
//                        $bchabc_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $bchabc_reserve_bal = $dash->reserve;
//                        $bchabc_total_bal = $bchabc_bal + $bchabc_reserve_bal;
//                    } elseif ($dash->currency == "BCHSV") {
//                        $tot_bchsv = $dash->total + $dash->profit;
//                        $bchsv_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $bchsv_reserve_bal = $dash->reserve;
//                        $bchsv_total_bal = $bchsv_bal + $bchsv_reserve_bal;
//                    } elseif ($dash->currency == "XRP") {
//                        $tot_xrp = $dash->total + $dash->profit;
//                        $xrp_bal = $dash->normal + $dash->bitfinex + $dash->indodax + $dash->liquid + $dash->auto;
//                        $xrp_reserve_bal = $dash->reserve;
//                        $xrp_total_bal = $xrp_bal + $xrp_reserve_bal;
//                    }
//
//                }
//                $reserve_T_XDC = $xdce_reserve_bal + $m_xdc_reserve_bal + $xdc_reserve_bal;
//                $xdc_xdce_bal = $xdce_total_bal + $xdc_bal + $m_xdc_total_bal;
//                $user_xdc_xdce = $tot_xdc + $tot_xdce;
//
//                if ($xdc_xdce_bal >= ($user_xdc_xdce * 0.9999) && $xdc_xdce_bal <= ($user_xdc_xdce * 1.0001)) {
//                    $status_xdc = 'True';
//                    $status_xdce = 'True';
//                } else {
//                    $status_xdc = 'False';
//                    $status_xdce = 'False';
//                }
//
//
//                if ($eth_total_bal >= ($tot_eth * 0.998) && $eth_total_bal <= ($tot_eth * 1.002)) {
//                    $status_eth = 'True';
//                } else {
//                    $status_eth = 'False';
//                }
//
//                if ($btc_total_bal >= ($tot_btc * 0.998) && $btc_total_bal <= ($tot_btc * 1.002)) {
//                    $status_btc = 'True';
//                } else {
//                    $status_btc = 'False';
//                }
//
//                if ($bchabc_total_bal >= ($tot_bchabc * 0.998) && $bchabc_total_bal <= ($tot_bchabc * 1.002)) {
//                    $status_bchabc = 'True';
//                } else {
//                    $status_bchabc = 'False';
//                }
//
//                if ($bchsv_total_bal >= ($tot_bchsv * 0.998) && $bchsv_total_bal <= ($tot_bchsv * 1.002)) {
//                    $status_bchsv = 'True';
//                } else {
//                    $status_bchsv = 'False';
//                }
//
//                if ($usdc_total_bal >= ($tot_usdc * 0.998) && $usdc_total_bal <= ($tot_usdc * 1.002)) {
//                    $status_usdc = 'True';
//                } else {
//                    $status_usdc = 'False';
//                }
//
//                if ($usdt_total_bal >= ($tot_usdt * 0.998) && $usdt_total_bal <= ($tot_usdt * 1.002)) {
//                    $status_usdt = 'True';
//                } else {
//                    $status_usdt = 'False';
//                }
//
//                if ($xrp_total_bal >= ($tot_xrp * 0.998) && $xrp_total_bal <= ($tot_xrp * 1.002)) {
//                    $status_xrp = 'True';
//                } else {
//                    $status_xrp = 'False';
//                }
//                \Log::info(['dashboard', $xdc_total_bal, $xdce_total_bal, $m_xdc_total_bal, $eth_total_bal, $btc_total_bal, $bchabc_total_bal, $bchsv_total_bal, $usdt_total_bal, $usdc_total_bal, $xrp_total_bal]);
//                $to = ['murphy@xinfin.org', 'aakash@xinfin.org', 'don@indsoft.net', 'alkeshc07@gmail.com', 'patelbunti@gmail.com', 'raj@xinfin.org', "mansi@xinfin.org"];
////                $to = 'raj@xinfin.org';
//                $subject = get_template('21', 'subject');
//                $message = get_template('21', 'template');
//                date_default_timezone_set('Asia/Kolkata');
//                $mailarr = array(
//                    '###TIME###' => date('Y-m-d H:i:s') . ' IST',
//                    '###XDC###' => $xdc_total_bal,
//                    '###USERXDC###' => $tot_xdc,
//                    '###RESERVEXDC###' => $xdc_reserve_bal,
//                    '###STATUSXDC###' => $status_xdc,
//                    '###MXDC###' => $m_xdc_bal,
//                    '###USERMXDC###' => $tot_xdc,
//                    '###RESERVEMXDC###' => $m_xdc_reserve_bal,
//                    '###STATUSMXDC###' => $status_xdc,
//                    '###TXDC###' => $xdc_xdce_bal,
//                    '###USERTXDC###' => $user_xdc_xdce,
//                    '###RESERVETXDC###' => $reserve_T_XDC,
//                    '###STATUSTXDC###' => $status_xdc,
//                    '###ETH###' => $eth_bal,
//                    '###USERETH###' => $tot_eth,
//                    '###RESERVEETH###' => $eth_reserve_bal,
//                    '###STATUSETH###' => $status_eth,
//                    '###BTC###' => $btc_bal,
//                    '###USERBTC###' => $tot_btc,
//                    '###RESERVEBTC###' => $btc_reserve_bal,
//                    '###STATUSBTC###' => $status_btc,
//                    '###XDCE###' => $xdce_bal,
//                    '###USERXDCE###' => $tot_xdce,
//                    '###RESERVEXDCE###' => $xdce_reserve_bal,
//                    '###STATUSXDCE###' => $status_xdce,
//                    '###BCHABC###' => $bchabc_bal,
//                    '###USERBCHABC###' => $tot_bchabc,
//                    '###RESERVEBCHABC###' => $bchabc_reserve_bal,
//                    '###STATUSBCHABC###' => $status_bchabc,
//                    '###BCHSV###' => $bchsv_bal,
//                    '###USERBCHSV###' => $tot_bchsv,
//                    '###RESERVEBCHSV###' => $bchsv_reserve_bal,
//                    '###STATUSBCHSV###' => $status_bchsv,
//                    '###USDC###' => $usdc_bal,
//                    '###USERUSDC###' => $tot_usdc,
//                    '###RESERVEUSDC###' => $usdc_reserve_bal,
//                    '###STATUSUSDC###' => $status_usdc,
//                    '###USDT###' => $usdt_bal,
//                    '###USERUSDT###' => $tot_usdt,
//                    '###RESERVEUSDT###' => $usdt_reserve_bal,
//                    '###STATUSUSDT###' => $status_usdt,
//                    '###XRP###' => $xrp_bal,
//                    '###USERXRP###' => $tot_xrp,
//                    '###RESERVEXRP###' => $xrp_reserve_bal,
//                    '###STATUSXRP###' => $status_xrp,
//                );
//                $message = strtr($message, $mailarr);
//                $subject = strtr($subject, $mailarr);
//                sendmail($to, $subject, ['content' => $message]);
//                \Log::info(['mailarr', $mailarr]);
//
//

                //raj's code

                $xdc_bal = get_admin_bal('XDC');
                $xdce_bal = get_admin_bal('XDCE');
                $m_xdc_bal = get_admin_bal('M-XDC');
                $eth_bal = get_admin_bal('ETH');
                $btc_bal = get_admin_bal('BTC');
                $bchabc_bal = get_admin_bal('BCHABC');
                $bchsv_bal = get_admin_bal('BCHSV');
                $usdt_bal = get_admin_bal('USDT');
                $usdc_bal = get_admin_bal('USDC');
                $xrp_bal = get_admin_bal('XRP');

                $xdce_auto_bal = get_admin_auto_bal('XDCE');
                $eth_auto_bal = get_admin_auto_bal('ETH');
                $usdc_auto_bal = get_admin_auto_bal('USDC');

//                $user_balance_result = Balance::whereNotIn('user_id', ['12677', '12635', '12971'])->get();
//
//                $pending_withdrwals = Transaction::where('status', '=', 'Pending')->where('type', '=', 'Withdraw')->get();
//
//                $pending_withdrwals_xdc = $pending_withdrwals->where('currency_name', '=', 'XDC')->sum('amount');
//                $pending_withdrwals_eth = $pending_withdrwals->where('currency_name', '=', 'ETH')->sum('amount');
//                $pending_withdrwals_btc = $pending_withdrwals->where('currency_name', '=', 'BTC')->sum('amount');
//                $pending_withdrwals_xdce = $pending_withdrwals->where('currency_name', '=', 'XDCE')->sum('amount');
//                $pending_withdrwals_bchabc = $pending_withdrwals->where('currency_name', '=', 'BCHABC')->sum('amount');
//                $pending_withdrwals_bchsv = $pending_withdrwals->where('currency_name', '=', 'BCHSV')->sum('amount');
//                $pending_withdrwals_usdc = $pending_withdrwals->where('currency_name', '=', 'USDC')->sum('amount');
//                $pending_withdrwals_usdt = $pending_withdrwals->where('currency_name', '=', 'USDT')->sum('amount');
//                $pending_withdrwals_xrp = $pending_withdrwals->where('currency_name', '=', 'XRP')->sum('amount');

                $user_bal_xdc = get_total_userbalance('XDC');
                $user_bal_xdce = get_total_userbalance('XDCE');
                $user_bal_eth = get_total_userbalance('ETH');
                $user_bal_btc = get_total_userbalance('BTC');
                $user_bal_xrp = get_total_userbalance('XRP');
                $user_bal_bchabc = get_total_userbalance('BCHABC');
                $user_bal_bchsv = get_total_userbalance('BCHSV');
                $user_bal_usdt = get_total_userbalance('USDT');
                $user_bal_usdc = get_total_userbalance('USDC');

                $intrade_xdc = get_total_intradebalance('XDC');
                $intrade_eth = get_total_intradebalance('ETH');
                $intrade_btc = get_total_intradebalance('BTC');
                $intrade_xdce = get_total_intradebalance('XDCE');
                $intrade_bchabc = get_total_intradebalance('BCHABC');
                $intrade_bchsv = get_total_intradebalance('BCHSV');
                $intrade_usdc = get_total_intradebalance('USDC');
                $intrade_usdt = get_total_intradebalance('USDT');
                $intrade_xrp = get_total_intradebalance('XRP');

                $profit_xdc = get_total_profit('XDC');
                $profit_xdce = get_total_profit('XDCE');
                $profit_eth = get_total_profit('ETH');
                $profit_btc = get_total_profit('BTC');
                $profit_xrp = get_total_profit('XRP');
                $profit_bchabc = get_total_profit('BCHABC');
                $profit_bchsv = get_total_profit('BCHSV');
                $profit_usdt = get_total_profit('USDT');
                $profit_usdc = get_total_profit('USDC');

                $user_xdc = number_format(($user_bal_xdc + $intrade_xdc + $profit_xdc), '4', '.', '');
                $user_eth = number_format(($user_bal_eth + $intrade_eth + $profit_eth), '4', '.', '');
                $user_btc = number_format(($user_bal_btc + $intrade_btc + $profit_btc), '4', '.', '');
                $user_xdce = number_format(($user_bal_xdce + $intrade_xdce + $profit_xdce), '4', '.', '');
                $user_bchabc = number_format(($user_bal_bchabc + $intrade_bchabc + $profit_bchabc), '4', '.', '');
                $user_bchsv = number_format(($user_bal_bchsv + $intrade_bchsv + $profit_bchsv), '4', '.', '');
                $user_usdc = number_format(($user_bal_usdc + $intrade_usdc + $profit_usdc), '4', '.', '');
                $user_usdt = number_format(($user_bal_usdt + $intrade_usdt + $profit_usdt), '4', '.', '');
                $user_xrp = number_format(($user_bal_xrp + $intrade_xrp + $profit_xrp), '4', '.', '');

                $reserve_XDC = number_format(get_reserve_balance('XDC'), 4, '.', '');
                $reserve_M_XDC = number_format(get_reserve_balance('M-XDC'), 4, '.', '');
                $reserve_ETH = number_format(get_reserve_balance('ETH'), 4, '.', '');
                $reserve_BTC = number_format(get_reserve_balance('BTC'), 4, '.', '');
                $reserve_XDCE = number_format(get_reserve_balance('XDCE'), 4, '.', '');
                $reserve_BCHABC = number_format(get_reserve_balance('BCHABC'), 4, '.', '');
                $reserve_BCHSV = number_format(get_reserve_balance('BCHSV'), 4, '.', '');
                $reserve_USDC = number_format(get_reserve_balance('USDC'), 4, '.', '');
                $reserve_USDT = number_format(get_reserve_balance('USDT'), 4, '.', '');
                $reserve_XRP = number_format(get_reserve_balance('XRP'), 4, '.', '');
                $reserve_T_XDC = $reserve_M_XDC + $reserve_XDC + $reserve_XDCE;

                $total_xdc = $xdc_bal + $reserve_XDC;
                $total_xdce = $xdce_bal + $reserve_XDCE + $xdce_auto_bal;
                $total_m_xdc = $m_xdc_bal + $reserve_M_XDC;
                $total_eth = $eth_bal + $reserve_ETH + $eth_auto_bal;
                $total_btc = $btc_bal + $reserve_BTC;
                $total_bchabc = $bchabc_bal + $reserve_BCHABC;
                $total_bchsv = $bchsv_bal + $reserve_BCHSV;
                $total_usdc = $usdc_bal + $reserve_USDC + $usdc_auto_bal;
                $total_usdt = $usdt_bal + $reserve_USDT;
                $total_xrp = $xrp_bal + $reserve_XRP;

                $xdc_xdce_bal = $xdce_bal + $xdc_bal + $m_xdc_bal;
                $total_xdc_xdce = $total_xdc + $total_xdce + $total_m_xdc;
                $user_xdc_xdce = $user_xdc + $user_xdce;

                if ($total_xdc_xdce >= ($user_xdc_xdce * 0.9999) && $total_xdc_xdce <= ($user_xdc_xdce * 1.0001)) {
                    $status_xdc = 'True';
                    $status_xdce = 'True';
                } else {
                    $status_xdc = 'False';
                    $status_xdce = 'False';
                }

//            if ($total_xdc >= ($user_xdc * 0.998) && $total_xdc <= ($user_xdc * 1.002)) {
//                $status_xdc = 'True';
//            } else {
//                $status_xdc = 'False';
//            }

                if ($total_eth >= ($user_eth * 0.998) && $total_eth <= ($user_eth * 1.002)) {
                    $status_eth = 'True';
                } else {
                    $status_eth = 'False';
                }


                if ($total_btc >= ($user_btc * 0.998) && $total_btc <= ($user_btc * 1.002)) {
                    $status_btc = 'True';
                } else {
                    $status_btc = 'False';
                }

//            if ($total_xdce >= ($user_xdce * 0.998) && $total_xdce <= ($user_xdce * 1.002)) {
//                $status_xdce = 'True';
//            } else {
//                $status_xdce = 'False';
//            }

                if ($total_bchabc >= ($user_bchabc * 0.998) && $total_bchabc <= ($user_bchabc * 1.002)) {
                    $status_bchabc = 'True';
                } else {
                    $status_bchabc = 'False';
                }

                if ($total_bchsv >= ($user_bchsv * 0.998) && $total_bchsv <= ($user_bchsv * 1.002)) {
                    $status_bchsv = 'True';
                } else {
                    $status_bchsv = 'False';
                }

                if ($total_usdc >= ($user_usdc * 0.998) && $total_usdc <= ($user_usdc * 1.002)) {
                    $status_usdc = 'True';
                } else {
                    $status_usdc = 'False';
                }

                if ($total_usdt >= ($user_usdt * 0.998) && $total_usdt <= ($user_usdt * 1.002)) {
                    $status_usdt = 'True';
                } else {
                    $status_usdt = 'False';
                }

                if ($total_xrp >= ($user_xrp * 0.998) && $total_xrp <= ($user_xrp * 1.002)) {
                    $status_xrp = 'True';
                } else {
                    $status_xrp = 'False';
                }

                $to = ['murphy@xinfin.org', 'aakash@xinfin.org', 'don@indsoft.net', 'alkeshc07@gmail.com', 'patelbunti@gmail.com', 'raj@xinfin.org', "mansi@xinfin.org"];
//                $to = 'raj@xinfin.org';
                $subject = get_template('21', 'subject');
                $message = get_template('21', 'template');
                date_default_timezone_set('Asia/Kolkata');
                $mailarr = array(
                    '###TIME###' => date('Y-m-d H:i:s') . ' IST',
                    '###XDC###' => $xdc_bal,
                    '###USERXDC###' => $user_xdc,
                    '###RESERVEXDC###' => $reserve_XDC,
                    '###STATUSXDC###' => $status_xdc,
                    '###MXDC###' => $m_xdc_bal,
                    '###USERMXDC###' => 0,
                    '###RESERVEMXDC###' => $reserve_M_XDC,
                    '###STATUSMXDC###' => $status_xdc,
                    '###TXDC###' => $xdc_xdce_bal,
                    '###USERTXDC###' => $user_xdc_xdce,
                    '###RESERVETXDC###' => $reserve_T_XDC,
                    '###STATUSTXDC###' => $status_xdc,
                    '###ETH###' => $eth_bal,
                    '###USERETH###' => $user_eth,
                    '###RESERVEETH###' => $reserve_ETH,
                    '###STATUSETH###' => $status_eth,
                    '###BTC###' => $btc_bal,
                    '###USERBTC###' => $user_btc,
                    '###RESERVEBTC###' => $reserve_BTC,
                    '###STATUSBTC###' => $status_btc,
                    '###XDCE###' => $xdce_bal,
                    '###USERXDCE###' => $user_xdce,
                    '###RESERVEXDCE###' => $reserve_XDCE,
                    '###STATUSXDCE###' => $status_xdce,
                    '###BCHABC###' => $bchabc_bal,
                    '###USERBCHABC###' => $user_bchabc,
                    '###RESERVEBCHABC###' => $reserve_BCHABC,
                    '###STATUSBCHABC###' => $status_bchabc,
                    '###BCHSV###' => $bchsv_bal,
                    '###USERBCHSV###' => $user_bchsv,
                    '###RESERVEBCHSV###' => $reserve_BCHSV,
                    '###STATUSBCHSV###' => $status_bchsv,
                    '###USDC###' => $usdc_bal,
                    '###USERUSDC###' => $user_usdc,
                    '###RESERVEUSDC###' => $reserve_USDC,
                    '###STATUSUSDC###' => $status_usdc,
                    '###USDT###' => $usdt_bal,
                    '###USERUSDT###' => $user_usdt,
                    '###RESERVEUSDT###' => $reserve_USDT,
                    '###STATUSUSDT###' => $status_usdt,
                    '###XRP###' => $xrp_bal,
                    '###USERXRP###' => $user_xrp,
                    '###RESERVEXRP###' => $reserve_XRP,
                    '###STATUSXRP###' => $status_xrp,
                );
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                sendmail($to, $subject, ['content' => $message]);
                \Log::info(['mailarr', $mailarr]);

            }


        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            $to = ['mansi@xinfin.org', 'raj@xinfin.org'];
            $message = 'Today balance mail failed due to and error : ' . $e->getMessage() . ' ' . $e->getLine() . ' ' . $e->getFile();
            $subject = 'Balance mail failure.';
            sendmail($to, $subject, ['content' => $message]);
            return view('errors.404');
        }
    }

}

