<?php

namespace App\Http\Controllers;

use App\model\Balance;
use App\model\Cms;
use App\model\Country;
use App\model\Enquiry;
use App\model\Faq;
use App\model\OTP;
use App\model\Pair;
use App\model\PairStats;
use App\model\Profit;
use App\model\SiteSettings;
use App\model\Tokenusers;
use App\model\Trade;
use App\model\Transaction;
use App\model\UserBalance;
use App\model\UserCurrencyAddresses;
use App\model\Users;
use App\model\Verification;
use App\model\Currencies;
use App\model\UserBalancesNew;
use App\model\TradeMapping;
use App\model\Erc20Requests;
use App\model\Erc20Details;
use App\model\XinfinRequests;
use App\model\XinfinDetails;
use App\model\ReferralBonus;
use App\model\ExtraBonus;
use App\model\ReferralEarning;
use Cache;
use DB;
use GuzzleHttp\Psr7\_caseless_remove;
use Hash;
use Illuminate\Http\Request;
use Mockery\Exception;
use PragmaRX\Google2FA\Google2FA;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Session;
use Validator;
use Pusher\Pusher;


class UserController extends Controller
{

    public function __construct()
    {
        try {
            //cons;
            $ip = \Request::ip();
            blockip_list($ip);
            return view('errors.404');
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function index()
    {
        try {
            if (Session::get('alphauserid') == "") {
//                $pairs = Pair::where('pair','<>','XDC-XDCE')->get();
//            if(isset($pairs))
//            {
//                foreach ($pairs as $pair)
//                {
//                    $this->update_pairstats($pair->id);
//                }
//            }
//            $this->update_XDC_XDCE('7');
                $result_array = '';
                $get_all_pairs = Pair::all();
                if ($get_all_pairs) {
                    foreach ($get_all_pairs as $get_all_pair) {

                        $get_pair_stat = PairStats::where('pair_id', $get_all_pair->id)->first();
                        $explode = explode('-', $get_all_pair->pair);
                        $first_currency = $explode[0];
                        $currency = $explode[1];
                        $pair = $get_all_pair->pair;
                        $id = $get_pair_stat->id;
                        $vol = $get_pair_stat->volume;
                        $low = $get_pair_stat->low;
                        $high = $get_pair_stat->high;
                        $last = $get_pair_stat->last;
                        $percentage_change = $get_pair_stat->percent_change . '%';
                        $change = $get_pair_stat->change;
                        $color = strtolower($get_pair_stat->colour);

                        $array = array('id' => $id, 'first_currency' => $first_currency, 'currency' => $currency, 'Pair' => $pair, 'Volume' => number_format($vol, 4, '.', ''), 'Low' => number_format($low, 8, '.', '')
                        , 'High' => number_format($high, 8, '.', ''), 'Percentage' => $percentage_change, 'Change' => number_format($change, 8, '.', ''), 'Colour' => $color, 'Last' => number_format($last, 8, '.', ''));
                        $result[] = $array;

                    }
                    $result_array = array('data' => $result);
                }
                return view('front.index', ['results' => $result]);
            } else {
                return redirect('/trade');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function howtostart()
    {
        try {
            return view('front.howtostart');
        } catch (\Exception $exception) {
            return view('front.error');
        }
    }

    function login(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                    'login_mail' => 'required|email',
                    'password' => 'required',
//                'g-recaptcha-response' => 'required|captcha'
                    'captcha' => 'required|captcha',
                ], [
                    'login_mail.required' => 'Email id is required',
                    'login_mail.email' => 'Enter valid email id',
                    'password.required' => 'Password is required',
//                'g-recaptcha-response.required' => 'Please verify that you are human.',
//                'g-recaptcha-response.captcha' => 'Captcha error! try again later or contact site admin.'
                    'captcha.required' => 'Captcha is required',
                    'captcha.captcha' => 'Captcha is wrong',
                ]);
                if ($validator->fails()) {
                    return redirect('login')->withErrors($validator);
                }
                $remember_me = $request['remember_me'];
                $email = strtolower($request['login_mail']);
                $password = $request['password'];
                $ip = \Request::ip();
                $res = $this->user_login_check($email, $password);
                switch ($res) {
                    case '1':
//                        if($email == 'nodeman01@yopmail.com')
                        if (Session::get('alphauserid') == '2690') {
                            $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org'];
                            $subject = 'Nodeman logged in.';
                            $message = 'Nodeman has logged in his account.';
                            sendmail($to, $subject, ['content' => $message]);
                        }
                        //send login status mail
                        $to = [$email];
                        $subject = get_template('17', 'subject');
                        $message = get_template('17', 'template');
                        $mailarr = array(
                            '###EMAIL###' => $email,
                            '###OS###' => getOS(),
                            '###BROWSER###' => getBrowser(),
                            '###IP###' => $ip,
                            '###TIME###' => date('Y-m-d H:i:s'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);
                        if ($remember_me == 'on') {
                            $hour = time() + 3600 * 24 * 30;
                            setcookie('email', $email, $hour);
                            setcookie('password', $password, $hour);
                        }
                        Session::flash('info', 'Welcome To AlphaEx Exchange');
                        return redirect('trade');
                        break;
                    case '5':
                        return view('front.tfacode');
                        break;
                    case '2':
                        Session::flash('error', 'Email or password is wrong');
                        return redirect()->back();
                        break;
                    case '3':
                        Session::flash('error', 'Your account is deactive');
                        return redirect()->back();
                        break;
                    case '4':
                        Session::flash('error', "Email or password is wrong / User dosen't exist.");
                        return redirect()->back();
                        break;
                    case '6':
                        Session::flash('error', 'Please Verify your email address to Login');
                        return redirect()->back();
                        break;
                    case '7':
                        Session::flash('error', 'Please Verify your Mobile Number to Login');
                        return redirect()->back();
                        break;

                    default:
                        Session::flash('error', 'Please Verify your email address to Login');
                        return redirect()->back();
                        break;
                }
            }
            if (Session::get('alphauserid') == "") {
                return view('front.login', ['user_id' => 0]);
            } else {
                return redirect('home');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function check_ripple_balance()
    {
        try {
            $output = array();
            $return_var = -1;
            $path = $_SERVER["DOCUMENT_ROOT"];


            $address = exec('cd ' . $path . '/public/crypto; node xrp.js ', $output, $return_var);
            $result = json_decode($address);
            $bal = $result->xrpBalance;
            return $bal;
        } catch (\Exception $exception) {

            return $path .
                $exception->getMessage();
        }

    }

    function register(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                //  echo "okay"; exit;

                $validator = Validator::make($request->all(), [
                    'first_name' => 'required',
//                'last_name' => 'required',
                    //'username' => 'required',
                    'email_id' => 'required|email',
                    'password' => 'required|confirmed|min:6',
                    'password_confirmation' => 'required|min:6',
//                'country_id' => 'required',
//                    'phone_no' => 'required|numeric',
                    'captcha' => 'required|captcha',
                ], [
                        'first_name.required' => 'First name is required',
//                    'last_name.required' => 'Last name is required',
                        //'username.required' => 'Username is required',
                        'email_id.required' => 'Email id is required',
                        'email_id.email' => 'Enter valid email id',
                        'password.required' => 'Password is required',
//                    'country_id.required' => 'Country is required',
//                        'phone_no.required' => 'Phone number is required',
//                        'phone_no.numeric' => 'Phone number should be digit format',
                        'captcha.required' => 'Captcha is required',
                        'captcha.captcha' => 'Captcha is wrong',
                    ]
                );
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator);
                }
                $ip = \Request::ip();

                $ref_code = strtolower($request['referral_code']);

                if ($ref_code == '') {
                    $user_code = '';
                    $referral_status = 0;
                } else {
                    $user_code = $ref_code;
                    $occurance = Users::where('referral_code', $user_code)->first();
                    if ($occurance == null) {
                        Session::flash('error', 'Referral Code you entered is not valid.');
                        return redirect()->back()->withInput($request->all());
                    }
//                    $referral_status = 1;
//                    if ($user_code != 'tfaex2019') {
//                        Session::flash('error', 'Referral link you entered is not valid.');
//                        return redirect()->back()->withInput($request->all());
//                    }
                    $referral_status = 1;
                }

                $first_name = $request['first_name'];
                $last_name = $request['last_name'];
                $email = strtolower($request['email_id']);
                $splemail = explode("@", $email);
                $end_user1 = encrypt($splemail[0]);
                $end_user2 = encrypt($splemail[1]);
                $res = $this->checking($splemail[0], $splemail[1]);
                if (count($res) > 0) {
                    Session::flash('error', 'The email address already exsits');
                    return redirect()->back();
                }
                $pass_code = bcrypt($request['password']);
                $activation_code = mt_rand(0000, 9999) . time();
                $forgot_code = mt_rand(111111, 999999) . time();
                $verify_status = 2;
                $status = 2;
                $created_at = date('Y-m-d H:i:s');
//                $country = $request['isdcode'];
//                $country = Country::where('phonecode', $country)->first();
//                $country = $country->id;
                $document_status = 0;
//                $mobile_no = $request['phone_no'];
//                $check = $this->checkphone($mobile_no);
//                if (count($check) > 0) {
//                    Session::flash('error', 'The Phone Number Already Exsits.');
//                    return redirect()->back();
//                }
//                $mob_isd = $request['isdcode'];
                $mobile_status = 0;

                $xdc_addr = "";
//                $xdcres = signup_XDC($email, '', $request['password']);
//                if ($xdcres->status == 'FAILED') {
//                    Session::flash('error', 'Problem -' . $xdcres->message);
//                    return redirect()->back();
//                } else {
//                    $xdc_addr = $xdcres->public;
//                }

                $referral_code = generate_uid();
                $true = Users::where('referral_code', $referral_code)->count();
                while ($true > 0) {
                    $referral_code = generate_uid();
                    $true = Users::where('referral_code', $referral_code)->get();
                }

                $xinpass = ownencrypt($request['password']);

                $ins = ['ip' => $ip, 'user_code' => $user_code, 'referral_code' => $referral_code, 'enjoyer_name' => $first_name, 'first_name' => $first_name, 'last_name' => $last_name, 'end_user1' => $end_user1, 'end_user2' => $end_user2, 'pass_code' => $pass_code, 'activation_code' => $activation_code, 'forgot_code' => $forgot_code, 'verify_status' => $verify_status, 'status' => $status, 'created_at' => $created_at, 'country' => '', 'document_status' => $document_status, 'mobile_no' => '', 'mobile_status' => $mobile_status, 'profile_image' => 'noimage.png', 'mob_isd' => '', 'XDC_addr' => $xdc_addr, 'referral_status' => $referral_status, 'xinpass' => $xinpass];

                $insert = Users::insertGetId($ins);
                //$lastid=$insert->id;

                $bal = ['user_id' => $insert, 'BTC' => 0, 'XRP' => 0, 'ETH' => 0, 'XDC' => 0, 'XDCE' => 0, 'BCHABC' => 0, 'ET' => 0, 'BCHSV' => 0, 'USDT' => 0, "USDC" => 0];
                Balance::insert($bal);
                $currencies = Currencies::all();
                foreach ($currencies as $val) {
                    $bal_new = new UserBalancesNew;
                    $bal_new->user_id = $insert;
                    $bal_new->currency_id = $val->unique_id;
                    $bal_new->currency_name = $val->currency_symbol;
                    $bal_new->balance = 0;
                    $bal_new->save();
                }

                if ($ref_code) {
                    if ($occurance) {
                        $referrer_id = $occurance->id;
                        $referred_id = $insert;
                        $referral_bonus = ReferralBonus::where('id', '1')->first();
                        $record = new ReferralEarning;
                        $record->referrer_id = $referrer_id;
                        $record->referred_id = $referred_id;
                        $record->referrer_name = get_user_details($referrer_id, 'enjoyer_name');
                        $record->referred_name = get_user_details($referred_id, 'enjoyer_name');
                        $record->referrer_email = get_usermail($referrer_id);
                        $record->referred_email = get_usermail($referred_id);
                        $record->referrer_bonus = $referral_bonus->referrer_bonus;
                        $record->referred_bonus = $referral_bonus->referred_bonus;
                        $record->referrer_status = 0;
                        $record->referred_status = 0;
                        $record->currency = $referral_bonus->currency;
                        $record->save();
                    }
                }

                if ($xdc_addr) {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $insert;
                    $addr->currency_id = 1;
                    $addr->currency_name = 'XDC';
                    $addr->currency_addr = $xdc_addr;
                    $addr->save();
                }

                //address generator
//                check_live_address($insert);

                //log
                last_activity($email, 'Registration', 0);

                $inst = new Tokenusers;
                $inst->user_id = $insert;
                $inst->email = ownencrypt($email);
                $inst->passcode = ownencrypt($request['password']);
                $inst->phone = '';
                $inst->created_at = $created_at;
                $inst->save();

                $to = $email;
                $subject = get_template('4', 'subject');
                $message = get_template('4', 'template');
                $mailarr = array(
                    '###USERNAME###' => $first_name,
                    '###LINK###' => url('userverification/' . $activation_code),
                    '###SITENAME###' => get_config('site_name'),
                );
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                sendmail($to, $subject, ['content' => $message]);
                Session::flash('success', 'Please check your email address and verified your email address to activate your account');

//            if($mobile_no != "")
//            {
//              $res= verify_user_registeration($mob_isd,$mobile_no,$email);
//              if($res['status'] == 0)
//              {
//                  $insert =0;
//              }
//            }
//            else
//                {
//                    $insert = 0;
//                }

                return view('front.login', ['user_id' => 0]);
            }
            if (Session::get('alphauserid') == "") {
                $country = Country::orderBy('phonecode', 'asc')->get();
                if ($request['referral_code']) {
                    Session::flash('_old_input', $request->all());
                }
                return view('front.register', ['country' => $country, 'user_id' => 0]);
            } else {
                return redirect('home');
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function export_pdf()
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $user_id = Session::get('alphauserid');

                $trade_records = Trade::select('trade_id', 'pair', 'type', 'original_qty', 'price', 'updated_total', 'status', 'updated_at')->where('user_id', $user_id)->
                where('status', 'completed')->get();
                if ($trade_records->count() > 0) {
                    Excel::create('Trade_Records', function ($excel) use ($trade_records) {
                        $excel->sheet('All', function ($sheet) use ($trade_records) {

                            $sheet->fromModel($trade_records, null, "A1", true);
                            $sheet->setOrientation('landscape');
                            $sheet->setScale(5);
                            $sheet->setAllBorders('thin');
                        }
                        );
                    })->export('pdf');
                } else {
                    Session::flash('error', 'This email ID does not exist in our database.');
                    return redirect()->back();
                }
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function export_csv()
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $user_id = Session::get('alphauserid');

                $trade_records = Trade::select('trade_id', 'pair', 'type', 'original_qty', 'price', 'fee', 'updated_total', 'status', 'updated_at')->where('user_id', $user_id)->
                where('status', 'completed')->get();
                if ($trade_records->count() > 0) {
                    Excel::create('Trade_Records', function ($excel) use ($trade_records) {
                        $excel->sheet('All', function ($sheet) use ($trade_records) {

                            $sheet->fromModel($trade_records, null, "A1", true);
                            $sheet->setOrientation('landscape');
                            $sheet->setScale(5);
                            $sheet->setAllBorders('thin');
                        }
                        );
                    })->export('csv');
                } else {
                    Session::flash('error', 'This email ID does not exist in our database.');
                    return redirect()->back();
                }
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function forgotpass(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                    'forgot_mail' => 'required|email',
                ], [
                    'forgot_mail.required' => 'Email id is required',
                    'forgot_mail.email' => 'Enter valid email id',
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator);
                }
                $email = strtolower($request['forgot_mail']);
                $spl = explode("@", $email);
                $user1 = $spl[0];
                $user2 = $spl[1];
                $res = $this->checking($user1, $user2);

                if (count($res) > 0) {
                    foreach ($res as $val) {
                        $to = $email;
                        $subject = get_template('5', 'subject');
                        $message = get_template('5', 'template');
                        $mailarr = array(
                            '###USERNAME###' => $val->enjoyer_name,
                            '###LINK###' => url('resetpassword/' . $val->forgot_code),
                            '###SITENAME###' => get_config('site_name'),
                            '###SITELINK###' => url('/'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);

                        Session::flash('success', 'Check your mail we have sent password reset link');
                        return redirect('/forgotpass');
                    }
                } else {
                    Session::flash('error', 'This email ID does not exist in our database.');
                    return redirect('/forgotpass');
                }

            }
            return view('front.forgotpass');
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function userverification($time)
    {
        try {
            $check = Users::where('activation_code', $time)->first();
            if ($check) {
                $activation_code = mt_rand(0000, 9999) . time();
                $check->activation_code = $activation_code;
                $check->verify_status = 1;
                $check->status = 1;
                $check->save();
                Session::flash('success', 'Your account is activated, Now you can login with your credentials');
                return redirect('/login');
            } else {
                Session::flash('error', 'Invalid Link');
                return redirect('/login');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function checking($end_user1, $end_user2)
    {
        try {
            $items = Users::all()->filter(function ($record) use ($end_user1, $end_user2) {
                if (decrypt($record->end_user1) == $end_user1 && decrypt($record->end_user2) == $end_user2) {
                    return $record;
                } else {
                    return false;
                }
            });

            return $items;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function checkphone($mobile_no)
    {
        try {
            $numbers = Users::all()->filter(function ($record) use ($mobile_no) {
                if (owndecrypt($record->mobile_no) == $mobile_no) {
                    return $record;
                } else {
                    return false;
                }
            });
            return $numbers;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function resetpassword(Request $request, $code)
    {
        try {
            if ($code) {
                $check = Users::where('forgot_code', $code)->first();
                if ($check) {

                    if ($request->isMethod('post')) {
                        $validator = Validator::make($request->all(), [
                            'password' => 'required|confirmed|min:6',
                            'password_confirmation' => 'required|min:6',
                        ]);
                        if ($validator->fails()) {
                            return redirect()->back()->withErrors($validator);
                        }
                        $forgot_code = mt_rand(111111, 999999) . time();
                        $check->forgot_code = $forgot_code;
                        $check->pass_code = bcrypt($request['password']);
                        $check->save();
                        //log
                        last_activity(get_usermail($check->id), 'Reset Password', $check->id);
                        Session::flash('success', 'Successfully password is reset');
                        return redirect('/login');
                    }

                    return view('front.newpass', ['code' => $code]);

                } else {
                    Session::flash('error', 'Invalid Link');
                    return redirect('/forgotpass');
                }
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function aboutus()
    {
        try {
//        $page = Cms::where('link', 'aboutus')->first();
//        return view('front.pages', ['page' => $page]);
            return view('front.aboutus');
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function terms()
    {
        try {
//        $page = Cms::where('link', 'terms')->first();
//        return view('front.pages', ['page' => $page]);
            return view('front.terms');
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function privacy()
    {
        try {
//        $page = Cms::where('link', 'privacy')->first();
//        return view('front.pages', ['page' => $page]);
            return view('front.privacy');
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function faq()
    {
        try {
            $data = Faq::where('status', '1')->orderBy('updated_at', 'desc')->get();
            return view('front.faq', ['data' => $data]);
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function XDCprice()
    {
        try {
            $data = array();
            $XDC_price = Trade::select('Price', 'pair', 'id')->where(['status' => 'completed', 'Type' => 'Buy'])->orderBy('id', 'DESC')->get()->unique('pair');
            if ($XDC_price) {
                $data['status'] = 'success';
                foreach ($XDC_price as $item) {
                    $pair = $item->getAttributeValue('pair');
                    if ($pair == 'XDC-ETH') {
                        $data['last_ETH_price'] = $item->getAttributeValue('Price');
                    } elseif ($pair == 'XDC-XRP') {
                        $data['last_XRP_price'] = $item->getAttributeValue('Price');
                    } elseif ($pair == 'XDC-BTC') {
                        $data['last_BTC_price'] = $item->getAttributeValue('Price');
                    }
                }
            } else {
                $data['status'] = 'success';
                $data['last_ETH_price'] = 0.0000;
                $data['last_XRP_price'] = 0.0000;
                $data['last_BTC_price'] = 0.0000;
            }
            $data['status'] = 'success';
            $data['last_ETH_price'] = 0.0000;
            $data['last_XRP_price'] = 0.0000;
            $data['last_BTC_price'] = 0.0000;
            return (json_encode($data));
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    //xdceprice
    function XDCEprice()
    {
        try {
            $data = array();
            $XDCE_price = Trade::select('Price', 'pair', 'id')->where(['status' => 'completed', 'Type' => 'Buy'])->orderBy('id', 'DESC')->get()->unique('pair');
            if ($XDCE_price) {
                $data['status'] = 'success';
                foreach ($XDCE_price as $item) {
                    $pair = $item->getAttributeValue('pair');
                    if ($pair == 'XDC-ETH') {
                        $data['last_ETH_price'] = $item->getAttributeValue('Price');
                    } elseif ($pair == 'XDC-XRP') {
                        $data['last_XRP_price'] = $item->getAttributeValue('Price');
                    } elseif ($pair == 'XDC-BTC') {
                        $data['last_BTC_price'] = $item->getAttributeValue('Price');
                    } else {
                        $data['last_XDCE_price'] = $item->getAttributrValue('Price');
                    }
                }
            } else {
                $data['status'] = 'success';
                $data['last_ETH_price'] = 0.0000;
                $data['last_XRP_price'] = 0.0000;
                $data['last_BTC_price'] = 0.0000;
                $data['last_XDCE_price'] = 1.0000;
            }
            return (json_encode($data));
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function user_login_check($email, $password)
    {
        try {
            $spl = explode("@", $email);
            $user1 = $spl[0];
            $user2 = $spl[1];
            $res = $this->checking($user1, $user2);
            /*$xdclogin = login_xdc_fun($email, $password);
                if ($xdclogin->status != 'SUCCESS') {
                    return "4";exit();
            */

            if ($res) {
                foreach ($res as $val) {
                    $recordid = $val->id;
                    $recordpass = $val->pass_code;
                    if (Hash::check($password, $recordpass)) {
                        if ($val->status == '1' && ($val->tfa_status == 'disable' || $val->tfa_status == '')) {
                            //log
                            last_activity(get_usermail($recordid), 'Login', $recordid);
                            $sess = array('alphauserid' => $recordid, 'alphausername' => $val->enjoyer_name, 'xinfinpass' => $password);
                            Session::put($sess);
                            return "1";
                        } elseif ($val->status == '1' && $val->tfa_status == 'enable') {
                            //log
                            last_activity(get_usermail($recordid), 'Login', $recordid);
                            Session::put('tfa_key', ownencrypt($recordid));
                            return "5";
                        } elseif ($val->verify_status == '2') {
                            return "6";
                        }
// elseif ($val->mobile_status == '0') {
//                        return "7";
//                    }
                        else {
                            return "3";
                        }

                    } else {
                        return "2";
                    }

                }
            } else {
                return "4";
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function sessionlogout()
    {
        try {
            Session::flush();
            Cache::flush();
            if (Session::get('alphauserid') == "") {
                sleep(1);
                return redirect('login');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function logout()
    {
        try {
            Session::flush();
            Cache::flush();
            if (Session::get('alphauserid') == "") {
                return redirect('sessionlogout');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function dashboard()
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {

                $num = encrypt('bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut');
                $num = owndecrypt('OahuNFlHaGRncWWMemawoFs+QdjPjItcg7jWwaHL+aM=');

                $bch_host = ownencrypt('78.129.229.69');
                $bch_port = ownencrypt('9555');
                $rpcuser = ownencrypt('apexcbitcash');
                $rpcpassword = ownencrypt('ApLExCash@2018%');


                $user_id = Session::get('alphauserid');
//            check_live_address($user_id);

                $xdcaddr = get_user_details($user_id, 'XDC_addr');
                $xdceaddr = get_user_details($user_id, 'XDCE_addr');
//			$xdceaddr ='0x853ac436688033ff32e80ba1f3ea19d19ab098b0';
                $xdcbal = get_livexdc_bal($xdcaddr);
                $xdcebal = get_livexdce_bal($xdceaddr);
                $xdce_blocknum = Transaction::where('type', 'Deposit')->where('currency_name', 'XDCE')->max('blocknumber');

//            $xdceTransactionList = get_xdce_transactions($xdceaddr,$xdce_blocknum);
//
//
//			if ($xdceTransactionList->status == 'true') {
//                    $transaction = $xdceTransactionList->data;
//                    for ($tr = 0; $tr < count($transaction); $tr++) {
//
//                        $block_number = $transaction[$tr]->blockNumber;
//                        $address = $transaction[$tr]->to;
//                        $txid = $transaction[$tr]->tx;
//                        $value = $transaction[$tr]->value;
//
//                        $dep_id = $txid;
//                        $eth_balance = $value;
//                        $ether_balance = $eth_balance;
//
//                        $dep_already = xdce_checkdepositalready($user_id, $dep_id);
//                        if ($dep_already === TRUE && (float)$ether_balance > 0) {
//                            if ($xdceaddr == $address) {
//
//                                $ether_balance = sprintf('%.10f', $ether_balance);
//
//                                //deposit transaction
//                                $transid = 'TXD' . $user_id . time();
//                                $today = date('Y-m-d H:i:s');
//                                $ip = \Request::ip();
//                                $ins = new Transaction;
//                                $ins->user_id = $user_id;
//                                $ins->payment_method = 'Cryptocurrency Account';
//                                $ins->transaction_id = $transid;
//                                $ins->currency_name = 'XDCE';
//                                $ins->type = 'Deposit';
//                                $ins->transaction_type = '1';
//                                $ins->amount = $ether_balance;
//                                $ins->updated_at = $today;
//                                $ins->crypto_address = $xdceaddr;
//                                $ins->transfer_amount = '0';
//                                $ins->fee = '0';
//                                $ins->tax = '0';
//                                $ins->verifycode = '1';
//                                $ins->order_id = '0';
//                                $ins->status = 'Completed';
//                                $ins->cointype = '2';
//                                $ins->payment_status = 'Paid';
//                                $ins->paid_amount = '0';
//                                $ins->wallet_txid = $dep_id;
//                                $ins->ip_address = $ip;
//                                $ins->verify = '1';
//                                $ins->blocknumber = '';
//                                if($ins->save())
//                                {
//                                    //update user
//                                    $fetchbalance = get_userbalance($user_id, 'XDCE');
//                                    $finalbalance = $fetchbalance + $ether_balance;
//                                    $upt = Balance::where('user_id', $user_id)->first();
//                                    $upt->XDCE = $finalbalance;
//                                    $upt->save();
//                                    deposit_mail($user_id, $ether_balance, $transid, 'XDCE');
//                                }
//                            }
//                        }
//                    }
//
//                }


//            if ($xdcbal > 0) {
//                $email = get_usermail($user_id);
//                //$pass = Session::get('xinfinpass');
//                $pass = get_user_details($user_id, 'xinpass');
//                login_xdc_fun($email, owndecrypt($pass));
//                $adminxdcaddr = decrypt(get_config('xdc_address'));
//                $res = transfer_xdctoken($xdcaddr, $xdcbal, $adminxdcaddr, $user_id, owndecrypt($pass));
//                if ($res->status == 'SUCCESS') {
//                    $fetchbalance = get_userbalance($user_id, 'XDC');
//                    $uptbal = $fetchbalance + $xdcbal;
//                    $upt = Balance::where('user_id', $user_id)->first();
//                    $upt->XDC = $uptbal;
//                    $upt->save();
//
//                    $transid = 'TXD' . $user_id . time();
//                    $today = date('Y-m-d H:i:s');
//                    $ip = \Request::ip();
//                    $ins = new Transaction;
//                    $ins->user_id = $user_id;
//                    $ins->payment_method = 'Cryptocurrency Account';
//                    $ins->transaction_id = $transid;
//                    $ins->currency_name = 'XDC';
//                    $ins->type = 'Deposit';
//                    $ins->transaction_type = '1';
//                    $ins->amount = $xdcbal;
//                    $ins->updated_at = $today;
//                    $ins->crypto_address = $xdcaddr;
//                    $ins->transfer_amount = '0';
//                    $ins->fee = '0';
//                    $ins->tax = '0';
//                    $ins->verifycode = '1';
//                    $ins->order_id = '0';
//                    $ins->status = 'Completed';
//                    $ins->cointype = '2';
//                    $ins->payment_status = 'Paid';
//                    $ins->paid_amount = '0';
//                    $ins->wallet_txid = '';
//                    $ins->ip_address = $ip;
//                    $ins->verify = '1';
//                    $ins->blocknumber = '';
//                    $ins->save();
//                }
//            }
                if ($xdceaddr != '') {
                    xdce_deposit_process_user($xdceaddr);
                }

                $data = [
                    'aid' => $user_id,
                    'status' => get_user_details($user_id, 'status'),
                    'mobile_status' => get_user_details($user_id, 'mobile_status'),
                    'document_status' => get_user_details($user_id, 'document_status'),
                ];
                return view('front.dashboard', $data);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    //history page
    function history($curr = '')
    {
        try {
            if (Session::get('alphauserid') == '') {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                $curr = $curr ? $curr : 'XDC';

                $open_orders = Trade::where('user_id', $userid)->whereIn('status', ['active', 'partially'])
                    ->where(function ($query) use ($curr) {
                        $query->where('firstCurrency', '=', $curr)->orWhere('secondCurrency', '=', $curr);
                    })->orderBy('created_at', 'desc')->get();
                $history = Trade::where('user_id', $userid)->whereIn('status', ['completed', 'cancelled', 'partially'])
                    ->where(function ($query) use ($curr) {
                        $query->where('firstCurrency', '=', $curr)->orWhere('secondCurrency', '=', $curr);
                    })->orderBy('created_at', 'desc')->get();
//            if($curr == 'XDC')
//            {
//                $open_orders = Trade::where('user_id',$userid)->whereIn('status',['active','partially'])->where('firstCurrency','=',$curr)->orderBy('updated_at', 'desc')->get();
//                $history = Trade::where('user_id',$userid)->whereIn('status',['completed','cancelled'])->where('firstCurrency','=',$curr)->orderBy('updated_at','desc')->get();
//            }
//            else {
//                $open_orders = Trade::where('user_id', $userid)->whereIn('status', ['active', 'partially'])->where('secondCurrency', '=', $curr)->orderBy('updated_at', 'desc')->get();
//                $history = Trade::where('user_id', $userid)->whereIn('status', ['completed', 'cancelled'])->where('secondCurrency', '=', $curr)->orderBy('updated_at', 'desc')->get();
//            }
                $deposit = Transaction::where('user_id', $userid)->where('type', 'Deposit')->where('currency_name', $curr)->orderBy('created_at', 'desc')->get();
                $withdraw = Transaction::where('user_id', $userid)->where('type', 'Withdraw')->where('currency_name', $curr)->orderBy('created_at', 'desc')->get();
                return view('front.history', ['open_orders' => $open_orders, 'history' => $history, 'deposit' => $deposit, 'withdraw' => $withdraw, 'currency' => $curr, 'userid' => $userid]);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    //kyc page
    function kyc_details(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            }
            if (!Session::get('JWT_TOKEN') == $request['hiddentoken']) {
                Session::flush();
                return redirect('logout');

            } else {
                if ($request->isMethod('post')) {
                    $user_id = Session::get('alphauserid');
                    $result = Users::where('id', $user_id)->first();
                    $verification = Verification::where('user_id', $user_id)->first();
                    if ($verification == null) {
                        $verification = new Verification();
                    }
                    $verify = Verification::where('user_id', '<>', $user_id)->where('national_id', 'like', $request['document_id'])->first();
                    if ($verify != null) {
                        Session::flash('error', 'The entered ID number is already registered.');
                        return redirect()->back();
                    }
                    $verification->user_id = $user_id;
                    $verification->proof1_status = 0;
                    $verification->proof2_status = 0;
                    $verification->proof3_status = 0;
                    $verification->first_name = $request['first_name'];
                    $verification->last_name = $request['last_name'];
                    $verification->country_code = $request['kyc_country_id'];
                    $verification->gender = $request['gender'];
                    $verification->national_id = $request['document_id'];
                    if ($request['f_side']) {
                        $info = pathinfo($_FILES['f_side']['name']);
                        $mime = mime_content_type($_FILES['f_side']['tmp_name']);
                        $mime_array = ['image/png', 'image/jpeg'];
                        $ext = strtolower($info['extension']);
                        $ext_array = ['png', 'jpg', 'jpeg'];
                        if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
//                    $file_name = $user_id.'_'.'f_side.'.$ext;
                            $check = uniqid("", 'true') . '.' . $ext;
                            $file_name = $this->check_unique($check, $ext);
                            while ($check != $file_name) {
                                $check = $this->check_unique($file_name, $ext);
                            }
//                    $target = $_SERVER['DOCUMENT_ROOT'].'/public/uploads/users/documents/'.$file_name;
//                    if($verification->proof1!='') {
//                        $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/documents/' . $verification->proof1;
//                        unlink($target1);
//                    }
//                    move_uploaded_file( $_FILES['f_side']['tmp_name'], $target);
                            if ($verification->proof1 != '') {
                                Storage::disk('ftp')->delete($verification->proof1);
                            }
                            Storage::disk('ftp')->put($file_name, fopen($request->file('f_side'), 'r+'));
                            $verification->proof1 = $file_name;
                        } else {
                            $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                            $subject = 'Some user trying to upload malicious file in KYC.';
                            $message = 'User id :' . $user_id . ', Email id : ' . get_usermail($user_id) . ' is trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                            sendmail($to, $subject, ['content' => $message]);
                            $result->status = '2';
                            $result->save();
                            Session::flash('error', 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.');
                            return redirect('logout');
                        }
                    }
                    if ($request['b_side']) {
                        $info = pathinfo($_FILES['b_side']['name']);
                        $mime = mime_content_type($_FILES['b_side']['tmp_name']);
                        $mime_array = ['image/png', 'image/jpeg'];
                        $ext = strtolower($info['extension']);
                        $ext_array = ['png', 'jpg', 'jpeg'];
                        if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
//                    $file_name = $user_id.'_'.'b_side.'.$ext;
                            $check = uniqid("", 'true') . '.' . $ext;
                            $file_name = $this->check_unique($check, $ext);
                            while ($check != $file_name) {
                                $check = $this->check_unique($file_name, $ext);
                            }
//                    $target = $_SERVER['DOCUMENT_ROOT'].'/public/uploads/users/documents/'.$file_name;
//                    if($verification->proof2!='') {
//                        $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/documents/' . $verification->proof2;
//                        unlink($target1);
//                    }
//                    move_uploaded_file( $_FILES['b_side']['tmp_name'], $target);
                            if ($verification->proof2 != '') {
                                Storage::disk('ftp')->delete($verification->proof2);
                            }
                            Storage::disk('ftp')->put($file_name, fopen($request->file('b_side'), 'r+'));
                            $verification->proof2 = $file_name;
                        } else {
                            $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                            $subject = 'Some user trying to upload malicious file in KYC.';
                            $message = 'User id :' . $user_id . ', Email id : ' . get_usermail($user_id) . ' is trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                            sendmail($to, $subject, ['content' => $message]);
                            $result->status = '2';
                            $result->save();
                            Session::flash('error', 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.');
                            return redirect('logout');
                        }
                    }
                    if ($request['h_side']) {
                        $info = pathinfo($_FILES['h_side']['name']);
                        $mime = mime_content_type($_FILES['h_side']['tmp_name']);
                        $mime_array = ['image/png', 'image/jpeg'];
                        $ext = strtolower($info['extension']);
                        $ext_array = ['png', 'jpg', 'jpeg'];
                        if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
//                    $file_name = $user_id.'_'.'h_side.'.$ext;
                            $check = uniqid("", 'true') . '.' . $ext;
                            $file_name = $this->check_unique($check, $ext);
                            while ($check != $file_name) {
                                $check = $this->check_unique($file_name, $ext);
                            }
//                    $target = $_SERVER['DOCUMENT_ROOT'].'/public/uploads/users/documents/'.$file_name;
//                    if($verification->proof3!='') {
//                        $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/documents/' . $verification->proof3;
//                        unlink($target1);
//                    }
//                    move_uploaded_file( $_FILES['h_side']['tmp_name'], $target);
                            if ($verification->proof3 != '') {
                                Storage::disk('ftp')->delete($verification->proof3);
                            }
                            Storage::disk('ftp')->put($file_name, fopen($request->file('h_side'), 'r+'));
                            $verification->proof3 = $file_name;
                        } else {
                            $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                            $subject = 'Some user trying to upload malicious file in KYC.';
                            $message = 'User id :' . $user_id . ', Email id : ' . get_usermail($user_id) . ' is trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                            sendmail($to, $subject, ['content' => $message]);
                            $result->status = '2';
                            $result->save();
                            Session::flash('error', 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.');
                            return redirect('logout');
                        }
                    }
                    if ($verification->save()) {
                        $user = Users::where('id', $user_id)->first();
                        $user->document_status = 3;
                        $user->save();
                        Session::flash('success', 'Your Kyc Verification request is placed.');
                        return redirect()->back();
                    } else {
                        Session::flash('error', 'Server error please retry again.');
                        return redirect()->back();
                    }
                }
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function check_unique($file_name, $ext)
    {
        try {
            $check = Verification::where('proof1', $file_name)->orWhere('proof2', $file_name)->orWhere('proof3', $file_name)->get();
            if (count($check) > 0) {
                $file_name = uniqid("", 'true') . '.' . $ext;
                return $file_name;
            } else {
                return $file_name;
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function profile(Request $request)
    {

        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');

            } else {
                $flag = 0;
                $user_id = Session::get('alphauserid');
                $result = Users::where('id', $user_id)->first();
                if ($request->isMethod('post')) {
                    if (!Session::get('JWT_TOKEN') == $request['hiddentoken']) {
                        Session::flush();
                        return redirect('logout');

                    }
                    $validator = Validator::make($request->all(), [
                        'username' => 'required',
                        'first_name' => 'required',
                        'last_name' => 'required',
                        'telephone' => 'required|numeric',
                        'city' => 'required',
                        'address' => 'required',
                        'state' => 'required',
                    ]);
                    if ($validator->fails()) {
                        return redirect()->back()->withErrors($validator);
                    }
                    if ($request['ptostatus']) {
                        $checkmobile = decrypt($request['ptostatus']);
                        if ($checkmobile) {
                            $splmob = explode("#", $checkmobile);
                            if ($splmob[0] == $request['telephone']) {
                                $result->mobile_no = ownencrypt($request['telephone']);
                                $result->mobile_status = '1';
                            }
                        }
                    }
                    $result->enjoyer_name = $request['username'];
                    $result->first_name = $request['first_name'];
                    $result->last_name = $request['last_name'];
                    $result->mobile_no = ownencrypt($request['telephone']);
                    $result->mob_isd = $request['isdcode'];
                    $result->city = $request['city'];
                    $result->address = $request['address'];
                    $result->state = $request['state'];
                    $result->country = $request['country_id'];
                    if ($request['imageUpload']) {
                        $info = pathinfo($_FILES['imageUpload']['name']);
                        $mime = mime_content_type($_FILES['imageUpload']['tmp_name']);
                        $mime_array = ['image/png', 'image/jpeg'];
                        $ext = strtolower($info['extension']);
                        $ext_array = ['png', 'jpg', 'jpeg'];
                        if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
                            $file_name = $user_id . '_' . 'imageUpload.' . $ext;

                            $target = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/profileimg/' . $file_name;
                            if ($result->profile_image != '' && $result->profile_image != 'noimage.png') {
                                $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/profileimg/' . $result->profile_image;
                                unlink($target1);
                            }
                            move_uploaded_file($_FILES['imageUpload']['tmp_name'], $target);
                            $result->profile_image = $file_name;
                        } else {
                            $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                            $subject = 'Some user trying to upload malicious file in profile image.';
                            $message = 'User id : ' . $result->id . ', Email id : ' . get_usermail($result->id) . ' trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                            sendmail($to, $subject, ['content' => $message]);
                            $result->status = '2';
                            $result->save();
                            Session::flash('error', 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.');
                            return redirect('logout');
                        }
                    }
                    if ($result->isDirty('mobile_no')) {
                        $check = $this->checkphone($request['telephone']);
                        if (count($check) > 0) {
                            Session::flash('error', 'The Phone Number Already Exsits.');
                            return redirect()->back();
                        }
                        $result->mobile_status = 0;
                        $result->save();
                        $flag = 1;
                    } else {
                        $result->save();
                        Session::flash('success', 'Profile Updated Successfully');
                    }
                    //log
                    last_activity(get_usermail($user_id), 'Profile Update', $user_id);
                    $country = Country::orderBy('phonecode', 'asc')->get();
                    $country_name = Country::all();
                    $countrycode = Country::where('phonecode', $result->mob_isd)->first();
                    $verification = Verification::where('user_id', $user_id)->first();

                    $google2fa = new Google2FA();
                    if ($result->tfa_code != "") {
                        $secret_code = $result->tfa_code;
                    } else {
                        $secret_code = $google2fa->generateSecretKey();
                        $result->tfa_code = $secret_code;
                        $result->tfa_status = 'disable';
                        $result->save();
                    }
                    $tfa_url = $google2fa->getQRCodeGoogleUrl(get_config('site_name'), get_usermail($user_id), $secret_code);

                    $data = ['result' => $result, 'countrycode' => $countrycode, 'flag' => 0, 'country' => $country, 'verification' => $verification, 'country_name' => $country_name, 'tfa_url' => $tfa_url, 'secret_code' => $secret_code];
                    return view('front.profile', $data);
                }
                $country = Country::orderBy('phonecode', 'asc')->get();
                $country_name = Country::all();
                $countrycode = Country::where('phonecode', $result->mob_isd)->first();
                $verification = Verification::where('user_id', $user_id)->first();

                $google2fa = new Google2FA();
                if ($result->tfa_code != "") {
                    $secret_code = $result->tfa_code;
                } else {
                    $secret_code = $google2fa->generateSecretKey();
                    $result->tfa_code = $secret_code;
                    $result->tfa_status = 'disable';
                    $result->save();
                }
                $tfa_url = $google2fa->getQRCodeGoogleUrl(get_config('site_name'), get_usermail($user_id), $secret_code);

                $data = ['result' => $result, 'countrycode' => $countrycode, 'flag' => 0, 'country' => $country, 'verification' => $verification, 'country_name' => $country_name, 'tfa_url' => $tfa_url, 'secret_code' => $secret_code];
                return view('front.profile', $data);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function change_password(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            }
            if (Session::get('JWT_TOKEN') != $request['changepasswordtoken']) {
                Session::flush();
                return redirect('logout');

            } else {
                if ($request->isMethod('post')) {
                    $validator = Validator::make($request->all(), [
                        'old_password' => 'required',
                        'password' => 'required|confirmed|min:6',
                        'password_confirmation' => 'required|min:6',
                    ]);
                    if ($validator->fails()) {
                        return redirect()->back()->withErrors($validator);
                    }
                    $userid = Session::get('alphauserid');
                    $old_password = $request['old_password'];
                    $password = $request['password'];
                    if ($old_password == $password) {
                        Session::flash('error', 'Password can not be the same as old one');
                        return redirect()->back();
                    }
                    $upt = Users::where('id', $userid)->first();
                    if (Hash::check($old_password, $upt->pass_code)) {
                        $upt->pass_code = bcrypt($password);
                        $upt->save();
                        //log
                        last_activity(get_usermail($userid), 'Profile Update', $userid);
                        Session::flash('success', 'Password changed Successfully.');
                    } else {
                        Session::flash('error', 'Old password is wrong.');
                    }

                }
                return redirect('profile');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function document_submission(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'proof1' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
                        'proof2' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
                        'proof3' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
                    ], [
                        'proof1.image' => 'Pan card upload image format',
                        'proof2.image' => 'Adhaar card upload image format',
                        'proof3.image' => 'Address proof upload image format',
                    ]);

                    $ins = Verification::firstOrCreate(['user_id' => $userid]);
                    if ($request->hasFile('proof1')) {
                        $proof1 = 'PAN' . time() . '.' . $request->proof1->getClientOriginalExtension();
                        $request->proof1->move(public_path('/public/uploads/users/documents'), $proof1);
                        $ins->proof1 = $proof1;
                        $ins->proof1_status = '0';
                    }

                    if ($request->hasFile('proof2')) {
                        $proof2 = 'ADHAAR' . time() . '.' . $request->proof2->getClientOriginalExtension();
                        $request->proof2->move(public_path('/public/uploads/users/documents'), $proof2);
                        $ins->proof2 = $proof2;
                        $ins->proof2_status = '0';
                    }

                    if ($request->hasFile('proof3')) {
                        $proof3 = 'AD' . time() . '.' . $request->proof3->getClientOriginalExtension();
                        $request->proof3->move(public_path('/public/uploads/users/documents'), $proof3);
                        $ins->proof3 = $proof3;
                        $ins->proof3_status = '0';
                    }
                    $ins->user_id = $userid;
                    $ins->save();

                    $upt = Users::where('id', $userid)->first();
                    $upt->document_status = '0';
                    $upt->save();

                    Session::flash('success', 'Successfully KYC documents submited. ');
                }
                return redirect('profile#kycdocuments');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function security(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');

            }
            if (!Session::get('JWT_TOKEN') == $request['securitytoken']) {
                Session::flush();
                return redirect('logout');

            } else {
                $userid = Session::get('alphauserid');
                $google2fa = new Google2FA();
                $userdata = Users::where('id', $userid)->first();
                if ($request->isMethod('post')) {
                    $onecode = $request['onecode'];
                    //$valid = $google2fa->verifyKey($userdata->tfa_code, $onecode);
                    $valid = checktfa_code($userdata->tfa_code, $onecode);
                    if ($valid == 1) {
                        if ($userdata->tfa_status == 'enable') {
                            $userdata->tfa_status = 'disable';
                        } else {
                            $userdata->tfa_status = 'enable';
                        }

                        $userdata->save();
                        Session::flash('success', 'Successfully ' . $userdata->tfa_status . 'd');
                        return redirect()->back();
                    } else {
                        Session::flash('error', 'Wrong Google authenticator otp code');
                        return redirect()->back();
                    }
                }
                return redirect()->back();
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function logindo(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $tfa_key_cli = $request['tfa_key'];
                $tfa_code = $request['tfa_code'];
                $tfa_key_ser = Session::get('tfa_key');
                if (owndecrypt($tfa_key_cli) == owndecrypt($tfa_key_ser)) {
                    $userid = owndecrypt($tfa_key_ser);
                    $userdata = Users::where('id', $userid)->first();
                    $google2fa = new Google2FA();
                    //$valid = $google2fa->verifyKey($userdata->tfa_code, $tfa_code);
                    $valid = checktfa_code($userdata->tfa_code, $tfa_code);
                    $ip = \Request::ip();
                    $email = get_usermail($userid);
                    if ($valid == 1) {
                        $sess = array('alphauserid' => $userdata->id, 'alphausername' => $userdata->enjoyer_name);
                        if ($userdata->id == '2690') {
                            $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org'];
                            $subject = 'Nodeman logged in.';
                            $message = 'Nodeman has logged in his account.';
                            sendmail($to, $subject, ['content' => $message]);
                        }
                        $to = [$email];
                        $subject = get_template('17', 'subject');
                        $message = get_template('17', 'template');
                        $mailarr = array(
                            '###EMAIL###' => $email,
                            '###OS###' => getOS(),
                            '###BROWSER###' => getBrowser(),
                            '###IP###' => $ip,
                            '###TIME###' => date('Y-m-d H:i:s'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);
                        Session::put($sess);
                        Session::flash('info', 'Welcome To AlphaEx Exchange');
                        return redirect('trade');
                    } else {
                        Session::flash('error', '2FA code is wrong');
                        return view('front.tfacode');
                    }

                } else {
                    Session::flush();
                    Cache::flush();
                    Session::flash('error', 'Some problem happened Please try again');
                    return redirect('login');
                }
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function deposit()
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                check_live_address($userid);
                if (get_user_details($userid, 'document_status') != '1') {
                    // Session::flash('error','Please Complete your KYC process');
                    //  return redirect('profile');
                }
                $id = encrypt('rhfzdZgZPTSqGVW41cwdfG4uudEhMwnd22');
                $sec = encrypt('snLgURciFLKyZZmW21zN1UyRCa2mC');
                $result = Users::where('id', $userid)->first();
                $xrpResult = SiteSettings::all()->first();
                return view('front.deposit', ['result' => $result, 'Xrpresult' => $xrpResult]);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function wallet()
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                if (get_user_details($userid, 'document_status') != '1') {
                    //Session::flash('error','Please Complete your KYC process');
                    //return redirect('profile');
                }

                check_live_address($userid);
                $currencies = DB::table('user_currency_addresses')->where('user_currency_addresses.user_id', '=', $userid)
                    ->join('user_balance_new', function ($join) {
                        $join->on('user_balance_new.user_id', '=', 'user_currency_addresses.user_id');
                        $join->on('user_balance_new.currency_id', '=', 'user_currency_addresses.currency_id');
                    })
                    ->orderBy('user_balance_new.currency_id', 'asc')
                    ->select('user_currency_addresses.*', 'user_balance_new.*')->get();
                $user = Users::where('id', $userid)->first();
                return view('front.wallet', ['userid' => $userid, 'result' => $user, 'currencies' => $currencies]);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function transfercrypto($currency = "")
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                if (get_user_details($userid, 'mobile_status') == 9) {
                    $isd_code = get_user_details($userid, 'mob_isd');
                    $mob = owndecrypt(get_user_details($userid, 'mobile_no'));
                    $res = verify_user_registeration($isd_code, $mob, 'xy');

                    Session::flash('error', 'Please Complete your Mobile verification');
                    return redirect('/dashboard');
                } elseif ($currency != "") {
                    $userid = Session::get('alphauserid');

                    if (get_user_details($userid, 'document_status') != '1') {
                        //Session::flash('error','Please Complete your KYC process');
                        // return redirect('profile');
                    }

                    $currency = strtoupper($currency);

                    $data = ['urlcurrency' => ownencrypt($currency), 'currency' => $currency, 'userid' => $userid];
                    return view('front.transfer', $data);
                } else {
                    return redirect('logout');
                }
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function transferverify(Request $request, $currency)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            }
            if (!Session::get('JWT_TOKEN') == $request['hiddentoken']) {
                Session::flush();
                return redirect('logout');

            } else {
                if ($request->isMethod('post')) {
                    $userid = Session::get('alphauserid');
                    if (get_user_details($userid, 'document_status') != 1) {
                        $message = 'Please complete your KYC to place a withdrawal request.';
                        Session::flash('error', $message);
                        return redirect()->back();
                    }
                    $validator = Validator::make($request->all(), [
                        'to_addr' => 'required',
                        'to_amount' => 'required',
                        'total_amount' => 'required',
                        'otp_code' => 'required',
                    ]);
                    if ($validator->fails()) {
                        return redirect()->back()->withErrors($validator);
                    }
                    $min = min_withdraw($currency);

                    if ($currency == 'XDC') {
                        if (strlen($request['to_addr']) == 43) {
                            if (substr($request['to_addr'], 0, 3) != 'xdc') {
                                $message = 'Address should start with xdc instead of 0x';
                                Session::flash('error', $message);
                                return redirect()->back();
                            }
                        } else {
                            $message = 'Invalid Address';
                            Session::flash('error', $message);
                            return redirect()->back();
                        }
                    }

                    if ($request['to_amount'] < $min) {
                        $message = 'Minimum withdrawal of ' . $currency . ' is ' . $min;
                        Session::flash('error', $message);
                        return redirect()->back();
                    }
                    if ($request['total_amount'] == 0) {
                        Session::flash('error', 'Wrong amount entered');
                        return redirect('wallet');
                    }
                    if (strtolower($request['to_addr']) == get_user_details($userid, $currency . '_addr')) {
                        Session::flash('error', 'To address as same as your address check it');
                        return redirect('wallet');
                    }
                    if ($request['total_amount'] > get_userbalance($userid, $currency)) {
                        Session::flash('error', 'Insufficient Balance');
                        return redirect('wallet');
                    }
                    if (!$this->checkotpcode($request['otp_code'], 'Withdraw')) {
                        Session::flash('error', 'OTP Code is wrong');
                        return redirect('wallet');
                    }
                    $to_addr = $request['to_addr'];
                    $amount = $request['to_amount'];


                    $paid_amount = $request['total_amount'];
                    $fee = $amount - $paid_amount;

                    $get_fee = getfee($currency);
                    if ($currency == 'XDCE') {
                        $fee = $amount * ($get_fee / 100);
                        $paid_amount = $amount - $fee;
                    } else {
                        $fee = $get_fee;
                        $paid_amount = $amount - $fee;
                    }

                    if ($currency == 'XRP') {
                        $xrp_desttag = $request['xrp_desttag'];
                    } else {
                        $xrp_desttag = "";
                    }

                    $transid = 'TXW' . $userid . time();
                    $today = date('Y-m-d H:i:s');
                    $ip = \Request::ip();
                    $ins = new Transaction;
                    $ins->user_id = $userid;
                    $ins->payment_method = 'Cryptocurrency Account';
                    $ins->transaction_id = $transid;
                    $ins->currency_name = $currency;
                    $ins->type = 'Withdraw';
                    $ins->transaction_type = '2';
                    $ins->amount = $amount;
                    $ins->updated_at = $today;
                    $ins->crypto_address = $to_addr;
                    $ins->transfer_amount = '0';
                    $ins->fee = $fee;
                    $ins->tax = '0';
                    $ins->verifycode = '1';
                    $ins->order_id = '0';
                    $ins->status = 'Pending';
                    $ins->cointype = '2';
                    $ins->payment_status = 'Not Paid';
                    $ins->paid_amount = $paid_amount;
                    $ins->wallet_txid = '';
                    $ins->ip_address = $ip;
                    $ins->verify = '1';
                    $ins->blocknumber = '';
                    $ins->xrp_desttag = $xrp_desttag;
                    $ins->ledgerversion = '';
                    if ($ins->save()) {
                        $fetchbalance = get_userbalance($userid, $currency);
                        $uptamt = $fetchbalance - $amount;
                        $upt = Balance::where('user_id', $userid)->first();
                        $upt->$currency = $uptamt;
                        $upt->save();
                        Session::flash('success', 'Withdraw request successfully transferred to Admin');
                        return redirect('wallet');
                    }
                }
                return redirect('wallet');
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function checkotpcode($code, $type)
    {
        try {
            $userid = Session::get('alphauserid');
            $mobile = get_user_details($userid, 'mobile_no');
            $check = OTP::where('mobile_no', $mobile)->where('otp', ownencrypt($code))->where('activity', $type)->orderBy('id', 'desc')->limit(1)->first();
            if (count($check) > 0) {

                try {
                    OTP::where('mobile_no', $mobile)->where('otp', ownencrypt($code))->where('activity', $type)->orderBy('id', 'desc')->delete();
                } catch (\Exception $e) {
                    echo $e;
                }

                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function deposit_history()
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');

                if (get_user_details($userid, 'document_status') != '1') {
                    //Session::flash('error','Please Complete your KYC process');
                    // return redirect('profile');
                }

                $result = Transaction::where(['type' => 'Deposit', 'user_id' => $userid])->orderBy('created_at', 'desc')->paginate(10);
                return view('front.history', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function transfer_history()
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');

                if (get_user_details($userid, 'document_status') != '1') {
                    //Session::flash('error','Please Complete your KYC process');
                    //return redirect('profile');
                }
                $result = Transaction::where(['type' => 'Withdraw', 'user_id' => $userid])->orderBy('created_at', 'desc')->paginate(10);
                return view('front.transfer_history', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function exchange($pair = "")
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                if (get_user_details($userid, 'document_status') != '1') {
                    // Session::flash('error','Please Complete your KYC process');
                    // return redirect('profile');
                }

                $xdcaddr = get_user_details($userid, 'XDC_addr');
                $xdcbal = get_livexdc_bal($xdcaddr);
                //$xdcbal = 0;
                if ($xdcbal > 0) {
                    $email = get_usermail($userid);
                    //$pass = Session::get('xinfinpass');
                    $pass = get_user_details($userid, 'xinpass');
                    login_xdc_fun($email, owndecrypt($pass));
                    $adminxdcaddr = decrypt(get_config('xdc_address'));
                    $res = transfer_xdctoken($xdcaddr, $xdcbal, $adminxdcaddr, $userid, owndecrypt($pass));
                    if ($res->status == 'SUCCESS') {
                        $fetchbalance = get_userbalance($userid, 'XDC');
                        $uptbal = $fetchbalance + $xdcbal;
                        $upt = Balance::where('user_id', $userid)->first();
                        $upt->XDC = $uptbal;
                        $upt->save();

                        $transid = 'TXD' . $userid . time();
                        $today = date('Y-m-d H:i:s');
                        $ip = \Request::ip();
                        $ins = new Transaction;
                        $ins->user_id = $userid;
                        $ins->payment_method = 'Cryptocurrency Account';
                        $ins->transaction_id = $transid;
                        $ins->currency_name = 'XDC';
                        $ins->type = 'Deposit';
                        $ins->transaction_type = '1';
                        $ins->amount = $xdcbal;
                        $ins->updated_at = $today;
                        $ins->crypto_address = $xdcaddr;
                        $ins->transfer_amount = '0';
                        $ins->fee = '0';
                        $ins->tax = '0';
                        $ins->verifycode = '1';
                        $ins->order_id = '0';
                        $ins->status = 'Completed';
                        $ins->cointype = '2';
                        $ins->payment_status = 'Paid';
                        $ins->paid_amount = '0';
                        $ins->wallet_txid = '';
                        $ins->ip_address = $ip;
                        $ins->verify = '1';
                        $ins->blocknumber = '';
                        $ins->save();
                    }
                }

                $pair = $pair ? $pair : 'XDC-ETH';

                $checkpair = Pair::where(['type' => 'exchange', 'pair' => $pair])->count();
                if ($checkpair == 0) {
                    abort(404);
                }

                $cur = explode("-", $pair);
                $first_currency = $cur[0];
                $second_currency = $cur[1];

                $buy_order = Transaction::where(['user_id' => $userid, 'pair' => $pair, 'type' => 'Buy'])->orderBy('id', 'desc')->paginate(10);
                $sell_order = Transaction::where(['user_id' => $userid, 'pair' => $pair, 'type' => 'Sell'])->orderBy('id', 'desc')->paginate(10);

                $fitst_cur_usd_price = get_estusd_price($first_currency, 1);
                $second_cur_usd_price = get_estusd_price($second_currency, 1);

                $first_cur_ex_price = get_market_price($first_currency, $second_currency);
                $second_cur_ex_price = get_market_price($second_currency, $first_currency);

                $min_ex_limit = get_fee_settings('buy_sell_limit');
                $max_ex_limit = get_fee_settings('buy_sell_limit_max');
                $ex_fee = get_fee_settings('exchange_fee');

                $first_cur_balance = get_userbalance($userid, $first_currency);
                $second_cur_balance = get_userbalance($userid, $second_currency);

                $data = ['pair' => $pair, 'first_currency' => $first_currency, 'second_currency' => $second_currency, 'buy_order' => $buy_order, 'sell_order' => $sell_order, 'fitst_cur_usd_price' => $fitst_cur_usd_price, 'second_cur_usd_price' => $second_cur_usd_price, 'first_cur_ex_price' => $first_cur_ex_price, 'second_cur_ex_price' => $second_cur_ex_price, 'min_ex_limit' => $min_ex_limit, 'max_ex_limit' => $max_ex_limit, 'ex_fee' => $ex_fee, 'first_cur_balance' => $first_cur_balance, 'second_cur_balance' => $second_cur_balance];

                return view('front.exchange', $data);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function indexexchange($pair = "")
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                if (get_user_details($userid, 'document_status') != '1') {
                    // Session::flash('error','Please Complete your KYC process');
                    //  return redirect('profile');
                }
                return redirect('exchange/' . $pair);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function exchangepair(Request $request, $pair = "")
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');
                if (get_user_details($userid, 'document_status') != '1') {
                    //  Session::flash('error','Please Complete your KYC process');
                    //   return redirect('profile');
                }
                if ($request->isMethod('post')) {
                    $type = $request['type'];
                    $pair = $pair ? $pair : 'XDC-ETH';
                    $cur = explode("-", $pair);
                    $first_currency = $cur[0];
                    $second_currency = $cur[1];
                    $userid = Session::get('alphauserid');

                    $min_ex_limit = get_fee_settings('buy_sell_limit');
                    $max_ex_limit = get_fee_settings('buy_sell_limit_max');

                    $first_cur_bal = get_userbalance($userid, $first_currency);
                    $second_cur_bal = get_userbalance($userid, $second_currency);

                    $data = array();
                    $first_cur_ex_price = get_market_price($first_currency, $second_currency);
                    $second_cur_ex_price = get_market_price($second_currency, $first_currency);
                    $first_bal = get_userbalance($userid, $first_currency);
                    $sec_bal = get_userbalance($userid, $second_currency);
                    // Buy orders
                    if ($type == 'Buy') {
                        $this->validate($request, [
                            'buy_' . $first_currency => 'required',
                            'buy_' . $second_currency => 'required',
                            //'buy_otp'=>'required',
                        ]);
                        $buy_price = $request['buy_' . $first_currency];
                        $sell_price = $request['buy_' . $second_currency];
                        $final_amount = $request['total_final_' . $second_currency];

                        $otp_buy = $request['buy_otp'];

                        if ($first_currency == 'XDC') {

                            if (((float)$min_ex_limit > (float)$buy_price) || ((float)$max_ex_limit < (float)$buy_price)) {
                                $data['status'] = '0';
                                $data['message'] = 'Limit exceed Please enter correct value';
                                echo json_encode($data);
                                die();
                            }
                        }

                        if ($second_currency == 'BTC') {
                            if (get_spendinglimit($userid) >= 5) {
                                $data['status'] = '0';
                                $data['message'] = 'Your spending BTC limit overed';
                                echo json_encode($data);
                                die();
                            }
                        }

                        if ((float)$second_cur_bal < (float)$sell_price || (float)$second_cur_bal < (float)$final_amount) {
                            $data['status'] = '0';
                            $data['message'] = 'Insufficient Balance of ' . $second_currency;
                            echo json_encode($data);
                            die();
                        }

                        /* if($this->checkotpcode($otp_buy,'buy')===false)
                                        {
                                                   $data['status']='0';
                                                  $data['message']='OTP is wrong';
                                                  echo json_encode($data); die();
                        */

                        $fee = $final_amount - $sell_price;

                        $transid = 'TXB' . $userid . time();
                        $today = date('Y-m-d H:i:s');
                        $ip = \Request::ip();
                        $ins = new Transaction;
                        $ins->user_id = $userid;
                        $ins->payment_method = 'Cryptocurrency Account';
                        $ins->transaction_id = $transid;
                        $ins->currency_name = $first_currency;
                        $ins->second_currency = $second_currency;
                        $ins->pair = $pair;
                        $ins->ex_price = $second_cur_ex_price;
                        $ins->type = $type;
                        $ins->transaction_type = '3';
                        $ins->amount = $buy_price;
                        $ins->updated_at = $today;
                        $ins->crypto_address = '';
                        $ins->transfer_amount = '0';
                        $ins->fee = (float)$fee;
                        $ins->tax = '0';
                        $ins->verifycode = '1';
                        $ins->order_id = '0';
                        $ins->status = 'Completed';
                        $ins->cointype = '2';
                        $ins->payment_status = 'Paid';
                        $ins->paid_amount = $final_amount;
                        $ins->wallet_txid = '';
                        $ins->ip_address = $ip;
                        $ins->verify = '1';
                        $ins->blocknumber = '';
                        if ($ins->save()) {

                            $first_bal = $first_bal + $buy_price;
                            $sec_bal = $sec_bal - $final_amount;
                            $upt = Balance::where('user_id', $userid)->first();
                            $upt->$first_currency = $first_bal;
                            $upt->$second_currency = $sec_bal;
                            $upt->save();

                            $this->update_profit($userid, $fee, $second_currency, $type);

                            $this->exchange_mail($userid, $first_currency, $second_currency, $type, 'Completed', $buy_price);

                            last_activity(get_usermail($userid), 'Ex-Buy', $userid);

                            $data['status'] = '1';
                            $data['message'] = 'Buy Order is completed';
                            echo json_encode($data);
                            die();
                        }

                    }

                    //Sell orders

                    if ($type == 'Sell') {
                        $this->validate($request, [
                            'sell_' . $first_currency => 'required',
                            'sell_' . $second_currency => 'required',
                            //'sell_otp'=>'required',
                        ]);
                        $buy_price = $request['sell_' . $first_currency];
                        $sell_price = $request['sell_' . $second_currency];
                        $final_amount = $request['total_final_sell_' . $second_currency];

                        $otp_sell = $request['sell_otp'];

                        if ($first_currency == 'XDC') {

                            if (((float)$min_ex_limit > (float)$buy_price) || ((float)$max_ex_limit < (float)$buy_price)) {
                                $data['status'] = '0';
                                $data['message'] = 'Limit exceed Please enter correct value';
                                echo json_encode($data);
                                die();
                            }
                        }

                        if ($second_currency == 'BTC') {
                            if (get_spendinglimit($userid) >= 5) {
                                $data['status'] = '0';
                                $data['message'] = 'Your spending BTC limit overed';
                                echo json_encode($data);
                                die();
                            }
                        }

                        if ((float)$first_cur_bal < (float)$buy_price || (float)$first_cur_bal < (float)$buy_price) {
                            $data['status'] = '0';
                            $data['message'] = 'Insuffient Balance of ' . $first_currency;
                            echo json_encode($data);
                            die();

                        }

                        /*if($this->checkotpcode($otp_sell,'sell')===false)
                                        {
                                                   $data['status']='0';
                                                  $data['message']='OTP is wrong';
                                                  echo json_encode($data); die();
                        */

                        $fee = $sell_price - $final_amount;

                        $transid = 'TXS' . $userid . time();
                        $today = date('Y-m-d H:i:s');
                        $ip = \Request::ip();
                        $ins = new Transaction;
                        $ins->user_id = $userid;
                        $ins->payment_method = 'Cryptocurrency Account';
                        $ins->transaction_id = $transid;
                        $ins->currency_name = $first_currency;
                        $ins->second_currency = $second_currency;
                        $ins->pair = $pair;
                        $ins->ex_price = $second_cur_ex_price;
                        $ins->type = $type;
                        $ins->transaction_type = '4';
                        $ins->amount = $buy_price;
                        $ins->updated_at = $today;
                        $ins->crypto_address = '';
                        $ins->transfer_amount = '0';
                        $ins->fee = (float)$fee;
                        $ins->tax = '0';
                        $ins->verifycode = '1';
                        $ins->order_id = '0';
                        $ins->status = 'Completed';
                        $ins->cointype = '2';
                        $ins->payment_status = 'Paid';
                        $ins->paid_amount = $final_amount;
                        $ins->wallet_txid = '';
                        $ins->ip_address = $ip;
                        $ins->verify = '1';
                        $ins->blocknumber = '';
                        if ($ins->save()) {

                            $first_bal = $first_bal - $buy_price;
                            $sec_bal = $sec_bal + $final_amount;
                            $upt = Balance::where('user_id', $userid)->first();
                            $upt->$first_currency = $first_bal;
                            $upt->$second_currency = $sec_bal;
                            $upt->save();

                            $this->update_profit($userid, $fee, $second_currency, $type);

                            $this->exchange_mail($userid, $first_currency, $second_currency, $type, 'Completed', $buy_price);

                            last_activity(get_usermail($userid), 'Ex-Sells', $userid);

                            $data['status'] = '1';
                            $data['message'] = 'Sell Order is completed';
                            echo json_encode($data);
                            die();
                        }

                    }

                }
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function exchange_mail($userid, $fircur, $sec_cur, $type, $status, $amt)
    {
        try {
            $to = get_usermail($userid);
            $subject = get_template('8', 'subject');
            $message = get_template('8', 'template');
            $mailarr = array(
                '###USERNAME###' => get_user_details($userid, 'enjoyer_name'),
                '###LINK###' => url('/'),
                '###TYPE###' => $type,
                '###FCURRENCY###' => $fircur,
                '###STATUS###' => $status,
                '###SITENAME###' => get_config('site_name'),
                '###AMT###' => $amt,
            );
            $message = strtr($message, $mailarr);
            $subject = strtr($subject, $mailarr);
            sendmail($to, $subject, ['content' => $message]);
            return true;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function update_profit($userid, $fee, $curr, $type)
    {
        try {
            $ins = new profit;
            $ins->userId = $userid;
            $ins->theftAmount = $fee;
            $ins->theftCurrency = $curr;
            $ins->type = $type;
            $ins->date = date('Y-m-d');
            $ins->time = date('H:i:s');
            $ins->save();
            return true;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function exchange_history($pair = "")
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');

                if (get_user_details($userid, 'document_status') != '1') {
                    // Session::flash('error','Please Complete your KYC process');
                    //  return redirect('profile');
                }
                if ($pair == 'all' || $pair == "") {
                    $pair = ['XDC-ETH', 'XDC-BTC', 'XDC-XRP'];
                } else {
                    $pair = $pair ? $pair : 'XDC-ETH';
                    $checkpair = Pair::where(['type' => 'exchange', 'pair' => $pair])->count();
                    if ($checkpair == 0) {
                        abort(404);
                    }
                    $pair = [$pair];
                }

                $result = Transaction::where(['user_id' => $userid])->whereIn('pair', $pair)->orderBy('created_at', 'desc')->paginate(10);
                return view('front.ex_history', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function contact_us(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                    'enquiry_name' => 'required',
                    'enquiry_email' => 'required|email',
                    'telephone' => 'required',
                    'enquiry_message' => 'required',
//                'g-recaptcha-response' => 'required|captcha'
                    'captcha' => 'required|captcha',
                ], [
//                'g-recaptcha-response.required' => 'Please verify that you are human.',
//                'g-recaptcha-response.captcha' => 'Captcha error! try again later or contact site admin.'
                    'captcha.required' => 'Captcha is required',
                    'captcha.captcha' => 'Captcha is wrong',
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator);
                }
                $ins = new Enquiry;
                $enquiry_name = $request['enquiry_name'];
                $enquiry_email = $request['enquiry_email'];
                $enquiry_subject = $request['subject_type'];
                $telephone = $request['telephone'];
                $enquiry_message = $request['enquiry_message'];

                $user_type = $request['user_type'];
                $user_id = 'NA';

                //recognizing user by email id
                if ($user_type == 'user') {
                    $spl = explode("@", $enquiry_email);
                    $user1 = $spl[0];
                    $user2 = $spl[1];
                    $user_record = $this->checking($user1, $user2);

                    foreach ($user_record as $user)
                        $user_id = $user->id;

                }

                $subject_type = $request['subject_type'];

                if ($subject_type == 'Deposit' || $subject_type == 'Withdrawal') {
                    $from = $request['from'];
                    if ($from == '') {
                        $from = 'NA';
                    }
                    $to = $request['to'];
                    if ($to == '') {
                        $to = 'NA';
                    }
                    $transaction = $request['transaction'];
                    if ($transaction == '') {
                        $transaction = 'NA';
                    }
                    $amount = $request['amount'];
                    if ($amount == '') {
                        $amount = 'NA';
                    }
                    $currency = $request['currency'];

                    $subject = $currency . ' ' . $subject_type;


                    $message = get_template('11', 'template');
                    $mailarr = array(
                        '###Name###' => $enquiry_name,
                        '###Id###' => $user_id,
                        '###AMOUNT###' => $amount,
                        '###Transaction###' => $transaction,
                        '###From###' => $from,
                        '###To###' => $to,
                        '###EMAIL###' => $enquiry_email,
                        '###CONTENT###' => $enquiry_message,
                    );

                } else {
                    $subject = $subject_type;
                    $message = get_template('12', 'template');
                    $mailarr = array(
                        '###Name###' => $enquiry_name,
                        '###Id###' => $user_id,
                        '###Email###' => $enquiry_email,
                        '###Number###' => $telephone,
                        '###CONTENT###' => $enquiry_message
                    );

                }

                //email body
                $to = 'support@alphaex.net';
                $username = $enquiry_name;
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                if (sendmail($to, $subject, ['content' => $message])) {
                    Session::flash('success', 'Your Message Successfully sent to Administrator');
                }
                return redirect('contact_us');

            }
            return view('front.contact_us');
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function wallet_history($currency = "")
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                $userid = Session::get('alphauserid');

                if (get_user_details($userid, 'document_status') != '1') {
                    //Session::flash('error','Please Complete your KYC process');
                    // return redirect('profile');
                }
                $currency = $currency ? $currency : 'XDC';
                $result = Transaction::where(['type' => 'Deposit', 'currency_name' => $currency, 'user_id' => $userid])->orderBy('created_at', 'desc')->paginate(10);

                $withresult = Transaction::where(['type' => 'Withdraw', 'currency_name' => $currency, 'user_id' => $userid])->orderBy('created_at', 'desc')->paginate(10);
                return view('front.wallethistory', ['result' => $result, 'withresult' => $withresult, 'currency' => $currency]);
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    //get otp
    function getotp()
    {
        echo owndecrypt('DAY9JjHYcFlfDpn8zqSCTyXSzLQepRP1nVIP7f8Vqgg=');

    }

    // end class
    function decryptnumber(Request $request)
    {
        try {
            $user_emailid = $request['emailid'];
            $mobile_no = ($request['mobile']);
//        $spl = explode("@", $user_emailid);
//        $user1 = $spl[0];
//        $user2 = $spl[1];
//        $enUser1 = encrypt($user1);
//        $enUser2 = encrypt($user2);
//        $decryptedValue = owndecrypt("37T5+m695WeP0DACf4gsPicoUVS3VH+P+Nfkjt+RsVw=");
//        $encryt = ownencrypt("9472729405");
            $data = array();
            $numbers = Users::all()->filter(function ($record) use ($mobile_no) {
                if (owndecrypt($record->mobile_no) == $mobile_no) {
                    return $record;
                }
            });
//        $items = Users::all()->filter(function ($record) use ($user1, $user2) {
//            if (decrypt($record->end_user1) == $user1 && decrypt($record->end_user2) == $user2) {
//                return $record;
//            } else {
//                return false;
//            }
//        });

            if ($numbers) {
                foreach ($numbers as $result) {
                    $data['status'] = 'success';
                    $data['userName'] = $result->getAttributeValue('enjoyer_name');
                    $data['first_name'] = $result->getAttributeValue('first_name');
                    $data['last_name'] = $result->getAttributeValue('last_name');
                    $data['userid'] = $result->getAttributeValue('id');
                    $data['mobile_number'] = owndecrypt($result->getAttributeValue('mobile_no'));
                    $data['mobile_status'] = $result->getAttributeValue('mobile_status');
                    $data['mob_isd'] = $result->getAttributeValue('mob_isd');
                }

            } else {
                $data['status'] = 'success';
                $data['last_ETH_price'] = 0.0000;
                $data['last_XRP_price'] = 0.0000;
                $data['last_BTC_price'] = 0.0000;
            }
            die(json_encode($data));
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    //decrypt
    function decryptAddress(Request $request)
    {
        echo $request['add'];
        $val = decrypt('eyJpdiI6InluTFZGTkhTTm1iNlliNjFQY24zOUE9PSIsInZhbHVlIjoiNDhqaG9PRzdIZjl1a2U5bFlGME9cL0RiSEVZMFJWdVIzcHZ5OTNyRThzYkU9IiwibWFjIjoiNzNhNjIzYTVmYzI3MzlkMDNhM2Y0Y2Q4ZWE4ZGNiMThmYzk2NmJhNGIwZGE3NjIwYTRlNjE3ZmMwYzhiYmNjMiJ9');

        echo decrypt($request['add']);
    }

    //decrypt
    function encryptdetails(Request $request)
    {

        $email = strtolower($request['email']);
        $splemail = explode("@", $email);
        $end_user1 = encrypt($splemail[0]);
        $end_user2 = encrypt($splemail[1]);
        $pass = ownencrypt($request['pass']);

        $arra = array('e1' => $end_user1, 'e2' => $end_user2, 'pass' => $pass, 'mob' => ownencrypt($request['mobile']));
        echo json_encode($arra);

    }

    function currentDateTime()
    {
        $dateTime = date('Y-m-d H:i:s');
        $json_array = array('date' => $dateTime);
        echo json_encode($json_array);
    }

    function editUserProfile(Request $request)
    {

    }

    //swap function
    function swap(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                if ($request->isMethod('post')) {
                    $userid = Session::get('alphauserid');
                    $user_balance = UserBalance::where('user_id', $userid)->first();
                    $XDC_bal = $user_balance->XDC;
                    $XDCE_bal = $user_balance->XDCE;
                    $currency = $request['currency'];
                    $amount = $request['swap_amount'];
                    if ($amount > 0) {
                        $ins = new Trade;
                        if ($currency == 'XDC') {
                            if ($XDC_bal >= $amount) {
                                $user_balance->XDC = $XDC_bal - $amount;
                                $user_balance->XDCE = $XDCE_bal + $amount;
                                $user_balance->update();
                                $ins->type = 'Sell';
                                $data['status'] = '1';
                                $data['id'] = $userid;
                                $data['message'] = 'Swap has been Completed';
                            } else {
                                $data['status'] = '0';
                                $data['message'] = 'Insufficient Balance of ' . $currency;
                                return json_encode($data);
                            }
                        } elseif ($currency == 'XDCE') {
                            if ($XDCE_bal >= $amount) {
                                $user_balance->XDCE = $XDCE_bal - $amount;
                                $user_balance->XDC = $XDC_bal + $amount;
                                $user_balance->update();
                                $ins->type = 'Buy';
                                $data['status'] = '1';
                                $data['id'] = $userid;
                                $data['message'] = 'Swap has been Completed';
                            } else {
                                $data['status'] = '0';
                                $data['message'] = 'Insufficient Balance of ' . $currency;
                                return json_encode($data);
                            }
                        }
                        $txid = 'SWTX' . time();
                        $ins->user_id = $userid;
                        $ins->pair_id = 7;
                        $ins->process = 0;
                        $ins->unique_id = $txid;
                        $ins->trade_id = $txid;
                        $ins->trade_type = 'limit_order';
                        $ins->firstCurrency = 'XDC';
                        $ins->secondCurrency = 'XDCE';
                        $ins->original_qty = $amount;
                        $ins->updated_qty = 0;
                        $ins->price = 1;
                        $ins->fee = 0;
                        $ins->total = $amount;
                        $ins->updated_total = $amount;
                        $ins->pair = 'XDC-XDCE';
                        $ins->status = 'completed';
                        $ins->save();
                        $this->update_XDC_XDCE($ins->pair_id);
                        return json_encode($data);
                    } else {
                        $data['status'] = '0';
                        $data['message'] = 'Invalid Amount Entered';
                        return json_encode($data);
                    }
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function update_XDC_XDCE($pairid)
    {
        try {
            $date = date('Y-m-d H:i:s', strtotime("-1 days"));
            $get_pair = Pair::where('id', $pairid)->first();
            $get_pair_name = $get_pair->pair;

            $pair_stats = PairStats::where('pair_id', $pairid)->first();

            $volume = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->sum('original_qty');
            $low = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->min('price');

            $high = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->max('price');

            $last_executed = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->first();
            $triggered_price = $last_executed->price;

            $first_executed = Trade::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'asc')->first();
            $first_executed_price = $first_executed->price;


            $pair_stats->volume = $volume;
            $pair_stats->low = $low;
            $pair_stats->high = $high;
            $pair_stats->last = $triggered_price;

            $percent_change = (($triggered_price - $first_executed_price) / $first_executed_price) * 100;

            if ($percent_change < 0) {
                $color = 'red';
            } else {
                $color = 'green';
            }

            if ($first_executed_price >= $triggered_price) {
                $change = $first_executed_price - $triggered_price;
                $change = number_format($change, 8, '.', '');
            } else {
                $change = $triggered_price - $first_executed_price;
                $change = number_format($change, 8, '.', '');

            }

            $pair_stats->percent_change = $percent_change;
            $pair_stats->colour = $color;
            $pair_stats->change = $change;
            $pair_stats->save();
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function update_pairstats($pairid)
    {
        try {
            $date = date('Y-m-d H:i:s', strtotime("-1 days"));
            $get_pair = Pair::where('id', $pairid)->first();
            $get_pair_name = $get_pair->pair;

            $pair_stats = PairStats::where('pair_id', $pairid)->first();

            $volume = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->sum('triggered_qty');
            $low = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->min('triggered_price');

            $high = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->max('triggered_price');

            $last_executed = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->first();
            $triggered_price = $last_executed->triggered_price;

            $first_executed = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'asc')->first();
            $first_executed_price = $first_executed->triggered_price;


            $pair_stats->volume = $volume;
            $pair_stats->low = $low;
            $pair_stats->high = $high;
            $pair_stats->last = $triggered_price;

            $percent_change = (($triggered_price - $first_executed_price) / $first_executed_price) * 100;

            if ($percent_change < 0) {
                $color = 'red';
            } else {
                $color = 'green';
            }

            if ($first_executed_price >= $triggered_price) {
                $change = $first_executed_price - $triggered_price;
                $change = number_format($change, 8, '.', '');
            } else {
                $change = $triggered_price - $first_executed_price;
                $change = number_format($change, 8, '.', '');

            }

            $pair_stats->percent_change = $percent_change;
            $pair_stats->colour = $color;
            $pair_stats->change = $change;
            $pair_stats->save();
        } catch (\Exception $exception) {

        }
    }

    //check
    function eth_checkdepositalready()
    {
        try {
            $check = Transaction::where('user_id', 478)->where('type', 'Deposit')->where('wallet_txid', '0x48a8ef710ac2cfb9da75a982beb83c4f09141eed75039d761b0615099af3b47b')->count();
            if ($check > 0) {
                return false;
            } else {
                return true;
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    public function sitemap()
    {
        try {
            return response()->view('front.sitemap')->header('Content-Type', 'text/xml');
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

//    function create_eth_address() {
//
//        $password = "alphaex";
//        $output = shell_exec('curl -H "Content-Type: application/json" -X POST --data'. " '".'{"jsonrpc":"2.0","method":"personal_newAccount","params":["alphaex"],"id":1}'."'".' 78.129.229.18:8545');
//        $abc = json_decode($output);
//        if ($abc) {
//            $createAddress = $abc->result;
//            $checkAddress_eth = $createAddress;
//            echo $checkAddress_eth;
//        } else {
//            echo "error";
//        }
//    }

    function create_usdt()
    {
        try {
            $transaction_details = get_usdt_transactionlist();

            echo json_encode($transaction_details);
        } catch (\Exception $e) {
            return ($e->getMessage() . '<br>' . $e->getLine() . '<br>' . $e->getFile());
//            return view('errors.404');
        }
    }

    function get_erc20_blocknumber()
    {
        try {
            $block = SiteSettings::where('id', 1)->first();
            return $block->xdce_block;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function trigger_pusher()
    {
        try {
            $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

            $pusher->trigger('demo1', 'demo-event', array('User_id' => 233, 'Pair' => 'XDC-ETH', 'Total' => '0.02', 'Amount' => number_format(2000, 0, '.', ''), 'Price' => number_format(0.000000600, 8, '.', ''), 'Type' => 'Buy'));

        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function add_asset()
    {
        try {
            if (Session::get('alphauserid') == "") {
                Session::flash('info', 'Please login to place asset listing request.');
                return redirect('login');
            } else {
                return view('front.add_asset');
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function add_erc20(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                Session::flash('info', 'Please login to place asset listing request.');
                return redirect('login');
            } else {
                if ($request->isMethod('post')) {
                    $validator = Validator::make($request->all(), [
                            'name' => 'required',
                            'contract_address' => 'required',
                            'symbol' => 'required',
                            'token_decimals' => 'required|numeric',
                            'requested_by' => 'required',
                            'logo_url' => 'required|url',
                            'email_id' => 'required|email'
                        ]
                    );
                    if ($validator->fails()) {
                        return redirect()->back()->withInput($request->all())->withErrors($validator);
                    }

                    $name = $request['name'];
                    $contract_address = $request['contract_address'];
                    $token_symbol = strtoupper($request['symbol']);
                    $token_decimals = $request['token_decimals'];
                    $logo_url = $request['logo_url'];
                    $email = $request['email_id'];

                    $result = Erc20Requests::where('contract_address', $contract_address)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a request for the provided contract address.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Erc20Details::where('contract_address', $contract_address)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have an ERC20 token listed for the provided contract address.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Erc20Requests::where('symbol', $token_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a request for the provided token symbol, please use different token symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Erc20Details::where('symbol', $token_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have an ERC20 token listed for the provided token symbol, please use different token symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Currencies::where('currency_symbol', $token_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a coin listed for the provided token symbol, please use different token symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $new = new Erc20Requests();
                    $new->description = $name;
                    $new->contract_address = $contract_address;
                    $new->token_decimals = $token_decimals;
                    $new->symbol = $token_symbol;
                    $new->requested_by = $request['requested_by'];
                    $new->logo_url = $logo_url;
                    $new->email = $email;
                    $new->status = 'Pending';
                    $new->save();
                    Session::flash('success', 'Request submitted successfully.');
                    return redirect('/add_asset');
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function add_xinfin_bond(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                Session::flash('info', 'Please login to place asset listing request.');
                return redirect('login');
            } else {
                if ($request->isMethod('post')) {
                    $validator = Validator::make($request->all(), [
                            'bond_name' => 'required',
                            'issuer_name' => 'required',
                            'bond_contract_address' => 'required',
                            'bond_symbol' => 'required',
                            'coupon' => 'required',
                            'maturity_date' => 'required|date_format:d/m/Y',
                            'interest_date' => 'required|date_format:d/m/Y',
                            'payment_frequency' => 'required',
                            'listing_date' => 'required|date_format:d/m/Y',
                            'requested_by' => 'required',
                            'email_id' => 'required|email'
                        ]
                    );
                    if ($validator->fails()) {
                        return redirect()->back()->withInput($request->all())->withErrors($validator);
                    }

                    $bond_name = $request['bond_name'];
                    $issuer_name = $request['issuer_name'];
                    $bond_contract_address = $request['bond_contract_address'];
                    $bond_symbol = strtoupper($request['bond_symbol']);
                    $coupon = number_format($request['coupon'], '3', '.', '');
                    $maturity_date = $request['maturity_date'];
                    $interest_date = $request['interest_date'];
                    $payment_frequency = $request['payment_frequency'];
                    $listing_date = $request['listing_date'];
                    $listing_price = $request['listing_price'];
                    $email = $request['email_id'];
                    $requested_by = $request['requested_by'];

                    $result = XinfinRequests::where('bond_contract_address', $bond_contract_address)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a request for the provided bond contract address.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = XinfinDetails::where('bond_contract_address', $bond_contract_address)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a bond token listed for the provided bond contract address.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = XinfinRequests::where('bond_symbol', $bond_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a request for the provided bond symbol, please use different bond symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = XinfinDetails::where('bond_symbol', $bond_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a bond token listed for the provided bond symbol, please use different bond symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Currencies::where('currency_symbol', $bond_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a coin listed for the provided bond symbol, please use different bond symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $new = new XinfinRequests();
                    $new->bond_name = $bond_name;
                    $new->issuer_name = $issuer_name;
                    $new->bond_contract_address = $bond_contract_address;
                    $new->bond_symbol = $bond_symbol;
                    $new->bond_decimals = '18';
                    $new->coupon = $coupon;
                    $new->maturity_date = $maturity_date;
                    $new->payment_frequency = $payment_frequency;
                    $new->interest_date = $interest_date;
                    $new->listing_date = $listing_date;
                    $new->listing_price = $listing_price;
                    $new->email = $email;
                    $new->requested_by = $requested_by;
                    $new->status = 'Pending';
                    $new->save();
                    Session::flash('success', 'Request submitted successfully.');
                    return redirect('/add_asset');
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function test()
    {

        $response = json_decode(indodax_wallet_balance());

        return json_encode($response->return->balance->btc);

//        $encrypt_address = encrypt('0x2642835a88A0B307Ba6B52b7b23876210A03812c');
//        $encrypt_key = encrypt('0x27d06d1366d61bda9a4fb2340ae7779d17fccc2904f470c4e98e86269ab1d66c');
//
//        $data = array('add' => $encrypt_address, 'key' => $encrypt_key);
//        $result = getting_xdc_status('0xf2798bce0288877bb5d8ef268dde478dde07cd6adeab9815361cc0090970f189');
//
//        return $data;
    }

    //bitfinex bot
    function bitfinex_bot()
    {
        try {
            return view('front.bitfinex_bot');
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function referral()
    {
        try {
            if (Session::get('alphauserid') == '') {
                return view('front.referral');
            } else {
                $user_id = Session::get('alphauserid');

                //referral code generation
                $referral_code = get_user_details($user_id, 'referral_code');
                if ($referral_code == null) {
                    $referral_code = generate_uid();
                    $true = Users::where('referral_code', $referral_code)->get();
                    while ($true == null) {
                        $referral_code = generate_uid();
                        $true = Users::where('referral_code', $referral_code)->get();

                    }
                    $users = Users::where('id', $user_id)->first();
                    $users->referral_code = $referral_code;
                    $users->save();
                }

                $referrer = ReferralEarning::where('referrer_id', $user_id)->get();
                $referred = ReferralEarning::where('referred_id', $user_id)->get();
                $referred_users = ExtraBonus::where('user_id', $user_id)->get();

                return view('front.referral', ['referral_code' => $referral_code, 'referrer' => $referrer, 'referred' => $referred, 'referred_users' => $referred_users]);

            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function sendreferral(Request $request)
    {
        try {
            if (Session::get('alphauserid') == '') {
                return redirect('logout');
            } else {
                if ($request['mytext']) {
                    $user_id = Session::get('alphauserid');
                    foreach ($request['mytext'] as $email) {
                        $to = [$email];
                        $referral_code = get_user_details($user_id, 'referral_code');
                        $subject = get_template('19', 'subject');
                        $message = get_template('19', 'template');
                        $mailarr = array(
                            '###USER###' => get_user_details($user_id, 'first_name'),
                            '###LINK###' => url('/register?referral_code=' . $referral_code . '&email_id=' . $email),
                            '###SITENAME###' => get_config('site_name'),
                            '###SITELINK###' => url('/'),
                            '###CODE###' => $referral_code,
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);
                    }
                    Session::flash('success', 'Mails have been sent to the email ids mentioned by you.');
                    return redirect()->back();
                } else {
                    Session::flash('error', 'Please enter atleast one email id to refer.');
                    return redirect()->back();
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function update_user_status()
    {
        try {
            $users = Users::all();
            $currencies = Currencies::all();
            $response_array = array();
            foreach ($users as $user) {
                $final_status = 0;
                foreach ($currencies as $currency) {
                    $deposit = get_user_deposit($user->id, $currency->currency_symbol);
                    $withdraw = get_user_withdraw($user->id, $currency->currency_symbol);
                    $buy = get_user_buy($user->id, $currency->currency_symbol);
                    $sell = get_user_sell($user->id, $currency->currency_symbol);
                    $intrade = get_user_intradebalance($user->id, $currency->currency_symbol);
                    $balance = get_userbalance($user->id, $currency->currency_symbol);
                    $plus = $deposit + $buy + $intrade + $balance;
                    $minus = $withdraw + $sell;
                    if ($plus >= ($minus * 0.99) && $plus <= ($minus * 1.01)) {
                        $user->user_status = 1;
                        $user->save();
                        $final_status = 1;
                    } else {
                        $user->user_status = 0;
                        $user->save();
                        $final_status = 0;
                        break;
                    }
                }
                $array = array('user_id' => $user->id, 'status' => $final_status);
                $response_array[] = $array;
            }
            return json_encode($response_array);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

}
