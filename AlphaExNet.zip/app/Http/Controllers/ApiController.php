<?php

namespace App\Http\Controllers;

use App\model\Balance;
use App\model\Cms;
use App\model\Country;
use App\model\Enquiry;
use App\model\Faq;
use App\model\Favorite;
use App\model\OTP;
use App\model\Pair;
use App\model\PairStats;
use App\model\Profit;
use App\model\SiteSettings;
use App\model\Tokenusers;
use App\model\Trade;
use App\model\Transaction;
use App\model\UserBalance;
use App\model\UserCurrencyAddresses;
use App\model\Users;
use App\model\Verification;
use App\model\Currencies;
use App\model\UserBalancesNew;
use App\model\TradeMapping;
use App\model\Erc20Details;
use App\model\Erc20Requests;
use App\model\AlphaExV3Address;
use Cache;
use DB;
use GuzzleHttp\Psr7\_caseless_remove;
use Hash;
use Illuminate\Http\Request;
use Mockery\Exception;
use PragmaRX\Google2FA\Google2FA;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Session;
use Validator;
use Pusher\Pusher;

class ApiController extends Controller
{
    function register(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                //  echo "okay"; exit;

                $validator = Validator::make($request->all(), [
                    'first_name' => 'required',
//                'last_name' => 'required',
                    //'username' => 'required',
                    'email_id' => 'required|email',
                    'password' => 'required|confirmed|min:6',
                    'password_confirmation' => 'required|min:6',
//                'country_id' => 'required',
//                    'phone_no' => 'required|numeric',
                ], [
                        'first_name.required' => 'First name is required',
//                    'last_name.required' => 'Last name is required',
                        //'username.required' => 'Username is required',
                        'email_id.required' => 'Email id is required',
                        'email_id.email' => 'Enter valid email id',
                        'password.required' => 'Password is required',
//                    'country_id.required' => 'Country is required',
//                        'phone_no.required' => 'Phone number is required',
//                        'phone_no.numeric' => 'Phone number should be digit format',
                    ]
                );
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $ip = \Request::ip();

                $first_name = $request['first_name'];
                $last_name = $request['last_name'];
                $email = strtolower($request['email_id']);
                $splemail = explode("@", $email);
                $end_user1 = encrypt($splemail[0]);
                $end_user2 = encrypt($splemail[1]);
                $res = $this->checking($splemail[0], $splemail[1]);
                if (count($res) > 0) {
                    $response['status'] = '0';
                    $response['message'] = 'The email address already exists.';
                    return json_encode($response);
                }
                $pass_code = bcrypt($request['password']);
                $activation_code = mt_rand(0000, 9999) . time();
                $forgot_code = mt_rand(111111, 999999) . time();
                $verify_status = 2;
                $status = 2;
                $created_at = date('Y-m-d H:i:s');
//                $country = $request['isdcode'];
//                $country = Country::where('phonecode', $country)->first();
//                $country = $country->id;
                $document_status = 0;
//                $mobile_no = $request['phone_no'];
//                $check = $this->check_phone($mobile_no);
//                if (count($check) > 0) {
//                    $response['status'] = '0';
//                    $response['message'] = 'The Phone Number Already exists.';
//                    return json_encode($response);
//                }
//                $mob_isd = $request['isdcode'];
                $mobile_status = 0;

                $xdc_addr = "";
                $xdcres = signup_XDC($email, '', $request['password']);
                if ($xdcres->status == 'FAILED') {
                    $response['status'] = '0';
                    $response['message'] = 'Something went wrong.please try again later.';
                    return json_encode($response);
                } else {
                    $xdc_addr = $xdcres->public;
                }

                $xinpass = ownencrypt($request['password']);

                $ins = ['ip' => $ip,  'enjoyer_name' => $first_name, 'first_name' => $first_name, 'last_name' => $last_name, 'end_user1' => $end_user1, 'end_user2' => $end_user2, 'pass_code' => $pass_code, 'activation_code' => $activation_code, 'forgot_code' => $forgot_code, 'verify_status' => $verify_status, 'status' => $status, 'created_at' => $created_at, 'country' => '', 'document_status' => $document_status, 'mobile_no' => '', 'mobile_status' => $mobile_status, 'profile_image' => 'noimage.png', 'mob_isd' => '', 'XDC_addr' => $xdc_addr, 'xinpass' => $xinpass];

                $insert = Users::insertGetId($ins);
                //$lastid=$insert->id;

                $bal = ['user_id' => $insert, 'BTC' => 10, 'XRP' => 1000, 'ETH' => 100, 'XDC' => 100000, 'XDCE' => 100000, 'BCH' => 1000, 'ET' => 1000];
                Balance::insert($bal);
                $currencies = Currencies::all();
                foreach ($currencies as $val) {
                    $bal_new = new UserBalancesNew;
                    $bal_new->user_id = $insert;
                    $bal_new->currency_id = $val->unique_id;
                    $bal_new->currency_name = $val->currency_symbol;
                    $bal_new->balance = 0;
                    $bal_new->save();
                }

                if ($xdc_addr) {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $insert;
                    $addr->currency_id = 1;
                    $addr->currency_name = 'XDC';
                    $addr->currency_addr = $xdc_addr;
                    $addr->save();
                }

                //address generator
//                check_live_address($insert);

                //log
                last_activity($email, 'Registration', 0);

                $inst = new Tokenusers;
                $inst->user_id = $insert;
                $inst->email = ownencrypt($email);
                $inst->passcode = ownencrypt($request['password']);
                $inst->phone = '';
                $inst->created_at = $created_at;
                $inst->save();

                $to = $email;
                $subject = get_template('4', 'subject');
                $message = get_template('4', 'template');
                $mailarr = array(
                    '###USERNAME###' => $first_name,
                    '###LINK###' => url('userverification/' . $activation_code),
                    '###SITENAME###' => get_config('site_name'),
                );
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                sendmail($to, $subject, ['content' => $message]);

                $response['status'] = '1';
                $response['message'] = 'Account creation successful.';
                return json_encode($response);
            } else {
                $response['status'] = '0';
                $response['message'] = 'Server Error.';
                return json_encode($response);
            }
        } catch (\Exception $e) {
            $response = array();
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function login(Request $request)
    {
        try {
            $response = array();
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                    'login_mail' => 'required|email',
                    'password' => 'required',
                ], [
                    'login_mail.required' => 'Email id is required',
                    'login_mail.email' => 'Enter valid email id',
                    'password.required' => 'Password is required',
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $remember_me = $request['remember_me'];
                $email = strtolower($request['login_mail']);
                $password = $request['password'];
                $ip = \Request::ip();
                $res = $this->user_login_check($email, $password);
                switch ($res) {
                    case '1':
//                        if($email == 'nodeman01@yopmail.com')
                        //send login status mail
                        $to = [$email];
                        $subject = get_template('17', 'subject');
                        $message = get_template('17', 'template');
                        $mailarr = array(
                            '###EMAIL###' => $email,
                            '###OS###' => getOS(),
                            '###BROWSER###' => getBrowser(),
                            '###IP###' => $ip,
                            '###TIME###' => date('Y-m-d H:i:s'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);
                        if ($remember_me == 'on') {
                            $hour = time() + 3600 * 24 * 30;
                            setcookie('email', $email, $hour);
                            setcookie('password', $password, $hour);
                        }
                        $user_id = Session::get('alphauserid');
                        $response['status'] = '1';
                        $response['message'] = 'Welcome To AlphaEx Exchange.';
                        $response['user_id'] = $user_id;
                        $response['tfa_status'] = '0';
                        return json_encode($response);
                        break;
                    case '5':
                        $tfa_key = Session::get('tfa_key');
                        $response['status'] = '1';
                        $response['message'] = 'Welcome To AlphaEx Exchange.';
                        $response['tfa_status'] = 1;
                        $response['tfa_key'] = $tfa_key;
                        return json_encode($response);
                        break;
                    case '2':
                        $response['status'] = '0';
                        $response['message'] = 'Email or password is wrong.';
                        return json_encode($response);
                        break;
                    case '3':
                        $response['status'] = '0';
                        $response['message'] = 'Your account is deactivated.';
                        return json_encode($response);
                        break;
                    case '4':
                        $response['status'] = '0';
                        $response['message'] = "Email or password is wrong / User doesn't exist.";
                        return json_encode($response);
                        break;
                    case '6':
                        $response['status'] = '0';
                        $response['message'] = 'Please Verify your email address to Login.';
                        return json_encode($response);
                        break;
                    case '7':
                        $response['status'] = '0';
                        $response['message'] = 'Please Verify your email address to Login.';
                        return json_encode($response);
                        break;

                    default:
                        $response['status'] = '0';
                        $response['message'] = 'Please Verify your email address to Login.';
                        return json_encode($response);
                        break;
                }
            } else {
                $response['status'] = '0';
                $response['message'] = 'Server Error.';
                return json_encode($response);
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function logindo(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $tfa_key_cli = $request['tfa_key'];
                $tfa_code = $request['tfa_code'];
                $tfa_key_ser = Session::get('tfa_key');
                if (owndecrypt($tfa_key_cli) == owndecrypt($tfa_key_ser)) {
                    $userid = owndecrypt($tfa_key_ser);
                    $userdata = Users::where('id', $userid)->first();
                    $google2fa = new Google2FA();
                    //$valid = $google2fa->verifyKey($userdata->tfa_code, $tfa_code);
                    $valid = checktfa_code($userdata->tfa_code, $tfa_code);
                    $ip = \Request::ip();
                    $email = get_usermail($userid);
                    if ($valid == 1) {
                        $sess = array('alphauserid' => $userdata->id, 'alphausername' => $userdata->enjoyer_name);
                        $to = [$email];
                        $subject = get_template('17', 'subject');
                        $message = get_template('17', 'template');
                        $mailarr = array(
                            '###EMAIL###' => $email,
                            '###OS###' => getOS(),
                            '###BROWSER###' => getBrowser(),
                            '###IP###' => $ip,
                            '###TIME###' => date('Y-m-d H:i:s'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);
                        Session::put($sess);
                        $response['user_id'] = $userdata->id;
                        $response['status'] = 1;
                        $response['message'] = 'Welcome To AlphaEx Exchange';
                        return json_encode($response);
                    } else {
                        $response['status'] = 0;
                        $response['message'] = '2FA code is wrong';
                        return json_encode($response);
                    }

                } else {
                    Session::flush();
                    Cache::flush();
                    $response['status'] = 0;
                    $response['message'] = '2FA Key Error';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = 0;
            $response['message'] = 'Server Error';
            return json_encode($response);
        }
    }

    function user_login_check($email, $password)
    {
        try {
            $spl = explode("@", $email);
            $user1 = $spl[0];
            $user2 = $spl[1];
            $res = $this->checking($user1, $user2);
            /*$xdclogin = login_xdc_fun($email, $password);
                if ($xdclogin->status != 'SUCCESS') {
                    return "4";exit();
            */

            if ($res) {
                foreach ($res as $val) {
                    $recordid = $val->id;
                    $recordpass = $val->pass_code;
                    if (Hash::check($password, $recordpass)) {
                        if ($val->status == '1' && ($val->tfa_status == 'disable' || $val->tfa_status == '')) {
                            //log
                            last_activity(get_usermail($recordid), 'Login', $recordid);
                            $sess = array('alphauserid' => $recordid, 'alphausername' => $val->enjoyer_name, 'xinfinpass' => $password);
                            Session::put($sess);
                            $x = Session::all();
                            return "1";
                        } elseif ($val->status == '1' && $val->tfa_status == 'enable') {
                            //log
                            last_activity(get_usermail($recordid), 'Login', $recordid);
                            Session::put('tfa_key', ownencrypt($recordid));
                            return "5";
                        } elseif ($val->verify_status == '2') {
                            return "6";
                        }
// elseif ($val->mobile_status == '0') {
//                        return "7";
//                    }
                        else {
                            return "3";
                        }

                    } else {
                        return "2";
                    }

                }
            } else {
                return "4";
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function checking($end_user1, $end_user2)
    {
        try {
            $items = Users::all()->filter(function ($record) use ($end_user1, $end_user2) {
                if (decrypt($record->end_user1) == $end_user1 && decrypt($record->end_user2) == $end_user2) {
                    return $record;
                } else {
                    return false;
                }
            });

            return $items;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function check_phone($mobile_no)
    {
        try {
            $numbers = Users::all()->filter(function ($record) use ($mobile_no) {
                if (owndecrypt($record->mobile_no) == $mobile_no) {
                    return $record;
                } else {
                    return false;
                }
            });
            return $numbers;
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function profile(Request $request)
    {
        try {
            $request->session()->all();
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $user_id = Session::get('alphauserid');
                if ($user_id == $request['userid']) {
                    $result = Users::where('id', $user_id)->first();

                    $countrycode = Country::where('id', $result->country)->first();
                    $verification = Verification::where('user_id', $user_id)->first();

                    $google2fa = new Google2FA();
                    if ($result->tfa_code != "") {
                        $secret_code = $result->tfa_code;
                    } else {
                        $secret_code = $google2fa->generateSecretKey();
                        $result->tfa_code = $secret_code;
                        $result->tfa_status = 'disable';
                        $result->save();
                    }
                    $tfa_url = $google2fa->getQRCodeGoogleUrl(get_config('site_name'), get_usermail($user_id), $secret_code);

                    $username = $result->enjoyer_name;
                    $image = $result->profile_image;
                    $email_id = get_usermail($result->id);
                    $first_name = $result->first_name;
                    $last_name = $result->last_name;
                    $phone_no = owndecrypt($result->mobile_no);
                    $isd = $result->mob_isd;
                    $address = $result->address;
                    $city = $result->city;
                    $state = $result->state;
                    $user_id = $result->id;
                    $mobile_status = $result->mobile_status;
                    $email_status = $result->verify_status;
                    $kyc_status = $result->document_status;

                    if ($kyc_status == 1) {
                        $kyc_message = "Your KYC is Completed";
                    } elseif ($kyc_status == 2) {
                        $kyc_message = "Your KYC is Rejected";
                    } elseif ($kyc_status == 3) {
                        $kyc_message = "Your KYC is under processing";
                    } else {
                        $kyc_message = "Please complete your KYC to use all functionalities of Alphaex";
                    }

                    if ($result->tfa_status == 'enable') {
                        $tfa_status = 1;
                    } else {
                        $tfa_status = 0;
                    }

                    if ($request->isMethod('post')) {
                        $validator = Validator::make($request->all(), [
                            'username' => 'required',
                            'first_name' => 'required',
                            'last_name' => 'required',
                            'telephone' => 'required|numeric',
                            'city' => 'required',
                            'address' => 'required',
                            'state' => 'required',
                        ]);
                        if ($validator->fails()) {
                            $errors = $validator->errors();
                            $message = "";
                            foreach ($errors->all() as $error) {
                                $message = $message . ', ' . $error;
                            }
                            $response['status'] = '0';
                            $response['message'] = $message;
                            $data = ['response' => $response, 'username' => $username, 'user_id' => $user_id, 'profile_image' => $image, 'email' => $email_id, 'first_name' => $first_name, 'last_name' => $last_name, 'phone_no' => $phone_no, 'isd' => $isd, 'address' => $address, 'city' => $city, 'state' => $state, 'email_status' => $email_status, 'mobile_status' => $mobile_status, 'tfa_status' => $tfa_status, 'countrycode' => $countrycode, 'verification' => $verification, 'tfa_url' => $tfa_url, 'secret_code' => $secret_code, 'kyc_status' => $kyc_status, 'kyc_message' => $kyc_message];
                            return json_encode($data);
                        }
                        if ($request['ptostatus']) {
                            $checkmobile = decrypt($request['ptostatus']);
                            if ($checkmobile) {
                                $splmob = explode("#", $checkmobile);
                                if ($splmob[0] == $request['telephone']) {
                                    $result->mobile_no = ownencrypt($request['telephone']);
                                    $result->mobile_status = '1';
                                }
                            }
                        }

                        $result->enjoyer_name = $request['username'];
                        $result->first_name = $request['first_name'];
                        $result->last_name = $request['last_name'];
                        $result->mobile_no = ownencrypt($request['telephone']);
                        $result->mob_isd = $request['isdcode'];
                        $result->city = $request['city'];
                        $result->address = $request['address'];
                        $result->state = $request['state'];
                        $result->country = $request['country_id'];
                        if ($request['imageUpload']) {
                            $info = pathinfo($_FILES['imageUpload']['name']);
                            $mime = mime_content_type($_FILES['imageUpload']['tmp_name']);
                            $mime_array = ['image/png', 'image/jpeg'];
                            $ext = strtolower($info['extension']);
                            $ext_array = ['png', 'jpg', 'jpeg'];
                            if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
                                $file_name = $user_id . '_' . 'imageUpload.' . $ext;

                                $target = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/profileimg/' . $file_name;
                                if ($result->profile_image != '' && $result->profile_image != 'noimage.png') {
                                    $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/profileimg/' . $result->profile_image;
                                    unlink($target1);
                                }
                                move_uploaded_file($_FILES['imageUpload']['tmp_name'], $target);
                                $result->profile_image = $file_name;
                            } else {
                                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                                $subject = 'Some user trying to upload malicious file in profile image.';
                                $message = 'User id : ' . $result->id . ', Email id : ' . get_usermail($result->id) . ' trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                                sendmail($to, $subject, ['content' => $message]);
                                $result->status = '2';
                                $result->save();
                                Session::flush();
                                $response['status'] = '0';
                                $response['message'] = 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.';
                                $data = ['response' => $response];
                                return json_encode($data);
                            }
                        }
                        if ($result->isDirty('mobile_no')) {
                            $check = $this->check_phone($request['telephone']);
                            if (count($check) > 0) {
//                            Session::flash('error', 'The Phone Number Already Exsits.');
//                            return redirect()->back();
//                            $response = json_encode($response);

                                $username = $result->enjoyer_name;
                                $image = $result->profile_image;
                                $email_id = get_usermail($result->id);
                                $first_name = $result->first_name;
                                $last_name = $result->last_name;
                                $phone_no = owndecrypt($result->mobile_no);
                                $isd = $result->mob_isd;
                                $address = $result->address;
                                $city = $result->city;
                                $state = $result->state;
                                $user_id = $result->id;
                                $mobile_status = $result->mobile_status;
                                $email_status = $result->verify_status;
                                if ($kyc_status == 1) {
                                    $kyc_message = "Your KYC is Completed";
                                } elseif ($kyc_status == 2) {
                                    $kyc_message = "Your KYC is Rejected";
                                } elseif ($kyc_status == 3) {
                                    $kyc_message = "Your KYC is under processing";
                                } else {
                                    $kyc_message = "Please complete your KYC to use all functionalities of Alphaex";
                                }

                                if ($result->tfa_status == 'enable') {
                                    $tfa_status = 1;
                                } else {
                                    $tfa_status = 0;
                                }
                                if ($result->tfa_status == 'enable') {
                                    $tfa_status = 1;
                                } else {
                                    $tfa_status = 0;
                                }

                                $data = ['status' => '0', 'message' => 'The Phone Number Already Exists.', 'username' => $username, 'user_id' => $user_id, 'profile_image' => $image, 'email' => $email_id, 'first_name' => $first_name, 'last_name' => $last_name, 'phone_no' => $phone_no, 'isd' => $isd, 'address' => $address, 'city' => $city, 'state' => $state, 'email_status' => $email_status, 'mobile_status' => $mobile_status, 'tfa_status' => $tfa_status, 'countrycode' => $countrycode, 'verification' => $verification, 'tfa_url' => $tfa_url, 'secret_code' => $secret_code, 'kyc_status' => $kyc_status, 'kyc_message' => $kyc_message];
                                return json_encode($data);
                            }
//                            $result->mobile_status = 0;
                            $result->save();
                        } else {
                            $result->save();
//                        Session::flash('success', 'Profile Updated Successfully');
                            //log
                            last_activity(get_usermail($user_id), 'Profile Update', $user_id);
//                        $response = json_encode($response);

                        }

                        $countrycode = Country::where('id', $result->country)->first();

                        $username = $result->enjoyer_name;
                        $image = $result->profile_image;
                        $email_id = get_usermail($result->id);
                        $first_name = $result->first_name;
                        $last_name = $result->last_name;
                        $phone_no = owndecrypt(get_user_details($user_id, 'mobile_no'));
                        $isd = $result->mob_isd;
                        $address = $result->address;
                        $city = $result->city;
                        $state = $result->state;
                        $user_id = $result->id;
                        $mobile_status = $result->mobile_status;
                        $email_status = $result->verify_status;
                        if ($kyc_status == 1) {
                            $kyc_message = "Your KYC is Completed";
                        } elseif ($kyc_status == 2) {
                            $kyc_message = "Your KYC is Rejected";
                        } elseif ($kyc_status == 3) {
                            $kyc_message = "Your KYC is under processing";
                        } else {
                            $kyc_message = "Please complete your KYC to use all functionalities of Alphaex";
                        }

                        if ($result->tfa_status == 'enable') {
                            $tfa_status = 1;
                        } else {
                            $tfa_status = 0;
                        }
                        if ($result->tfa_status == 'enable') {
                            $tfa_status = 1;
                        } else {
                            $tfa_status = 0;
                        }

                        $data = ['status' => '1', 'message' => 'Profile Updated Successfully.', 'user_id' => $user_id, 'profile_image' => $image, 'username' => $username, 'email' => $email_id, 'first_name' => $first_name, 'last_name' => $last_name, 'phone_no' => $phone_no, 'isd' => $isd, 'address' => $address, 'city' => $city, 'state' => $state, 'email_status' => $email_status, 'mobile_status' => $mobile_status, 'tfa_status' => $tfa_status, 'countrycode' => $countrycode, 'verification' => $verification, 'tfa_url' => $tfa_url, 'secret_code' => $secret_code, 'kyc_status' => $kyc_status, 'kyc_message' => $kyc_message];
                        return json_encode($data);

//                    $data = ['username' => $username, 'email' => $email_id, 'first_name' => $first_name, 'last_name' => $last_name, 'phone_no' => $phone_no, 'isd' => $isd, 'address' => $address, 'city' => $city, 'state' => $state, 'user_id' =>$user_id, 'mobile_status' => $mobile_status, 'countrycode' => $countrycode, 'verification' => $verification, 'tfa_url' => $tfa_url, 'secret_code' => $secret_code];
//                    return view('front.profile', $data);
                    }
//                $country = Country::orderBy('phonecode', 'asc')->get();
//                $country_name = Country::all();

//                $countrycode = Country::where('phonecode', $result->mob_isd)->first();
//                $verification = Verification::where('user_id', $user_id)->first();
//
//                $google2fa = new Google2FA();
//                if ($result->tfa_code != "") {
//                    $secret_code = $result->tfa_code;
//                } else {
//                    $secret_code = $google2fa->generateSecretKey();
//                    $result->tfa_code = $secret_code;
//                    $result->tfa_status = 'disable';
//                    $result->save();
//                }
//                $tfa_url = $google2fa->getQRCodeGoogleUrl(get_config('site_name'), get_usermail($user_id), $secret_code);
//
//                $username = $result->enjoyer_name;
//                $email_id = get_usermail($result->id);
//                $first_name = $result->first_name;
//                $last_name = $result->last_name;
//                $phone_no = owndecrypt($result->mobile_no);
//                $isd = $result->mob_isd;
//                $address = $result->address;
//                $city = $result->city;
//                $state = $result->state;
//                $user_id = $result->id;
//                $mobile_status = $result->mobile_status;

                    $data = ['status' => 1, 'user_id' => $user_id, 'username' => $username,
                        'email' => $email_id, 'first_name' => $first_name, 'last_name' => $last_name,
                        'phone_no' => $phone_no, 'isd' => $isd, 'address' => $address,
                        'city' => $city, 'state' => $state, 'email_status' => $email_status,
                        'mobile_status' => $mobile_status, 'tfa_status' => $tfa_status, 'countrycode' => $countrycode,
                        'verification' => $verification, 'tfa_url' => $tfa_url, 'secret_code' => $secret_code,
                        'kyc_status' => $kyc_status, 'kyc_message' => $kyc_message];
//                return view('front.profile', $data);
                    return json_encode($data);
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = 0;
            $response['message'] = 'Server Error';
            return json_encode($response);
        }
    }

    function checkphone(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $mobile_no = $request['mobile_no'];
                if ($request['user_id']) {
                    $user_id = $request['user_id'];
                    $user = Users::where('id', '=', $user_id)->first();
                    $user->mobile_no = ownencrypt($mobile_no);
                    if ($user->isDirty('mobile_no')) {
                        $numbers = Users::where('mobile_no', '=', $user->mobile_no)->first();
                        if ($numbers == null) {
                            $response['status'] = 1;
                            $response['message'] = 'No matching numbers found.';
                            return json_encode($response);
                        } else {
                            $response['status'] = 0;
                            $response['message'] = 'The Phone Number Already Exists.';
                            return json_encode($response);
                        }
                    } else {
                        $response['status'] = 1;
                        $response['message'] = 'No matching numbers found.';
                        return json_encode($response);
                    }
                } else {
                    $numbers = Users::where('mobile_no', '=', ownencrypt($mobile_no))->first();
                    if ($numbers == null) {
                        $response['status'] = 1;
                        $response['message'] = 'No matching numbers found.';
                        return json_encode($response);
                    } else {
                        $response['status'] = 0;
                        $response['message'] = 'The Phone Number Already Exists.';
                        return json_encode($response);
                    }
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function otp(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $type = $request['type'];
                $otp_type = $request['otp_type'];
                if ($type == "Register" || $type == "Update") {
                    $mobile_no = $request['phone'];
                    if ($request['userid']) {
                        $user_id = $request['userid'];
                        $user = Users::where('id', '=', $user_id)->first();
                        $user->mobile_no = ownencrypt($mobile_no);
                        if ($user->isDirty('mobile_no')) {
                            $numbers = Users::where('mobile_no', '=', $user->mobile_no)->first();
                            if ($numbers != null) {
                                $response['status'] = 0;
                                $response['message'] = 'Phone number already exists.';
                                return json_encode($response);
                            }
                        }
                    } else {
                        $numbers = Users::where('mobile_no', '=', ownencrypt($mobile_no))->first();
                        if ($numbers != null) {
                            $response['status'] = 0;
                            $response['message'] = 'Phone number already exists.';
                            return json_encode($response);
                        }
                    }
                }
                if ($type == "Register") {
                    $isdcode = $request['isdcode'];
                    $phone = $request['phone'];
                    $otp = get_otpnumber('0', $isdcode, $phone, $type, $otp_type);
                } elseif ($type == "Forgot") {
                    $email = strtolower($request['forgot_mail']);
                    $spl = explode("@", $email);
                    $user1 = $spl[0];
                    $user2 = $spl[1];
                    $res = $this->checking($user1, $user2);
                    if (count($res) == 1) {
                        foreach ($res as $val)
                            $isdcode = $val->mob_isd;
                        $phone = owndecrypt($val->mobile_no);
                        $otp = get_otpnumber($val->id, $isdcode, $phone, $type, $otp_type);
                    } else {
                        $data['status'] = 0;
                        $data['message'] = 'This mail id is not registered.';
                        return json_encode($data);
                    }
                } elseif ($type == 'Withdraw') {
                    $userid = Session::get('alphauserid');
                    if ($userid == $request['userid']) {
                        $isdcode = get_user_details($userid, 'mob_isd');
                        $phone = owndecrypt(get_user_details($userid, 'mobile_no'));
                        $otp = get_otpnumber($userid, $isdcode, $phone, $type, $otp_type);
                    } else {
                        $response['status'] = 0;
                        $response['message'] = 'Session and given user id mismatch.';
                        return json_encode($response);
                    }
                } elseif ($type == 'Update') {
                    $userid = Session::get('alphauserid');
                    if ($userid == $request['userid']) {
                        $isdcode = $request['isdcode'];
                        $phone = $request['phone'];
                        $otp = get_otpnumber($userid, $isdcode, $phone, $type, $otp_type);
                    } else {
                        $response['status'] = 0;
                        $response['message'] = 'Session and given user id mismatch.';
                        return json_encode($response);
                    }
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Provide valid type.';
                    return json_encode($data);
                }
                if ($otp_type == 'sms') {
                    if (is_numeric($otp)) {
                        $to = '+' . $isdcode . $phone;
                        $text = "Alphaex authentication code is " . $otp;
                        send_sms($to, $text);
                        $data['status'] = 1;
                        $data['message'] = 'OTP has been successfully sent to your registered mobile number.';
                        return json_encode($data);
                    } else {
                        $data['status'] = 0;
                        $data['message'] = 'Otp hasnt been sent.';
                        return json_encode($data);
                    }
                } elseif ($otp_type == 'call') {
                    $check = OTP::where('mobile_no', ownencrypt($phone))->orderBy('id', 'desc')->first();
                    $otp = owndecrypt($check->otp);
                    $to = '+' . $isdcode . $phone;
                    $ansurl = url('https://alphaex.net/ticker/getxmlres/' . $otp);
                    $result = voiceotp($to, $ansurl);
                    if ($result == true) {
                        $data['status'] = 1;
                        $data['message'] = 'Call placed.';
                        return json_encode($data);
                    } else {
                        $data['status'] = 0;
                        $data['message'] = 'Call not placed.';
                        return json_encode($data);
                    }
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Provide valid otp type.';
                    return json_encode($data);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function verify_otp(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $type = $request['type'];
                $otp_type = $request['otp_type'];
                if ($otp_type == 'sms' || $otp_type == 'call') {
                    if ($type == 'Register') {
                        $code = $request['verify_code'];
                        $mobile = $request['mobile'];
                        $vcode = ownencrypt($code);
                        /*$check = OTP::where('mobile_no', ownencrypt($mobile))->where('otp', ownencrypt($code))->orderBy('id', 'desc')->limit(1)->first();*/
                        $check = OTP::where('mobile_no', ownencrypt($mobile))->where('activity', $type)->where('type', $otp_type)->orderBy('id', 'desc')->limit(1)->first();
                    } elseif ($type == 'Forgot') {
                        $email = strtolower($request['forgot_mail']);
                        $spl = explode("@", $email);
                        $user1 = $spl[0];
                        $user2 = $spl[1];
                        $res = $this->checking($user1, $user2);
                        if (count($res) == 1) {
                            foreach ($res as $val)
                                $userid = $val->id;
                            $code = $request['verify_code'];
                            $vcode = ownencrypt($code);
                            $check = OTP::where('user_id', $userid)->where('activity', $type)->where('type', $otp_type)->orderBy('id', 'desc')->limit(1)->first();
                        } else {
                            $data['status'] = 0;
                            $data['message'] = 'This mail id is not registered.';
                            return json_encode($data);
                        }
                    } else {
                        $data['status'] = 0;
                        $data['message'] = "Provide valid type.";
                        return json_encode($data);
                    }
                    if (count($check) > 0 && $check->otp == $vcode) {
                        $data['status'] = 1;
                        $data['message'] = "Mobile verified successfully";
                        $check->delete();
                        return json_encode($data);
                    } else {
                        $data['status'] = 0;
                        $data['message'] = "Enter valid code";
                        return json_encode($data);
                    }
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Provide valid otp type.';
                    return json_encode($data);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function resetpassword(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                    'forgot_mail' => 'required|email',
                    'password' => 'required|confirmed|min:6',
                    'password_confirmation' => 'required|min:6',
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $email = strtolower($request['forgot_mail']);
                $spl = explode("@", $email);
                $user1 = $spl[0];
                $user2 = $spl[1];
                $res = $this->checking($user1, $user2);
                if (count($res) == 1) {
                    foreach ($res as $val)
                        $check = $val;
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Please enter a valid email id.';
                    return json_encode($data);
                }
                $forgot_code = mt_rand(111111, 999999) . time();
                $check->forgot_code = $forgot_code;
                $check->pass_code = bcrypt($request['password']);
                $check->save();
                //log
                last_activity(get_usermail($check->id), 'Reset Password', $check->id);
                $data['status'] = 1;
                $data['message'] = 'Password reset successful.';
                return json_encode($data);
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    //limit order
    function trade_orders(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                return redirect('logout');
            } else {
                if ($request->isMethod('post')) {
                    $type = $request['type'];
                    if ($type == 'Buy')
                        $pair = $request['pair-buy'];
                    else
                        $pair = $request['pair-sell'];
                    $user_id = Session::get('alphauserid');
                    $trade_type = $request['tradetype'];
                    if ($type == 'Buy') {
                        $amount = $request['buy_amount'];
                        $price = $request['buy_price'];
                        $matching_type = 'Sell';
                        $matching_trade = Trade::where('user_id', $user_id)
                            ->where('type', $matching_type)->where('price', '<=', $price)
                            ->where('pair', $pair)
                            ->where(function ($query) {
                                $query->where('status', 'active')->orWhere('status', 'partially');
                            })->count();
                        $message = 'You have already a Sell order less than or equal to buy price';
                    } else {
                        $amount = $request['sell_amount'];
                        $price = $request['sell_price'];
                        $matching_type = 'Buy';
                        $matching_trade = Trade::where('user_id', $user_id)
                            ->where('type', $matching_type)->where('price', '>=', $price)
                            ->where('pair', $pair)
                            ->where(function ($query) {
                                $query->where('status', '=', 'active')->orWhere('status', '=', 'partially');
                            })->count();
                        $message = 'You have already a Buy order greater than or equal to sell price';
                    }

                    if ($matching_trade > 0) {
                        $data['status'] = '4';
                        $data['message'] = $message;
                        return json_encode($data);
                    } else {

                        if ($amount < 1000) {
                            $data['status'] = 0;
                            $data['message'] = 'Minimum 1000 XDC';
                            return json_encode($data);
                        }

                        $cur = explode("-", $pair);
                        $first_currency = $cur[0];
                        $second_currency = $cur[1];
                        $first_cur_balance = get_userbalance($user_id, $first_currency);
                        $second_cur_balance = get_userbalance($user_id, $second_currency);

                        $get_pair_id = Pair::where('pair', $pair)->first();
                        $amount = number_format($amount, 0, '.', '');
                        $price = number_format($price, 8, '.', '');

                        $total = $amount * $price;

                        if ($type == 'Buy') {
                            $get_txn_fee = get_trade_fee($type, $pair);
                            $trade_fee = $total * $get_txn_fee;
                            $trade_fee = number_format($trade_fee, 12, '.', '');
                            $total = $total + $trade_fee;
                            $deduct_bal = $total;
                            $available_bal = $second_cur_balance;
                            $currency = $second_currency;
                            $update_balance = $second_cur_balance - $deduct_bal;
                            $txd_id = 'BTX' . time();
                        } else {
                            $get_txn_fee = get_trade_fee($type, $pair);
                            $trade_fee = $total * $get_txn_fee;
                            $trade_fee = number_format($trade_fee, 12, '.', '');
                            $total = $total - $trade_fee;
                            $deduct_bal = $amount;
                            $available_bal = $first_cur_balance;
                            $currency = $first_currency;
                            $update_balance = $first_cur_balance - $amount;
                            $txd_id = 'STX' . time();
                        }

                        if ($deduct_bal <= $available_bal) {
                            $trade = new Trade();
                            if ($trade_type == 'stop_limit') {
                                $stop_limit = $request['stop'];
                                $trade->stoporderprice = $stop_limit;
                            }

                            $trade->unique_id = $txd_id;
                            $trade->trade_id = $txd_id;
                            $trade->trade_type = $trade_type;
                            $trade->user_id = $user_id;
                            $trade->pair_id = $get_pair_id->id;
                            $trade->pair = $pair;
                            $trade->firstCurrency = $first_currency;
                            $trade->secondCurrency = $second_currency;
                            $trade->price = $price;
                            $trade->total = $total;
                            $trade->type = $type;
                            $trade->process = '0';
                            $trade->fee = $trade_fee;
                            $trade->original_qty = $amount;
                            $trade->updated_qty = $amount;

                            $trade->status = 'active';

                            if ($trade->save()) {
                                $user_bal = UserBalance::where('user_id', $user_id)->first();
                                $user_bal->$currency = $update_balance;
                                $user_bal->save();

                                //user activity
                                last_activity(get_usermail($user_id), 'Limit Buy order', $user_id);

                                //id
                                $active_id = $trade->id;

                                //find trade now

                                $this->find_trades($active_id, $type, $price, $amount, $pair);

                                $trade_status = Trade::where('id', $active_id)->first();
                                $status = $trade_status->status;
                                if ($status == 'completed') {
                                    $data['status'] = '1';
                                    $data['id'] = $user_id;
                                    $data['message'] = 'Order is been Completed';
                                } else if ($status == 'active') {
                                    $amount = $trade_status->updated_qty;
                                    $price = $trade_status->price;
                                    $pusher_total = $amount * $price;
                                    $trade_fee = $pusher_total * $get_txn_fee;
                                    if ($type == 'Buy') {
                                        $pusher_total = number_format($pusher_total + $trade_fee, 2, '.', '');
                                    } else {
                                        $pusher_total = number_format($pusher_total - $trade_fee, 2, '.', '');
                                    }

                                    $pusher = new Pusher('427b3e2b5664f25aa88f', '5a2be92b0e6a4cc90024', '606412', array('cluster' => 'ap2'));

                                    $pusher->trigger('demo1', 'demo-event', array('User_id' => $user_id, 'Pair' => $pair, 'Total' => $pusher_total, 'Amount' => number_format($amount, 0, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type));

                                    $data['status'] = '2';
                                    $data['message'] = 'Your Order placed';
                                } else if ($status == 'partially') {
                                    $amount = $trade_status->updated_qty;
                                    $price = $trade_status->price;
                                    $pusher_total = $amount * $price;
                                    $trade_fee = $pusher_total * $get_txn_fee;
                                    if ($type == 'Buy') {
                                        $pusher_total = number_format($pusher_total + $trade_fee, 2, '.', '');
                                    } else {
                                        $pusher_total = number_format($pusher_total - $trade_fee, 2, '.', '');
                                    }

                                    $pusher = new Pusher('427b3e2b5664f25aa88f', '5a2be92b0e6a4cc90024', '606412', array('cluster' => 'ap2'));

                                    $pusher->trigger('demo1', 'demo-event', array('User_id' => $user_id, 'Pair' => $pair, 'Total' => $pusher_total, 'Amount' => number_format($amount, 0, '.', ''), 'Price' => number_format($price, 8, '.', ''), 'Type' => $type));

                                    $data['status'] = '3';
                                    $data['message'] = 'Your order is partially executed';
                                }

                                $this->update_pairstats($get_pair_id->id);
                                return json_encode($data);
                            } else {
                                $data['status'] = '0';
                                $data['message'] = 'Some error occurred while placing trade';
                                return json_encode($data);
                            }

                        } else {
                            $data['status'] = '0';
                            $data['message'] = 'Insufficient Balance of ' . $currency;
                            return json_encode($data);
                        }
                    }
                }  //post method
            }
        } catch (\Exception $exception) {
            $data['status'] = '0';
            $data['message'] = 'Server Error.';
            return json_encode($data);
        }
    }

    //find trades
    function find_trades($active_id, $type, $price, $amount, $pair)
    {
        try {
            $find_trade_type = ($type == 'Buy') ? 'Sell' : 'Buy';
            $trade_user_id = $this->single_trade_details($active_id, 'user_id');
            if ($type == 'Buy') {

                $findorders = Trade::where('user_id', '<>', $trade_user_id)->where('price', '<=', $price)->where(['pair' => $pair, 'type' => $find_trade_type])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->orderBy('price', 'asc')->get();

            } else {
                $findorders = Trade::where('user_id', '<>', $trade_user_id)->where('price', '>=', $price)->where(['pair' => $pair, 'type' => $find_trade_type])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->orderBy('price', 'desc')->get();
            }

            $order_process_result = 0;

            //iterating each record
            foreach ($findorders as $foundorder) {
                $found_order_amount = $foundorder->updated_qty;
                $pairid = $foundorder->pair_id;
                if ($found_order_amount > $amount) {
                    $active_status = 'completed';
                    $found_status = 'partially';
                    $executed_price = $foundorder->price;


                    //active order completed
                    $order_process_result = $this->order_process($active_status, $found_status, $active_id, $foundorder->id, $amount, $executed_price);
                    $this->update_pairstats($pairid);

                    break;
                } else if ($found_order_amount == $amount) {
                    $active_status = 'completed';
                    $found_status = 'completed';
                    $executed_price = $foundorder->price;


                    //active order completed
                    $order_process_result = $this->order_process($active_status, $found_status, $active_id, $foundorder->id, $amount, $executed_price);
                    $this->update_pairstats($pairid);

                    break;
                } else {
                    $active_status = 'partially';
                    $found_status = 'completed';
                    $executed_price = $foundorder->price;


                    //active order completed
                    $order_process_result = $this->order_process($active_status, $found_status, $active_id, $foundorder->id, $found_order_amount, $executed_price);
                    $this->update_pairstats($pairid);


                    $amount = $amount - $found_order_amount;
                    if ($amount == 0) {
                        $order_process_result = 1;
                        break;
                    }

                }
            }
            return $order_process_result;
        } catch (\Exception $exception) {
            $data['status'] = '0';
            $data['message'] = 'Server Error.';
            return json_encode($data);
        }
    }

    //order completed
    function order_process($user_status, $trader_status, $user_trade_id, $trader_id, $amount, $executed_price)
    {
        try {

            DB::transaction(function () use ($user_status, $trader_status, $user_trade_id, $trader_id, $amount, $executed_price) {
                $trade = Trade::where('id', $trader_id)->first();

                $up_amt = $trade->updated_qty;
                if ($up_amt >= $amount) {
                    $trader_user_id = $trade->user_id;
                    $trader_type = $trade->type;
                    $pair = $trade->pair;
                    $cur = explode("-", $pair);
                    $first_currency = $cur[0];
                    $second_currency = $cur[1];
                    $trader_total = ($amount * $executed_price);

                    $trader_expected_total = ($amount * $trade->price);
                    if ($trader_type == 'Buy') {

                        $trading_fee = get_trade_fee('Buy', $pair);
                        $trader_fee_charged = $trader_expected_total * $trading_fee;
                        $trader_expected_fee = $trader_total * $trading_fee;
                    } else {
                        $trading_fee = get_trade_fee('Sell', $pair);;
                        $trader_fee_charged = $trader_expected_total * $trading_fee;
                        $trader_expected_fee = $trader_total * $trading_fee;
                    }


                    $trade->status = $trader_status;
                    $upt_qty = $trade->updated_qty - $amount;
                    $trade->updated_qty = $trade->updated_qty - $amount;


                    if ($trader_type == 'Buy') {
                        $trade->updated_total = $trade->updated_total + $trader_total + $trader_expected_fee;

                        $trade->total = ($upt_qty * $trade->price) + ($upt_qty * $trade->price * $trading_fee);
                    } else {
                        $trade->updated_total = $trade->updated_total + $trader_total - $trader_expected_fee;
                        $trade->total = ($upt_qty * $trade->price) - ($upt_qty * $trade->price * $trading_fee);
                    }

                    $trade->save();

                    $trader_user_balance = UserBalance::where('user_id', $trader_user_id)->first();
                    if ($trader_type == 'Buy') {
                        if ($executed_price < $trade->price) {

                            $return_total = ($trader_expected_total - $trader_total) + ($trader_fee_charged - $trader_expected_fee);
                        } else {
                            $return_total = 0;
                        }

                        $trader_user_balance->$first_currency = $trader_user_balance->$first_currency + $amount;
                        $trader_user_balance->$second_currency = $trader_user_balance->$second_currency + $return_total;
                        $trader_user_balance->save();


                    } else {
                        $updated_total = $trader_total - $trader_expected_fee;
                        $trader_user_balance->$second_currency = $trader_user_balance->$second_currency + $updated_total;
                        $trader_user_balance->save();

                    }

                    //user trade process
                    $user_trade = Trade::where('id', $user_trade_id)->first();
                    $user_user_id = $user_trade->user_id;
                    $user_trade_type = $user_trade->type;

                    $user_trade_expected_total = ($amount * $user_trade->price);

                    if ($user_trade_type == 'Buy') {
                        $trading_fee = get_trade_fee('Buy', $pair);;
                        $user_trade_fee_charged = $trader_expected_total * $trading_fee;
                        $user_trader_expected_fee = $trader_total * $trading_fee;
                    } else {
                        $trading_fee = get_trade_fee('Sell', $pair);;
                        $user_trade_fee_charged = $trader_expected_total * $trading_fee;
                        $user_trader_expected_fee = $trader_total * $trading_fee;
                    }

                    $user_trade->status = $user_status;
                    $user_updated_qty = $user_trade->updated_qty - $amount;
                    $user_trade->updated_qty = $user_trade->updated_qty - $amount;

                    if ($user_trade_type == 'Buy') {
                        $user_trade->updated_total = $user_trade->updated_total + $trader_total + $user_trader_expected_fee;
                        $user_trade->total = ($user_updated_qty * $user_trade->price) + ($user_updated_qty * $user_trade->price * $trading_fee);
                    } else {
                        $user_trade->updated_total = $user_trade->updated_total + $trader_total - $user_trader_expected_fee;
                        $user_trade->total = ($user_updated_qty * $user_trade->price) - ($user_updated_qty * $user_trade->price * $trading_fee);
                    }

                    $user_trade->save();

                    $user_user_balance = UserBalance::where('user_id', $user_user_id)->first();
                    if ($user_trade_type == 'Buy') {

                        if ($executed_price < $user_trade->price) {
                            $return_total = ($user_trade_expected_total - $trader_total) + ($user_trade_fee_charged - $user_trader_expected_fee);
                        } else {
                            $return_total = 0;
                        }

                        $user_user_balance->$first_currency = $user_user_balance->$first_currency + $amount;
                        $user_user_balance->$second_currency = $user_user_balance->$second_currency + $return_total;
                        $user_user_balance->save();


                    } else {

                        $updated_total = $trader_total - $user_trader_expected_fee;
                        $user_user_balance->$second_currency = $user_user_balance->$second_currency + $updated_total;
                        $user_user_balance->save();

                    }

                    //admin  trade profit
                    $Trader_admin_coin_teft = new Profit();
                    $Trader_admin_coin_teft->userId = $trader_user_id;
                    $Trader_admin_coin_teft->type = 'Trd-' . $trade->type;
                    $Trader_admin_coin_teft->record_id = $trader_id;
                    $Trader_admin_coin_teft->theftAmount = $trader_expected_fee;
                    $Trader_admin_coin_teft->theftCurrency = $second_currency;
                    $Trader_admin_coin_teft->date = date('Y-m-d');
                    $Trader_admin_coin_teft->time = date('H:i:s');
                    $Trader_admin_coin_teft->save();

                    //admin  trade profit
                    $user_admin_coin_teft = new Profit();
                    $user_admin_coin_teft->userId = $user_user_id;
                    $user_admin_coin_teft->type = 'Trd-' . $user_trade->type;
                    $user_admin_coin_teft->record_id = $user_trade_id;
                    $user_admin_coin_teft->theftAmount = $user_trader_expected_fee;
                    $user_admin_coin_teft->theftCurrency = $second_currency;
                    $user_admin_coin_teft->date = date('Y-m-d');
                    $user_admin_coin_teft->time = date('H:i:s');
                    $user_admin_coin_teft->save();

                    //trade history


                    //trade mapping

                    if ($user_trade_type == 'Buy') {
                        $buy_id = $user_trade_id;
                        $sell_id = $trader_id;
                    } else {
                        $buy_id = $trader_id;
                        $sell_id = $user_trade_id;
                    }
                    $trade_mapping = new TradeMapping();
                    $trade_mapping->unique_id = 'MTX' . time();
                    $trade_mapping->pair = $pair;
                    $trade_mapping->buy_trade_order_id = $buy_id;
                    $trade_mapping->sell_trade_order_id = $sell_id;
                    $trade_mapping->type = $user_trade_type;
                    $trade_mapping->triggered_price = $executed_price;
                    $trade_mapping->triggered_qty = $amount;
                    if ($user_trade_type == 'Buy') {
                        $trade_mapping->total = $trader_total + $user_trader_expected_fee;
                    } else {
                        $trade_mapping->total = $trader_total - $user_trader_expected_fee;
                    }
                    $trade_mapping->save();


//                    //charts data
//                    $xdc_charts = new Charts();
//                                        $vdate = date('Y-m-d H:i:s');
//
//                                        $high = $this->trade_max_value($vdate,$pair);
//                                        $open = $this->trade_open_value($vdate,$pair);
//                                        $close = $this->trade_close_value($vdate,$pair);
//                                        $low = $this->trade_min_value($vdate,$pair);
//
//                                        $xdc_charts->datetime = $vdate;
//                                        $xdc_charts->high = $high;
//                                        $xdc_charts->millsec = strtotime($vdate) * 1000;
//                                        $xdc_charts->open = $open;
//                                        $xdc_charts->low = $low;
//                                        $xdc_charts->volume = $amount;
//                                        $xdc_charts->close = $close;
//                                        $xdc_charts->pair = $pair;
//
//                                        $xdc_charts->save();

                    $trade_mapping_data = TradeMapping::where('id', $trade_mapping->id)->first();

                    $date = $trade_mapping_data->created_at->format('Y-m-d H:i:s');
                    //for alphaex trade history
                    $pusher = new Pusher('427b3e2b5664f25aa88f', '5a2be92b0e6a4cc90024', '606412', array('cluster' => 'ap2'));


                    $pusher->trigger('trade', 'trade-history', array('Pair' => $pair, 'Time' => $date, 'Type' => $user_trade_type, 'Amount' => number_format($amount, 2, '.', ''), 'Price' => number_format($executed_price, 8, '.', ''), 'Total' => number_format($trade_mapping_data->total, 8, '.', '')));


                    //for alphaex pusher
                    $pusher->trigger('order', 'order-history', array('trade_status' => $trader_status, 'Pair' => $pair, 'user_id' => $user_user_id, 'trade_id' => $trader_user_id, 'Type' => $user_trade_type,
                        'Amount' => number_format($amount, 2, '.', ''),
                        'Price' => number_format($executed_price, 8, '.', ''),
                        'Total' => number_format($trade_mapping_data->total, 8, '.', ''),
                        'Fee' => $trading_fee));

                    return 1;

                } else {

                    return 0;
                }

            });
        } catch (\Exception $exception) {

            return 0;
        }
    }

    function single_trade_details($tradid, $key)
    {
        $result = Trade::where('id', $tradid)->first();
        return $result->$key;
    }

    function update_pairstats($pairid)
    {
        try {
            $date = date('Y-m-d H:i:s', strtotime("-1 days"));
            $get_pair = Pair::where('id', $pairid)->first();
            $get_pair_name = $get_pair->pair;

            $pair_stats = PairStats::where('pair_id', $pairid)->first();

            $volume = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->sum('triggered_qty');
            $low = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->min('triggered_price');

            $high = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->max('triggered_price');

            $last_executed = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'desc')->first();
            $triggered_price = $last_executed->triggered_price;

            $first_executed = TradeMapping::where('pair', $get_pair_name)->where('updated_at', '>=', $date)
                ->orderBy('created_at', 'asc')->first();
            $first_executed_price = $first_executed->triggered_price;


            $pair_stats->volume = $volume;
            $pair_stats->low = $low;
            $pair_stats->high = $high;
            $pair_stats->last = $triggered_price;

            $percent_change = (($triggered_price - $first_executed_price) / $first_executed_price) * 100;

            if ($percent_change < 0) {
                $color = 'red';
            } else {
                $color = 'green';
            }

            if ($first_executed_price >= $triggered_price) {
                $change = $first_executed_price - $triggered_price;
                $change = number_format($change, 8, '.', '');
            } else {
                $change = $triggered_price - $first_executed_price;
                $change = number_format($change, 8, '.', '');

            }

            $pair_stats->percent_change = $percent_change;
            $pair_stats->colour = $color;
            $pair_stats->change = $change;
            $pair_stats->save();
        } catch (\Exception $exception) {

        }
    }

    function sessionlogout()
    {
        try {
            Session::flush();
            Cache::flush();
            if (Session::get('alphauserid') == "") {
                sleep(1);
                $response['status'] = 1;
                $response['message'] = 'You have been logged out successfully.';
                return json_encode($response);
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function logout()
    {
        try {
            Session::flush();
            Cache::flush();
            if (Session::get('alphauserid') == "") {
                return redirect('/api/sessionlogout');
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function security(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
//                $google2fa = new Google2FA();
                    $userdata = Users::where('id', $userid)->first();
                    if ($request->isMethod('post')) {
                        $onecode = $request['onecode'];
                        //$valid = $google2fa->verifyKey($userdata->tfa_code, $onecode);
                        $valid = checktfa_code($userdata->tfa_code, $onecode);
                        if ($valid == 1) {
                            if ($userdata->tfa_status == 'enable') {
                                $userdata->tfa_status = 'disable';
                            } else {
                                $userdata->tfa_status = 'enable';
                            }

                            $userdata->save();

                            $responseObject = [];
                            $responseObject['status'] = '1';
                            $responseObject['message'] = 'Successfully ' . $userdata->tfa_status . 'd.';
                            return response()->json($responseObject);

                        } else {
                            $responseObject = [];
                            $responseObject['status'] = 0;
                            $responseObject['message'] = 'Wrong Google authenticator code.';
                            return response()->json($responseObject);
                        }
                    }
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function change_password(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
                    $response = array();
                    if ($request->isMethod('post')) {
                        $validator = Validator::make($request->all(), [
                            'old_password' => 'required',
                            'password' => 'required|confirmed|min:6',
                            'password_confirmation' => 'required|min:6',
                        ]);
                        if ($validator->fails()) {
                            $errors = $validator->errors();
                            $message = "";
                            foreach ($errors->all() as $error) {
                                $message = $message . ', ' . $error;
                            }
                            $response['status'] = '0';
                            $response['message'] = $message;
                            return json_encode($response);
                        }
                        $userid = Session::get('alphauserid');
                        $old_password = $request['old_password'];
                        $password = $request['password'];
                        if ($old_password == $password) {
                            $response['status'] = '0';
                            $response['message'] = 'Password can not be the same as old one';
                            return json_encode($response);
                        }
                        $upt = Users::where('id', $userid)->first();
                        if (Hash::check($old_password, $upt->pass_code)) {
                            $upt->pass_code = bcrypt($password);
                            $upt->save();
                            //log
                            last_activity(get_usermail($userid), 'Profile Update', $userid);
                            $response['status'] = '1';
                            $response['message'] = 'Password changed Successfully.';
                            return json_encode($response);
                        } else {
                            $response['status'] = '0';
                            $response['message'] = 'Old password is wrong.';
                            return json_encode($response);
                        }
                    }

                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }

            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }


    //ADD PAIR THROUGH API
    function add_erc20(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                        'name' => 'required',
                        'contract_address' => 'required',
                        'symbol' => 'required',
                        'token_decimals' => 'required|numeric',
                        'requested_by' => 'required',
                        'logo_url' => 'required|url',
                        'email_id' => 'required|email'
                    ]
                );
                if ($validator->fails()) {
                    $data['status'] = 0;
                    $data['message'] = 'there is some error in submitted data please recheck.';
                    return json_encode($data);
                }

                $name = $request['name'];
                $contract_address = $request['contract_address'];
                $token_symbol = strtoupper($request['symbol']);
                $token_decimals = $request['token_decimals'];
                $logo_url = $request['logo_url'];
                $email = $request['email_id'];

                $result = Erc20Requests::where('contract_address', $contract_address)->first();
                if (isset($result)) {
                    $data['status'] = 0;
                    $data['message'] = 'Contract address already exists';
                    return json_encode($data);
                }

                $result = Erc20Details::where('contract_address', $contract_address)->first();
                if (isset($result)) {
                    $data['status'] = 0;
                    $data['message'] = 'Contract address already exists';
                    return json_encode($data);
                }

                $result = Erc20Requests::where('symbol', $token_symbol)->first();
                if (isset($result)) {
                    $data['status'] = 0;
                    $data['message'] = 'Symbol address already exists';
                    return json_encode($data);
                }

                $result = Erc20Details::where('symbol', $token_symbol)->first();
                if (isset($result)) {
                    $data['status'] = 0;
                    $data['message'] = 'Symbol address already exists';
                    return json_encode($data);
                }

                $result = Currencies::where('currency_symbol', $token_symbol)->first();
                if (isset($result)) {
                    $data['status'] = 0;
                    $data['message'] = 'Symbol address already exists';
                    return json_encode($data);
                }

                $new = new Erc20Requests();
                $new->description = $name;
                $new->contract_address = $contract_address;
                $new->token_decimals = $token_decimals;
                $new->symbol = $token_symbol;
                $new->requested_by = $request['requested_by'];
                $new->logo_url = $logo_url;
                $new->email = $email;
                $new->status = 'Pending';
                $new->save();
                $data['status'] = 1;
                $data['message'] = 'Your request is successfully submitted and waiting for approval from admin';
                return json_encode($data);
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function kyc_details(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $user_id = Session::get('alphauserid');
                if ($user_id == $request['userid']) {
                    $response = array();
                    if ($request->isMethod('post')) {
                        $validator = Validator::make($request->all(), [
                            'first_name' => 'required',
                            'last_name' => 'required',
                            'kyc_country_id' => 'required',
                            'gender' => 'required',
                            'document_id' => 'required',
                            'dob' => 'required|date_format:d/m/Y|before:-18 years',
                        ], [
                            'dob.before' => 'The age in KYC DOB should be greater than 18 years.',
                        ]);
                        if ($validator->fails()) {
                            $errors = $validator->errors();
                            $message = "";
                            foreach ($errors->all() as $error) {
                                $message = $message . ', ' . $error;
                            }
                            $response['status'] = '0';
                            $response['message'] = $message;
                            return json_encode($response);
                        }
                        $result = Users::where('id', $user_id)->first();
                        $verification = Verification::where('user_id', $user_id)->first();
                        if ($verification == null) {
                            $verification = new Verification();
                        }
                        $verify = Verification::where('user_id', '<>', $user_id)->where('national_id', 'like', $request['document_id'])->first();
                        if ($verify != null) {
                            $response['status'] = '0';
                            $response['message'] = 'The entered ID number is already registered.';
                            return json_encode($response);
                        }
                        $verification->user_id = $user_id;
                        $verification->proof1_status = 0;
                        $verification->proof2_status = 0;
                        $verification->proof3_status = 0;
                        $verification->first_name = $request['first_name'];
                        $verification->last_name = $request['last_name'];
                        $verification->country_code = $request['kyc_country_id'];
                        $verification->gender = $request['gender'];
                        $verification->national_id = $request['document_id'];
                        $verification->dob = $request['dob'];
                        if ($request['f_side']) {
                            $info = pathinfo($_FILES['f_side']['name']);
                            $mime = mime_content_type($_FILES['f_side']['tmp_name']);
                            $mime_array = ['image/png', 'image/jpeg'];
                            $ext = strtolower($info['extension']);
                            $ext_array = ['png', 'jpg', 'jpeg'];
                            if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
//                    $file_name = $user_id.'_'.'f_side.'.$ext;
                                $check = uniqid("", 'true') . '.' . $ext;
                                $file_name = $this->check_unique($check, $ext);
                                while ($check != $file_name) {
                                    $check = $this->check_unique($file_name, $ext);
                                }
//                    $target = $_SERVER['DOCUMENT_ROOT'].'/public/uploads/users/documents/'.$file_name;
//                    if($verification->proof1!='') {
//                        $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/documents/' . $verification->proof1;
//                        unlink($target1);
//                    }
//                    move_uploaded_file( $_FILES['f_side']['tmp_name'], $target);
                                if ($verification->proof1 != '') {
                                    Storage::disk('ftp')->delete($verification->proof1);
                                }
                                Storage::disk('ftp')->put($file_name, fopen($request->file('f_side'), 'r+'));
                                $verification->proof1 = $file_name;
                            } else {
                                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                                $subject = 'Some user trying to upload malicious file in KYC.';
                                $message = 'User id :' . $user_id . ', Email id : ' . get_usermail($user_id) . ' is trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                                sendmail($to, $subject, ['content' => $message]);
                                $result->status = '2';
                                $result->save();
                                $response['status'] = '0';
                                $response['message'] = 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.';
                                Session::flush();
                                return json_encode($response);
                            }
                        }
                        if ($request['b_side']) {
                            $info = pathinfo($_FILES['b_side']['name']);
                            $mime = mime_content_type($_FILES['b_side']['tmp_name']);
                            $mime_array = ['image/png', 'image/jpeg'];
                            $ext = strtolower($info['extension']);
                            $ext_array = ['png', 'jpg', 'jpeg'];
                            if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
//                    $file_name = $user_id.'_'.'b_side.'.$ext;
                                $check = uniqid("", 'true') . '.' . $ext;
                                $file_name = $this->check_unique($check, $ext);
                                while ($check != $file_name) {
                                    $check = $this->check_unique($file_name, $ext);
                                }
//                    $target = $_SERVER['DOCUMENT_ROOT'].'/public/uploads/users/documents/'.$file_name;
//                    if($verification->proof2!='') {
//                        $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/documents/' . $verification->proof2;
//                        unlink($target1);
//                    }
//                    move_uploaded_file( $_FILES['b_side']['tmp_name'], $target);
                                if ($verification->proof2 != '') {
                                    Storage::disk('ftp')->delete($verification->proof2);
                                }
                                Storage::disk('ftp')->put($file_name, fopen($request->file('b_side'), 'r+'));
                                $verification->proof2 = $file_name;
                            } else {
                                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                                $subject = 'Some user trying to upload malicious file in KYC.';
                                $message = 'User id :' . $user_id . ', Email id : ' . get_usermail($user_id) . ' is trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                                sendmail($to, $subject, ['content' => $message]);
                                $result->status = '2';
                                $result->save();
                                $response['status'] = '0';
                                $response['message'] = 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.';
                                Session::flush();
                                return json_encode($response);
                            }
                        }
                        if ($request['h_side']) {
                            $info = pathinfo($_FILES['h_side']['name']);
                            $mime = mime_content_type($_FILES['h_side']['tmp_name']);
                            $mime_array = ['image/png', 'image/jpeg'];
                            $ext = strtolower($info['extension']);
                            $ext_array = ['png', 'jpg', 'jpeg'];
                            if (in_array($mime, $mime_array) && in_array($ext, $ext_array)) {
//                    $file_name = $user_id.'_'.'h_side.'.$ext;
                                $check = uniqid("", 'true') . '.' . $ext;
                                $file_name = $this->check_unique($check, $ext);
                                while ($check != $file_name) {
                                    $check = $this->check_unique($file_name, $ext);
                                }
//                    $target = $_SERVER['DOCUMENT_ROOT'].'/public/uploads/users/documents/'.$file_name;
//                    if($verification->proof3!='') {
//                        $target1 = $_SERVER['DOCUMENT_ROOT'] . '/public/uploads/users/documents/' . $verification->proof3;
//                        unlink($target1);
//                    }
//                    move_uploaded_file( $_FILES['h_side']['tmp_name'], $target);
                                if ($verification->proof3 != '') {
                                    Storage::disk('ftp')->delete($verification->proof3);
                                }
                                Storage::disk('ftp')->put($file_name, fopen($request->file('h_side'), 'r+'));
                                $verification->proof3 = $file_name;
                            } else {
                                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'alkeshc07@gmail.com', 'patelbunti@gmail.com'];
                                $subject = 'Some user trying to upload malicious file in KYC.';
                                $message = 'User id :' . $user_id . ', Email id : ' . get_usermail($user_id) . ' is trying to upload a file other than the allowed extensions. His account has been deactivated. He is trying to upload a file with extension : ' . $ext . ' and the file format is : ' . $mime;
                                sendmail($to, $subject, ['content' => $message]);
                                $result->status = '2';
                                $result->save();

                                $response['status'] = '0';
                                $response['message'] = 'Your account has been deactivated, if you have any query regarding this then please contact our support at support@alphaex.net.';
                                Session::flush();
                                return json_encode($response);
                            }
                        }
                        if ($verification->save()) {
                            $user = Users::where('id', $user_id)->first();
                            $user->document_status = 3;
                            $user->save();
                            $response['status'] = '1';
                            $response['message'] = 'Your Kyc Verification request is placed.';
                            return json_encode($response);
                        } else {
                            $response['status'] = '0';
                            $response['message'] = 'Server Error.';
                            return json_encode($response);
                        }
                    }
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function check_unique($file_name, $ext)
    {
        try {
            $check = Verification::where('proof1', $file_name)->orWhere('proof2', $file_name)->orWhere('proof3', $file_name)->get();
            if (count($check) > 0) {
                $file_name = uniqid("", 'true') . '.' . $ext;
                return $file_name;
            } else {
                return $file_name;
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function fav_pairs(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $user_id = Session::get('alphauserid');
                if ($user_id == $request['userid']) {
                    $fav_pairs = Favorite::where('user_id', $user_id)->get();
                    $fav = array();
                    if (isset($fav_pairs)) {
                        foreach ($fav_pairs as $fav_pair) {
                            $fav_user_id = $fav_pair->user_id;
                            $fav_pair_id = $fav_pair->pair_id;
                            $array = array('user_id' => $fav_user_id, 'pair_id' => $fav_pair_id);
                            $fav[] = $array;
                        }
                    }
                    $data['status'] = 1;
                    $data['message'] = $fav;
                    return json_encode($data);
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function market_rate($pair)
    {
        try {
            $cur = explode("-", $pair);
            $first_currency = $cur[0];
            $second_currency = $cur[1];
            if ($second_currency == 'XDCE') {
                $buy_rate = 1;
                $sell_rate = 1;
            } else {
                $buy_rate = get_buy_market_rate($first_currency, $second_currency);
                $sell_rate = get_sell_market_rate($first_currency, $second_currency);
            }
            $response['status'] = '1';
            $response['message'] = 'Success';
            $response['buy_rate'] = number_format($buy_rate, 8, '.', '');
            $response['sell_rate'] = number_format($sell_rate, 8, '.', '');
            return json_encode($response);
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function open_orders(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
                    $curr = $request['curr'];
                    $curr = $curr ? $curr : 'XDC';

                    $open_orders = Trade::where('user_id', $userid)->whereIn('status', ['active', 'partially'])
                        ->where(function ($query) use ($curr) {
                            $query->where('firstCurrency', '=', $curr)->orWhere('secondCurrency', '=', $curr);
                        })->orderBy('created_at', 'desc')->get();
                    $response['status'] = '1';
                    $response['message'] = $open_orders;
                    return json_encode($response);
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function trade_history(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
                    $curr = $request['curr'];
                    $curr = $curr ? $curr : 'XDC';

                    $trade_history = Trade::where('user_id', $userid)->whereIn('status', ['completed', 'cancelled', 'partially'])
                        ->where(function ($query) use ($curr) {
                            $query->where('firstCurrency', '=', $curr)->orWhere('secondCurrency', '=', $curr);
                        })->orderBy('created_at', 'desc')->get();
                    $response['status'] = '1';
                    $response['message'] = $trade_history;
                    return json_encode($response);
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function deposit_history(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
                    $curr = $request['curr'];
                    $curr = $curr ? $curr : 'XDC';

                    $deposit_history = Transaction::where('user_id', $userid)->where('type', 'Deposit')->where('currency_name', $curr)->orderBy('created_at', 'desc')->get();

                    $response['status'] = '1';
                    $response['message'] = $deposit_history;
                    return json_encode($response);
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function withdraw_history(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
                    $curr = $request['curr'];
                    $curr = $curr ? $curr : 'XDC';

                    $withdraw_history = Transaction::where('user_id', $userid)->where('type', 'Withdraw')->where('currency_name', $curr)->orderBy('created_at', 'desc')->get();

                    $response['status'] = '1';
                    $response['message'] = $withdraw_history;
                    return json_encode($response);
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function wallet(Request $request)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            } else {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
//                    check_live_address($userid);
                    $currencies = DB::table('user_currency_addresses')->where('user_currency_addresses.user_id', '=', $userid)
                        ->join('user_balance_new', function ($join) {
                            $join->on('user_balance_new.user_id', '=', 'user_currency_addresses.user_id');
                            $join->on('user_balance_new.currency_id', '=', 'user_currency_addresses.currency_id');
                        })
                        ->orderBy('user_balance_new.currency_id', 'asc')
                        ->select('user_currency_addresses.currency_name', 'user_currency_addresses.currency_addr')->get();
                    if (isset($currencies[0])) {
                        foreach ($currencies as $currency) {
                            $bal = number_format(get_userbalance($userid, $currency->currency_name), '4', '.', ',');
                            $intradebal = number_format(get_user_intradebalance($userid, $currency->currency_name), '4', '.', ',');
                            $totalbal = number_format((get_userbalance($userid, $currency->currency_name) + get_user_intradebalance($userid, $currency->currency_name)), '4', '.', ',');
                            $usd_bal = number_format(get_estimate_usd($currency->currency_name, $bal), '4', '.', ',');
                            $array = array('currency' => $currency->currency_name, 'address' => $currency->currency_addr, 'balance' => $bal, 'intrade_balance' => $intradebal, 'total_balance' => $totalbal, 'usd' => $usd_bal);
                            $result[] = $array;
                        }
                    } else {
                        $result = [];
                    }
                    $response['status'] = '1';
                    $response['userid'] = $userid;
                    $response['isdcode'] = get_user_details($userid, 'mob_isd');
                    $response['mobile_no'] = owndecrypt(get_user_details($userid, 'mobile_no'));
                    $response['kyc_status'] = get_user_details($userid, 'document_status');
                    $response['totalusd'] = number_format(get_total_usdbalance($userid), '4', '.', ',');
                    $response['XRP_addr'] = 'rhfzdZgZPTSqGVW41cwdfG4uudEhMwnd22';
//                    $response['result'] = $user;
                    $response['currencies'] = $result;
                    return json_encode($response);
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function transferverify(Request $request, $currency)
    {
        try {
            if (Session::get('alphauserid') == "") {
                $data['status'] = 0;
                $data['message'] = 'Please login.';
                return json_encode($data);
            }
            if ($request->isMethod('post')) {
                $userid = Session::get('alphauserid');
                if ($userid == $request['userid']) {
                    if (get_user_details($userid, 'document_status') != 1) {
                        $response['status'] = '0';
                        $response['message'] = 'Please complete your KYC to place a withdrawal request.';
                        return json_encode($response);
                    }
                    $validator = Validator::make($request->all(), [
                        'to_addr' => 'required',
                        'to_amount' => 'required',
//                        'total_amount' => 'required',
                        'otp_code' => 'required',
                    ]);
                    if ($validator->fails()) {
                        $errors = $validator->errors();
                        $message = "";
                        foreach ($errors->all() as $error) {
                            $message = $message . ', ' . $error;
                        }
                        $response['status'] = '0';
                        $response['message'] = $message;
                        return json_encode($response);
                    }
                    $min = min_withdraw($currency);
                    if ($request['to_amount'] < $min) {
                        $response['status'] = '0';
                        $response['message'] = 'Minimum withdrawal of ' . $currency . ' is ' . $min;
                        return json_encode($response);
                    }
                    if (strtolower($request['to_addr']) == get_user_details($userid, $currency . '_addr')) {
                        $response['status'] = '0';
                        $response['message'] = 'To address as same as your address please check it';
                        return json_encode($response);
                    }
                    if ($request['to_amount'] > get_userbalance($userid, $currency)) {
                        $response['status'] = '0';
                        $response['message'] = 'Insufficient Balance';
                        return json_encode($response);
                    }
                    if (!$this->checkotpcode($request['otp_code'], 'Withdraw')) {
                        $response['status'] = '0';
                        $response['message'] = 'OTP Code is wrong';
                        return json_encode($response);
                    }
                    $to_addr = $request['to_addr'];
                    $amount = $request['to_amount'];

                    $get_fee = getfee($currency);
                    if ($currency == 'XDCE') {
                        $fee = $amount * ($get_fee / 100);
                        $paid_amount = $amount - $fee;
                    } else {
                        $fee = $get_fee;
                        $paid_amount = $amount - $fee;
                    }

                    if ($currency == 'XRP') {
                        $xrp_desttag = $request['xrp_desttag'];
                    } else {
                        $xrp_desttag = "";
                    }

                    $transid = 'TXW' . $userid . time();
                    $today = date('Y-m-d H:i:s');
                    $ip = \Request::ip();
                    $ins = new Transaction;
                    $ins->user_id = $userid;
                    $ins->payment_method = 'Cryptocurrency Account';
                    $ins->transaction_id = $transid;
                    $ins->currency_name = $currency;
                    $ins->type = 'Withdraw';
                    $ins->transaction_type = '2';
                    $ins->amount = $amount;
                    $ins->updated_at = $today;
                    $ins->crypto_address = $to_addr;
                    $ins->transfer_amount = '0';
                    $ins->fee = $fee;
                    $ins->tax = '0';
                    $ins->verifycode = '1';
                    $ins->order_id = '0';
                    $ins->status = 'Pending';
                    $ins->cointype = '2';
                    $ins->payment_status = 'Not Paid';
                    $ins->paid_amount = $paid_amount;
                    $ins->wallet_txid = '';
                    $ins->ip_address = $ip;
                    $ins->verify = '1';
                    $ins->blocknumber = '';
                    $ins->xrp_desttag = $xrp_desttag;
                    $ins->ledgerversion = '';
                    if ($ins->save()) {
                        $fetchbalance = get_userbalance($userid, $currency);
                        $uptamt = $fetchbalance - $amount;
                        $upt = Balance::where('user_id', $userid)->first();
                        $upt->$currency = $uptamt;
                        $upt->save();
                        $response['status'] = '1';
                        $response['message'] = 'Withdraw request successfully transferred to Admin';
                        return json_encode($response);
                    }
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'Session and given user id mismatch.';
                    return json_encode($response);
                }
            } else {
                $response['status'] = '0';
                $response['message'] = 'Invalid Request.';
                return json_encode($response);
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }

    function checkotpcode($code, $type)
    {
        try {
            $userid = Session::get('alphauserid');
            $mobile = get_user_details($userid, 'mobile_no');
            $check = OTP::where('mobile_no', $mobile)->where('otp', ownencrypt($code))->where('activity', $type)->orderBy('id', 'desc')->limit(1)->first();
            if (count($check) > 0) {

                try {
                    OTP::where('mobile_no', $mobile)->where('otp', ownencrypt($code))->where('activity', $type)->orderBy('id', 'desc')->delete();
                } catch (\Exception $e) {
                    echo $e;
                }

                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            echo $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage();
        }
    }

    function contact_us(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $validator = Validator::make($request->all(), [
                    'enquiry_name' => 'required',
                    'enquiry_email' => 'required|email',
                    'enquiry_telephone' => 'required',
                    'enquiry_message' => 'required',
                    'enquiry_subject' => 'required',
//                'g-recaptcha-response' => 'required|captcha'
//                    'captcha' => 'required|captcha',
                ], [
//                'g-recaptcha-response.required' => 'Please verify that you are human.',
//                'g-recaptcha-response.captcha' => 'Captcha error! try again later or contact site admin.'
//                    'captcha.required' => 'Captcha is required',
//                    'captcha.captcha' => 'Captcha is wrong',
                ]);
                if ($validator->fails()) {
                    $errors = $validator->errors();
                    $message = "";
                    foreach ($errors->all() as $error) {
                        $message = $message . ', ' . $error;
                    }
                    $response['status'] = '0';
                    $response['message'] = $message;
                    return json_encode($response);
                }
                $enquiry_name = $request['enquiry_name'];
                $enquiry_email = $request['enquiry_email'];
                $enquiry_subject = $request['enquiry_subject'];
                $telephone = $request['enquiry_telephone'];
                $enquiry_message = $request['enquiry_message'];

                $user_id = 'NA';

                //recognizing user by email id
                $spl = explode("@", $enquiry_email);
                $user1 = $spl[0];
                $user2 = $spl[1];
                $user_record = $this->checking($user1, $user2);

                if (isset($user_record)) {
                    foreach ($user_record as $user)
                        $user_id = $user->id;
                }

                $subject = $enquiry_subject;
                $message = get_template('12', 'template');
                $mailarr = array(
                    '###Name###' => $enquiry_name,
                    '###Id###' => $user_id,
                    '###Email###' => $enquiry_email,
                    '###Number###' => $telephone,
                    '###CONTENT###' => $enquiry_message
                );


                //email body
                $to = 'support@alphaex.net';
                $username = $enquiry_name;
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                if (sendmail($to, $subject, ['content' => $message])) {
                    $response['status'] = '1';
                    $response['message'] = 'Your Message Successfully sent to Administrator.';
                    return json_encode($response);
                } else {
                    $response['status'] = '0';
                    $response['message'] = 'Server Error.';
                    return json_encode($response);
                }
            }
        } catch (\Exception $e) {
            $response['status'] = '0';
            $response['message'] = 'Server Error.';
            return json_encode($response);
        }
    }


    function transfer_erc20admin(Request $request)
    {
        try {
            $fromaddress = $request['from_address'];
            $toaddr = $request['to_address'];
            $contractaddress = $request['contract_address'];
            $amount = $request['amount'];
            $password = $request['password'];
            $wallet_ip = $request['eth_ip'];
            $wallet_port = $request['port'];
            $tokendecimal = $request['tokendecimal'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $result = exec('cd ' . $server_path . '/erc && node send_erc20_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddress . ' ' . $toaddr . ' ' . $amount . ' ' . $contractaddress . ' ' . $password . ' ' . $tokendecimal, $output, $return_var);
            $out = json_decode($result);
            return json_encode($out);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function transfer_erc20(Request $request)
    {
        try {
            $fromaddress = $request['from_address'];
            $toaddr = $request['to_address'];
            $contractaddress = $request['contract_address'];
            $amount = $request['amount'];
            $password = $request['password'];
            $wallet_ip = $request['eth_ip'];
            $wallet_port = $request['port'];
            $tokendecimal = $request['tokendecimal'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $result = exec('cd ' . $server_path . '/erc && node send_erc20.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddress . ' ' . $toaddr . ' ' . $amount . ' ' . $contractaddress . ' ' . $password . ' ' . $tokendecimal, $output, $return_var);
            $out = json_decode($result);
            return json_encode($out);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return json_encode('error');
        }
    }

    function getting_eth_balance(Request $request)
    {
        try {
            $output = array();
            $return_var = -1;
            $ip = $request['eth_ip'];
            $port = $request['port'];
            $address = $request['address'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $balance = exec('cd ' . $server_path . '/crypto && node eth_balance.js ' . $ip . ' ' . $port . ' ' . $address, $output, $return_var);
            $bal = $balance / 1000000000000000000;
            return json_encode($bal);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function get_token_balance(Request $request)
    {
        try {
//            $start_time = microtime(true);
            $output = array();
            $return_var = -1;
            $ip = $request['eth_ip'];
            $port = $request['port'];
            $address = $request['address'];
            $contract_addr = $request['contract_address'];
            $tokendecimal = $request['tokendecimal'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $balance = exec('cd ' . $server_path . '/erc && node token_balance.js ' . $ip . ' ' . $port . ' ' . $address . ' ' . $contract_addr . ' ' . $tokendecimal, $output, $return_var);
//            $end_time = microtime(true);
//            \Log::info(['Token Balance',$balance, __LINE__, ($start_time - $end_time), basename($_SERVER['PHP_SELF'])]);
            return json_encode($balance);
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return 0;
        }
    }

    function get_estimate_gas(Request $request)
    {
        try {
            $output = array();
            $return_var = -1;
            $ip = $request['eth_ip'];
            $port = $request['port'];
            $fromaddr = $request['from_address'];
            $toaddr = $request['to_address'];
            $amount = $request['amount'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $gas = exec('cd ' . $server_path . '/erc && node estimate_gas.js ' . $ip . ' ' . $port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount, $output, $return_var);
            $estimate_gas = $gas / 1000000000000000000;
            return json_encode($estimate_gas);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function eth_transfer_erc20_admin(Request $request)
    {
        try {
            $output = array();
            $return_var = -1;
            $wallet_ip = $request['eth_ip'];
            $wallet_port = $request['port'];
            $password = $request['password'];
            $fromaddr = $request['from_address'];
            $toaddr = $request['to_address'];
            $amount = $request['amount'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $result = exec('cd ' . $server_path . '/crypto && node sent_eth_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
            $out = json_decode($result);
            return json_encode($out);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function check_tx_status_eth(Request $request)
    {
        try {
            $output = array();
            $return_var = -1;
            $wallet_ip = $request['eth_ip'];
            $wallet_port = $request['port'];
            $hash = $request['hash'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $result = exec('cd ' . $server_path . '/erc && node transaction_status.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $hash, $output, $return_var);
            return json_encode($result);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function eth_transfer_fun_admin(Request $request)
    {
        try {
            $output = array();
            $return_var = -1;
            $wallet_ip = $request['eth_ip'];
            $wallet_port = $request['port'];
            $password = $request['password'];
            $fromaddr = $request['from_address'];
            $toaddr = $request['to_address'];
            $amount = $request['amount'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $result = exec('cd ' . $server_path . '/crypto && node sent_eth_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
            $out = json_decode($result);
            return json_encode($out);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function eth_transfer_fun(Request $request)
    {
        try {
            $output = array();
            $return_var = -1;
            $wallet_ip = $request['eth_ip'];
            $wallet_port = $request['port'];
            $password = $request['password'];
            $fromaddr = $request['from_address'];
            $toaddr = $request['to_address'];
            $amount = $request['amount'];
            $server_path = $_SERVER["DOCUMENT_ROOT"];
            $result = exec('cd ' . $server_path . '/crypto && node sent_eth.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
            $out = json_decode($result);
            return json_encode($out);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function session_info()
    {
        return Session::all();
    }

    function test(Request $request)
	{

		try {
		
			$public_key = '0fa7d0b9c39d57db0cd9b58e89418f6443ae177bba58c7b73b46708eb7ea3803'; 
			$private_key = 'd6f9da38F5Dd880735DbEa7D5832c8EA90ef2f4c546c19A645dB32357542DF39'; 
			$secret = ']MJ.Xv=G%}{4';
			
			// Note there are two required post fields  "cmd" and "currency" per the above referenced documentation
			// version, key and format will stay the same for all your requests. 
			$req['version'] = 1; 
			$req['cmd'] = "get_callback_address";
			$req['currency'] = "LTCT";
			$req['key'] = $public_key; 
			$req['format'] = 'json'; //supported values are json and xml 
			
			// Generate the query string 
			$post_data = http_build_query($req, '', '&'); 
			
			// Calculate the HMAC signature on the POST data 
			$hmac = hash_hmac('sha512', $post_data, $private_key); 
			
			// Use curl to hit the endpoint so that you can send the required headers 
			$ch = curl_init('https://www.coinpayments.net/api.php'); 
			curl_setopt($ch, CURLOPT_FAILONERROR, TRUE); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('HMAC: '.$hmac,'Content-Type: application/x-www-form-urlencoded')); 
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data); 
			
			// Execute the call and close cURL handle      
			$data = curl_exec($ch); 
			$err = curl_error($ch);
			\Log::info(['hmac'=>$hmac,'data'=>$data,'secret'=>$secret,'error',$err]);
			// dump the data returned back from coinpayments
			return $data;
			
		} catch (\Exception $e) {
			\Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
			return view('errors.404');
		}


    }
    
    function test1(Request $request)
	{

		try {
		
			$public_key = '0fa7d0b9c39d57db0cd9b58e89418f6443ae177bba58c7b73b46708eb7ea3803'; 
			$private_key = 'd6f9da38F5Dd880735DbEa7D5832c8EA90ef2f4c546c19A645dB32357542DF39'; 
			$secret = ']MJ.Xv=G%}{4';
			
			// Note there are two required post fields  "cmd" and "currency" per the above referenced documentation
			// version, key and format will stay the same for all your requests. 
			$req['version'] = 1; 
			$req['cmd'] = "get_callback_address";
            $req['currency'] = "LTCT";
            $req['ipn_url'] = "http://uat.alphaex.net/api/demo";
			$req['key'] = $public_key; 
			$req['format'] = 'json'; //supported values are json and xml 
			
			// Generate the query string 
			$post_data = http_build_query($req, '', '&'); 
			
			// Calculate the HMAC signature on the POST data 
			$hmac = hash_hmac('sha512', $post_data, $private_key,$secret); 
			
			// Use curl to hit the endpoint so that you can send the required headers 
			$ch = curl_init('https://www.coinpayments.net/api.php'); 
			curl_setopt($ch, CURLOPT_FAILONERROR, TRUE); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('HMAC: '.$hmac,'Content-Type: application/x-www-form-urlencoded')); 
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data); 
			
			// Execute the call and close cURL handle      
			$data = curl_exec($ch); 
			$err = curl_error($ch);
			\Log::info(['hmac'=>$hmac,'data'=>$data,'secret'=>$secret,'error',$err]);
			// dump the data returned back from coinpayments
			return $data;
			
		} catch (\Exception $e) {
			\Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
			return view('errors.404');
		}


	}

    function demo(Request $request)
	{

		try {
        
            \Log::info(["data",$request]);
			return $request;
			
		} catch (\Exception $e) {
			\Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
			return view('errors.404');
		}


    }
    
    //for alphaex v3 
    function generateAddress(Request $request){
        try{
            if ($request->isMethod('post')) {
                $currency = $request['currency'];
                $uniqueId = $request['uniqueId'];
                $email = $request['email'];

                if($currency == 'BTC'){
                    $address = create_btc_address($uniqueId);
                }else if($currency == 'USDT'){
                    $address = create_usdt_address($uniqueId);
                }
                
                if($address != null){
                    $addr = new AlphaExV3Address();
                    $addr->uniqueId = $uniqueId;
                    $addr->email = $email;
                    $addr->currency = $currency;
                    $addr->currencyAddress = $address;
                    $addr->save();
                    $response['status'] = 200;
                    $response['address'] = $address;
                }
                else{
                    $response['status'] = 500;
                    $response['message'] = 'Address not generated';
                }
                return json_encode($response);
            } 
        }catch(\Exception $e){
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            // return view('errors.404');
            $response['status'] = 500;
            $response['message'] = 'Server Error';
            return json_encode($response);
        }
    }


}