<?php

namespace App\Http\Controllers;

//use App\Jobs\MoveKey;
use App\model\Admin;
use App\model\Balance;
use App\model\Cms;
use App\model\Enquiry;
use App\model\Erc20Details;
use App\model\Erc20Requests;
use App\model\Currencies;
use App\model\ExtraBonus;
use App\model\Faq;
use App\model\Fees;
use App\model\ico;
use App\model\icodetails;
use App\model\ICORate;
use App\model\Marketprice;
use App\model\Metacontent;
use App\model\Node;
use App\model\OpeningBalance;
use App\model\OTP;
use App\model\ICOTrade;
use App\model\Pair;
use App\model\PairStats;
use App\model\Profit;
use App\model\ReferralExtra;
use App\model\ReserveBalances;
use App\model\SiteSettings;
use App\model\Template;
use App\model\Trade;
use App\model\TradeMapping;
use App\model\Tradingfee;
use App\model\Transaction;
use App\model\Transactionfee;
use App\model\UserBalance;
use App\model\Users;
use App\model\Verification;
use App\model\Wallettrans;
use App\model\Whitelist;
use App\model\XDCChart;
use App\model\Wallet;
use App\model\DeletedUsers;
use App\model\ReferralEarning;
use App\model\ReferralBonus;
use App\model\XdcePass;
use App\model\Xdce_transfer;
use Cache;
use DateTime;
use DB;
use Hash;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Session;
use Carbon\Carbon;
use Pusher\Pusher;
use Maatwebsite\Excel\Facades\Excel;
use Validator;
use File;

//use Barryvdh\DomPDF\Facade as PDF;

class SiteadminController extends Controller
{
    //
    public function __construct()
    {
        try {
            //$this->middleware('Adminlogin');
            $ip = \Request::ip();
            blockip_list($ip);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function index(Request $request)
    {
        try {
            if ($request->isMethod('post')) {

                $validator = $this->validate($request, [
                    'alpha_username' => 'required',
                    'alpha_password' => 'required|min:6',
                    'pattern' => 'required',
                ], [
                    'alpha_username.required' => 'Email is required',
                    'alpha_password.required' => 'Password is required',
                    'alpha_password.min' => 'Password 6 characters is required',
                ]);

                $email = $request['alpha_username'];
                $password = $request['alpha_password'];
                $auth = $this->adminauth($email, $password);
                switch ($auth) {
                    case '1':
                        return redirect('prashaasak/home');
                        break;
                    case '2':
                        Session::flash('error', 'Password is invalid');
                        return redirect('prashaasak');
                        break;
                    case '3':
                        return redirect('prashaasak/pending_history');
                        break;
                    case '0':
                        Session::flash('error', 'Account is deactive');
                        return redirect('prashaasak');
                        break;

                    default:
                        return redirect('prashaasak');
                        break;
                }
            }
            return view('panel.login');
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function adminauth($email, $password)
    {
        try {
            $arr = array('email_id' => $email, 'status' => 'active');
            $check = Admin::where($arr)->first();
            if ($check) {
                if (Hash::check($password, $check->XDC_password)) {
                    $sess = array('alpha_id' => $check->id, 'role' => $check->role, 'alowner' => $email);

                    Session::put($sess);
                    owner_activity($email, 'Login');
                    if ($check->XDC_username == "Traders") {
                        return 3;
                    }
                    return "1";
                } else {
                    return "2";
                }
            } else {
                return "0";
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function logout()
    {
        try {
            Session::flush();
            Cache::flush();
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function home()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {

//                $adminxdcaddr = decrypt(get_config('xdc_address'));
//                $adminetaddr = decrypt(get_config('et_address'));
//                $adminxdceaddr = decrypt(get_config('xdce_address'));
//                $adminethaddr = decrypt(get_config('eth_address'));
//                $xdc_bal = number_format(get_livexdc_bal($adminxdcaddr), 2, '.', '');
////                $et_bal = number_format(get_liveet_bal($adminetaddr), 2, '.', '');
//                $xdce_bal = number_format(get_livexdce_bal($adminxdceaddr), '2', '.', '');
//                $usdc_bal = number_format(get_token_balance($adminethaddr, '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', 6), '2', '.', '');
//                $eth_bal = number_format(getting_eth_balance($adminethaddr), '3', '.', '');
//                $adminbtcaddr = decrypt(get_config('btc_address'));
//                $btc_bal = get_btc_wallet_info($adminbtcaddr);
//                $btc_bal1 = number_format($btc_bal['balance'], 4, '.', '');
//                $adminusdtaddr = decrypt(get_config('usdt_address'));
//                $usdt_bal1 = usdt_bal();
////                $usdt_bal1 = 0;
//
//                $adminbchaddr = decrypt(get_config('bch_address'));
//                $bch_bal = get_bch_wallet_info($adminbchaddr);
//                $bch_bal1 = number_format($bch_bal['balance'], 4, '.', '');
//
////            $btc_bal1 = "qqqqqq";
//                $adminxrpaddr = decrypt(get_config('xrp_address'));
//                $xrp_res = get_xrp_balance($adminxrpaddr);

//                $pending_sell_transaction = Trade::query()->whereIn('trade_order.status', ['partially', 'active'])->get();
//                $pending_eth_transaction_buy = $pending_sell_transaction->where('type', 'Buy')->where('secondCurrency', 'ETH')->sum('total');
//                $pending_eth_transaction_sell = $pending_sell_transaction->where('type', 'Sell')->where('firstCurrency', 'ETH')->sum('updated_qty');
//                $pending_eth_transaction = $pending_eth_transaction_buy + $pending_eth_transaction_sell;
//                $pending_xrp_transaction_buy = $pending_sell_transaction->where('type', 'Buy')->where('secondCurrency', 'XRP')->sum('total');
//                $pending_xrp_transaction_sell = $pending_sell_transaction->where('type', 'Sell')->where('firstCurrency', 'XRP')->sum('updated_qty');
//                $pending_xrp_transaction = $pending_xrp_transaction_buy + $pending_xrp_transaction_sell;
//                $pending_btc_transaction_buy = $pending_sell_transaction->where('type', 'Buy')->where('secondCurrency', 'BTC')->sum('total');
//                $pending_btc_transaction_sell = $pending_sell_transaction->where('type', 'Sell')->where('firstCurrency', 'BTC')->sum('updated_qty');
//                $pending_btc_transaction = $pending_btc_transaction_buy + $pending_btc_transaction_sell;
//                $pending_bch_transaction = $pending_sell_transaction->where('type', 'Buy')->where('pair', 'XDC-BCHABC')->sum('total');
//                $pending_bchsv_transaction = $pending_sell_transaction->where('type', 'Buy')->where('pair', 'XDC-BCHSV')->sum('total');
////                $pending_et_transaction = $pending_sell_transaction->where('type', 'Buy')->where('pair', 'XDC-ET')->sum('total');
//                $pending_usdt_transaction = $pending_sell_transaction->where('type', 'Buy')->where('pair', 'XDC-USDT')->sum('total');
//                $pending_usdc_transaction = $pending_sell_transaction->where('type', 'Buy')->where('pair', 'XDC-USDC')->sum('total');
//                $pending_xdc_transaction = $pending_sell_transaction->where('type', 'Sell')->where('firstCurrency', 'XDC')->sum('updated_qty');

//                $trade_eth = Profit::query()->where('theftCurrency', 'ETH')->sum('theftAmount');
//                $trade_btc = Profit::query()->where('theftCurrency', 'BTC')->sum('theftAmount');
//                $trade_bch = Profit::query()->where('theftCurrency', 'BCHABC')->sum('theftAmount');
//                $trade_bchsv = Profit::query()->where('theftCurrency', 'BCHSV')->sum('theftAmount');
//                $trade_xrp = Profit::query()->where('theftCurrency', 'XRP')->sum('theftAmount');
////                $trade_et = Profit::query()->where('theftCurrency', 'ET')->sum('theftAmount');
//                $trade_usdt = Profit::query()->where('theftCurrency', 'USDT')->sum('theftAmount');
//                $trade_usdc = Profit::query()->where('theftCurrency', 'USDC')->sum('theftAmount');
//                $trade_xdce = Profit::query()->where('theftCurrency', 'XDCE')->sum('theftAmount');

//                $res = $xrp_res->result;
//                $xrp_bal1 = 0;
//                if ($res == 'success') {
//                    $xrp_bal = $xrp_res->balances;
//                    $xrp_bal1 = $xrp_bal[0]->value;
//                }
//
//                $xrp_bal1 = check_ripple_balance();
//                $start_time = microtime(true);
//               $user_balance_result = Balance::all();
//                $end_time = microtime(true);
//                \Log::info(['Balance', __LINE__, ($start_time - $end_time), basename($_SERVER['PHP_SELF'])]);

                //for last 25 trade
                $trade_25 = Trade::orderBy('id', 'desc')->take(25)->get();

                $currencies = Currencies::all();

//                Session::put('xrpbalad', $xrp_bal1);
//                return view('panel.home', ['trade_25' => $trade_25, 'user_xdc' => $user_balance_result->sum('XDC'), 'user_usdt' => $user_balance_result->sum('USDT'), 'user_usdc' => $user_balance_result->sum('USDC'), 'user_eth' => $user_balance_result->sum('ETH'), 'user_btc' => $user_balance_result->sum('BTC'), 'user_bchabc' => $user_balance_result->sum('BCHABC'), 'user_bchsv' => $user_balance_result->sum('BCHSV'), 'user_xrp' => $user_balance_result->sum('XRP'), 'user_xdce' => $user_balance_result->sum('XDCE')]);
                return view('panel.home', ['trade_25' => $trade_25, 'currencies' => $currencies]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    //for trade admins view page
    function tradeadmin()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $date = new DateTime;
                $date->modify('-1440 minutes');
                $formatted_date = $date->format('Y-m-d H:i:s');

                $result = DB::table('tokenusers')
                    ->join('enjoyer', 'tokenusers.user_id', '=', 'enjoyer.id')
                    ->where('tokenusers.created_at', '>=', $formatted_date)
                    ->select('enjoyer.*', 'enjoyer.created_at')
                    ->paginate(25);
                return view('panel.trade_admin', ['result' => $result, 'status' => 1]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    //for viewing pending ico requests
    function ico_listing()
    {
        try {
            $get_ico = ico::where('status', '<>', 'Ended')->paginate(25);
            return view('panel.ico_lists', ['result' => $get_ico]);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for viewing a particular ico
    function ico_view(Request $request, $id)
    {
        try {
            if ($request->isMethod('post')) {
                $get_ico = ico::where('id', $id)->first();
                $status = $get_ico->status;
                if ($status == $request['status']) {
                    return redirect('prashaasak/ico_listing');
                } else {

                    $get_ico->status = $request['status'];
                    Session::flash('success', 'Successfully Updated');
                    $get_ico->save();
                    if ($request['update_status'] == 'on') {
                        $get_ico_details = icodetails::where('ico_id', $id)->first();
                        $get_ico_details->reason = $request['email_body'];

                        $to = $get_ico_details->email;

                        $subject = get_template('14', 'subject');
                        $message = get_template('14', 'template');
                        $mailarr = array(
                            '###CONTENT###' => $request['email_body'],
                            '##STATUS##' => $request['status'],
                            '###Name###' => get_config('site_name'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);
                    }
                    return redirect('prashaasak/ico_listing');
                }


            } else {
                $get_ico = ico::where('id', $id)->first();

                $get_ico_details = icodetails::where('ico_id', $id)->first();

                return view('panel.ico_view', ['result' => $get_ico, 'results' => $get_ico_details, 'id' => $id]);
            }
        } catch (\Exception $exception) {
            return $exception->getMessage() . '<br>' . $exception->getLine() . '<br>' . $exception->getFile();
        }
    }

    function profile(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $alpha_id = Session::get('alpha_id');
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'admin_email' => 'required|email',
                        'admin_username' => 'required',
                        //'admin_phone' => 'numeric',
                    ], [
                        'admin_email.required' => 'Email is required',
                        'admin_username.required' => 'Username is required',
                        //'admin_phone.required' => 'Phone number must numeric',
                    ]);
                    $upt = Admin::find($alpha_id);
                    if ($request['curr_pass'] != "") {
                        $this->validate($request, [
                            'curr_pass' => 'required',
                            'password' => 'required|confirmed|min:6',
                            'password_confirmation' => 'required|min:6',
                        ]);

                        if (Hash::check($request['curr_pass'], get_adminprofile('XDC_password'))) {
                            $upt->XDC_password = bcrypt($request['password']);
                        } else {
                            Session::flash('error', 'Current password is wrong');
                            return redirect('prashaasak/profile');
                        }

                    }

                    $upt->XDC_username = $request['admin_username'];
                    $upt->email_id = $request['admin_email'];

                    $upt->country = $request['admin_country'];
                    if ($upt->save()) {
                        Session::flash('success', 'Successfully Updated');
                        return redirect('prashaasak/profile');
                    }
                }
                return view('panel.profile');
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function site_settings(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'site_name' => 'required',
                        'contact_mail' => 'required',
                        'country' => 'required',
                        'address' => 'required',
                        'facebook_url' => 'url',
                        'twitter_url' => 'url',
                        'google_url' => 'url',
                        'linkedin_url' => 'url',
                        'contact_no' => 'numeric',
                    ]);
                    $upt = SiteSettings::find(1);
                    if ($request->hasFile('site_logo')) {
                        $this->validate($request, [
                            'site_logo' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
                        ]);
                        $logo = time() . '.' . $request->site_logo->getClientOriginalExtension();
                        $request->site_logo->move(public_path('uploads/logo'), $logo);
                        $upt->site_logo = $logo;
                    }

                    $upt->site_name = $request['site_name'];
                    $upt->facebook_url = $request['facebook_url'];
                    $upt->twitter_url = $request['twitter_url'];
                    $upt->google_url = $request['google_url'];
                    $upt->linkedin_url = $request['linkedin_url'];
                    $upt->google_analytics = $request['google_analytics'];
                    $upt->smtp_host = encrypt($request['smtp_host']);
                    $upt->smtp_port = encrypt($request['smtp_port']);
                    $upt->smtp_email = encrypt($request['smtp_email']);
                    $upt->smtp_password = encrypt($request['smtp_password']);
                    $upt->contact_mail = $request['contact_mail'];
                    $upt->address = $request['address'];
                    $upt->city = $request['city'];
                    $upt->provience = $request['provience'];
                    $upt->country = $request['country'];
                    $upt->contact_no = $request['contact_no'];
                    if ($upt->save()) {
                        Session::flash('success', 'Successfully Updated');
                        return redirect('prashaasak/site_settings');
                    }

                }
                return view('panel.site_settings');
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function checkpattern(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $key1 = $request['key1'];
                $key2 = $request['key2'];
                $pattern = $key2 - $key1;
                $sitepat = get_superadmin('pattern');
                $original = decrypt($sitepat);
                if ($original == $pattern) {
                    echo $original;
                } else {
                    echo "12345";
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function change_pattern()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                return view('panel.change_pattern');
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function set_pattern(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $key = $request['key'];
                $set = Admin::find(1);
                $set->pattern = encrypt($key);
                $set->save();
                Session::flash('success', 'Pattern changed Successfully');
                echo "true";
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function cms()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = DB::table('cms')->orderBy('id', 'desc')->get();
                return view('panel.cms', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function updatecms(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {

                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'heading' => 'required',
                        'content' => 'required',
                    ]);
                    $upt = Cms::find($id);
                    $upt->heading = $request['heading'];
                    $upt->content = $request['content'];
                    if ($upt->update()) {
                        Session::flash('success', 'Successfully updated');
                        return redirect('prashaasak/cms');
                    }
                }
                $result = DB::table('cms')->where('id', $id)->first();
                return view('panel.updatecms', ['result' => $result, 'id' => $id]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //validate_eth_block
    function validate_eth_block()
    {
        try {
            $balance = getting_eth_block();

            return view('panel.ether_block', ['Current' => $balance->currentBlock, 'Highest' => $balance->highestBlock]);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function users(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {

                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $search = $request['search'];
                    $email = $request['email'];
                    $status = $request['status'];
                    $paging = $request['paging'];
                    $q = Users::query();
                    if ($min) {
                        $q->where('created_at', '>=', $min);
                    }
                    if ($max) {
                        $q->where('created_at', '<=', $max);
                    }
                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('id', 'like', '%' . $search . '%')->Orwhere('enjoyer_name', 'like', '%' . $search . '%')->orWhere('mobile_no', '=', ownencrypt($search));
                        });
                    }
                    if ($email) {
                        $spl = explode("@", $email);
                        $user1 = $spl[0];
                        $user2 = $spl[1];
                        $record = getByEmail($user1, $user2);

                        foreach ($record as $val) {
                            $user_id = $val->id;
                            $q->where('id', $user_id);
                        }
                    }
                    if ($status != '' && $status != 'all') {
                        $q->where('user_verified', $status);
                    }

                    $result = $q->orderBy('id', 'desc')->paginate($paging);
                } else {
                    $result = Users::orderBy('id', 'desc')->paginate(25);
                }

                return view('panel.users', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function userbalance(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request['currency']) {
                    $result = DB::table('userbalance')
                        ->join('enjoyer', 'userbalance.user_id', '=', 'enjoyer.id')
                        ->orderBy('userbalance.' . $request['currency'], 'desc')
                        ->select('userbalance.*', 'enjoyer.id', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.BCHSV_addr')
                        ->paginate(25);
                } elseif ($request->isMethod('get')) {

                    $search = $request['search'];
                    $email = $request['email'];
                    $user_search_id = $request['user_search_id'];
                    $q = UserBalance::query();
                    $q->join('enjoyer', 'userbalance.user_id', '=', 'enjoyer.id')->select('userbalance.*', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.BCHSV_addr');

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }
                    if ($email) {
                        $spl = explode("@", $email);
                        $user1 = $spl[0];
                        $user2 = $spl[1];
                        $record = getByEmail($user1, $user2);

                        foreach ($record as $val) {
                            $user_id = $val->id;
                            $q->where('userbalance.user_id', $user_id);
                        }
                    }
                    if ($user_search_id) {
                        $q->where('userbalance.user_id', $user_search_id);
                    }

                    $result = $q->orderBy('userbalance.user_id', 'asc')->paginate(25);
                } else {
                    $result = DB::table('userbalance')
                        ->join('enjoyer', 'userbalance.user_id', '=', 'enjoyer.id')
                        ->orderBy('userbalance.user_id', 'asc')
                        ->select('userbalance.*', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.BCHSV_addr')
                        ->paginate(25);
                }

                return view('panel.userbalance', ['result' => $result, 'Header' => 'User Wallet Balance']);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function update_userbal(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = UserBalance::where('user_id', $request['user_id'])->first();
                $xdc = $result->XDC;
                $btc = $result->BTC;
                $bchabc = $result->BCHABC;
                $xrp = $result->XRP;
                $eth = $result->ETH;
                $xdce = $result->XDCE;
                $usdc = $result->USDC;
                $usdt = $result->USDT;
                $bchsv = $result->BCHSV;

                if ($request['currency']) {
                    $result->XDC = $request['amount'];
                    if ($result->update()) {
                        $transid = 'TXD' . $request['user_id'] . time();
                        $today = date('Y-m-d H:i:s');
                        $ip = \Request::ip();
                        $ins = new Transaction;
                        $ins->user_id = $request['user_id'];
                        $ins->payment_method = 'Cryptocurrency Account';
                        $ins->transaction_id = $transid;
                        $ins->currency_name = 'XDC';
                        $ins->type = 'Updated';
                        $ins->transaction_type = '1';
                        $ins->amount = $request['amount'];
                        $ins->updated_at = $today;
                        $ins->crypto_address = 'By Admin';
                        $ins->transfer_amount = '0';
                        $ins->fee = '0';
                        $ins->tax = '0';
                        $ins->verifycode = '1';
                        $ins->order_id = '0';
                        $ins->status = 'Completed';
                        $ins->cointype = '2';
                        $ins->payment_status = 'Paid';
                        $ins->paid_amount = '0';
                        $ins->wallet_txid = '';
                        $ins->ip_address = $ip;
                        $ins->verify = '1';
                        $ins->blocknumber = '';
                        $ins->save();

                    }
                } else {
                    $result->BTC = $request['btc'];
                    $result->BCHABC = $request['bchabc'];
                    $result->BCHSV = $request['bchsv'];
                    $result->XDC = $request['xdc'];
                    $result->XRP = $request['xrp'];
                    $result->ETH = $request['eth'];
                    $result->XDCE = $request['xdce'];
                    $result->USDC = $request['usdc'];
                    $result->USDT = $request['usdt'];
                    if ($result->update()) {
                        $transid = 'TXD' . $request['user_id'] . time();
                        $today = date('Y-m-d H:i:s');
                        $ip = \Request::ip();


                        if ($xdc != $request['xdc']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';


                            $ins->currency_name = 'XDC';
                            $ins->amount = $request['xdc'];
                            $ins->save();
                        }
                        if ($xdce != $request['xdce']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'XDCE';
                            $ins->amount = $request['xdce'];
                            $ins->save();
                        }
                        if ($btc != $request['btc']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'BTC';
                            $ins->amount = $request['btc'];
                            $ins->save();
                        }
                        if ($bchabc != $request['bchabc']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'BCHABC';
                            $ins->amount = $request['bchabc'];
                            $ins->save();
                        }
                        if ($bchsv != $request['bchsv']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'BCHSV';
                            $ins->amount = $request['bchsv'];
                            $ins->save();
                        }
                        if ($eth != $request['eth']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'ETH';
                            $ins->amount = $request['eth'];
                            $ins->save();
                        }
                        if ($xrp != $request['xrp']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'XRP';
                            $ins->amount = $request['xrp'];
                            $ins->save();
                        }
                        if ($usdc != $request['usdc']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'USDC';
                            $ins->amount = $request['usdc'];
                            $ins->save();
                        }
                        if ($usdt != $request['usdt']) {
                            $ins = new Transaction;
                            $ins->user_id = $request['user_id'];
                            $ins->payment_method = 'Cryptocurrency Account';
                            $ins->transaction_id = $transid;

                            $ins->type = 'Updated';
                            $ins->transaction_type = '1';

                            $ins->updated_at = $today;
                            $ins->crypto_address = 'By Admin';
                            $ins->transfer_amount = '0';
                            $ins->fee = '0';
                            $ins->tax = '0';
                            $ins->verifycode = '1';
                            $ins->order_id = '0';
                            $ins->status = 'Completed';
                            $ins->cointype = '2';
                            $ins->payment_status = 'Paid';
                            $ins->paid_amount = '0';
                            $ins->wallet_txid = '';
                            $ins->ip_address = $ip;
                            $ins->verify = '1';
                            $ins->blocknumber = '';

                            $ins->currency_name = 'USDT';
                            $ins->amount = $request['usdt'];
                            $ins->save();
                        }

                    }
                }


                Session::flash('success', $request['user_name'] . ' balance updated');
                if ($request['currency']) {
                    return redirect('prashaasak/users_balance_validation?currency=' . $request['currency']);
                } else {
                    return redirect('prashaasak/userbalance');
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function updated_history(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $currency = $request['currency'];
                    $search = $request['search'];
                    $q = Transaction::query();
                    $q->select(DB::raw('XDC_enjoyer.enjoyer_name,XDC_transactions.*'));
                    $q->join('enjoyer', 'transactions.user_id', '=', 'enjoyer.id');
                    if ($currency == 'all' || $currency == '') {
                        $currency = get_all_currencies();
                    } else {
                        $currency = [$currency];
                    }
                    $q->where('type', 'Updated');
                    $q->whereIn('currency_name', $currency);
                    if ($min) {
                        $q->where('updated_at', '>=', $min);
                    }

                    if ($max) {
                        $q->where('updated_at', '<=', $max);
                    }

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('transactions.transaction_id', 'like', '%' . $search . '%')->Orwhere('transactions.user_id', 'like', '%' . $search . '%')->Orwhere('transactions.amount', 'like', '%' . $search . '%')->Orwhere('enjoyer.enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->orderBy('transactions.id', 'desc')->paginate(25);
                } else {
                    $result = Transaction::where('type', 'Deposit')->where('status', 'Completed')->orderBy('id', 'desc')->paginate(25);
                }

                $currencies = Currencies::all();
                return view('panel.transactions', ['result' => $result, 'currencies' => $currencies]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for userbalance tally
    function getTotal_Usersbalance()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $adminxdcaddr = decrypt(get_config('xdc_address'));
                $xdc_bal = get_livexdc_bal($adminxdcaddr);

                $adminetaddr = decrypt(get_config('et_address'));
                $et_bal = get_liveet_bal($adminetaddr);

                $adminxdceaddr = decrypt(get_config('xdce_address'));
                $xdce_bal = get_livexdce_bal($adminxdceaddr);

                $adminethaddr = decrypt(get_config('eth_address'));
                $eth_bal = getting_eth_balance($adminethaddr);

                $adminxrpaddr = decrypt(get_config('xrp_address'));
                $xrp_res = get_xrp_balance($adminxrpaddr);

                $res = @$xrp_res->result;

                $adminbtcaddr = decrypt(get_config('btc_address'));
                $btc_bal = get_btc_wallet_info($adminbtcaddr);
                $btc_bal1 = $btc_bal['balance'];

                $adminbchaddr = decrypt(get_config('bch_address'));
                $bch_bal = get_bch_wallet_info($adminbchaddr);
                $bch_bal1 = $bch_bal['balance'];

                $result = DB::table('userbalance')->get();
                $result_array = array("ETH" => $result->sum('ETH'), "Admin_ETH" => $eth_bal, "BTC" => $result->sum('BTC'), "BCH" => $result->sum('BCH'), "Admin_BTC" => $btc_bal1, "Admin_BCH" => $bch_bal1, "XRP" => $result->sum('XRP'), "Admin_XRP" => $res, "XDC" => $result->sum('XDC'), "Admin_XDC" => $xdc_bal, "ET" => $result->sum('ET'), "Admin_ET" => $et_bal, "XDCE" => $result->sum('XDCE'), "Admin_XDCE" => $xdce_bal);
                echo json_encode($result_array);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function faq()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Faq::orderBy('id', 'desc')->get();
                return view('panel.faq', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function confirm()
    {
        try {
            $result = Faq::orderBy('id', 'desc')->get();
            $flag = $this->ftp();
            switch ($flag) {
                case '1' :
                    Session::flash('success', 'FAQ updated.');
                    break;
                case '2' :
                    Session::flash('error', 'FAQ updated.');
                    break;
                case '3' :
                    Session::flash('error', 'There was an error in updating the FAQ.');
                    break;
                case '4' :
                    Session::flash('error', 'Failed to establish the connection.');
                    break;
                case '5' :
                    Session::flash('error', 'No such file found.');
                    break;
            }
            return view('panel.faq', ['result' => $result]);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function ftp()
    {
        try {
            $ftp_server = decrypt(get_config('ftp_server'));
            $ftp_username = decrypt(get_config('ftp_username'));
            $ftp_userpass = decrypt(get_config('ftp_password'));
            $ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");

            if (@ftp_login($ftp_conn, $ftp_username, $ftp_userpass)) {
                ftp_pasv($ftp_conn, true);
                $path = "./";
                $path1 = "./keystore";
                $file = decrypt(get_config('file_name'));
                $file_list = ftp_nlist($ftp_conn, $path);
                $file_list1 = ftp_nlist($ftp_conn, $path1);
                if (in_array($file, $file_list)) {
                    $old_path = "./" . $file;
                    $new_path = "./keystore/" . $file;
                    if (ftp_rename($ftp_conn, $old_path, $new_path)) {
//                    MoveKey::dispatch(new MoveKey())->delay(Carbon::now()->addMinutes(1));
                        return 1;
                    } else {
                        return 3;
                    }
                } else if (in_array($file, $file_list1)) {
                    $old_path = "./keystore/" . $file;
                    $new_path = "./" . $file;
                    if (ftp_rename($ftp_conn, $old_path, $new_path)) {
                        return 2;
                    } else {
                        return 3;
                    }
                } else {
                    return 5;
                }
            } else {
                return 4;
            }
            // close connection
            ftp_close($ftp_conn);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function add_faq(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'question' => 'required',
                        'description' => 'required',
                    ]);

                    $ins = new Faq();
                    $ins->question = $request['question'];
                    $ins->description = $request['description'];
                    $ins->status = 1;
                    $ins->created_at = date('Y-m-d H:i:s');
                    if ($ins->save()) {
                        Session::flash('success', 'FAQ Successfully added');
                        return redirect('prashaasak/faq');
                    }
                }
                return view('panel.add_faq', ['view' => 'add']);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function delete_faq($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $del = Faq::find($id);
                if ($del->delete()) {
                    Session::flash('success', 'FAQ Successfully deleted');
                    return redirect('prashaasak/faq');
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function status_faq($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $upt = Faq::find($id);
                if ($upt->status == 1) {
                    $upt->status = '0';
                } else {
                    $upt->status = '1';
                }
                if ($upt->save()) {
                    Session::flash('success', 'FAQ Successfully updated');
                    return redirect('prashaasak/faq');
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function update_faq(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'question' => 'required',
                        'description' => 'required',
                    ]);

                    $ins = Faq::find($id);
                    $ins->question = $request['question'];
                    $ins->description = $request['description'];
                    if ($ins->save()) {
                        Session::flash('success', 'FAQ Successfully updated');
                        return redirect('prashaasak/faq');
                    }
                }
                $result = Faq::where('id', $id)->first();
                return view('panel.add_faq', ['result' => $result, 'view' => 'edit', 'id' => $id]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function mail_template()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Template::orderBy('id', 'desc')->get();
                return view('panel.mail_template', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function update_template(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'subject' => 'required',
                        'template' => 'required',
                    ]);
                    $upt = Template::find($id);
                    $upt->subject = $request['subject'];
                    $upt->template = $request['template'];
                    if ($upt->save()) {
                        Session::flash('success', 'Template Successfully updated');
                        return redirect('prashaasak/mail_template');
                    }
                }
                $result = Template::where('id', $id)->first();
                return view('panel.update_template', ['result' => $result, 'id' => $id]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function contact_query()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Enquiry::orderBy('enquiry_id', 'desc')->get();
                return view('panel.contact_query', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function transactions(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request['min']) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $result = Transaction::where('updated_at', '>=', $min)
                        ->where('updated_at', '<=', $max)->where('type', '=', 'Buy')->orWhere('type', '=', 'Sell')->orderBy('id', 'desc')->paginate(25);
                } else {
                    $result = Transaction::where('type', '=', 'Buy')->orWhere('type', '=', 'Sell')->orderBy('id', 'desc')->paginate(25);
                }

                return view('panel.transactions', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function profit(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request['min']) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $result = DB::table('coin_theft')
                        ->where('theftAmount', '>', 0)
                        ->where('updated_at', '>=', $min)
                        ->where('updated_at', '<=', $max)
                        ->orderBy('id', 'desc')->paginate(25);
                } else {
                    $result = DB::table('coin_theft')->where('theftAmount', '>', 0)->orderBy('id', 'desc')->paginate(25);
                }

                return view('panel.profit', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function kyc_users(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request['min']) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $result = Verification::orderBy('verification.updated_at', 'desc')
                        ->join('enjoyer', 'verification.user_id', '=', 'enjoyer.id')
                        ->select('verification.*', 'enjoyer.enjoyer_name', 'enjoyer.document_status')
                        ->where('verification.updated_at', '>=', $min)
                        ->where('verification.updated_at', '<=', $max)
                        ->get();
                } elseif ($request['status']) {
                    $status = $request['status'];
                    if ($status == '' || $status == 'all') {
                        $status = [0, 1, 2, 3];
                    } else {
                        $status = [$status];
                    }
                    $result = Verification::orderBy('verification.updated_at', 'desc')
                        ->join('enjoyer', 'verification.user_id', '=', 'enjoyer.id')
                        ->select('verification.*', 'enjoyer.enjoyer_name', 'enjoyer.document_status')
                        ->whereIn('enjoyer.document_status', $status)
                        ->get();
                } else {
                    $result = Verification::orderBy('verification.updated_at', 'desc')
                        ->join('enjoyer', 'verification.user_id', '=', 'enjoyer.id')
                        ->select('verification.*', 'enjoyer.enjoyer_name', 'enjoyer.document_status')
                        ->get();
                }

                return view('panel.kyc_users', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function view_enquiry(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Enquiry::where('enquiry_id', $id)->first();
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'answer' => 'required',
                    ]);
                    $ins = ['answer' => $request['answer'], 'enquiry_id' => $id];
                    DB::table('enquiry_reply')->insert($ins);
                    $upt = Enquiry::where('enquiry_id', $id)->update(['status' => 'replied']);
                    $to = [$result->enquiry_email];
                    $subject = get_template('1', 'subject');
                    $message = get_template('1', 'template');
                    $mailarr = array(
                        '###USERNAME###' => $result->enquiry_name,
                        '###QUESTION###' => $result->enquiry_message,
                        '###CONTENT###' => $request['answer'],
                        '###SITENAME###' => get_config('site_name'),
                    );
                    $message = strtr($message, $mailarr);
                    $subject = strtr($subject, $mailarr);
                    sendmail($to, $subject, ['content' => $message]);
                    Session::flash('success', 'Successfully replied');
                    return redirect('prashaasak/contact_query');
                }

                $result_rply = DB::table('enquiry_reply')->where('enquiry_id', $id)->get();
                return view('panel.view_enquiry', ['result' => $result, 'result_rply' => $result_rply, 'id' => $id]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function status_users($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $upt = Users::find($id);
                if ($upt->status == 1) {
                    $upt->status = 0;
                } else {
                    $upt->status = 1;
                }
                if ($upt->save()) {
                    Session::flash('success', 'Successfully status updated');
                    return redirect()->back();
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function view_users($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
//                $check = check_live_address($id);
                $result = Users::where('id', $id)->first();
                $ether_value = verifyEther($result->ETH_addr);
                $xrp_value = verifyRipple($result->XRP_addr);
                $btc_value = verifyBTC($result->BTC_addr);
                $bchabc_value = verifyBCH($result->BCHABC_addr);
                $bchsv_value = verifyBCH($result->BCHSV_addr);
                $xdc_value = verifyXDC($result->XDC_addr);
                $xdce_value = get_xdceDeposit_user($result->XDCE_addr);
                $et_value = verifyET($result->ET_addr);

//                echo $ether_value;
                if (Session::get('role') == 2) {
                    return view('panel.view_users_tradeadmin', ['result' => $result, 'id' => $id, 'BTC_Bal' => $btc_value, 'BCHABC_Bal' => $bchabc_value, 'ETH_Bal' => $ether_value, 'XRP_Bal' => $xrp_value, 'XDC_Bal' => $xdc_value, 'XDCE_Bal' => $xdce_value, 'ET_Bal' => $et_value, 'BCHSV_Bal' => $bchsv_value]);
                }
                return view('panel.view_users', ['result' => $result, 'id' => $id, 'BTC_Bal' => $btc_value, 'BCHABC_Bal' => $bchabc_value, 'ETH_Bal' => $ether_value, 'XRP_Bal' => $xrp_value, 'XDC_Bal' => $xdc_value, 'XDCE_Bal' => $xdce_value, 'ET_Bal' => $et_value, 'BCHSV_Bal' => $bchsv_value]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function view_kyc(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Verification::where('verification.id', $id)
                    ->join('enjoyer', 'verification.user_id', '=', 'enjoyer.id')
                    ->select('verification.*', 'enjoyer.enjoyer_name', 'enjoyer.document_status', 'enjoyer.status', 'enjoyer.mob_isd', 'enjoyer.mobile_no')
                    ->first();

                if ($request->isMethod('post')) {
                    $status = $request['kycstatus'];
                    $upt = Verification::find($id);
                    $upt->proof1_status = ($request['proof1_status'] == 'on') ? '1' : '0';
                    $upt->proof2_status = ($request['proof2_status'] == 'on') ? '1' : '0';
                    $upt->proof3_status = ($request['proof3_status'] == 'on') ? '1' : '0';
                    $upt->reason = ($status == 1) ? '' : $request['kycreason'];
                    $upt->save();

                    $upt1 = Users::find($result->user_id);
                    $upt1->document_status = $status;
                    $upt1->save();

                    if ($status == 1) {
                        $statusmessage = "Approved";
                    } else if ($status == 2) {
                        $statusmessage = "Rejected";
                    } else if ($status == 0) {

                        $statusmessage = "Pending";
                    } else {
                        $statusmessage = "Submitted";
                    }

                    $to = [get_usermail($result->user_id)];
                    $subject = get_template('2', 'subject');
                    $message = get_template('2', 'template');
                    $mailarr = array(
                        '###USERNAME###' => $result->enjoyer_name,
                        '###STATUS###' => $statusmessage,
                        '###REASON###' => ($status == 1) ? '' : $request['kycreason'],
                        '###SITENAME###' => get_config('site_name'),
                    );
                    $message = strtr($message, $mailarr);
                    $subject = strtr($subject, $mailarr);
                    sendmail($to, $subject, ['content' => $message]);

//                    $referrer = ReferralEarning::where('referrer_id', $result->user_id)->get();
//                    $referred = ReferralEarning::where('referred_id', $result->user_id)->get();
//
//                    if (isset($referred)) {
//                        foreach ($referred as $val) {
//                            if ($val->referred_status != 1) {
//                                if (get_user_details($val->referred_id, 'document_status') == 1) {
//                                    $referred_bal = get_userbalance($val->referred_id, $val->currency);
//                                    $referred_bal = $referred_bal + $val->referred_bonus;
//                                    $status = update_user_balance($val->referred_id, $val->currency, $referred_bal);
//                                    if ($status == true) {
//                                        $val->referred_status = 1;
//                                        $val->save();
//                                    }
//                                }
//                            }
//                            if ($val->referrer_status != 1) {
//                                if (get_user_details($val->referrer_id, 'document_status') == 1) {
//                                    $referrer_bal = get_userbalance($val->referrer_id, $val->currency);
//                                    $referrer_bal = $referrer_bal + $val->referrer_bonus;
//                                    $status = update_user_balance($val->referrer_id, $val->currency, $referrer_bal);
//                                    if ($status == true) {
//                                        $val->referrer_status = 1;
//                                        $val->save();
//                                    }
//                                }
//                            }
//                        }
//                    }
//
//                    if (isset($referrer)) {
//                        foreach ($referrer as $val) {
//                            if ($val->referred_status != 1) {
//                                if (get_user_details($val->referred_id, 'document_status') == 1) {
//                                    $referred_bal = get_userbalance($val->referred_id, $val->currency);
//                                    $referred_bal = $referred_bal + $val->referred_bonus;
//                                    $status = update_user_balance($val->referred_id, $val->currency, $referred_bal);
//                                    if ($status == true) {
//                                        $val->referred_status = 1;
//                                        $val->save();
//                                    }
//                                }
//                            }
//                            if ($val->referrer_status != 1) {
//                                if (get_user_details($val->referrer_id, 'document_status') == 1) {
//                                    $referrer_bal = get_userbalance($val->referrer_id, $val->currency);
//                                    $referrer_bal = $referrer_bal + $val->referrer_bonus;
//                                    $status = update_user_balance($val->referrer_id, $val->currency, $referrer_bal);
//                                    if ($status == true) {
//                                        $val->referrer_status = 1;
//                                        $val->save();
//                                    }
//                                }
//                            }
//                        }
//                    }

                    Session::flash('success', 'KYC Status Successfully Updated');
                    return redirect('prashaasak/kyc_users');

                }

                return view('panel.view_kyc', ['result' => $result, 'id' => $id]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function forgot(Request $request)
    {
        try {
            if ($request->isMethod('post')) {
                $this->validate($request, [
                    'forgot_username' => 'required|email',
                ], [
                    'forgot_username.required' => 'Email id is required',
                    'forgot_username.email' => 'Enter valid email id']);
                $email = $request['forgot_username'];
                $result = Admin::where(['email_id' => $email, 'status' => 'active'])->first();
                if ($result) {
                    $rand = mt_rand(0, 999999);
                    $pass = bcrypt($rand);
                    $upt = Admin::find($result->id);
                    $upt->XDC_password = $pass;
                    $upt->save();

                    $to = [$email];
                    $subject = get_template('3', 'subject');
                    $message = get_template('3', 'template');
                    $mailarr = array(
                        '###EMAIL###' => $email,
                        '###PASS###' => $rand,
                        '###SITENAME###' => get_config('site_name'),
                    );
                    $message = strtr($message, $mailarr);
                    $subject = strtr($subject, $mailarr);
                    sendmail($to, $subject, ['content' => $message]);

                    Session::flash('success', 'We sent password into your email. Check your mail');
                    return redirect()->back();

                } else {
                    Session::flash('error', 'Email is wrong');
                    return redirect()->back();
                }
            }
            return view('panel.forgot');
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function trade_history(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $pair = "";
                $min = null;
                $max = null;
                $status = "";
                $search = null;

                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $status = $request['status'];
                    $pair = $request['pair'];
                    $search = $request['search'];
                    $q = Trade::query();
                    $q->select(DB::raw('XDC_enjoyer.enjoyer_name,XDC_trade_order.*'));
                    $q->join('enjoyer', 'trade_order.user_id', '=', 'enjoyer.id');
                    if ($status == 'all' || $status == "") {
                        $status = ['completed', 'partially', 'active', 'cancelled'];
                    } else {
                        $status = [$status];
                    }
                    $q->whereIn('trade_order.status', $status);
                    if ($pair == 'all' || $pair == "") {
                        $pair = get_all_pairs();
                    } else {
                        $pair = [$pair];
                    }
                    $q->whereIn('trade_order.pair', $pair);


                    if ($min) {
                        $q->where('trade_order.updated_at', '>=', $min);
                    }

                    if ($max) {
                        $q->where('trade_order.updated_at', '<=', $max);
                    }

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('trade_order.user_id', 'like', '%' . $search . '%')->Orwhere('trade_order.updated_qty', 'like', '%' . $search . '%')->Orwhere('trade_order.original_qty', 'like', '%' . $search . '%')->Orwhere('trade_order.price', 'like', '%' . $search . '%')->Orwhere('enjoyer.enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->orderBy('trade_order.updated_at', 'desc')->paginate(25)->appends(array('pair' => $request['pair'],
                        'status' => $request['status'], 'search' => $search
                    , 'min' => $min, 'max' => $max));
                } else {
                    $result = Trade::orderBy('id', 'desc')->paginate(25);
                }
                $pairs = Pair::all();
                return view('panel.trade_history', ['result' => $result, 'pairs' => $pairs]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function swap_history(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {

                $min = null;
                $max = null;
                $search = null;

                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $search = $request['search'];
                    $q = Trade::query();
                    $q->select(DB::raw('XDC_enjoyer.enjoyer_name,XDC_trade_order.*'));
                    $q->join('enjoyer', 'trade_order.user_id', '=', 'enjoyer.id');
                    $q->whereIn('trade_order.pair', ['XDC-XDCE']);
                    $q->whereIn('trade_order.status', ['completed']);

                    if ($min) {
                        $q->where('trade_order.updated_at', '>=', $min);
                    }

                    if ($max) {
                        $q->where('trade_order.updated_at', '<=', $max);
                    }

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('trade_order.user_id', 'like', '%' . $search . '%')->Orwhere('trade_order.original_qty', 'like', '%' . $search . '%')->Orwhere('trade_order.Price', 'like', '%' . $search . '%')->Orwhere('enjoyer.enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->orderBy('trade_order.id', 'desc')->paginate(25)->appends(array('pair' => 'XDC-XDCE',
                        'status' => 'completed', 'search' => $search
                    , 'min' => $min, 'max' => $max));
                } else {
                    $result = Trade::orderBy('id', 'desc')->paginate(25);
                }

                return view('panel.swap_history', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for ico history
    //ico history
    function ico_history(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {

                $min = null;
                $max = null;
                $search = null;
                $status = null;

                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $search = $request['search'];
                    $status = $request['status'];
                    $q = ICOTrade::query();
                    $q->select(DB::raw('XDC_enjoyer.enjoyer_name,XDC_ico_buy_trade.*'));
                    $q->join('enjoyer', 'ico_buy_trade.user_id', '=', 'enjoyer.id');


                    if ($min) {
                        $q->where('ico_buy_trade.updated_at', '>=', $min);
                    }

                    if ($max) {
                        $q->where('ico_buy_trade.updated_at', '<=', $max);
                    }

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('ico_buy_trade.user_id', 'like', '%' . $search . '%')->Orwhere('ico_buy_trade.Total', 'like', '%' . $search . '%')->Orwhere('enjoyer.enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }
                    if ($status != null && $status != 'all') {
                        $q->where('ico_buy_trade.Status', $status);
                    }

                    $result = $q->orderBy('ico_buy_trade.id', 'desc')->paginate(25)->appends(array(
                        'status' => $status, 'search' => $search
                    , 'min' => $min, 'max' => $max));
                }

                //for ico rates
                $ico_rates = ICORate::all();
                foreach ($ico_rates as $ico_rate) {
                    if ($ico_rate->SecondCurrency == 'BTC') {
                        $btc_price = $ico_rate->Amount;

                    } elseif ($ico_rate->SecondCurrency == 'BCH') {
                        $bch_price = $ico_rate->Amount;

                    } elseif ($ico_rate->SecondCurrency == 'ETH') {

                        $eth_price = $ico_rate->Amount;
                    } elseif ($ico_rate->SecondCurrency == 'XRP') {

                        $xrp_price = $ico_rate->Amount;
                    }
                }

                //for ico stats
                $ico_eth = ICOTrade::where('SecondCurrency', 'ETH')->where('Status', 'Completed')->sum('Amount');
                $eth_usd = get_estusd_price('ETH', $ico_eth);

                $ico_btc = ICOTrade::where('SecondCurrency', 'BTC')->where('Status', 'Completed')->sum('Amount');
                $btc_usd = get_estusd_price('BTC', $ico_btc);

                $ico_bch = ICOTrade::where('SecondCurrency', 'BCH')->where('Status', 'Completed')->sum('Amount');
                $bch_usd = get_estusd_price('BCH', $ico_bch);

                $ico_xrp = ICOTrade::where('SecondCurrency', 'XRP')->where('Status', 'Completed')->sum('Amount');
                $xrp_usd = get_estusd_price('XRP', $ico_xrp);

                $ico_total = ICOTrade::where('Status', 'Completed')->sum('Total');
                $ico_usd_total = $eth_usd + $btc_usd + $bch_usd + $xrp_usd;


                $price = array('BTC' => $btc_price, 'BCH' => $bch_price, 'ETH' => $eth_price, 'XRP' => $xrp_price);

                $stats = array('Total' => $ico_total, 'USD' => $ico_usd_total, 'BTC' => $ico_btc, 'BTC' => $ico_btc, 'BCH' => $ico_bch, 'ETH' => $ico_eth, 'XRP' => $ico_xrp);

                return view('panel.ico_history', ['result' => $result, 'price' => $price, 'stats' => $stats]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function Cancel_pending_ico_order($id)
    {
        try {
            $trade = ICOTrade::where('id', $id)->first();

            $amount = $trade->Amount;
            $trade->Status = 'Cancelled';
            $user_id = $trade->user_id;
            $currency = $trade->SecondCurrency;
            $get_user_bal = get_userbalance($user_id, $currency);

            $amount = $amount + $get_user_bal;

            //update Userbalance
            $val = update_user_balance($user_id, $currency, $amount);

            if ($val == true) {
                $trade->save();
                Session::flash('Success', 'Your order is been cancelled');

                return redirect('prashaasak/ico_history');
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for pending trade history  in admin panel
    function pending_history(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $pair = "";
                $min = null;
                $max = null;
                $status = "";
                $search = null;
                $type = "";

                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $status = $request['status'];
                    $pair = $request['pair'];
                    $search = $request['search'];
                    $type = $request['type'];
                    $q = Trade::query();
                    $q->select(DB::raw('XDC_enjoyer.enjoyer_name,XDC_trade_order.*'));
                    $q->join('enjoyer', 'trade_order.user_id', '=', 'enjoyer.id');
                    if ($status == 'all' || $status == "") {
                        if (Session::get('role') == 2) {
                            $status = ['partially', 'active', 'completed', 'cancelled'];
                        } else {
                            $status = ['partially', 'active'];
                        }

                    } else {
                        $status = [$status];
                    }
                    if ($type == 'all' || $type == "") {
                        $type = ['Buy', 'Sell'];
                    } else {
                        $type = [$type];
                    }
                    if ($pair == 'all' || $pair == "") {
                        $pair = get_all_pairs();
                    } else {
                        $pair = [$pair];
                    }

                    $q->whereIn('trade_order.pair', $pair);
                    $q->whereIn('trade_order.status', $status);
                    $q->whereIn('trade_order.type', $type);

                    if ($min) {
                        $q->where('trade_order.updated_at', '>=', $min);
                    }

                    if ($max) {
                        $q->where('trade_order.updated_at', '<=', $max);
                    }

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('trade_order.user_id', 'like', '%' . $search . '%')->Orwhere('trade_order.updated_qty', 'like', '%' . $search . '%')->Orwhere('trade_order.price', 'like', '%' . $search . '%')->Orwhere('enjoyer.enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }

                    if (Session::get('role') == 2) {
                        $result = $q->orderBy('trade_order.id', 'desc')->limit(100)->paginate(25)->appends(array('pair' => $request['pair'],
                            'status' => $request['status'], 'search' => $search
                        , 'min' => $min, 'max' => $max));
                    } else {
                        $result = $q->orderBy('trade_order.id', 'desc')->limit(100)->paginate(25)->appends(array('pair' => $request['pair'],
                            'status' => $request['status'], 'search' => $search
                        , 'min' => $min, 'max' => $max));
                    }

                } else {
                    if (Session::get('role') == 2) {
                        $result = Trade::orderBy('id', 'desc')->limit(100)->paginate(25);
                    } else {
                        $result = Trade::orderBy('id', 'desc')->limit(100)->paginate(25);
                    }
                }

                if (Session::get('role') == 2) {
                    return view('panel.trade_admin', ['result' => $result, 'status' => 2]);
                }
                $pairs = Pair::all();
                return view('panel.pending_trade', ['result' => $result, 'pairs' => $pairs]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function deposit_history(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $currency = $request['currency'];
                    $search = $request['search'];
                    $status = $request['status'];
                    $q = Transaction::query();
                    $q->select(DB::raw('XDC_enjoyer.enjoyer_name,XDC_transactions.*'));
                    $q->join('enjoyer', 'transactions.user_id', '=', 'enjoyer.id');
                    if ($currency == 'all' || $currency == '') {
                        $currency = get_all_currencies();
                    } else {
                        $currency = [$currency];
                    }
                    if ($status == 'all' || $status == "") {
                        $status = ['completed', 'partially', 'active', 'cancelled'];
                    } else {
                        $status = [$status];
                    }
                    $q->where('type', 'Deposit');
                    $q->whereIn('currency_name', $currency);
                    $q->whereIn('transactions.status', $status);
                    if ($min) {
                        $q->where('transactions.updated_at', '>=', $min);
                    }

                    if ($max) {
                        $q->where('transactions.updated_at', '<=', $max);
                    }

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('transactions.transaction_id', 'like', '%' . $search . '%')->Orwhere('transactions.user_id', 'like', '%' . $search . '%')->Orwhere('transactions.amount', 'like', '%' . $search . '%')->Orwhere('enjoyer.enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->orderBy('transactions.id', 'desc')->paginate(25);
                } else {
                    $result = Transaction::where('type', 'Deposit')->where('status', 'Completed')->orderBy('id', 'desc')->paginate(25);
                }

                $currencies = Currencies::all();
                return view('panel.transactions', ['result' => $result, 'currencies' => $currencies]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function withdraw_history(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $currency = $request['currency'];
                    $status = $request['status'];
                    $search = $request['search'];
                    $q = Transaction::query();
                    $q->select(DB::raw('XDC_enjoyer.enjoyer_name,XDC_transactions.*'));
                    $q->join('enjoyer', 'transactions.user_id', '=', 'enjoyer.id');

                    if ($status == 'all' || $status == '') {
                        $status = ['Pending', 'Completed', 'Processing', 'Cancelled'];
                    } else {
                        $status = [$status];
                    }
                    $q->where('type', 'Withdraw');
                    $q->whereIn('transactions.status', $status);
                    if ($currency == 'all' || $currency == '') {
                        $currency = get_all_currencies();
                    } else {
                        $currency = [$currency];
                    }

                    $q->whereIn('currency_name', $currency);
                    if ($min) {
                        $q->where('transactions.updated_at', '>=', $min);
                    }

                    if ($max) {
                        $q->where('transactions.updated_at', '<=', $max);
                    }

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('transactions.transaction_id', 'like', '%' . $search . '%')->Orwhere('transactions.user_id', 'like', '%' . $search . '%')->Orwhere('transactions.amount', 'like', '%' . $search . '%')->Orwhere('enjoyer.enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->orderBy('transactions.id', 'desc')->paginate(25);
                } else {
                    $result = Transaction::where('type', 'Withdraw')->orderBy('id', 'desc')->paginate(25);
                }

                $currencies = Currencies::all();
                return view('panel.transactions', ['result' => $result, 'currencies' => $currencies]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function market_price(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'xdc_btc' => 'required',
                        'xdc_bch' => 'required',
                        'xdc_eth' => 'required',
                        'xdc_xrp' => 'required',
                        'xdc_usd' => 'required',
//                        'xdc_et' => 'required',
                        'xdc_usdt' => 'required',
                    ]);
                    $upt = Marketprice::find('4');
                    $upt->BTC = $request['xdc_btc'];
                    $upt->BCHABC = $request['xdc_bchabc'];
                    $upt->BCHSV = $request['xdc_bchsv'];
                    $upt->ETH = $request['xdc_eth'];
                    $upt->XRP = $request['xdc_xrp'];
                    $upt->USD = $request['xdc_usd'];
                    $upt->USDT = $request['xdc_usdt'];
//                    $upt->ET = $request['xdc_et'];
                    if ($upt->save()) {
                        $btc = (1 / $request['xdc_btc']);
                        $bchabc = (1 / $request['xdc_bchabc']);
                        $bchsv = (1 / $request['xdc_bchsv']);
                        $eth = (1 / $request['xdc_eth']);
                        $xrp = (1 / $request['xdc_xrp']);
                        $et = (1 / $request['xdc_et']);
                        $usdt = (1 / $request['xdc_usdt']);
                        Marketprice::where('id', '1')->update(['XDC' => (double)$btc]);
                        Marketprice::where('id', '5')->update(['XDC' => (double)$bchabc]);
                        Marketprice::where('id', '7')->update(['XDC' => (double)$bchsv]);
                        Marketprice::where('id', '2')->update(['XDC' => (double)$eth]);
                        Marketprice::where('id', '3')->update(['XDC' => (double)$xrp]);
                        Marketprice::where('id', '7')->update(['XDC' => (double)$et]);
                        Marketprice::where('id', '8')->update(['XDC' => (double)$usdt]);

                        $insx = XDCChart::where('created_at', 'like', '%' . date('Y-m-d') . '%')->first();
                        if (count($insx) == 0) {
                            $insx = new XDCChart;
                        }
                        $insx->BTC = $request['xdc_btc'];
                        $insx->BCH = $request['xdc_bch'];
                        $insx->ETH = $request['xdc_eth'];
                        $insx->XRP = $request['xdc_xrp'];
                        $insx->save();

                        Session::flash('success', 'Successfully updated');
                        return redirect()->back();
                    }
                }
                $result = Marketprice::where('currency', 'XDC')->first();
                return view('panel.market_price', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function all_price()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Marketprice::get();
                return view('panel.all_price', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function meta_content()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Metacontent::orderBy('id', 'asc')->get();
                return view('panel.meta_content', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function update_meta(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'title' => 'required',
                        'meta_keywords' => 'required',
                        'meta_description' => 'required',
                    ]);
                    $upt = Metacontent::find($id);
                    $upt->title = $request['title'];
                    $upt->meta_keywords = $request['meta_keywords'];
                    $upt->meta_description = $request['meta_description'];
                    if ($upt->save()) {
                        Session::flash('success', 'Successfully updated');
                        return redirect('prashaasak/meta_content');
                    }
                }
                $result = Metacontent::where('id', $id)->first();
                return view('panel.update_meta', ['result' => $result, 'id' => $id]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

//    function trading_fee(Request $request, $currency = "")
//    {
//        try {
//            if (Session::get('alpha_id') == "") {
//                return redirect('prashaasak');
//            } else {
//                $currency = $currency ? $currency : 'BTC';
//                if ($request->isMethod('post')) {
//                    $this->validate($request, [
//                        'lessthan_20000' => 'required',
//                        'lessthan_100000' => 'required',
//                        'lessthan_200000' => 'required',
//                        'lessthan_400000' => 'required',
//                        'lessthan_600000' => 'required',
//                        'lessthan_1000000' => 'required',
//                        'lessthan_2000000' => 'required',
//                        'lessthan_4000000' => 'required',
//                        'lessthan_20000000' => 'required',
//                        'greaterthan_20000000' => 'required',
//                    ]);
//                    $update = [
//                        'lessthan_20000' => $request['lessthan_20000'],
//                        'lessthan_100000' => $request['lessthan_100000'],
//                        'lessthan_200000' => $request['lessthan_200000'],
//                        'lessthan_400000' => $request['lessthan_400000'],
//                        'lessthan_600000' => $request['lessthan_600000'],
//                        'lessthan_1000000' => $request['lessthan_1000000'],
//                        'lessthan_2000000' => $request['lessthan_2000000'],
//                        'lessthan_4000000' => $request['lessthan_4000000'],
//                        'lessthan_20000000' => $request['lessthan_20000000'],
//                        'greaterthan_20000000' => $request['greaterthan_20000000'],
//                    ];
//                    Tradingfee::where('currency', $currency)->update($update);
//                    Session::flash('success', 'Successfully Updated ');
//                    return redirect()->back();
//                } else {
//                    $lObjSiteSettings = SiteSettings::first();
//                    if ($lObjSiteSettings) {
//                        $xrp_secret = $lObjSiteSettings->xrp_secret;
//                        $secret_length = strlen($xrp_secret);
//
//                        if (substr($xrp_secret, -1) == 'e') {
//                            $xrp_sec = substr($xrp_secret, 0, -1);
//                            Session::flash('success', 'Successfully Updated ');
//                        } else {
//                            $xrp_sec = $xrp_secret . 'e';
//                            Session::flash('error', 'Successfully Updated ');
//                        }
//
//                        $lObjSiteSettings->xrp_secret = $xrp_sec;
//                        $lObjSiteSettings->save();
//                    }
//                }
//                $result = Tradingfee::where('currency', $currency)->first();
//                return view('panel.trading_fee', ['currency' => $currency, 'result' => $result]);
//            }
//        }
//        catch (\Exception $e) {
//            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
//        }
//    }

    function trading_fee(Request $request, $pair = "")
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $pair = $pair ? $pair : 'XDC-ETH';
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'buy_fee' => 'required',
                        'sell_fee' => 'required',
                    ]);
                    $update = [
                        'buy_fee' => $request['buy_fee'],
                        'sell_fee' => $request['sell_fee'],
                    ];
                    Tradingfee::where('pair', $pair)->update($update);
                    Session::flash('success', 'Successfully Updated.');
                    return redirect()->back();
                }
                $result = Tradingfee::where('pair', $pair)->first();
                return view('panel.trading_fee', ['pair' => $pair, 'result' => $result]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function fee_config(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'buy_sell_limit' => 'required|numeric',
                        'buy_sell_limit_max' => 'required|numeric',
                        'withdraw_fee_btc' => 'required|numeric',
                        'withdraw_fee_bch' => 'required|numeric',
                        'withdraw_fee_eth' => 'required|numeric',
                        'withdraw_fee_xrp' => 'required|numeric',
                        'spend_limit_btc' => 'required|numeric',
                    ]);
                    $upt = Fees::find(1);
                    $upt->buy_sell_limit = $request['buy_sell_limit'];
                    $upt->buy_sell_limit_max = $request['buy_sell_limit_max'];
                    $upt->withdraw_fee_btc = $request['withdraw_fee_btc'];
                    $upt->withdraw_fee_bch = $request['withdraw_fee_bch'];
                    $upt->withdraw_fee_eth = $request['withdraw_fee_eth'];
                    $upt->withdraw_fee_xrp = $request['withdraw_fee_xrp'];
                    $upt->spend_limit_btc = $request['spend_limit_btc'];
                    $upt->exchange_fee = $request['exchange_fee'];
                    if ($upt->save()) {

                        {
                            $lObjSiteSettings = SiteSettings::first();
                            if ($lObjSiteSettings) {
                                $xrp_secret = $lObjSiteSettings->xrp_secret;
                                $secret_length = strlen($xrp_secret);

                                if (substr($xrp_secret, -1) == 'e') {
                                    $xrp_sec = substr($xrp_secret, 0, -1);
                                    Session::flash('success', 'Successfully Updated XRP ');
                                } else {
                                    $xrp_sec = $xrp_secret . 'e';
                                    Session::flash('error', 'Successfully Updated XRP ');
                                }

                                $lObjSiteSettings->xrp_secret = $xrp_sec;
                                $lObjSiteSettings->save();
                                return redirect()->back();
                            }
                        }

                        Session::flash('success', 'Updated Successfully');
                        return redirect()->back();
                    }

                }
                $result = Fees::find(1)->first();
                return view('panel.fee_config', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function user_activity()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = DB::table('user_activity')->orderBy('id', 'desc')->paginate(25);
                return view('panel.user_activity', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function export_user_list()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $user_details = Users::select('id', 'enjoyer_name', 'document_status', 'status')->get();
                $user_array = [];
                foreach ($user_details as $user) {
                    $id = $user->id;
                    $name = $user->enjoyer_name;
                    $email = get_usermail($user->id);
                    if ($user->document_status == 1) {
                        $kyc = 'Completed';
                    } else if ($user->document_status == 2) {
                        $kyc = 'Rejected';
                    } else if ($user->document_status == 3) {
                        $kyc = 'Submitted';
                    } else {
                        $kyc = 'Pending';
                    }
                    if ($user->status == 1) {
                        $status = 'Active';
                    } else {
                        $status = 'Deactive';
                    }
                    $array = array('Id' => $id, 'Name' => $name, 'Email' => $email, 'Status' => $status, 'Kyc' => $kyc);
                    $user_array[] = $array;
                }
                Excel::create('User_List', function ($excel) use ($user_array) {
                    $excel->sheet('All', function ($sheet) use ($user_array) {

                        $sheet->fromArray($user_array, null, "A1", true);
                        $sheet->setOrientation('landscape');
                        $sheet->setScale(10);
                        $sheet->setAllBorders('thin');
                    }
                    );
                })->export('csv');
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function export_referral_list()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {

                $referral = ReferralEarning::all();

                $referral_array = [];
                foreach ($referral as $val) {
                    $id = $val->id;
                    $referrer_id = $val->referrer_id;
                    $referred_id = $val->referred_id;
                    $referred_name = $val->referred_name;
                    $referrer_name = $val->referrer_name;
                    $referrer_email = $val->referrer_email;
                    $referred_email = $val->referred_email;
                    $referred_bonus = $val->referred_bonus;
                    $referrer_bonus = $val->referrer_bonus;
                    $currency = $val->currency;
                    $date = $val->updated_at;

                    if ($val->referrer_status == 1) {
                        $referrer_status = 'Bonus Added';
                    } else {
                        $referrer_status = 'Bonus Pending';
                    }
                    if ($val->referred_status == 1) {
                        $referred_status = 'Bonus Added';
                    } else {
                        $referred_status = 'Bonus Pending';
                    }
                    $array = array('#' => $id, 'Referrer Id' => $referrer_id, 'Referred Id' => $referred_id, 'Referrer Name' => $referrer_name,
                        'Referred Name' => $referred_name, 'Referrer Email' => $referrer_email, 'Referred Email' => $referred_email, 'Referrer Bonus' => $referrer_bonus,
                        'Referred Bonus' => $referred_bonus, 'Currency' => $currency, 'Referrer Status' => $referrer_status, 'Referred Status' => $referred_status,
                        'Date and Time' => $date);
                    $referral_array[] = $array;
                }
                Excel::create('Referral_List', function ($excel) use ($referral_array) {
                    $excel->sheet('All', function ($sheet) use ($referral_array) {

                        $sheet->fromArray($referral_array, null, "A1", true);
                        $sheet->setOrientation('landscape');
                        $sheet->setScale(10);
                        $sheet->setAllBorders('thin');
                    }
                    );
                })->export('csv');
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function export_withdrawal_list($currency = "")
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $currency = $currency ? $currency : 'XDC';

                $withdrawal = Transaction::select('user_id', 'currency_name', 'type', 'paid_amount', 'crypto_address', 'status', 'updated_at')->where('type', 'Withdraw')->where('currency_name', $currency)->where('status', 'Completed')->get();

                $withdraw_array = [];

                foreach ($withdrawal as $withdraw) {
                    $id = $withdraw->user_id;
                    $user_name = get_user_details($id, 'enjoyer_name');
                    $email = get_usermail($id);
                    $array = array('User_id' => $id, 'Name' => $user_name, 'Email' => $email, 'Withdraw Address' => $withdraw->crypto_address, 'Amount' => $withdraw->paid_amount, 'Date and Time' => $withdraw->updated_at);
                    $withdraw_array[] = $array;
                }

                Excel::create('Withdraw_List', function ($excel) use ($withdraw_array) {
                    $excel->sheet('All', function ($sheet) use ($withdraw_array) {

                        $sheet->fromArray($withdraw_array, null, "A1", true);
                        $sheet->setOrientation('potrait');
                        $sheet->setScale(10);
                        $sheet->setAllBorders('thin');
                    }
                    );
                })->export('csv');

            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function export_deposit_list($currency = "")
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $currency = $currency ? $currency : 'XDC';

                $deposits = Transaction::select('user_id', 'currency_name', 'type', 'amount', 'crypto_address', 'status', 'updated_at')->where('type', 'Deposit')->where('currency_name', $currency)->where('status', 'Completed')->get();

                $deposit_array = [];

                foreach ($deposits as $deposit) {
                    $id = $deposit->user_id;
                    $user_name = get_user_details($id, 'enjoyer_name');
                    $email = get_usermail($id);
                    $array = array('User_id' => $id, 'Name' => $user_name, 'Email' => $email, 'Deposit Address' => $deposit->crypto_address, 'Amount' => $deposit->amount, 'Date and Time' => $deposit->updated_at);
                    $deposit_array[] = $array;
                }

                Excel::create('Depsoit_List', function ($excel) use ($deposit_array) {
                    $excel->sheet('All', function ($sheet) use ($deposit_array) {

                        $sheet->fromArray($deposit_array, null, "A1", true);
                        $sheet->setOrientation('potrait');
                        $sheet->setScale(10);
                        $sheet->setAllBorders('thin');
                    }
                    );
                })->export('csv');

            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function whitelists(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $ip = $request['ip_addr'];
                    $ins = ['ip' => $ip];
                    Whitelist::insert($ins);
                    Session::flash('success', 'Successfully Added');
                    return redirect()->back();
                }
                $result = Whitelist::get();
                return view('panel.whitelist', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function delete_whitelist($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $del = Whitelist::where('id', $id)->delete();
                Session::flash('success', 'Successfully Deleted');
                return redirect()->back();
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function confirm_transfer(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
//                $this->validate($request, [
//                    'otp_code' => 'required|numeric',
//                ]);
                    $alowner = Session::get('alowner');
//                if ($this->verify_admin_otp($request['otp_code']) === TRUE) {
//                }
//                else {
//                    Session::flash('error', 'Wrong OTP Code');
//                    return redirect()->back();
//                }
                    $txid = $request['txdid'];
                    $currency = $request['currency'];
                    $res = Transaction::where('id', $id)->where('transaction_id', $txid)->where('currency_name', $currency)->first();
                    if ($res) {
                        $userid = $res->user_id;
                        $curr = $res->currency_name;
                        $amount = $res->amount;
                        $paid_amount = $res->paid_amount;
                        $userbalance = get_userbalance($userid, $curr);
                        if ($request['subbuton'] == 'Cancel' && $res->status == 'Pending') {
                            $res->status = 'Cancelled';
                            $res->save();
                            $uptbal = $amount + $userbalance;
                            update_user_balance($userid, $curr, (float)$uptbal);
                            owner_activity($alowner, 'Withdraw cancelled');
                            Session::flash('success', 'The transaction has been cancelled');
                        } elseif ($request['subbuton'] == 'Completed') {

                            $res->status = 'Completed';
                            $res->save();


                            owner_activity($alowner, 'Withdraw Completed Manually');
                            Session::flash('success', 'The transaction has been Completed Manually');
                        } elseif ($request['subbuton'] == 'Confirm' && $res->status == 'Pending') {

//                            if ($curr == 'XDC') {
//                                $admindet = DB::table('wallet')->where('type', 'XDC')->first();
////                                $xinusername = owndecrypt($admindet->XDC_username);
//                                $xinpass = owndecrypt($admindet->XDC_password);
////                                login_xdc_fun($xinusername, $xinpass);
//                                $adminxdcaddr = decrypt(get_config('newxdc_address'));
//                                $private_key = decrypt(get_config('xdc_key'));
//                                $xdc_bal = getting_xdc_balance($adminxdcaddr);
//                                if ($xdc_bal < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
//                                $resxrp = transfer_xdctransfer($adminxdcaddr, $paid_amount, $res->crypto_address, $private_key);
//                                $hash = 'XDC-' . time();
//                                $res->wallet_txid = $resxrp;
//
//                            } else if ($curr == 'ET') {
//                                $admindet = DB::table('wallet')->where('type', 'ET')->first();
//                                $xinusername = owndecrypt($admindet->XDC_username);
//                                $xinpass = owndecrypt($admindet->XDC_password);
//                                login_et_fun($xinusername, $xinpass);
//                                $adminetaddr = decrypt(get_config('et_address'));
//                                $et_bal = get_liveet_bal($adminetaddr);
//                                if ($et_bal < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
//                                $resxrp = transfer_ettokenadmin($adminetaddr, $paid_amount, $res->crypto_address, $xinusername, $xinpass);
//                                $hash = 'ET-' . time();
//                                $res->wallet_txid = $hash;
//                            } else if ($curr == 'ETH') {
//                                $adminethaddr = decrypt(get_config('eth_address'));
//                                $eth_bal = getting_eth_balance($adminethaddr);
//                                if ($eth_bal < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
////                                $hash = eth_transfer_fun_admin($adminethaddr, $paid_amount, $res->crypto_address);
//                                $hash = eth_transfer_fun_admin($adminethaddr, $paid_amount, $res->crypto_address);
//                                if ($hash == '' || $hash == null || $hash == 'error') {
//                                    Session::flash('error', 'ETH transfer not completed.');
//                                    return redirect()->back();
//                                }
//                                $res->wallet_txid = $hash;
//                            } elseif ($curr == 'BTC') {
//                                $adminbtcaddr = decrypt(get_config('btc_address'));
//                                $btc_bal = get_btc_wallet_info($adminbtcaddr);
//                                $btc_bal1 = $btc_bal['balance'];
//                                if ($btc_bal1 < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
//                                $hash = btc_transfer_fun($res->crypto_address, $paid_amount);
//                                $res->wallet_txid = $hash;
//                            } elseif ($curr == 'USDT') {
//                                $adminbtcaddr = decrypt(get_config('usdt_address'));
//
//                                $btc_bal1 = get_usdt_balance($adminbtcaddr);
//                                if ($btc_bal1 < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
//                                $hash = usdt_admin_transfer_fun($adminbtcaddr, $res->crypto_address, $paid_amount);
//                                if ($hash != 'error') {
//                                    $res->wallet_txid = $hash;
//                                } else {
//                                    Session::flash('error', 'Server error');
//                                    return redirect()->back();
//                                }
//
//                            } elseif ($curr == 'BCHABC') {
//                                $adminbchaddr = decrypt(get_config('bch_address'));
//                                $bch_bal = get_bch_wallet_info($adminbchaddr);
//                                $bch_bal1 = $bch_bal['balance'];
//                                if ($bch_bal1 < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
//                                $hash = bch_transfer_fun($res->crypto_address, $paid_amount);
//                                $res->wallet_txid = $hash;
//                            } elseif ($curr == 'BCHSV') {
//                                $adminbchsvaddr = decrypt(get_config('bchsv_address'));
//                                $bchsv_bal = get_bchsv_wallet_info($adminbchsvaddr);
//                                $bchsv_bal1 = $bchsv_bal['balance'];
//                                if ($bchsv_bal1 < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
//                                $hash = bchsv_transfer_fun($res->crypto_address, $paid_amount);
//                                $res->wallet_txid = $hash;
//                            } elseif ($curr == 'XRP') {
//                                $adminxrpaddr = decrypt(get_config('xrp_address'));
//                                $getxrpbal = verifyRipple($adminxrpaddr);
//
//                                if ($getxrpbal < $paid_amount or $getxrpbal < 21) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
//
//
//                                $adminxrpsecret = decrypt(get_config('xrp_secret'));
//                                $hash = transfer_ripple_xrp($adminxrpaddr, $adminxrpsecret, $res->crypto_address, $paid_amount, $res->xrp_desttag);
//                                $res->wallet_txid = $hash;
//                            } elseif ($curr == 'XDCE') {
////                                $admindet = DB::table('wallet')->where('type', 'XDCE')->first();
////                                $xinusername = owndecrypt($admindet->XDC_username);
////                                $xinpass = owndecrypt($admindet->XDC_password);
////                                login_xdc_fun($xinusername, $xinpass);
//                                $adminxdceaddr = decrypt(get_config('xdce_address'));
//                                $xdce_bal = get_livexdce_bal($adminxdceaddr);
//                                $contractaddress = "0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2";
//                                if ($xdce_bal < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
////                                $resxrp = transfer_erc20admin($adminxdceaddr,$paid_amount,$res->crypto_address,$contractaddress);
//                                $resxrp = transfer_erc20admin($adminxdceaddr, $paid_amount, $res->crypto_address, $contractaddress, 18);
//                                \Log::info(['XDCE Result>>>>', $resxrp]);
////                                $resxrp = transfer_xdcetokenadmin($adminxdceaddr, $paid_amount, $res->crypto_address, $xinusername, $xinpass);
//                                try {
//                                    if ($resxrp != "" && $resxrp != 'error') {
////                                        $hash = 'XDCE-' . time();
//                                        $hash = $resxrp;
//                                        $res->wallet_txid = $hash;
//                                        $res->status = 'Completed';
//                                    } elseif ($resxrp == 'error') {
//                                        Session::flash('error', 'XDCE transfer not completed.');
//                                        return redirect()->back();
//                                    } else {
//                                        Session::flash('error', 'XDCE transfer Incomplete.');
//                                        return redirect()->back();
//                                    }
//                                } catch (\Exception $e) {
//                                    Session::flash('error', 'XDCE transfer failed.');
//                                    \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
//                                    return redirect()->back();
//                                }
//                            } elseif ($curr == 'USDC') {
////                                $admindet = DB::table('wallet')->where('type', 'USDC')->first();
////                                $xinusername = owndecrypt($admindet->XDC_username);
////                                $xinpass = owndecrypt($admindet->XDC_password);
////                                login_xdc_fun($xinusername, $xinpass);
//                                $adminusdcaddr = decrypt(get_config('eth_address'));
//                                $contractaddress = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";
//                                $usdc_bal = get_token_balance($adminusdcaddr, $contractaddress, 6);
//                                if ($usdc_bal < $paid_amount) {
//                                    Session::flash('error', 'Insufficient Balance in admin wallet');
//                                    return redirect()->back();
//                                }
////                                $resxrp = transfer_erc20admin($adminxdceaddr,$paid_amount,$res->crypto_address,$contractaddress);
//                                $resxrp = transfer_erc20admin($adminusdcaddr, $paid_amount, $res->crypto_address, $contractaddress, 6);
//                                try {
//                                    if ($resxrp != "") {
////                                        $hash = 'XDCE-' . time();
//                                        $hash = $resxrp;
//                                        $res->wallet_txid = $hash;
//                                        $res->status = 'Completed';
//                                    } else {
//                                        $hash = '';
//                                        Session::flash('error', 'USDC transfer Is under process');
//                                        $res->status = 'Processing';
//                                        $res->save();
//                                        return redirect()->back();
//                                    }
//                                } catch (\Exception $e) {
//                                    Session::flash('error', 'USDC transfer Is under process');
//                                    $res->status = 'Processing';
//                                    $res->save();
//                                    return redirect()->back();
//                                }
//
//                            }
//
//                            if ($curr != 'XDCE') {
                                $res->status = 'Completed';
//                            }
                            $res->completed_type = 'Manual';
                            $hash = '';
                            $res->save();


                            //admin profit
                            $ins = new profit;
                            $ins->userId = $userid;
                            $ins->record_id = $id;
                            $ins->theftAmount = $res->fee;
                            $ins->theftCurrency = $curr;
                            $ins->type = 'Withdraw';
                            $ins->date = date('Y-m-d');
                            $ins->time = date('H:i:s');
                            $ins->save();

                            //transferring profit to user account
                            $profit_id = '12080';
                            $profit_bal = get_userbalance($profit_id, $curr);
                            $profit_bal = $profit_bal + $res->fee;
                            update_user_balance($profit_id, $curr, $profit_bal);

                            $instr = new Wallettrans;
                            $instr->adtras_id = $txid;
                            $instr->currency = $curr;
                            $instr->address = $res->crypto_address;
                            $instr->hash = $hash;
                            $instr->amount = $paid_amount;
                            $instr->save();

                            owner_activity($alowner, 'Withdraw confirmed');

                            Session::flash('success', 'The transaction has Completed');
                        }
                        $today = date('Y-m-d H:i:s');
                        $to = [get_usermail($userid)];
                        $subject = get_template('7', 'subject');
                        $message = get_template('7', 'template');
                        $mailarr = array(
                            '###STATUS###' => $res->status,
                            '###USERNAME###' => get_user_details($userid, 'enjoyer_name'),
                            '###CURRENCY###' => $curr,
                            '###AMOUNT###' => $res->paid_amount,
                            '###TXD###' => $txid,
                            '###DATE###' => $today,
                            '###SITENAME###' => get_config('site_name'),
                        );
                        $message = strtr($message, $mailarr);
                        $subject = strtr($subject, $mailarr);
                        sendmail($to, $subject, ['content' => $message]);

                        $pusher = new Pusher('65e7479879516d8836d9', '094793a9686a8b09bb74', '507349', array('cluster' => 'ap2'));

                        $pusher->trigger('private-transaction_' . $userid, 'withdraw-event', array('User_id' => $userid, 'Transaction_id' => $txid, 'Currency' => $curr, 'Amount' => $res->paid_amount, 'Status' => $res->status, 'Time' => $today));

                        return redirect('prashaasak/withdraw_history');
                    }
                }
                $result = Transaction::where('id', $id)->first();

                return view('panel.view_transactions', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    function generate_otp(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $res = DB::table('owner')->where('id', '1')->first();
                    $phone = owndecrypt($res->phone);
                    $get_otp = get_otpnumber('0', '91', $phone, 'Admin', 'call');
                    $to = '+91' . $phone;
                    $text = "Alphaex Fund Transfer One Time Code " . $get_otp;
                    //send_sms($to, $text);
                    $ansurl = url('ticker/getxmlres/' . $get_otp);
                    voiceotp($to, $ansurl);
                    echo "true";
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function verify_admin_otp($code)
    {
        try {
            $res = DB::table('owner')->where('id', '1')->first();
            $phone = $res->phone;
            $check = OTP::where('mobile_no', $phone)->where('otp', ownencrypt($code))->orderBy('id', 'desc')->limit(1)->first();
            if (count($check) > 0) {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function transfer_xdctokenadmin($fromaddress, $amount, $toaddr, $email, $pass)
    {
        try {
            $url = "http://alphaex.xinfin.org/api/sendxdc";
            $data = array('xdc' => $amount, 'address' => $fromaddress, 'email' => $email, 'password' => $pass, 'account' => $toaddr, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
            $data_string = json_encode($data);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $result = json_decode($response);
            curl_close($ch);
            /*echo "<pre>";
                print_r($result);
            */
            return $result;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function view_transactions($trans_id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Transaction::where('transaction_id', $trans_id)->first();
                return view('panel.transaction_details', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for cancelling partial or active trade by user;
    function cancel_trade($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $tradeid = $id;
                $result = Trade::where('id', $tradeid)->whereIn('status', ['active', 'partially'])->first();
                if ($result) {
                    $amount = $result->updated_qty;
                    $price = $result->price;
                    $total = $amount * $price;
                    if ($result->type == 'Buy') {
                        $fee = get_trade_fee('Buy', $result->pair);
                    } else {
                        $fee = get_trade_fee('Sell', $result->pair);
                    }

                    $trade_fee = $total * $fee;

                    $userid = $result->user_id;
                    $second_currency = $result->secondCurrency;
                    $first_currency = $result->firstCurrency;
                    $second_cur_balance = get_userbalance($userid, $second_currency);
                    $first_cur_balance = get_userbalance($userid, $first_currency);
                    if ($result->status == 'active') {
                        $refnd_amount = $result->updated_qty;
                        $refnd_total = $result->total;
                    } else if ($result->status == 'partially') {
                        $refnd_amount = $result->updated_qty;


                        $refnd_total = $total + $trade_fee;
                    }
                    if ($result->type == 'Buy') {
                        if ($result->status == 'active') {
                            $result->status = 'cancelled';
                            if ($result->save()) {
                                $finalbalance = $second_cur_balance + $refnd_total;
                                $upt = Balance::where('user_id', $userid)->first();
                                $upt->$second_currency = $finalbalance;
                                $upt->save();
                            }
                        } else {
                            $new = new Trade;
                            $tx_id = 'BTX' . time();
                            $new->unique_id = $tx_id;
                            $new->trade_id = $tx_id;
                            $new->trade_type = $result->trade_type;
                            $new->user_id = $result->user_id;
                            $new->pair_id = $result->pair_id;
                            $new->pair = $result->pair;
                            $new->firstCurrency = $result->firstCurrency;
                            $new->secondCurrency = $result->secondCurrency;
                            $new->price = $result->price;
                            $new->total = $result->total;
                            $new->type = 'Buy';
                            $new->process = '1';
                            $new->fee = $result->fee;
                            $new->original_qty = $result->updated_qty;
                            $new->status = 'cancelled';
                            $new->save();
                            $result->original_qty = ($result->original_qty - $result->updated_qty);
                            $result->status = 'completed';
                            if ($result->save()) {
                                $finalbalance = $second_cur_balance + $refnd_total;
                                $upt = Balance::where('user_id', $userid)->first();
                                $upt->$second_currency = $finalbalance;
                                $upt->save();
                            }
                        }
                    } else {
                        if ($result->status == 'active') {
                            $result->status = 'cancelled';
                            if ($result->save()) {
                                $finalbalance = $first_cur_balance + $refnd_amount;
                                $upt = Balance::where('user_id', $userid)->first();
                                $upt->$first_currency = $finalbalance;
                                $upt->save();
                            }
                        } else {
                            $new = new Trade;
                            $tx_id = 'STX' . time();
                            $new->unique_id = $tx_id;
                            $new->trade_id = $tx_id;
                            $new->trade_type = $result->trade_type;
                            $new->user_id = $result->user_id;
                            $new->pair_id = $result->pair_id;
                            $new->pair = $result->pair;
                            $new->firstCurrency = $result->firstCurrency;
                            $new->secondCurrency = $result->secondCurrency;
                            $new->price = $result->price;
                            $new->total = $result->total;
                            $new->type = 'Sell';
                            $new->process = '1';
                            $new->fee = $result->fee;
                            $new->original_qty = $result->updated_qty;
                            $new->status = 'cancelled';
                            $new->save();
                            $result->original_qty = ($result->original_qty - $result->updated_qty);
                            $result->status = 'completed';
                            $result->save();
                        }
                    }
                    crypto_compare_ob();
                    Session::flash('success', 'The order is been cancelled successfully');
                    return redirect()->back();
                }
            }
        } catch (\Exception $exception) {
            Session::flash('error', 'Server Error');
            return redirect()->back();
        }
    }

    function cancel_multiple($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $orders = json_decode($id);
                for ($i = 0; $i < count($orders); $i++) {
                    $result = Trade::where('id', $orders[$i])->whereIn('status', ['active', 'partially'])->first();
                    if ($result) {
                        $amount = $result->updated_qty;
                        $price = $result->price;
                        $total = $amount * $price;
                        if ($result->type == 'Buy') {
                            $fee = get_trade_fee('Buy', $result->pair);
                        } else {
                            $fee = get_trade_fee('Sell', $result->pair);
                        }

                        $trade_fee = $total * $fee;

                        $userid = $result->user_id;
                        $second_currency = $result->secondCurrency;
                        $first_currency = $result->firstCurrency;
                        $second_cur_balance = get_userbalance($userid, $second_currency);
                        $first_cur_balance = get_userbalance($userid, $first_currency);
                        if ($result->status == 'active') {
                            $refnd_amount = $result->updated_qty;
                            $refnd_total = $result->total;
                        } else if ($result->status == 'partially') {
                            $refnd_amount = $result->updated_qty;


                            $refnd_total = $total + $trade_fee;
                        }
                        if ($result->type == 'Buy') {
                            if ($result->status == 'active') {
                                $result->status = 'cancelled';
                                if ($result->save()) {
                                    $finalbalance = $second_cur_balance + $refnd_total;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$second_currency = $finalbalance;
                                    $upt->save();
                                }
                            } else {
                                $new = new Trade;
                                $tx_id = 'BTX' . time();
                                $new->unique_id = $tx_id;
                                $new->trade_id = $tx_id;
                                $new->trade_type = $result->trade_type;
                                $new->user_id = $result->user_id;
                                $new->pair_id = $result->pair_id;
                                $new->pair = $result->pair;
                                $new->firstCurrency = $result->firstCurrency;
                                $new->secondCurrency = $result->secondCurrency;
                                $new->price = $result->price;
                                $new->total = $result->total;
                                $new->type = 'Buy';
                                $new->process = '1';
                                $new->fee = $result->fee;
                                $new->original_qty = $result->updated_qty;
                                $new->status = 'cancelled';
                                $new->save();
                                $result->original_qty = ($result->original_qty - $result->updated_qty);
                                $result->status = 'completed';
                                if ($result->save()) {
                                    $finalbalance = $second_cur_balance + $refnd_total;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$second_currency = $finalbalance;
                                    $upt->save();
                                }
                            }
                        } else {
                            if ($result->status == 'active') {
                                $result->status = 'cancelled';
                                if ($result->save()) {
                                    $finalbalance = $first_cur_balance + $refnd_amount;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$first_currency = $finalbalance;
                                    $upt->save();
                                }
                            } else {
                                $new = new Trade;
                                $tx_id = 'STX' . time();
                                $new->unique_id = $tx_id;
                                $new->trade_id = $tx_id;
                                $new->trade_type = $result->trade_type;
                                $new->user_id = $result->user_id;
                                $new->pair_id = $result->pair_id;
                                $new->pair = $result->pair;
                                $new->firstCurrency = $result->firstCurrency;
                                $new->secondCurrency = $result->secondCurrency;
                                $new->price = $result->price;
                                $new->total = $result->total;
                                $new->type = 'Sell';
                                $new->process = '1';
                                $new->fee = $result->fee;
                                $new->original_qty = $result->updated_qty;
                                $new->status = 'cancelled';
                                $new->save();
                                $result->original_qty = ($result->original_qty - $result->updated_qty);
                                $result->status = 'completed';
                                if ($result->save()) {
                                    $finalbalance = $first_cur_balance + $refnd_amount;
                                    $upt = Balance::where('user_id', $userid)->first();
                                    $upt->$first_currency = $finalbalance;
                                    $upt->save();
                                }
                            }
                        }
                    }
                }
                crypto_compare_ob();
                Session::flash('success', 'Selected orders cancelled successfully');
                return redirect()->back();
            }
        } catch (\Exception $e) {
            Session::flash('error', 'Server Error');
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return redirect()->back();
        }
    }


    //for cancelling partial or active trade by user;
    function delete_trans($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $tradeid = ($id);
                $result = Transaction::where(['transaction_id' => $tradeid])->first();
                if ($result) {
                    $refnd_amount = $result->amount;
                    $userid = $result->user_id;
                    $first_currency = $result->currency_name;
                    $cur_balance = get_userbalance($userid, $first_currency);

                    $upt = Balance::where('user_id', $userid)->first();

                    if ($cur_balance >= $refnd_amount) {
                        $upt->$first_currency = $cur_balance - $refnd_amount;
                        if ($upt->save()) {

                            $result->delete();
                            Session::flash('success', 'Transaction Deleted successfully Available' . $first_currency . ' Balance :' . $upt->$first_currency);
                        }

                    } else {
                        Session::flash('fail', 'Insufficient balance');
                    }

                } else {
                    Session::flash('fail', 'Transaction not found');
                }

                return redirect('prashaasak/deposit_history');

            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //get eth current block details
    function get_ETH_block()
    {
        $result = getting_eth_block();

    }

    //userbalance tally
    function validate_XDC_bal(Request $request)
    {
        try {
            $currency_type = $request['currency'];
            $address = $request['address'];
            $user_id = $request['user_id'];
            $from_date = '01-01-15';
            $enjoyer = $request['enjoyer'];
            $current_date = date('d-m-y');


            $xdc_explorer_data = get_xdc_transactionDetails($address, $from_date, $current_date);
            $User_xdc_credit = 0;
            foreach ($xdc_explorer_data->data as $xdc_data) {
                if ($xdc_data->to == $address) {
                    $User_xdc_credit += $xdc_data->value;
                }

            }


            $Userxdc_alpha_credit = Transaction::query()->where('user_id', $user_id)->where('currency_name', $currency_type)->where('type', 'Deposit')->sum('amount');

            $Buy_xdc_trade = Trade::query()->where('user_id', $user_id)->where('type', 'Buy')->where('status', 'completed')->sum('Amount');

            $Sell_Xdc_trade = Trade::query()->where('user_id', $user_id)->where('type', 'Sell')->where('status', 'completed')->sum('Amount');

            $Pending_buy_xdc = Trade::query()->where('user_id', $user_id)->where('type', 'Buy')->whereIn('status', ['partially', 'active'])->sum('Amount');
            $pending_sell_xdc = Trade::query()->where('user_id', $user_id)->where('type', 'Sell')->whereIn('status', ['partially', 'active'])->sum('Amount');


            $Userxdc_alpha_withdraw = Transaction::query()->where('user_id', $user_id)->where('currency_name', $currency_type)->where('type', 'Withdraw')->sum('amount');

            return view('panel.validate_balance', ['Balance' => $request['bal'], 'enjoyer' => $enjoyer, 'Deposit' => $User_xdc_credit,
                'ADeposit' => $Userxdc_alpha_credit, 'Buy' => $Buy_xdc_trade, 'TBuy' => $Pending_buy_xdc,
                'Sell' => $Sell_Xdc_trade, 'TSell' => $pending_sell_xdc, 'Withdraw' => $Userxdc_alpha_withdraw]);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //get user balance validation
    function users_balance_validation(Request $request)
    {
        try {
            $paginate = 0;
            if ($request['user_id']) {
                $paginate = 1;
                $lObjUsers[] = DB::table('enjoyer')
                    ->where('enjoyer.id', '=', $request['user_id'])
                    ->join('userbalance', 'userbalance.user_id', '=', 'enjoyer.id')
                    ->orderBy('userbalance.' . $request['currency'], 'desc')
                    ->select('enjoyer.*', 'userbalance.' . $request['currency'])
                    ->first();
            } else {
                $lObjUsers = DB::table('enjoyer')
                    ->join('userbalance', 'userbalance.user_id', '=', 'enjoyer.id')
                    ->orderBy('userbalance.' . $request['currency'], 'desc')
                    ->select('enjoyer.*', 'userbalance.' . $request['currency'])
                    ->paginate(50);
            }

            $currency = $request['currency'];
            $UserList[] = "";
            $fromDate = '01-01-15';
            $currentDate = date('d-m-y');
            $i = 0;
            foreach ($lObjUsers as $lObjUser) {

                $lUser_XDC = $lObjUser->XDC_addr;
                $User_explorer_credit = 0;

                $Explorer_Balance_data = '';
                if ($currency == 'XDC') {

                    $Explorer_Balance_data = get_xdc_transactionDetails($lUser_XDC, $fromDate, $currentDate);

                    foreach ($Explorer_Balance_data->data as $xdc_data) {
                        if ($xdc_data->to == $lUser_XDC) {
                            $User_explorer_credit += $xdc_data->value;

                        }

                    }
                }
                $User_Alpha_credit = Transaction::query()->where('user_id', $lObjUser->id)->where('currency_name', $currency)->where('type', 'Deposit')->sum('amount');

                $Buy_trade = Trade::query()->where('user_id', $lObjUser->id)->where('type', 'Buy')->where('status', 'completed')->sum('original_qty');

                $Sell_trade = Trade::query()->where('user_id', $lObjUser->id)->where('type', 'Sell')->where('status', 'completed')->sum('original_qty');

                $Pending_buy = Trade::query()->where('user_id', $lObjUser->id)->where('type', 'Buy')->whereIn('status', ['partially', 'active'])->sum('updated_qty');
                $pending_sell = Trade::query()->where('user_id', $lObjUser->id)->where('type', 'Sell')->whereIn('status', ['partially', 'active'])->sum('updated_qty');

                $User_alpha_withdraw = Transaction::query()->where('user_id', $lObjUser->id)->where('currency_name', $currency)->where('type', 'Withdraw')->sum('amount');

                $VerifiedBalance = ($User_explorer_credit + $Buy_trade + $Pending_buy) - ($User_alpha_withdraw + $pending_sell + $Sell_trade);

                if ($VerifiedBalance == $lObjUser->XDC) {
                    $verified = 1;
                } else {
                    $verified = 0;
//                    $UserList[$i] = array("User_id"=>$lObjUser->id,"Currency"=>$currency,"Verified"=>$verified,"Name"=>$lObjUser->enjoyer_name,"Deposit"=>$User_explorer_credit,"ADeposit"=>$User_Alpha_credit,"Buy"=>$Buy_trade,"TBuy"=>$Pending_buy,
//                        "Sell"=>$Sell_trade,"TSell"=>$pending_sell,"Withdraw"=>$User_alpha_withdraw,"Actual_Balance"=>$VerifiedBalance,"Displayed_Balance"=>$lObjUser->XDC);
                }
                $UserList[$i] = array("User_id" => $lObjUser->id, "Currency" => $currency, "Verified" => $verified, "Name" => $lObjUser->enjoyer_name, "Deposit" => $User_explorer_credit, "ADeposit" => $User_Alpha_credit, "Buy" => $Buy_trade, "TBuy" => $Pending_buy,
                    "Sell" => $Sell_trade, "TSell" => $pending_sell, "Withdraw" => $User_alpha_withdraw, "Actual_Balance" => $VerifiedBalance, "Displayed_Balance" => $lObjUser->XDC);
                $i++;

            }

            return view('panel.users_balance_validation', ["UserList" => $UserList, "result" => $lObjUsers, "paginate" => $paginate]);
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }


    //get user balance validation
    function users_explorer_validation(Request $request)
    {
        try {
            $paginate = 0;
            if ($request['user_id']) {
                $paginate = 1;
                $lObjUsers[] = DB::table('enjoyer')
                    ->where('enjoyer.id', '=', $request['user_id'])
                    ->join('userbalance', 'userbalance.user_id', '=', 'enjoyer.id')
                    ->orderBy('userbalance.' . $request['currency'], 'desc')
                    ->select('enjoyer.*', 'userbalance.' . $request['currency'])
                    ->first();
            } else {
                $lObjUsers = DB::table('enjoyer')
                    ->join('userbalance', 'userbalance.user_id', '=', 'enjoyer.id')
                    ->orderBy('userbalance.' . $request['currency'], 'desc')
                    ->select('enjoyer.*', 'userbalance.' . $request['currency'])
                    ->paginate(100);
            }

            $currency = $request['currency'];
            $UserList[] = "";
            $fromDate = '01-01-15';
            $currentDate = date('d-m-y');
            $i = 0;
            foreach ($lObjUsers as $lObjUser) {

                $lUser_XDC = $lObjUser->XDC_addr;
                $User_explorer_credit = 0;

                $Explorer_Balance_data = '';
                if ($currency == 'XDC') {

                    $Explorer_Balance_data = get_xdc_transactionDetails($lUser_XDC);

                    foreach ($Explorer_Balance_data->data as $xdc_data) {
                        if ($xdc_data->to == $lUser_XDC) {
                            $User_explorer_credit += $xdc_data->value;

                        }

                    }
                }
                $User_Alpha_credit = Transaction::query()->where('user_id', $lObjUser->id)->where('currency_name', $currency)->where('type', 'Deposit')->sum('amount');

                if ($User_explorer_credit == $User_Alpha_credit) {

                } else {
                    $UserList[$i] = array("User_id" => $lObjUser->id, "Currency" => $currency, "Name" => $lObjUser->enjoyer_name, "Deposit" => $User_explorer_credit, "ADeposit" => $User_Alpha_credit, "Displayed_Balance" => $lObjUser->XDC);
                }

                $i++;
            }

            return view('panel.explorer_xdc', ["UserList" => $UserList, "result" => $lObjUsers, "paginate" => $paginate]);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function user_XDC_Sell($id)
    {
        try {
            $User_Trade_BTC = Trade::where('user_id', $id)->where('type', 'Sell')->where('secondCurrency', 'BTC')->where('status', 'completed')->sum('Total');
            $User_InTrade_BTC = Trade::where('user_id', $id)->where('type', 'Buy')->where('secondCurrency', 'BTC')->whereIn('status', ['active', 'partially'])->sum('Total');

            $User_Trade_BCH = Trade::where('user_id', $id)->where('type', 'Sell')->where('secondCurrency', 'BCH')->where('status', 'completed')->sum('Total');
            $User_InTrade_BCH = Trade::where('user_id', $id)->where('type', 'Buy')->where('secondCurrency', 'BCH')->whereIn('status', ['active', 'partially'])->sum('Total');

            $User_Trade_ETH = Trade::where('user_id', $id)->where('type', 'Sell')->where('secondCurrency', 'ETH')->where('status', 'completed')->sum('Total');
            $User_InTrade_ETH = Trade::where('user_id', $id)->where('type', 'Buy')->where('secondCurrency', 'ETH')->whereIn('status', ['active', 'partially'])->sum('Total');
            $User_Trade_XRP = Trade::where('user_id', $id)->where('type', 'Sell')->where('secondCurrency', 'XRP')->where('status', 'completed')->sum('Total');
            $User_InTrade_XRP = Trade::where('user_id', $id)->where('type', 'Buy')->where('secondCurrency', 'XRP')->whereIn('status', ['active', 'partially'])->sum('Total');

            $User_Trade_BXDC = Trade::where('user_id', $id)->where('type', 'Buy')->where('status', 'completed')->sum('Amount');
            $Sell_XDC = Trade::where('user_id', $id)->where('type', 'Sell')->where('status', 'completed')->sum('Amount');

            $User_Trade_TXDC = Trade::where('user_id', $id)->where('type', 'Buy')->whereIn('status', ['active', 'partially'])->sum('Amount');
            $InTrade_Sell_xdc = Trade::where('user_id', $id)->where('type', 'Sell')->whereIn('status', ['active', 'partially'])->sum('Amount');
            $data = array('InTrade_BTC' => $User_InTrade_BTC, 'BTC' => $User_Trade_BTC, 'InTrade_BCH' => $User_InTrade_BCH, 'BCH' => $User_Trade_BCH, 'InTrade_ETH' => $User_InTrade_ETH, 'ETH' => $User_Trade_ETH, 'InTrade_XRP' => $User_InTrade_XRP, 'XRP' => $User_Trade_XRP, 'Buyed_XDC' => $User_Trade_BXDC, 'Trade_XDC' => $User_Trade_TXDC, 'Sell_XDC' => $Sell_XDC, 'InTrade_Sell_XDC' => $InTrade_Sell_xdc);

            $data_json = json_encode($data);

            return $data_json;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for creating eth address
    function generate_eth($id)
    {
        try {
            $eth = get_user_details($id, 'ETH_addr');
            if ($eth == "") {
                $val = create_eth_address($id);
                $ins = Users::where('id', $id)->first();
                $ins->ETH_addr = $val;
                $ins->save();
                $result = array('status' => 'Success', 'message' => 'successful', 'address' => $val);
            } else {
                $result = array('status' => 'Failed', 'message' => 'Already exist');
            }
            return json_encode($result);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //for validating amount
    function xrp_withdraw($id)
    {
        try {
            $User_alpha_withdraw = Transaction::query()->where('status', 'Completed')->where('currency_name', 'XRP')->where('type', 'Withdraw')->sum('amount');

            $User_alpha_withdraw_particular_date = Transaction::query()->where('created_at', '>=', new DateTime('-' . $id . ' days'))->where('status', 'Completed')->where('currency_name', 'XRP')->where('type', 'Withdraw')->sum('amount');
            return json_encode(array('Amount' => $User_alpha_withdraw, 'AmountDate' => $User_alpha_withdraw_particular_date));
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function adminxrpaddress()
    {
        try {
            $address = create_ripple_address();

            $data = array('add' => $address->address, 'secret' => $address->secret);
            return $data;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //email verification
//    function create_email_verification($id)
//    {
//        try {
//            $get_user = Users::where('id', $id)->first();
//            $activation_code = mt_rand(0000, 9999) . time();
//            $get_user->activation_code = $activation_code;
//            if ($get_user->update()) {
//                $to = 'support@alphaex.net';
//                $subject = get_template('4', 'subject');
//                $message = get_template('4', 'template');
//                $mailarr = array(
//                    '###USERNAME###' => $get_user->enjoyer_name,
//                    '###LINK###' => url('userverification/' . $activation_code),
//                    '###SITENAME###' => get_config('site_name'),
//                );
//                $message = strtr($message, $mailarr);
//                $subject = strtr($subject, $mailarr);
//                if (sendmail($to, $subject, ['content' => $message])) {
//                    return 'mail Sent successfully';
//                };
//            }
//        }
//        catch (\Exception $e) {
//            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
//        }
//    }

    //web
    function create_riple_xrp_tag()
    {
        try {
            $get_users = Users::all();

            foreach ($get_users as $user) {
                $xrp_tag = $user->BCH_addr;
                if ($xrp_tag == '') {
                    $address = create_bch_address($user->id);
                    $ins = Users::where('id', $user->id)->first();
                    $ins->BCH_addr = $address;
                    $ins->save();
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //user_transaction details
    function user_transaction_details(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $user_id = $request['user_id'];
                // check_live_address($user_id);
                $currency = $request['currency'];
                $withdrawal_amount = $request['amount'];
                $type = $request['type'];

                //user record
                $User = Users::where('id', $user_id)->first();

                $btc_add = $User->BTC_addr;
                $bchabc_add = $User->BCHABC_addr;
                $bchsv_add = $User->BCHSV_addr;
                $eth_add = $User->ETH_addr;
                $xrp_add = $User->xrp_desttag;
                $xdc_add = $User->XDC_addr;
                $xdce_add = $User->XDCE_addr;
                $et_add = $User->ET_addr;
                $usdt_add = $User->USDT_addr;
                $usdc_add = $User->USDC_addr;

                //for btc explorer deposit
                if ($btc_add) {
                    $BTC_explorer = get_btcDeposit_user($btc_add);
                } else {
                    $BTC_explorer = 0;
                }


                // for bch explorer deposit
                // $BCH_explorer = get_bchDeposit_user($bch_add);

                //for eth explorer deposit
                $ETH_explorer = get_ethDeposit_user($eth_add);

                //for xrp explorer deposit
                $XRP_explorer = get_xrpDeposit_user($xrp_add);

                //for xdc  explorer deposit
                $XDC_explorer = get_xdcDeposit_user($xdc_add);

                //for xdce explorer deposit
                $XDCE_explorer = get_xdceDeposit_user($xdce_add);

                //for usdc explorer deposit
                $USDC_explorer = get_erc20Deposit_user($usdc_add, '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', 6);

                // $ET_explorer = get_etDeposit_user($et_add);
                $ET_explorer = '0';

                // $USDT_explorer = get_usdtDeposit_user($usdt_add);

                //Explorer_deposit array
                $explorer = array('BTC' => $BTC_explorer, 'BCH' => 'under verification', 'BCHSV' => 'under verification', 'USDC' => $USDC_explorer, 'ETH' => $ETH_explorer, 'XRP' => $XRP_explorer, 'XDC' => $XDC_explorer, 'XDCE' => $XDCE_explorer, 'ET' => $ET_explorer, 'USDT' => 'under verification');

                //for xdc withdrawal
                $xdc_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'XDC')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for xdce withdrawal
                $xdce_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'XDCE')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for btc withdrawal
                $btc_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'BTC')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for bch withdrawal
                $bch_withdrawal = Transaction::where('user_id', $user_id)->whereIn('currency_name', ['BCH', 'BCHABC'])->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for bchsv withdrawal
                $bchsv_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'BCHSV')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for eth withdrawal
                $eth_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'ETH')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for xrp withdrawal
                $xrp_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'XRP')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for et withdrawal
                $et_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'ET')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for usdt withdrawal
                $usdt_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'USDT')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for usdc withdrawal
                $usdc_withdrawal = Transaction::where('user_id', $user_id)->where('currency_name', 'USDC')->
                where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');

                //for withdrawal
                $withdraw = array('BTC' => $btc_withdrawal, 'BCH' => $bch_withdrawal, 'BCHSV' => $bchsv_withdrawal, 'ETH' => $eth_withdrawal, 'XRP' => $xrp_withdrawal, 'XDC' => $xdc_withdrawal, 'XDCE' => $xdce_withdrawal, 'ET' => $et_withdrawal, 'USDT' => $usdt_withdrawal, 'USDC' => $usdc_withdrawal);

                //for userbalance
                $Userbalance = UserBalance::where('user_id', $user_id)->first();

                //for ico Transaction
                $ico_transactions = ICOTrade::where('user_id', $user_id)->where('Status', 'Completed')->get();

                //ico stats
                $eth_spent_ico = ICOTrade::where('user_id', $user_id)
                    ->where('Status', 'Completed')->where('SecondCurrency', 'ETH')->sum('Amount');

                $xrp_spent_ico = ICOTrade::where('user_id', $user_id)
                    ->where('Status', 'Completed')->where('SecondCurrency', 'XRP')->sum('Amount');

                $btc_spent_ico = ICOTrade::where('user_id', $user_id)
                    ->where('Status', 'Completed')->where('SecondCurrency', 'BTC')->sum('Amount');

                $bch_spent_ico = ICOTrade::where('user_id', $user_id)
                    ->where('Status', 'Completed')->where('SecondCurrency', 'BCH')->sum('Amount');

                $buy_xdce_ico = ICOTrade::where('user_id', $user_id)
                    ->where('Status', 'Completed')->sum('Total');

                $ico = array('ETH' => $eth_spent_ico, 'BTC' => $btc_spent_ico, 'BCH' => $bch_spent_ico, 'XRP' => $xrp_spent_ico, 'XDCE' => $buy_xdce_ico);


                //user withdrawal transaction
                $user_withdrawal = Transaction::where('user_id', $user_id)->
                where('type', 'Withdraw')->where('status', 'Completed')->get();

                //user deposit transaction
                $user_deposit = Transaction::where('user_id', $user_id)->
                where('type', 'Deposit')->where('status', 'Completed')->get();

                //Referral Bonus
                $referrer = ReferralEarning::where('referrer_id', $user_id)->get();
                $referred = ReferralEarning::where('referred_id', $user_id)->get();
                $referred_users = ExtraBonus::where('user_id', $user_id)->get();

                $referrer_bonus = ReferralEarning::where('referrer_id', $user_id)->where('referrer_status', '=', '1')->sum('referrer_bonus');
                $referred_bonus = ReferralEarning::where('referred_id', $user_id)->where('referred_status', '=', '1')->sum('referred_bonus');
                $referred_users_bonus = ExtraBonus::where('user_id', $user_id)->where('status', '=', '1')->sum('bonus');
                $referral_bonus = $referrer_bonus + $referred_bonus + $referred_users_bonus;
                $referral_bonus = number_format($referral_bonus, '0', '.', ',');

                $buy_trade = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('status', 'completed')
                    ->orderBy('id', 'desc')->get();

                $sell_trade = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('status', 'completed')
                    ->orderBy('id', 'desc')->get();

                $pending_trade = Trade::where('user_id', $user_id)->whereIn('status', ['active', 'partially'])
                    ->orderBy('id', 'desc')->get();

            //    $total_xdc_buy = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('status', 'completed')->sum('original_qty');
            //    $total_xdc_sell = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('status', 'completed')->sum('original_qty');
            //    $total_intrade_xdc = Trade::where('user_id', $user_id)->where('type', 'Sell')->whereIn('status', ['active', 'partially'])->sum('updated_qty');

            //    //btc
            //    $total_btc_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BTC')->where('status', 'completed')->sum('updated_total');
            //    $total_btc_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-BTC')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_btc = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BTC')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //eth
            //    $total_eth_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-ETH')->where('status', 'completed')->sum('updated_total');
            //    $total_eth_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-ETH')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_eth = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-ETH')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //xrp
            //    $total_xrp_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-XRP')->where('status', 'completed')->sum('updated_total');
            //    $total_xrp_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-XRP')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_xrp = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-XRP')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //bch
            //    $total_bch_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BCH')->where('status', 'completed')->sum('updated_total');
            //    $total_bch_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-BCH')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_bch = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BCH')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //bchabc
            //    $total_bchabc_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BCHABC')->where('status', 'completed')->sum('updated_total');
            //    $total_bchabc_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-BCHABC')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_bchabc = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BCHABC')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //bchsv
            //    $total_bchasv_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BCHSV')->where('status', 'completed')->sum('updated_total');
            //    $total_bchsv_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-BCHSV')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_bchsv = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-BCHSV')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //xdce
            //    $total_xdce_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-XDCE')->where('status', 'completed')->sum('updated_total');
            //    $total_xdce_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-XDCE')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_xdce = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-XDCE')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //et
            //    $total_et_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-ET')->where('status', 'completed')->sum('updated_total');
            //    $total_et_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-ET')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_et = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-ET')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //usdt
            //    $total_usdt_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-USDT')->where('status', 'completed')->sum('updated_total');
            //    $total_usdt_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-USDT')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_usdt = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-USDT')->whereIn('status', ['active', 'partially'])->sum('total');

            //    //usdc
            //    $total_usdc_sell = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-USDC')->where('status', 'completed')->sum('updated_total');
            //    $total_usdc_buy = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('pair', 'XDC-USDC')->where('status', 'completed')->sum('updated_total');
            //    $total_intrade_usdc = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('pair', 'XDC-USDC')->whereIn('status', ['active', 'partially'])->sum('total');

                //xdc
                $total_xdc_sell = get_user_sell($user_id, 'XDC');
                $total_xdc_buy = get_user_buy($user_id, 'XDC');
                $total_intrade_xdc = get_user_intradebalance($user_id, 'XDC');

                //btc
                $total_btc_sell = get_user_sell($user_id, 'BTC');
                $total_btc_buy = get_user_buy($user_id, 'BTC');
                $total_intrade_btc = get_user_intradebalance($user_id, 'BTC');

                //eth
                $total_eth_sell = get_user_sell($user_id, 'ETH');
                $total_eth_buy = get_user_buy($user_id, 'ETH');
                $total_intrade_eth = get_user_intradebalance($user_id, 'ETH');

                //xrp
                $total_xrp_sell = get_user_sell($user_id, 'XRP');
                $total_xrp_buy = get_user_buy($user_id, 'XRP');
                $total_intrade_xrp = get_user_intradebalance($user_id, 'XRP');

                //bch
                $total_bch_sell = get_user_sell($user_id, 'BCH');
                $total_bch_buy = get_user_buy($user_id, 'BCH');
                $total_intrade_bch = get_user_intradebalance($user_id, 'BCH');

                //bchabc
                $total_bchabc_sell = get_user_sell($user_id, 'BCHABC');
                $total_bchabc_buy = get_user_buy($user_id, 'BCHABC');
                $total_intrade_bchabc = get_user_intradebalance($user_id, 'BCHABC');

                //bchsv
                $total_bchasv_sell = get_user_sell($user_id, 'BCHSV');
                $total_bchsv_buy = get_user_buy($user_id, 'BCHSV');
                $total_intrade_bchsv = get_user_intradebalance($user_id, 'BCHSV');

                //xdce
                $total_xdce_sell = get_user_sell($user_id, 'XDCE');
                $total_xdce_buy = get_user_buy($user_id, 'XDCE');
                $total_intrade_xdce = get_user_intradebalance($user_id, 'XDCE');

                //et
                $total_et_sell = get_user_sell($user_id, 'ET');
                $total_et_buy = get_user_buy($user_id, 'ET');
                $total_intrade_et = get_user_intradebalance($user_id, 'ET');

                //usdt
                $total_usdt_sell = get_user_sell($user_id, 'USDT');
                $total_usdt_buy = get_user_buy($user_id, 'USDT');
                $total_intrade_usdt = get_user_intradebalance($user_id, 'USDT');

                //usdc
                $total_usdc_sell = get_user_sell($user_id, 'USDC');
                $total_usdc_buy = get_user_buy($user_id, 'USDC');
                $total_intrade_usdc = get_user_intradebalance($user_id, 'USDC');

                //buy trade sum

                $buy_total = array('XDC' => $total_xdc_buy, 'XDCE' => $total_xdce_buy, 'ETH' => $total_eth_buy, 'XRP' => $total_xrp_buy, 'BCH' => $total_bch_buy, 'BCHABC' => $total_bchabc_buy, "BCHSV" => $total_bchsv_buy, "BTC" => $total_btc_buy, "ET" => $total_et_buy, "USDT" => $total_usdt_buy, "USDC" => $total_usdc_buy);

                $sell_total = array('XDC' => $total_xdc_sell, 'XDCE' => $total_xdce_sell, 'ETH' => $total_eth_sell, 'XRP' => $total_xrp_sell, 'BCH' => $total_bch_sell, 'BCHABC' => $total_bchabc_sell, "BCHSV" => $total_bchasv_sell, 'BTC' => $total_btc_sell, "ET" => $total_et_sell, "USDT" => $total_usdt_sell, "USDC" => $total_usdc_sell);

                $intrade_total = array('XDC' => $total_intrade_xdc, 'XDCE' => $total_intrade_xdce, 'ETH' => $total_intrade_eth, 'XRP' => $total_intrade_xrp, 'BCH' => $total_intrade_bch, 'BCHABC' => $total_intrade_bchabc, "BCHSV" => $total_intrade_bchsv, 'BTC' => $total_intrade_btc, "ET" => $total_intrade_et, "USDT" => $total_intrade_usdt, "USDC" => $total_intrade_usdc);

                if ($type == 'PDF') {
                    $buy_trade = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('status', 'completed')
                        ->orderBy('id', 'desc')->get();

                    $sell_trade = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('status', 'completed')
                        ->orderBy('id', 'desc')->get();

                    $pending_trade = Trade::where('user_id', $user_id)->whereIn('status', ['active', 'partially'])
                        ->orderBy('id', 'desc')->get();

                    return view('panel.pdfview', ['ico' => $ico, 'ico_trade' => $ico_transactions, 'Buy_total' => $buy_total, 'Sell_total' => $sell_total, 'id' => $user_id, 'Deposit' => $user_deposit, 'Withdrawal' => $user_withdrawal, 'currency' => $currency, 'bal' => $Userbalance,
                        'explorer' => $explorer, 'withdraw' => $withdraw, 'buy_trade' => $buy_trade, 'sell_trade' => $sell_trade, 'pending_trade' => $pending_trade, 'Intrade_total' => $intrade_total, 'user' => $User, 'referred' => $referred, 'referrer' => $referrer, 'referred_users' => $referred_users, 'referral_bonus' => $referral_bonus]);
                } else {
                    //depend on currency
                    return view('panel.user_transaction_details', ['ico' => $ico, 'ico_trade' => $ico_transactions, 'Buy_total' => $buy_total, 'Sell_total' => $sell_total, 'id' => $user_id, 'Deposit' => $user_deposit, 'Withdrawal' => $user_withdrawal, 'currency' => $currency, 'bal' => $Userbalance,
                        'explorer' => $explorer, 'withdraw' => $withdraw, 'buy_trade' => $buy_trade, 'sell_trade' => $sell_trade, 'pending_trade' => $pending_trade, 'Intrade_total' => $intrade_total, 'user' => $User, 'referred' => $referred, 'referrer' => $referrer, 'referred_users' => $referred_users, 'referral_bonus' => $referral_bonus]);
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //opening balance of user
    public function users_opening_balance(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request['currency']) {
                    $result = DB::table('useropeningbalance')
                        ->join('enjoyer', 'useropeningbalance.user_id', '=', 'enjoyer.id')
                        ->orderBy('useropeningbalance.' . $request['currency'], 'desc')
                        ->select('useropeningbalance.*', 'enjoyer.id', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.ET_addr', 'enjoyer.USDT_addr', 'enjoyer.BCHSV_addr', 'enjoyer.USDC_addr')
                        ->paginate(25);
                } elseif ($request->isMethod('get')) {

                    $search = $request['search'];
                    $email = $request['email'];
                    $user_search_id = $request['user_search_id'];
                    $q = OpeningBalance::query();
                    $q->join('enjoyer', 'useropeningbalance.user_id', '=', 'enjoyer.id')->select('useropeningbalance.*', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.ET_addr', 'enjoyer.USDT_addr', 'enjoyer.BCHSV_addr', 'enjoyer.USDC_addr');

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }
                    if ($email) {
                        $spl = explode("@", $email);
                        $user1 = $spl[0];
                        $user2 = $spl[1];
                        $record = getByEmail($user1, $user2);

                        foreach ($record as $val) {
                            $user_id = $val->id;
                            $q->where('useropeningbalance.user_id', $user_id);
                        }
                    }
                    if ($user_search_id) {
                        $q->where('useropeningbalance.user_id', $user_search_id);
                    }
                    $result = $q->orderBy('useropeningbalance.id', 'desc')->paginate(25);
                } else {
                    $result = DB::table('useropeningbalance')
                        ->join('enjoyer', 'useropeningbalance.user_id', '=', 'enjoyer.id')
                        ->orderBy('useropeningbalance.user_id', 'asc')
                        ->select('useropeningbalance.*', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.ET_addr', 'enjoyer.USDT_addr', 'enjoyer.BCHSV_addr', 'enjoyer.USDC_addr')
                        ->paginate(25);
                }

                return view('panel.userbalance', ['result' => $result, 'Header' => 'Users Opening Balance']);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    //closing balance of user
    public function users_closing_balance(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request['currency']) {
                    $result = DB::table('useropeningbalance')
                        ->join('enjoyer', 'useropeningbalance.user_id', '=', 'enjoyer.id')
                        ->orderBy('useropeningbalance.' . $request['currency'], 'desc')
                        ->select('useropeningbalance.*', 'enjoyer.id', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.ET_addr', 'enjoyer.USDT_addr', 'enjoyer.BCHSV_addr', 'enjoyer.USDC_addr')
                        ->paginate(25);
                } elseif ($request->isMethod('get')) {

                    $search = $request['search'];
                    $email = $request['email'];
                    $user_search_id = $request['user_search_id'];
                    $q = OpeningBalance::query();
                    $q->join('enjoyer', 'useropeningbalance.user_id', '=', 'enjoyer.id')->select('useropeningbalance.*', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.ET_addr', 'enjoyer.USDT_addr', 'enjoyer.BCHSV_addr', 'enjoyer.USDC_addr');

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }
                    if ($email) {
                        $spl = explode("@", $email);
                        $user1 = $spl[0];
                        $user2 = $spl[1];
                        $record = getByEmail($user1, $user2);

                        foreach ($record as $val) {
                            $user_id = $val->id;
                            $q->where('useropeningbalance.user_id', $user_id);
                        }
                    }
                    if ($user_search_id) {
                        $q->where('useropeningbalance.user_id', $user_search_id);
                    }
                    $result = $q->orderBy('useropeningbalance.id', 'desc')->paginate(25);
                } else {
                    $result = DB::table('useropeningbalance')
                        ->join('enjoyer', 'useropeningbalance.user_id', '=', 'enjoyer.id')
                        ->orderBy('useropeningbalance.user_id', 'asc')
                        ->select('useropeningbalance.*', 'enjoyer.enjoyer_name', 'enjoyer.XDC_addr', 'enjoyer.XDCE_addr', 'enjoyer.BTC_addr', 'enjoyer.BCHABC_addr', 'enjoyer.XRP_addr', 'enjoyer.ETH_addr', 'enjoyer.ET_addr', 'enjoyer.USDT_addr', 'enjoyer.BCHSV_addr', 'enjoyer.USDC_addr')
                        ->paginate(25);
                }

                return view('panel.userbalance', ['result' => $result, 'Header' => 'Users Closing Balance']);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    //ico price update
    function update_ico_price(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $btc_price = $request['btc'];
                    $bch_price = $request['bch'];
                    $eth_price = $request['eth'];
                    $xrp_price = $request['xrp'];

                    //update price
                    $ico_rates = ICORate::all();

                    foreach ($ico_rates as $ico_rate) {
                        if ($ico_rate->SecondCurrency == 'BTC') {
                            $ico_rate->Amount = $btc_price;
                            $ico_rate->update();

                        } elseif ($ico_rate->SecondCurrency == 'BCH') {
                            $ico_rate->Amount = $bch_price;
                            $ico_rate->update();

                        } elseif ($ico_rate->SecondCurrency == 'ETH') {
                            $ico_rate->Amount = $eth_price;
                            $ico_rate->update();

                        } elseif ($ico_rate->SecondCurrency == 'XRP') {
                            $ico_rate->Amount = $xrp_price;
                            $ico_rate->update();

                        }
                    }
                    Session::flash('success', 'Price updated successfully.');
                    return redirect('prashaasak/ico_history');

                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function ftp_test()
    {
        try {
            $ftp_user_name = 'alphaexftp';
            $ftp_user_pass = 'AlpH$#4dFTP';
            $ftp_server = '78.129.212.213';
            // set up basic connection
            $conn_id = ftp_connect($ftp_server);

            //login with username and password
            $login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

            // check connection
            if ((!$conn_id) || (!$login_result)) {
                echo "FTP connection has failed!";
                echo "Attempted to connect to $ftp_server for user $ftp_user_name";
                exit;
            } else {

                echo "Connected to $ftp_server, for user $ftp_user_name";
            }
            // open some file for reading
            $file = '/home/rahulraj/te.html';
            $fp = fopen($file, 'r');

            // try to upload $file
            if (ftp_put($conn_id, "localfile.txt", $file, FTP_ASCII)) {
                echo "Successfully uploaded $file\n";
            } else {
                echo "There was a problem while uploading $file\n";
            }

// close the connection and the file handler
            ftp_close($conn_id);
            fclose($fp);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }


    function set_trade_cancel()
    {
        try {
            $active_trades = Trade::whereIn('status', ['active', 'partially'])->get();
            $updated_record = array();
            $i = 0;
            $ip = \Request::ip();
            foreach ($active_trades as $active_trade) {
                $user_id = $active_trade->user_id;
                $user = Users::where('id', $user_id)->first();
                $user_balance = UserBalance::where('user_id', $user_id)->first();
                $type = $active_trade->Type;
                $second_currency = $active_trade->secondCurrency;

                if ($type == 'Buy') {
                    $refund_currency = $active_trade->secondCurrency;
                    $refund_amount = $active_trade->Total;
                    $user_balance->$second_currency = $user_balance->$second_currency + $refund_amount;

                    $active_trade->status = 'cancelled';

                } else {
                    $refund_currency = 'XDC';
                    $refund_amount = $active_trade->Amount;
                    $user_balance->XDC = $user_balance->XDC + $refund_amount;
                    $active_trade->status = 'cancelled';

                }

                if ($active_trade->save()) {
                    $transid = 'TXD' . $user_id . time();
                    if ($user_balance->save()) {
                        $ins = new Transaction;
                        $ins->user_id = $user_id;
                        $ins->payment_method = 'Cryptocurrency Account';
                        $ins->transaction_id = $transid;
                        $ins->currency_name = 'XDC';
                        $ins->type = 'Updated';
                        $ins->transaction_type = '1';
                        $ins->amount = $user_balance->XDC + $refund_amount;

                        $ins->crypto_address = 'By Admin';
                        $ins->transfer_amount = $refund_amount;
                        $ins->fee = '0';
                        $ins->tax = '0';
                        $ins->verifycode = '1';
                        $ins->order_id = '0';
                        $ins->status = 'Completed';
                        $ins->cointype = '2';
                        $ins->payment_status = 'Cancelled_Trade';
                        $ins->paid_amount = '0';
                        $ins->wallet_txid = '';
                        $ins->ip_address = $ip;
                        $ins->verify = '1';
                        $ins->blocknumber = '';
                        $ins->save();

                        $record[$i] = array('Sr.No' => $i, 'user_id' => $user->id, 'user_name' => $user->enjoyer_name,
                            'trade_id' => $active_trade->id, 'type' => $type, 'Currency' => $refund_currency,
                            'Amount' => $refund_amount);
                    }
                }

                $i++;

            }
            return json_encode($record);
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function create_bch_all()
    {
        try {
            $ico = ICOTrade::where('Status', 'Completed')->sum('Total');
            echo $ico;
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function manage_node(Request $request, $currency = "")
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $currency = $currency ? $currency : 'XDC';
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'host' => 'required',
                        'port' => 'required',
                    ]);
                    $update = [
                        'host' => ownencrypt($request['host']),
                        'portnumber' => ownencrypt($request['port']),
                    ];
                    Wallet::where('type', $currency)->update($update);
                    Session::flash('success', 'Successfully Updated.');
//                    return redirect()->back();
                }
                $result = Wallet::where('type', $currency)->first();
                $uname = owndecrypt($result->XDC_username);
                $password = owndecrypt($result->XDC_password);
                $port = owndecrypt($result->portnumber);
                $host = owndecrypt($result->host);
                return view('panel.manage_node', ['currency' => $currency, 'uname' => $uname, 'password' => $password, 'port' => $port, 'host' => $host]);

            }

        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function trade_mapping(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('get')) {

                    $min = $request['min'];
                    $max = $request['max'];
                    $search = $request['search'];
                    $user_id = $request['user_id'];
                    $pair = $request['pair'];
                    $q = TradeMapping::query();
                    if ($min) {
                        $q->where('updated_at', '>=', $min);
                    }
                    if ($max) {
                        $q->where('updated_at', '<=', $max);
                    }

                    if ($pair == 'all' || $pair == "") {
                        $pair = get_all_pairs();
                    } else {
                        $pair = [$pair];
                    }

                    $q->whereIn('pair', $pair);

                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('unique_id', 'like', '%' . $search . '%')->Orwhere('triggered_price', 'like', '%' . $search . '%')->orWhere('triggered_qty', 'like', '%' . $search . '%')->orWhere('total', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->where('unique_id', 'LIKE', '%MTX%')->orderBy('id', 'desc')->paginate(25);
                } else {
                    $result = TradeMapping::where('unique_id', 'LIKE', '%MTX%')->orderBy('updated_at', 'desc')->paginate(25);
                }

                $pairs = Pair::all();
                return view('panel.trade_mapping', ['result' => $result, 'pairs' => $pairs]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function deleteaccount(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if (Session::get('alpha_id') == "1") {
                    $user_id = base64_decode($request['user_id']);
                    $user = Users::where('id', $user_id)->first();
                    if (isset($user)) {
                        $data = $user->attributesToArray();
//                        $data = array_except($data, ['id']);
                        $deleted_user = DeletedUsers::insert($data);
                        if ($deleted_user) {
                            $user->delete();
                            $return['status'] = '1';
                            $email = Session::get('alowner');
                            owner_activity($email, 'Delete Account id : ' . $user->id . ' name : ' . $user->enjoyer_name);
                            Session::flash('success', 'Account deleted for user ' . $user->enjoyer_name . ' id : ' . $user->id);
                            return json_encode($return);
                        } else {
                            $return['status'] = '0';
                            return json_encode($return);
                        }
                    } else {
                        $return['status'] = '0';
                        return json_encode($return);
                    }
                } else {
                    Session::flash('error', 'Sorry you are not authorised to complete this action.');
                    return redirect()->back();
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function non_email_verified(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {

                if ($request->isMethod('get')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $search = $request['search'];
                    $email = $request['email'];
                    $status = $request['status'];
                    $paging = $request['paging'];
                    $q = Users::query();
                    $q->where('verify_status', 2);
                    if ($min) {
                        $q->where('created_at', '>=', $min);
                    }
                    if ($max) {
                        $q->where('created_at', '<=', $max);
                    }
                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('id', 'like', '%' . $search . '%')->Orwhere('enjoyer_name', 'like', '%' . $search . '%');
                        });
                    }
                    if ($email) {
                        $spl = explode("@", $email);
                        $user1 = $spl[0];
                        $user2 = $spl[1];
                        $record = getByEmail($user1, $user2);

                        foreach ($record as $val) {
                            $user_id = $val->id;
                            $q->where('id', $user_id);
                        }
                    }
                    if ($status != '' && $status != 'all') {
                        $q->where('user_verified', $status);
                    }

                    $result = $q->orderBy('id', 'desc')->paginate($paging);
                } else {
                    $result = Users::orderBy('id', 'desc')->paginate(25);
                }

                return view('panel.email_verification', ['result' => $result]);
            }

        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function create_email_verification($id)
    {
        try {
            $get_user = Users::where('id', $id)->first();
            $activation_code = mt_rand(0000, 9999) . time();
            $get_user->activation_code = $activation_code;
            if ($get_user->update()) {
                $to = get_usermail($id);
                $subject = get_template('4', 'subject');
                $message = get_template('4', 'template');
                $mailarr = array(
                    '###USERNAME###' => $get_user->enjoyer_name,
                    '###LINK###' => url('userverification/' . $activation_code),
                    '###SITENAME###' => get_config('site_name'),
                );
                $message = strtr($message, $mailarr);
                $subject = strtr($subject, $mailarr);
                if (sendmail($to, $subject, ['content' => $message])) {
                    Session::flash('success', 'Email verification have been sent.');
                    return redirect()->back();
                };
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function erc20_requests(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Erc20Requests::all();
                return view('panel.erc20_requests', ['result' => $result]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function add_erc20_request(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $validator = Validator::make($request->all(), [
                            'name' => 'required',
                            'contract_address' => 'required',
                            'symbol' => 'required',
                            'token_decimals' => 'required|numeric',
                            'requested_by' => 'required'
                        ]
                    );
                    if ($validator->fails()) {
                        return redirect()->back()->withInput($request->all())->withErrors($validator);
                    }

                    $name = $request['name'];
                    $contract_address = $request['contract_address'];
                    $token_symbol = strtoupper($request['symbol']);
                    $token_decimals = $request['token_decimals'];

                    $result = Erc20Requests::where('contract_address', $contract_address)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a request for the provided contract address.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Erc20Details::where('contract_address', $contract_address)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have an ERC20 token listed for the provided contract address.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Erc20Requests::where('symbol', $token_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a request for the provided token symbol, please use different token symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Erc20Details::where('symbol', $token_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have an ERC20 token listed for the provided token symbol, please use different token symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $result = Currencies::where('currency_symbol', $token_symbol)->first();
                    if (isset($result)) {
                        Session::flash('error', 'We already have a coin listed for the provided token symbol, please use different token symbol.');
                        return redirect()->back()->withInput($request->all());
                    }

                    $new = new Erc20Requests();
                    $new->description = $name;
                    $new->contract_address = $contract_address;
                    $new->token_decimals = $token_decimals;
                    $new->symbol = $token_symbol;
                    $new->requested_by = $request['requested_by'];
                    $new->status = 'Pending';
                    $new->save();
                    Session::flash('success', 'Request submitted successfully.');
                    return redirect('prashaasak/erc20_requests');
                } else {
                    return view('panel.add_erc20_request');
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function view_erc20_request($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = Erc20Requests::where('id', $id)->first();
                return view('panel.view_erc20_request', ['result' => $result]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function confirm_erc20_request(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $result = Erc20Requests::where('id', $id)->first();
                    if (isset($result)) {
                        if ($result->status == 'Pending') {
                            if ($request['subbuton'] == 'Reject') {
                                $validator = Validator::make($request->all(), [
                                        'reason' => 'required'
                                    ]
                                );
                                if ($validator->fails()) {
                                    return redirect()->back()->withInput($request->all())->withErrors($validator);
                                }
                                $result->status = 'Rejected';
                                $result->save();
                                Session::flash('error', 'The listing request has been rejected.');
                                return redirect('prashaasak/erc20_requests');
                            } elseif ($request['subbuton'] == 'Accept') {

                                $validator = Validator::make($request->all(), [
                                        'deposit_fees' => 'required',
                                        'withdrawal_fees' => 'required'
                                    ]
                                );
                                if ($validator->fails()) {
                                    return redirect()->back()->withInput($request->all())->withErrors($validator);
                                }

                                $result->status = 'Accepted';

                                $contract_address = $result->contract_address;
                                $token_symbol = $result->symbol;

                                $check = Erc20Details::where('contract_address', $contract_address)->first();
                                if (isset($check)) {
                                    Session::flash('error', 'There is token listed with the provided contract address.');
                                    return redirect()->back();
                                }

                                $check = Erc20Details::where('symbol', $token_symbol)->first();
                                if (isset($check)) {
                                    Session::flash('error', 'There is token listed with the provided token symbol.');
                                    return redirect()->back();
                                }

                                $check = Currencies::where('currency_symbol', $token_symbol)->first();
                                if (isset($check)) {
                                    Session::flash('error', 'There is coin listed with the provided token symbol.');
                                    return redirect()->back();
                                }

                                $details = new Erc20Details();
                                $details->description = $result->description;
                                $details->symbol = $token_symbol;
                                $details->contract_address = $contract_address;
                                $details->token_decimals = $result->token_decimals;
                                if ($details->save()) {

                                    $check = Currencies::orderBy('unique_id', 'desc')->first();

                                    $currency = new Currencies();
                                    $currency->currency_symbol = $token_symbol;
                                    $currency->name = $result->description;
//                                    $currency->unique_id = $check->unique_id + 1;
                                    $currency->fiat_or_crypto = 1;
                                    if ($currency->save()) {
                                        $currency->unique_id = $currency->id;
                                        $currency->save();

                                        $pair = new Pair();
                                        $pair->pair = 'XDC-' . $token_symbol;
                                        $pair->type = 'trade';
                                        if ($pair->save()) {
                                            $pairstat = new PairStats();
                                            $pairstat->pair_id = $pair->id;
                                            $pairstat->volume = 0;
                                            $pairstat->low = 0;
                                            $pairstat->high = 0;
                                            $pairstat->change = 0;
                                            $pairstat->last = 0;
                                            $pairstat->quotevolume = 0;
                                            $pairstat->colour = 'GREEN';
                                            $pairstat->percent_change = 0;
                                            if ($pairstat->save()) {
                                                $fee = new Tradingfee();
                                                $fee->unique_id = 'PXDC' . $token_symbol;
                                                $fee->pair_id = $pair->id;
                                                $fee->pair = $pair->pair;
                                                $fee->sell_fee = '0.005';
                                                $fee->buy_fee = '0.005';
                                                if ($fee->save()) {
                                                    $tx_fee = new Transactionfee();
                                                    $tx_fee->unique_id = 'TR' . $token_symbol;
                                                    $tx_fee->currency_id = $currency->id;
                                                    $tx_fee->currency = $token_symbol;
                                                    $tx_fee->withdrawal_fee = $request['withdrawal_fees'];
                                                    $tx_fee->deposit_fee = $request['deposit_fees'];
                                                    if ($tx_fee->save()) {
                                                        $result->save();
                                                        Session::flash('success', $token_symbol . ' has been listed successfully.');
                                                        return redirect('prashaasak/erc20_requests');
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Session:
                                flash('error', 'Invalid request recieved.');
                                return redirect()->back()->withInput($request->all());
                            }
                        } else {
                            Session::flash('error', 'The provided id has already been processed.');
                            return redirect()->back()->withInput($request->all());
                        }
                    } else {
                        Session::flash('error', 'Incorrect Id provided.');
                        return redirect()->back()->withInput($request->all());
                    }
                }
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function referral(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $referrer_bonus = $request['referrer_bonus'];
                    $referred_bonus = $request['referred_bonus'];
                    $currency = $request['currency'];
                    $referral = ReferralBonus::where('id', 1)->first();
                    $referral->referrer_bonus = $referrer_bonus;
                    $referral->referred_bonus = $referred_bonus;
                    $referral->currency = $currency;
                    $referral->save();
                    Session::flash('success', 'Referral stats updated successfully.');
                }
                $referral = ReferralBonus::where('id', 1)->first();
                $currencies = Currencies::all();
                return view('panel.referral', ['referral' => $referral, 'currencies' => $currencies]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function view_referral_earnings(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $search = $request['search'];
                    $paging = $request['paging'];
                    $q = ReferralEarning::query();
                    if ($min) {
                        $q->where('created_at', '>=', $min);
                    }
                    if ($max) {
                        $q->where('created_at', '<=', $max);
                    }
                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('id', 'like', '%' . $search . '%')->Orwhere('referrer_id', 'like', '%' . $search . '%')->Orwhere('referred_id', 'like', '%' . $search . '%')->Orwhere('referrer_name', 'like', '%' . $search . '%')->Orwhere('referred_name', 'like', '%' . $search . '%')->Orwhere('referrer_email', 'like', '%' . $search . '%')->Orwhere('referred_email', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->orderBy('id', 'desc')->paginate($paging);
                } else {
                    $result = ReferralEarning::orderBy('id', 'desc')->paginate(25);
                }
                return view('panel.view_referral_earnings', ['result' => $result]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function add_referral(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'users' => 'required',
                        'bonus' => 'required',
                    ]);

                    $ins = new ReferralExtra();
                    $ins->users = $request['users'];
                    $ins->bonus = $request['bonus'];
                    $ins->status = 1;
//                    $ins->created_at = date('Y-m-d H:i:s');
                    if ($ins->save()) {
                        Session::flash('success', 'New Referral has been Successfully added');
                        return redirect('prashaasak/referral_extra');
                    }
                }
                return view('panel.add_referral', ['view' => 'add']);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function delete_referral($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $del = ReferralExtra::find($id);
                if ($del->delete()) {
                    Session::flash('success', 'Referral Successfully deleted');
                    return redirect('prashaasak/referral_extra');
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function status_referral($id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $upt = ReferralExtra::find($id);
                if ($upt->status == 1) {
                    $upt->status = '0';
                } else {
                    $upt->status = '1';
                }
                if ($upt->save()) {
                    Session::flash('success', 'Referral Successfully updated');
                    return redirect('prashaasak/referral_extra');
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function update_referral(Request $request, $id)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $this->validate($request, [
                        'users' => 'required',
                        'bonus' => 'required',
                    ]);

                    $ins = ReferralExtra::find($id);
                    $ins->users = $request['users'];
                    $ins->bonus = $request['bonus'];
                    if ($ins->save()) {
                        Session::flash('success', 'Referral Successfully updated');
                        return redirect('prashaasak/referral_extra');
                    }
                }
                $result = ReferralExtra::where('id', $id)->first();
                return view('panel.add_referral', ['result' => $result, 'view' => 'edit', 'id' => $id]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function referral_extra()
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                $result = ReferralExtra::orderBy('id', 'desc')->get();
                return view('panel.referral_extra', ['result' => $result]);
            }
        } catch (\Exception $e) {
            echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
        }
    }

    function extra_earnings(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $min = $request['min'];
                    $max = $request['max'];
                    $search = $request['search'];
                    $paging = $request['paging'];
                    $q = ExtraBonus::query();
                    if ($min) {
                        $q->where('created_at', '>=', $min);
                    }
                    if ($max) {
                        $q->where('created_at', '<=', $max);
                    }
                    if ($search) {
                        $q->where(function ($qq) use ($search) {
                            $qq->where('id', 'like', '%' . $search . '%')->Orwhere('user_id', 'like', '%' . $search . '%');
                        });
                    }

                    $result = $q->orderBy('id', 'desc')->paginate($paging);
                } else {
                    $result = ExtraBonus::orderBy('id', 'desc')->paginate(25);
                }
                return view('panel.extra_earnings', ['result' => $result]);
            }
        } catch (\Exception $e) {
            \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
            return view('errors.404');
        }
    }

    function send_balance_email()
    {
        try {
            $xdc_bal = get_admin_bal('XDC');
            $xdce_bal = get_admin_bal('XDCE');
            $m_xdc_bal = get_admin_bal('M-XDC');
            $eth_bal = get_admin_bal('ETH');
            $btc_bal = get_admin_bal('BTC');
            $bchabc_bal = get_admin_bal('BCHABC');
            $bchsv_bal = get_admin_bal('BCHSV');
            $usdt_bal = get_admin_bal('USDT');
            $usdc_bal = get_admin_bal('USDC');
            $xrp_bal = get_admin_bal('XRP');

            $user_balance_result = Balance::whereNotIn('user_id', ['12677', '12635'])->get();

            $pending_withdrwals = Transaction::where('status', '=', 'Pending')->where('type', '=', 'Withdraw')->get();

            $pending_withdrwals_xdc = $pending_withdrwals->where('currency_name', '=', 'XDC')->sum('amount');
            $pending_withdrwals_eth = $pending_withdrwals->where('currency_name', '=', 'ETH')->sum('amount');
            $pending_withdrwals_btc = $pending_withdrwals->where('currency_name', '=', 'BTC')->sum('amount');
            $pending_withdrwals_xdce = $pending_withdrwals->where('currency_name', '=', 'XDCE')->sum('amount');
            $pending_withdrwals_bchabc = $pending_withdrwals->where('currency_name', '=', 'BCHABC')->sum('amount');
            $pending_withdrwals_bchsv = $pending_withdrwals->where('currency_name', '=', 'BCHSV')->sum('amount');
            $pending_withdrwals_usdc = $pending_withdrwals->where('currency_name', '=', 'USDC')->sum('amount');
            $pending_withdrwals_usdt = $pending_withdrwals->where('currency_name', '=', 'USDT')->sum('amount');
            $pending_withdrwals_xrp = $pending_withdrwals->where('currency_name', '=', 'XRP')->sum('amount');

            $intrade_xdc = get_total_intradebalance('XDC');
            $intrade_eth = get_total_intradebalance('ETH');
            $intrade_btc = get_total_intradebalance('BTC');
            $intrade_xdce = get_total_intradebalance('XDCE');
            $intrade_bchabc = get_total_intradebalance('BCHABC');
            $intrade_bchsv = get_total_intradebalance('BCHSV');
            $intrade_usdc = get_total_intradebalance('USDC');
            $intrade_usdt = get_total_intradebalance('USDT');
            $intrade_xrp = get_total_intradebalance('XRP');

            $user_xdc = number_format($user_balance_result->sum('XDC') + $intrade_xdc + $pending_withdrwals_xdc, '4', '.', '');
            $user_eth = number_format($user_balance_result->sum('ETH') + $intrade_eth + $pending_withdrwals_eth, '4', '.', '');
            $user_btc = number_format($user_balance_result->sum('BTC') + $intrade_btc + $pending_withdrwals_btc, '4', '.', '');
            $user_xdce = number_format($user_balance_result->sum('XDCE') + $intrade_xdce + $pending_withdrwals_xdce, '4', '.', '');
            $user_bchabc = number_format($user_balance_result->sum('BCHABC') + $intrade_bchabc + $pending_withdrwals_bchabc, '4', '.', '');
            $user_bchsv = number_format($user_balance_result->sum('BCHSV') + $intrade_bchsv + $pending_withdrwals_bchsv, '4', '.', '');
            $user_usdc = number_format($user_balance_result->sum('USDC') + $intrade_usdc + $pending_withdrwals_usdc, '4', '.', '');
            $user_usdt = number_format($user_balance_result->sum('USDT') + $intrade_usdt + $pending_withdrwals_usdt, '4', '.', '');
            $user_xrp = number_format($user_balance_result->sum('XRP') + $intrade_xrp + $pending_withdrwals_xrp, '4', '.', '');

            $reserve_XDC = number_format(get_reserve_balance('XDC'), 4, '.', '');
            $reserve_M_XDC = number_format(get_reserve_balance('M-XDC'), 4, '.', '');
            $reserve_ETH = number_format(get_reserve_balance('ETH'), 4, '.', '');
            $reserve_BTC = number_format(get_reserve_balance('BTC'), 4, '.', '');
            $reserve_XDCE = number_format(get_reserve_balance('XDCE'), 4, '.', '');
            $reserve_BCHABC = number_format(get_reserve_balance('BCHABC'), 4, '.', '');
            $reserve_BCHSV = number_format(get_reserve_balance('BCHSV'), 4, '.', '');
            $reserve_USDC = number_format(get_reserve_balance('USDC'), 4, '.', '');
            $reserve_USDT = number_format(get_reserve_balance('USDT'), 4, '.', '');
            $reserve_XRP = number_format(get_reserve_balance('XRP'), 4, '.', '');
            $reserve_T_XDC = $reserve_M_XDC + $reserve_XDC + $reserve_XDCE;

            $total_xdc = $xdc_bal + $reserve_XDC;
            $total_xdce = $xdce_bal + $reserve_XDCE;
            $total_m_xdc = $m_xdc_bal + $reserve_M_XDC;
            $total_eth = $eth_bal + $reserve_ETH;
            $total_btc = $btc_bal + $reserve_BTC;
            $total_bchabc = $bchabc_bal + $reserve_BCHABC;
            $total_bchsv = $bchsv_bal + $reserve_BCHSV;
            $total_usdc = $usdc_bal + $reserve_USDC;
            $total_usdt = $usdt_bal + $reserve_USDT;
            $total_xrp = $xrp_bal + $reserve_XRP;

            $xdc_xdce_bal = $xdce_bal + $xdc_bal + $m_xdc_bal;
            $total_xdc_xdce = $total_xdc + $total_xdce + $total_m_xdc;
            $user_xdc_xdce = $user_xdc + $user_xdce;

            if ($total_xdc_xdce >= ($user_xdc_xdce * 0.9999) && $total_xdc_xdce <= ($user_xdc_xdce * 1.0001)) {
                $status_xdc = 'True';
                $status_xdce = 'True';
            } else {
                $status_xdc = 'False';
                $status_xdce = 'False';
            }

//            if ($total_xdc >= ($user_xdc * 0.999) && $total_xdc <= ($user_xdc * 1.001)) {
//                $status_xdc = 'True';
//            } else {
//                $status_xdc = 'False';
//            }

            if ($total_eth >= ($user_eth * 0.999) && $total_eth <= ($user_eth * 1.001)) {
                $status_eth = 'True';
            } else {
                $status_eth = 'False';
            }


            if ($total_btc >= ($user_btc * 0.999) && $total_btc <= ($user_btc * 1.001)) {
                $status_btc = 'True';
            } else {
                $status_btc = 'False';
            }

//            if ($total_xdce >= ($user_xdce * 0.999) && $total_xdce <= ($user_xdce * 1.001)) {
//                $status_xdce = 'True';
//            } else {
//                $status_xdce = 'False';
//            }

            if ($total_bchabc >= ($user_bchabc * 0.999) && $total_bchabc <= ($user_bchabc * 1.001)) {
                $status_bchabc = 'True';
            } else {
                $status_bchabc = 'False';
            }

            if ($total_bchsv >= ($user_bchsv * 0.999) && $total_bchsv <= ($user_bchsv * 1.001)) {
                $status_bchsv = 'True';
            } else {
                $status_bchsv = 'False';
            }

            if ($total_usdc >= ($user_usdc * 0.999) && $total_usdc <= ($user_usdc * 1.001)) {
                $status_usdc = 'True';
            } else {
                $status_usdc = 'False';
            }

            if ($total_usdt >= ($user_usdt * 0.999) && $total_usdt <= ($user_usdt * 1.001)) {
                $status_usdt = 'True';
            } else {
                $status_usdt = 'False';
            }

            if ($total_xrp >= ($user_xrp * 0.999) && $total_xrp <= ($user_xrp * 1.001)) {
                $status_xrp = 'True';
            } else {
                $status_xrp = 'False';
            }

            $to = ['murphy@xinfin.org', 'aakash@xinfin.org', 'don@indsoft.net', 'alkeshc07@gmail.com', 'patelbunti@gmail.com', 'raj@xinfin.org'];
//            $to = 'raj@xinfin.org';
            $subject = get_template('21', 'subject');
            $message = get_template('21', 'template');
            date_default_timezone_set('Asia/Kolkata');
            $mailarr = array(
                '###TIME###' => date('Y-m-d H:i:s') . ' IST',
                '###XDC###' => $xdc_bal,
                '###USERXDC###' => $user_xdc,
                '###RESERVEXDC###' => $reserve_XDC,
                '###STATUSXDC###' => $status_xdc,
                '###MXDC###' => $m_xdc_bal,
                '###USERMXDC###' => 0,
                '###RESERVEMXDC###' => $reserve_M_XDC,
                '###STATUSMXDC###' => $status_xdc,
                '###TXDC###' => $xdc_xdce_bal,
                '###USERTXDC###' => $user_xdc_xdce,
                '###RESERVETXDC###' => $reserve_T_XDC,
                '###STATUSTXDC###' => $status_xdc,
                '###ETH###' => $eth_bal,
                '###USERETH###' => $user_eth,
                '###RESERVEETH###' => $reserve_ETH,
                '###STATUSETH###' => $status_eth,
                '###BTC###' => $btc_bal,
                '###USERBTC###' => $user_btc,
                '###RESERVEBTC###' => $reserve_BTC,
                '###STATUSBTC###' => $status_btc,
                '###XDCE###' => $xdce_bal,
                '###USERXDCE###' => $user_xdce,
                '###RESERVEXDCE###' => $reserve_XDCE,
                '###STATUSXDCE###' => $status_xdce,
                '###BCHABC###' => $bchabc_bal,
                '###USERBCHABC###' => $user_bchabc,
                '###RESERVEBCHABC###' => $reserve_BCHABC,
                '###STATUSBCHABC###' => $status_bchabc,
                '###BCHSV###' => $bchsv_bal,
                '###USERBCHSV###' => $user_bchsv,
                '###RESERVEBCHSV###' => $reserve_BCHSV,
                '###STATUSBCHSV###' => $status_bchsv,
                '###USDC###' => $usdc_bal,
                '###USERUSDC###' => $user_usdc,
                '###RESERVEUSDC###' => $reserve_USDC,
                '###STATUSUSDC###' => $status_usdc,
                '###USDT###' => $usdt_bal,
                '###USERUSDT###' => $user_usdt,
                '###RESERVEUSDT###' => $reserve_USDT,
                '###STATUSUSDT###' => $status_usdt,
                '###XRP###' => $xrp_bal,
                '###USERXRP###' => $user_xrp,
                '###RESERVEXRP###' => $reserve_XRP,
                '###STATUSXRP###' => $status_xrp,
            );
            $message = strtr($message, $mailarr);
            $subject = strtr($subject, $mailarr);
            sendmail($to, $subject, ['content' => $message]);
            \Log::info(['mailarr', $mailarr]);
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            $to = 'raj@xinfin.org';
            $message = 'Today balance mail failed due to and error : ' . $e->getMessage() . ' ' . $e->getLine() . ' ' . $e->getFile();
            $subject = 'Balance mail failure.';
            sendmail($to, $subject, ['content' => $message]);
            return view('errors.404');
        }
    }

    function reserve_balances(Request $request)
    {
        try {
            if (Session::get('alpha_id') == "") {
                return redirect('prashaasak');
            } else {
                if ($request->isMethod('post')) {
                    $currencies = Currencies::all();
                    $validator = Validator::make($request->all(), [
                        'XDC' => 'required',
                        'M-XDC' => 'required',
                        'ETH' => 'required',
                        'BTC' => 'required',
                        'XDCE' => 'required',
                        'BCHABC' => 'required',
                        'BCHSV' => 'required',
                        'USDT' => 'required',
                        'USDC' => 'required',
                        'XRP' => 'required',
                    ]);
                    if ($validator->fails()) {
                        return redirect()->back()->withErrors($validator);
                    }
                    foreach ($currencies as $currency) {
                        $result = ReserveBalances::where('currency_symbol', $currency->currency_symbol)->first();
                        $result->amount = $request[$currency->currency_symbol];
                        $result->save();
                    }
                    $result = ReserveBalances::where('currency_symbol', 'M-XDC')->first();
                    $result->amount = $request['M-XDC'];
                    $result->save();
                    Session::flash('success', 'Reserve Balances Updated Successfully.');
                }
                $currencies = Currencies::all();
                return view('panel.reserve_balance', ['currencies' => $currencies]);

            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function transfer_xdce()
    {
        try {
//            if (Session::get('alpha_id') == "") {
//                return redirect('prashaasak');
//            }
//            else
//            {
            $admin = SiteSettings::where('id', 1)->first();
            $last_transaction_id = $admin->xdce_transaction;

            $last = Transaction::orderBy('id', 'desc')->first();
            $last_id = $last->id;

            if ($last_transaction_id == $last_id) {
                $last_transaction_id = 1;
            }

            $xdce_deposits = Transaction::where('id', '>=', $last_transaction_id)->where('currency_name', 'XDCE')->where('type', 'Deposit')->where('status', 'Completed')->groupBy('crypto_address')->orderBy('id', 'asc')->get();
            if (isset($xdce_deposits)) {
                $contract_address = '0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2';
                $admin_eth_address = decrypt(get_config('eth_address'));
                $admin_address = '0x90d1028a543412169946Ee34d384A6d0A450ef82';
                foreach ($xdce_deposits as $deposit) {
                    $address = $deposit->crypto_address;
                    $count = Users::where('XDCE_addr', $address)->first();
                    $token_bal = get_token_balance($address, $contract_address, '18');
                    if ($token_bal > 0) {
                        $eth_bal = getting_eth_balance($address);
                        $gas = get_estimate_gas($address, $admin_eth_address, $token_bal);
                        $record = XdcePass::where('public', $address)->first();
                        if (count($record) > 0) {
                            $password = $record->phrase;
                        } else {
                            $password = 'alphaex';
                        }
                        if ($eth_bal < $gas) {
//                            $gas = $gas - $eth_bal;
                            $test = unlock_account($address, $password);
                            \Log::info([$test, $address, 'Before test']);
                            if ($test == 'true') {
                                \Log::info([$test, $address, 'After test']);
                                $check = eth_transfer_erc20_admin($admin_address, 0.001, $address);
                                $status = check_tx_status_eth($check);
                                while ($status != "0x1") {
                                    $status = check_tx_status_eth($check);
                                    sleep(10);
                                }
                                $eth_bal1 = getting_eth_balance($address);
                                while ($eth_bal1 == $eth_bal) {
                                    $eth_bal1 = getting_eth_balance($address);
                                    sleep(10);
                                }
                            }
                        }
                        $hash = transfer_erc20($address, $token_bal, $admin_eth_address, $contract_address, '18', $password);
                        echo $hash . '  ' . $address . '<br>';
                        if ($hash != '' && $hash != null && $hash != 'error') {
                            $record = new Xdce_transfer;
                            $record->from_address = $address;
                            $record->hash = $hash;
                            $record->in_hash = $deposit->wallet_txid;
                            $record->amount = $token_bal;
                            $status = check_tx_status_eth($hash);
                            while ($status != "0x1") {
                                $status = check_tx_status_eth($hash);
                                sleep(10);
                            }
                            $record->remaining_balance = getting_eth_balance($address);
                            $record->user_id = $count->id;
                            $record->status = 'Completed';
                            $record->save();
                        }
                    }
                    if ($deposit->id < $last_id) {
                        $admin->xdce_transaction = $deposit->id;
                    } else {
                        $admin->xdce_transaction = 1;
                    }
                    $admin->save();
                }
            }
//            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function transfer_eth()
    {
        try {
//            if (Session::get('alpha_id') == "") {
//                return redirect('prashaasak');
//            }
//            else
//            {
            $eth_deposits = Transaction::where('currency_name', 'ETH')->where('type', 'Deposit')->where('status', 'Completed')->groupBy('crypto_address')->get();
            if (isset($eth_deposits)) {
                $admin_eth_address = decrypt(get_config('eth_address'));
//                $admin_address = '0x90d1028a543412169946Ee34d384A6d0A450ef82';
                foreach ($eth_deposits as $deposit) {
                    $address = $deposit->crypto_address;
                    $count = Users::where('ETH_addr', $address)->first();
//                    $token_bal = get_token_balance($address, $contract_address, '18');
//                    if ($token_bal > 0) {
//                        $eth_bal = getting_eth_balance($address);
//                        $gas = get_estimate_gas($address, $admin_eth_address, $token_bal);
//                        if ($eth_bal < $gas) {
//                            $gas = $gas - $eth_bal;
//                            $check = eth_transfer_erc20_admin($admin_address, $gas * 1.1, $address);
//                            $status = check_tx_status_eth($check);
//                            while ($status != "0x1") {
//                                $status = check_tx_status_eth($check);
//                                sleep(10);
//                            }
//                            $eth_bal1 = getting_eth_balance($address);
//                            while ($eth_bal1 == $eth_bal) {
//                                $eth_bal1 = getting_eth_balance($address);
//                                sleep(10);
//                            }
//                        }
//                        $record = XdcePass::where('public', $address)->first();
//                        if (count($record) > 0) {
//                            $password = $record->phrase;
//                        } else {
//                            if (count($count) > 0) {
//                                $password = owndecrypt($count->xinpass);
//                            } else {
//                                $password = 'alphaex';
//                            }
//                        }
//                        $hash = transfer_xdce($address, $token_bal, $admin_eth_address, $contract_address, '18', $password);
                    $ether_balance = getting_eth_balance($address);
                    if ($ether_balance > 0.01) {
                        $hash = eth_transfer_fun($address, $ether_balance, $admin_eth_address, '');
                    } else {
                        $hash = $ether_balance;
                    }
                    echo $hash . '  ' . $address . '<br>';
                    File::append($_SERVER["DOCUMENT_ROOT"] . '/new.txt', '<br>' . $hash . ' ' . $address);
//                    if ($hash != '' && $hash != null && $hash != 'error') {
//                        $record = new Xdce_transfer;
//                        $record->from_address = $address;
//                        $record->hash = $hash;
//                        $record->in_hash = $deposit->wallet_txid;
//                        $record->amount = $ether_balance;
//                        $status = check_tx_status_eth($hash);
//                        while ($status != "0x1") {
//                            $status = check_tx_status_eth($hash);
//                            sleep(10);
//                        }
//                        $record->remaining_balance = getting_eth_balance($address);
//                        $record->user_id = $count->id;
//                        $record->status = 'Completed';
//                        $record->save();
//                    }
                }
            }
//            }
        } catch (\Exception $e) {
            \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
            return view('errors.404');
        }
    }

    function test()
    {
//        echo ownencrypt('alphaexbtc').'<br>';
//        echo ownencrypt('AlpH861ExBtC15').'<br>';
//        echo ownencrypt('78.159.100.156').'<br>';
//        echo ownencrypt('9555').'<br>';
//        echo test();

        echo encrypt('3M4n1daBJZ34n5g6eBYmoCZAbJPSXDM5LG');
    }

    function currentDateTime()
    {
        $dateTime = date('Y-m-d H:i:s');
        $json_array = array('date' => $dateTime);
        echo json_encode($json_array);
    }

}
