<?php

use App\model\Admin;
use App\model\Balance;
use App\model\Country;
use App\model\Marketprice;
use App\model\Metacontent;
use App\model\SiteSettings;
use App\model\Trade;
use App\model\TradeMapping;
use App\model\Transaction;
use App\model\Useractivity;
use App\model\Users;
use App\model\Verification;
use App\model\Tradingfee;
use App\model\Transactionfee;
use App\model\ico;
use App\model\UserCurrencyAddresses;
use App\model\MinWithdrawal;
use App\model\Mintrade;
use App\model\Currencies;
use App\model\Pair;
use App\model\UserBalance;
use App\model\MaxAutoWithdraw;
use App\model\ReserveBalances;
use App\model\Charts;
use Firebase\JWT\JWT;

//use Mail;

function get_adminprofile($key)
{
    try {
        $id = Session::get('alpha_id');
        $result = Admin::where('id', $id)->first();
        return $result->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_superadmin($key)
{
    try {
        $result = Admin::where('id', 1)->first();
        return $result->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_config($key)
{
    try {
        $result = SiteSettings::where('id', 1)->first();
        return $result->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function admin_class($key = "")
{
    try {
        $uri = Request::segment(2);
        if ($uri == $key) {
            return "active";
        } else {
            return "";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function sendmail($emails, $subject, $data = "")
{
    try {
        Mail::send(['html' => 'emails.template'], $data, function ($message) use ($emails, $subject) {
            $message->to($emails)->from(get_config('contact_mail'), get_config('site_name'))->subject($subject);
            $message->replyTo('support@alphaex.net');
        });
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


function get_template($id, $key)
{
    try {
        $result = DB::table('email_template')->where('id', $id)->first();
        return $result->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }

}

function get_usermail($user_id)
{
    try {
        $result = Users::where('id', $user_id)->first();
        return decrypt($result->end_user1) . '@' . decrypt($result->end_user2);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_user_verified($user_id)
{
    try {
        $result = Users::where('id', $user_id)->first();
        $user_verified = $result->user_verified;

        if ($user_verified == 1) {
            return 'Verified';
        } else {
            return 'Unverified';
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'Unverified';
    }
}

function get_auto_withdrawal($user_id)
{
    try {
        $result = Users::where('id', $user_id)->first();
        $auto_withdrawal = $result->auto_withdrawal;

        if ($auto_withdrawal == 1) {
            return 'On';
        } else {
            return 'Off';
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'Off';
    }
}

function get_userbalance($user_id, $key)
{
    try {
        $result = DB::table('userbalance')->where('user_id', $user_id)->first();
        return $result->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_user_currencyaddress($user_id, $currency)
{
    try {
        $user = UserCurrencyAddresses::where('user_id', $user_id)->where('currency_name', $currency)->first();
        if (isset($user)) {
            return $user->currency_addr;
        } else {
            return "";
        }
    } catch (\Exception $e) {
        return "";
    }
}

function get_user_intradebalance($user_id, $key)
{
    try {
        if ($key == 'XDC')
            $result = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('firstCurrency', $key)->whereIn('status', ['active', 'partially'])->sum('updated_qty');
        else if ($key == 'BTC' || $key == 'ETH' || $key == 'XRP') {
            $buy_total = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('secondCurrency', $key)->whereIn('status', ['active', 'partially'])->sum('total');
            $sell_total = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('firstCurrency', $key)->whereIn('status', ['active', 'partially'])->sum('updated_qty');
            $result = $buy_total + $sell_total;
        } else
            $result = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('secondCurrency', $key)->whereIn('status', ['active', 'partially'])->sum('total');
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_user_buy($user_id, $curr)
{
    try {
        $buy_total = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('secondCurrency', $curr)->whereIn('status', ['completed', 'partially'])->sum('updated_total');
        $sell_total = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('firstCurrency', $curr)->whereIn('status', ['completed', 'partially'])->sum('original_qty');
        $result = $buy_total + $sell_total;
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_user_sell($user_id, $curr)
{
    try {
        $buy_total = Trade::where('user_id', $user_id)->where('type', 'Buy')->where('secondCurrency', $curr)->whereIn('status', ['completed', 'partially'])->sum('updated_total');
        $sell_total = Trade::where('user_id', $user_id)->where('type', 'Sell')->where('firstCurrency', $curr)->whereIn('status', ['completed', 'partially'])->sum('original_qty');
        $result = $buy_total + $sell_total;
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_user_deposit($user_id, $curr)
{
    try {
        $deposit = Transaction::where('user_id', $user_id)->where('currency_name', $curr)->where('type', 'Deposit')->where('status', 'Completed')->sum('amount');
        return $deposit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_user_withdraw($user_id, $curr)
{
    try {
        $withdraw = Transaction::where('user_id', $user_id)->where('currency_name', $curr)->where('type', 'Withdraw')->where('status', 'Completed')->sum('amount');
        return $withdraw;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_cointype($id = "")
{
    if ($id == 1) {
        return "BTC";
    } elseif ($id == 2) {
        return "ETH";
    } elseif ($id == 3) {
        return "XRP";
    } elseif ($id == 4) {
        return "XDC";
    }
}

function dashboard_usercount()
{
    try {
        return Users::count();
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function dashboard_totaltrans()
{
    try {
        return Trade::count();
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function dashbard_totalbtcprofit()
{
    try {
        $sum = DB::table('coin_theft')->where('theftCurrency', 'BTC')->sum('theftAmount');
        return $sum;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function dashbard_totalkyc()
{
    try {
        return Verification::count();
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function dashboard_ico_listing_count()
{
    try {
        return ico::where('status', 'Pending')->count();
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


function dasboard_chart_btc($currency)
{
    try {
        /*$result=DB::table('coin_theft')->select('updated_at','theftAmount')->where('theftCurrency',$currency)->get();*/
        $daily = "SELECT DATE(date) as dateval, SUM(theftAmount) as total FROM XDC_coin_theft where theftCurrency='$currency' GROUP BY YEAR(date), MONTH(date), DATE(date)";
        $result = DB::select(DB::raw($daily));
        $arr = "";
        if ($result) {
            foreach ($result as $val) {
                $millsec = strtotime($val->dateval) * 1000;
                $arr .= "[" . $millsec . "," . $val->total . "]";
                $arr .= ",";
            }
            echo $arr;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function getBrowser()
{
    try {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $browser = "Unknown Browser";

        $browser_array = array(
            '/msie/i' => 'Internet Explorer',
            '/firefox/i' => 'Firefox',
            '/safari/i' => 'Safari',
            '/chrome/i' => 'Chrome',
            '/edge/i' => 'Edge',
            '/opera/i' => 'Opera',
            '/netscape/i' => 'Netscape',
            '/maxthon/i' => 'Maxthon',
            '/konqueror/i' => 'Konqueror',
            '/mobile/i' => 'Handheld Browser',
        );

        foreach ($browser_array as $regex => $value) {

            if (preg_match($regex, $user_agent)) {
                $browser = $value;
            }

        }

        return $browser;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function getOS()
{
    try {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];

        $os_platform = "Unknown OS Platform";

        $os_array = array(
            '/windows nt 10/i' => 'Windows 10',
            '/windows nt 6.3/i' => 'Windows 8.1',
            '/windows nt 6.2/i' => 'Windows 8',
            '/windows nt 6.1/i' => 'Windows 7',
            '/windows nt 6.0/i' => 'Windows Vista',
            '/windows nt 5.2/i' => 'Windows Server 2003/XP x64',
            '/windows nt 5.1/i' => 'Windows XP',
            '/windows xp/i' => 'Windows XP',
            '/windows nt 5.0/i' => 'Windows 2000',
            '/windows me/i' => 'Windows ME',
            '/win98/i' => 'Windows 98',
            '/win95/i' => 'Windows 95',
            '/win16/i' => 'Windows 3.11',
            '/macintosh|mac os x/i' => 'Mac OS X',
            '/mac_powerpc/i' => 'Mac OS 9',
            '/linux/i' => 'Linux',
            '/ubuntu/i' => 'Ubuntu',
            '/iphone/i' => 'iPhone',
            '/ipod/i' => 'iPod',
            '/ipad/i' => 'iPad',
            '/android/i' => 'Android',
            '/blackberry/i' => 'BlackBerry',
            '/webos/i' => 'Mobile',
        );

        foreach ($os_array as $regex => $value) {

            if (preg_match($regex, $user_agent)) {
                $os_platform = $value;
            }

        }

        return $os_platform;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function last_activity($email, $activity, $id = 0)
{
    try {
        //$ip_address = $_SERVER['REMOTE_ADDR'];
        $ip = \Request::ip();
        $ins = [
            'user_email' => $email,
            'ip_address' => $ip,
            'activity' => $activity,
            'browser_name' => getBrowser(),
            'os_name' => getOS(),
            'user_id' => $id,
        ];
        if ($activity == 'Login') {
            $getdatetime = $today = date('Y-m-d H:i:s');
            //send mail to user
            $to = $email;
            $subject = get_template('17', 'subject');
            $message = get_template('17', 'template');
            $mailarr = array(
                '###SITENAME###' => get_config('site_name'),
                '###EMAIL###' => $email,
                '###NAME###' => get_user_details($id, 'enjoyer_name'),
                '###IP###' => $ip,
                '###TIME###' => $getdatetime,
                '###BROWSER###' => getBrowser(),
                '###OS###' => getOS(),
            );
            $message = strtr($message, $mailarr);
            $subject = strtr($subject, $mailarr);
//        sendmail($to, $subject, ['content' => $message]);
        }
        Useractivity::insert($ins);
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function front_class($key = "")
{
    try {
        $uri = Request::segment(1);
        if ($uri == $key) {
            return "active";
        } else {
            return "";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function second_class($key = "")
{
    try {
        $uri = Request::segment(2);
        if ($uri == $key) {
            return "active";
        } else {
            return "";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function second_selected($key = "")
{
    try {
        $uri = Request::segment(2);
        if ($uri == $key) {
            return "selected";
        } else {
            return "";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_otpnumber($user_id, $isd, $mobile, $activity, $otp_type)
{
    try {
        $rand = mt_rand(000000, 999999);
        $check = \App\model\OTP::where('user_id', $user_id)->count();
        if ($check > 0) {
            \App\model\OTP::where('user_id', $user_id)->delete();
        }
        $ins = ['user_id' => $user_id, 'isd' => $isd, 'mobile_no' => ownencrypt($mobile), 'otp' => ownencrypt($rand), 'activity' => $activity, 'type' => $otp_type];
        DB::table('otp')->insert($ins);
        return $rand;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_user_details($id, $key)
{
    try {
        $res = Users::where('id', $id)->first();
        return $res->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_fee_settings($key)
{
    try {
        $res = DB::table('fee_settings')->where('id', '1')->first();
        return $res->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//for ico mail
function ico_mail($userid, $amount, $txid, $currency)
{
    try {
        $to = get_usermail($userid);
        $username = get_user_details($userid, 'enjoyer_name');
        $subject = get_template('7', 'subject');
        $message = get_template('7', 'template');
        $mailarr = array(
            '###USERNAME###' => $username,
            '###CURRENCY###' => $currency,
            '###AMOUNT###' => $amount,
            '###TXD###' => $txid,
            '###STATUS###' => 'Completed',
            '###SITENAME###' => get_config('site_name'),
        );
        $message = strtr($message, $mailarr);
        $subject = strtr($subject, $mailarr);
        sendmail($to, $subject, ['content' => $message]);
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//get trade fee
function get_trade_fee($type, $pair)
{
    try {
        if ($type == 'Buy') {
            $trade_fee = Tradingfee::where('pair', $pair)->first();
            $buy_fee = $trade_fee->buy_fee;
            return $buy_fee;
        } else if ($type == 'Sell') {
            $trade_fee = Tradingfee::where('pair', $pair)->first();
            $sell_fee = $trade_fee->sell_fee;
            return $sell_fee;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function send_sms($to, $text)
{
    try {
        if ($to == '+12843410586') {
            $user_id = Session::get('alphauserid');
            $to_mail = ['raj@xinfin.org'];
            $subject = 'User trying to spam plivo.';
            $message = 'User ID : ' . $user_id . ' number : ' . $to . ' .';
            sendmail($to_mail, $subject, ['content' => $message]);
            return false;
        } else {
            $AUTH_ID = "MAOTZLZGI0ODGXZGM4MZ";
            $AUTH_TOKEN = "NDA5ZmJkY2NiODg3N2QyMGJjNzliOWNhYjIxMTZi";
            //$fromnum = "+919930403019";
//	$fromnum = "+6588769089";
            $account_details = plivo_account_details();
            $bal = $account_details->cash_credits;
            if ($bal <= 1) {
//            $to_mail = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org'];
                $to_mail = ['raj@xinfin.org', 'rahul@xinfin.org'];
                $subject = 'Plivo account balance low.';
                $message = 'Plivo account balance is low, please recharge. Current account balance : ' . $bal . '$';
                sendmail($to_mail, $subject, ['content' => $message]);
            }
            $fromnum = "+18604304028";
            $url = 'https://api.plivo.com/v1/Account/' . $AUTH_ID . '/Message/';
            $data = array("src" => "$fromnum", "dst" => "$to", "text" => "$text");
            $data_string = json_encode($data);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
            curl_setopt($ch, CURLOPT_USERPWD, $AUTH_ID . ":" . $AUTH_TOKEN);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            curl_close($ch);

            /*echo "<pre>";
                print_r(json_decode($response));*/

            return true;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function plivo_account_details()
{
    try {
        $AUTH_ID = "MAOTZLZGI0ODGXZGM4MZ";
        $AUTH_TOKEN = "NDA5ZmJkY2NiODg3N2QyMGJjNzliOWNhYjIxMTZi";
        //$fromnum = "+919930403019";
//	$fromnum = "+6588769089";
//        $fromnum = "+18604304028";
        $url = 'https://api.plivo.com/v1/Account/' . $AUTH_ID . "/";
//        $data = array("src" => "$fromnum", "dst" => "$to", "text" => "$text");
        $data_string = '';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 0);
//        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_USERPWD, $AUTH_ID . ":" . $AUTH_TOKEN);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array());
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        /*echo "<pre>";
            print_r(json_decode($response));*/

        return json_decode($response);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_country_name($country_id)
{
    try {
        $res = Country::where('id', $country_id)->first();
        return $res->nicename;
    } catch (\Exception $e) {
        return '';
    }
}

function ownencrypt($q)
{
    try {
        $cryptKey = 'xeahpla';
        $qEncoded = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($cryptKey), $q, MCRYPT_MODE_CBC, md5(md5($cryptKey))));
        return ($qEncoded);
        return $q;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function owndecrypt($q)
{
    try {
        $cryptKey = 'xeahpla';
        $qDecoded = rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($cryptKey), base64_decode($q), MCRYPT_MODE_CBC, md5(md5($cryptKey))), "\0");
        return ($qDecoded);
        return $q;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_document_status($user_id, $key)
{
    try {
        $res = Verification::where('user_id', $user_id)->first();
        if ($res) {
            return $res->$key;
        } else {
            return "";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function getDataURI($image, $mime = '')
{
    try {
        return 'data: ' . (function_exists('mime_content_type') ? mime_content_type($image) : $mime) . ';base64,' . base64_encode(file_get_contents($image));
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function checktfa_code($secret, $onecode)
{
    try {
        include app_path() . '/Googleauthenticator.php';
        $ga = new \Googleauthenticator();
        if ($ga->verifyCode($secret, $onecode, 3)) {
            return "1";
        } else {
            return "0";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_estusd_price($currency, $amt)
{
    try {
        $res = Marketprice::where('currency', $currency)->first();
        $getusd = $res->USD;
        $retres = $getusd * $amt;
        return (float)$retres;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_live_estusd_price($cur, $amount)
{
    try {
        $url = "https://api.bitfinex.com/v2/ticker/" . $cur;
        $result = file_get_contents($url);
        $res = json_decode($result);
        $price = $res[6];
        return $price * $amount;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function check_live_address($userid)
{
    try {
        $xdc = get_user_details($userid, 'XDC_addr');
        $eth = get_user_details($userid, 'ETH_addr');
        $btc = get_user_details($userid, 'BTC_addr');
        $xdce = get_user_details($userid, 'XDCE_addr');
        $xrp_tag = get_user_details($userid, 'xrp_desttag');

        $bch = get_user_details($userid, 'BCHABC_addr');
        $bchsv = get_user_details($userid, 'BCHSV_addr');
//        $et = get_user_details($userid,'ET_addr');

        $usdt = get_user_details($userid, 'USDT_addr');

        $usdc = get_user_details($userid, 'USDC_addr');

        $email = get_usermail($userid);
        $phone = get_user_details($userid, 'mobile_no');
        if ($phone == "" || $phone == null) {
            $phone = "";
        } else {
            $phone = owndecrypt($phone);
        }
        $pass = owndecrypt(get_user_details($userid, 'xinpass'));

        if ($xdc == "") {
            $xdcaddr = signup_XDC($email, $phone, $pass);
            $ins = Users::where('id', $userid)->first();
            $ins->XDC_addr = $xdcaddr->public;
            $ins->save();
            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDC')->first();
            if ($count != null) {
                $count->currency_addr = $xdcaddr->public;
                $count->save();
            } else {
                $addr = new UserCurrencyAddresses;
                $addr->user_id = $userid;
                $addr->currency_id = 1;
                $addr->currency_name = 'XDC';
                $addr->currency_addr = $xdcaddr->public;
                $addr->save();
            }

        }
//        if($et == "")
//        {
//            $etaddress = signup_ET($email,$phone,$pass);
//            if ($etaddress->status == 'FAILED') {
//                Session::flash('error', 'Problem -' . $etaddress->message);
//                return redirect()->back();
//            } else {
//                $et_addr = $etaddress->public;
//            }
//            $ins = Users::where('id',$userid)->first();
//            $ins->ET_addr=$et_addr;
//            $ins->save();
//            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'ET')->first();
//            if ($count != null) {
//                $count->currency_addr = $etaddress->public;
//                $count->save();
//            } else {
//                $addr = new UserCurrencyAddresses;
//                $addr->user_id = $userid;
//                $addr->currency_id = 7;
//                $addr->currency_name = 'ET';
//                $addr->currency_addr = $etaddress->public;
//                $addr->save();
//            }
//        }
        if ($eth == "") {
            $val = create_eth_address();
            $ins = Users::where('id', $userid)->first();

            $ins->ETH_addr = $val;
            $ins->save();
            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'ETH')->first();
            if ($count != null) {
                $count->currency_addr = $val;
                $count->save();
            } else {
                $addr = new UserCurrencyAddresses();
                $addr->user_id = $userid;
                $addr->currency_id = 2;
                $addr->currency_name = 'ETH';
                $addr->currency_addr = $val;
                $addr->save();
            }
        }
//        if ($usdc == "") {
//            $val = create_eth_address();
//            $ins = Users::where('id', $userid)->first();
//
//            $ins->USDC_addr = $val;
//            $ins->save();
//            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDC')->first();
//            if ($count != null) {
//                $count->currency_addr = $val;
//                $count->save();
//            } else {
//                $addr = new UserCurrencyAddresses();
//                $addr->user_id = $userid;
//                $addr->currency_id = 10;
//                $addr->currency_name = 'USDC';
//                $addr->currency_addr = $val;
//                $addr->save();
//            }
//        }

        if ($xdce == "" || $xdce == 'error' || $xdce == null || $usdc == "" || $usdc == "error" || $usdc == null) {
            if ($xdce == "" && $usdc == "") {
                $val = create_eth_address();
                if ($val != '' && $val != 'error') {
                    $ins = Users::where('id', $userid)->first();
                    $ins->XDCE_addr = $val;
                    $ins->USDC_addr = $val;
                    $ins->save();
                    $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDCE')->first();
                    if ($count != null) {
                        $count->currency_addr = $val;
                        $count->save();
                    } else {
                        $addr = new UserCurrencyAddresses();
                        $addr->user_id = $userid;
                        $addr->currency_id = 5;
                        $addr->currency_name = 'XDCE';
                        $addr->currency_addr = $val;
                        $addr->save();
                    }
                    $count1 = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDC')->first();
                    if ($count1 != null) {
                        $count1->currency_addr = $val;
                        $count1->save();
                    } else {
                        $addr = new UserCurrencyAddresses();
                        $addr->user_id = $userid;
                        $addr->currency_id = 10;
                        $addr->currency_name = 'USDC';
                        $addr->currency_addr = $val;
                        $addr->save();
                    }
                }
            } else if ($xdce == "") {
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDC')->first();
                if ($count != null) {
                    $ins = Users::where('id', $userid)->first();
                    $ins->XDCE_addr = $count->currency_addr;
                    $ins->save();
                    $count1 = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDCE')->first();
                    if ($count1 != null) {
                        $count1->currency_addr = $count->currency_addr;
                        $count1->save();
                    } else {
                        $addr = new UserCurrencyAddresses();
                        $addr->user_id = $userid;
                        $addr->currency_id = 5;
                        $addr->currency_name = 'XDCE';
                        $addr->currency_addr = $count->currency_addr;
                        $addr->save();
                    }
                }
            } else if ($usdc == "") {
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDCE')->first();
                if ($count != null) {
                    $ins = Users::where('id', $userid)->first();
                    $ins->USDC_addr = $count->currency_addr;
                    $ins->save();
                    $count1 = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDC')->first();
                    if ($count1 != null) {
                        $count1->currency_addr = $count->currency_addr;
                        $count1->save();
                    } else {
                        $addr = new UserCurrencyAddresses();
                        $addr->user_id = $userid;
                        $addr->currency_id = 10;
                        $addr->currency_name = 'USDC';
                        $addr->currency_addr = $count->currency_addr;
                        $addr->save();
                    }
                }
            }
        }

        if ($btc == "") {
            $btcaddr = create_btc_address($userid);
            $ins = Users::where('id', $userid)->first();
            $ins->BTC_addr = $btcaddr;
            $ins->save();
            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'BTC')->first();
            if ($count != null) {
                $count->currency_addr = $btcaddr;
                $count->save();
            } else {
                $addr = new UserCurrencyAddresses;
                $addr->user_id = $userid;
                $addr->currency_id = 3;
                $addr->currency_name = 'BTC';
                $addr->currency_addr = $btcaddr;
                $addr->save();
            }
        }

        if ($usdt == "") {
            $btcaddr = create_usdt_address($userid);
            $ins = Users::where('id', $userid)->first();
            $ins->USDT_addr = $btcaddr;
            $ins->save();
            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDT')->first();
            if ($count != null) {
                $count->currency_addr = $btcaddr;
                $count->save();
            } else {
                $addr = new UserCurrencyAddresses;
                $addr->user_id = $userid;
                $addr->currency_id = 8;
                $addr->currency_name = 'USDT';
                $addr->currency_addr = $btcaddr;
                $addr->save();
            }
        }
        if ($xrp_tag == "") {
            $xrp_desttag = generateredeemString();
            $checktag = get_dest_userid($xrp_desttag);
            if ($checktag != "") {
                $xrp_desttag = generateredeemString();
            }
            $ins = Users::where('id', $userid)->first();
            $ins->xrp_desttag = $xrp_desttag;
            $ins->save();
            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XRP')->first();
            if ($count != null) {
                $count->currency_addr = $xrp_desttag;
                $count->save();
            } else {
                $addr = new UserCurrencyAddresses;
                $addr->user_id = $userid;
                $addr->currency_id = 6;
                $addr->currency_name = 'XRP';
                $addr->currency_addr = $xrp_desttag;
                $addr->save();
            }
        }
//        if ($xdce == "" || $xdce == null) {
//            $xdceaddr = signup_XDCE($email, $phone, $pass);
//            $ins = Users::where('id', $userid)->first();
//            $ins->XDCE_addr = $xdceaddr->public;
//            $ins->save();
//            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDCE')->first();
//            if ($count != null) {
//                $count->currency_addr = $xdceaddr->public;
//                $count->save();
//            } else {
//                $addr = new UserCurrencyAddresses;
//                $addr->user_id = $userid;
//                $addr->currency_id = 5;
//                $addr->currency_name = 'XDCE';
//                $addr->currency_addr = $xdceaddr->public;
//                $addr->save();
//            }
//        }
        if ($bch == "") {
            $bchaddress = create_bch_address($userid);
            $ins = Users::where('id', $userid)->first();
            $ins->BCHABC_addr = $bchaddress;
            $ins->save();
            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'BCHABC')->first();
            if ($count != null) {
                $count->currency_addr = $bchaddress;
                $count->save();
            } else {
                $addr = new UserCurrencyAddresses;
                $addr->user_id = $userid;
                $addr->currency_id = 4;
                $addr->currency_name = 'BCHABC';
                $addr->currency_addr = $bchaddress;
                $addr->save();
            }
        }
        if ($bchsv == "") {
            $bchaddress = create_bchsv_address($userid);
            $ins = Users::where('id', $userid)->first();
            $ins->BCHSV_addr = $bchaddress;
            $ins->save();
            $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'BCHSV')->first();
            if ($count != null) {
                $count->currency_addr = $bchaddress;
                $count->save();
            } else {
                $addr = new UserCurrencyAddresses;
                $addr->user_id = $userid;
                $addr->currency_id = 9;
                $addr->currency_name = 'BCHSV';
                $addr->currency_addr = $bchaddress;
                $addr->save();
            }
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return "";
    }
}

function get_usdt_transactionlist()
{
    try {
        require_once app_path('jsonRPCClient.php');
        $checkAddress = "";
        $bitcoin_username = 'USDTExNet';
        $bitcoin_password = 'USDTExNetCash@2018%';
        $bitcoin_portnumber = '9556';
        $bitcoin_host = '109.169.40.126';
        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");
        if ($bitcoin) {
            $block_info = $bitcoin->omni_listtransactions();
            return $block_info;
        }
    } catch (\Exception $exception) {
        return '';
    }
}

function getting_xdc_balance($address)
{
    try {
        $output = array();
        $return_var = -1;
        $server_path = $_SERVER["DOCUMENT_ROOT"];
        $toaddr = '0x' . substr($address, 3, 42);
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $bal = exec('cd ' . $server_path . '/erc20 && node xdc_balance.js ' . $address, $output, $return_var);
        } else {
            $bal = exec('cd ' . $server_path . '/public/erc20; node xdc_balance.js ' . $address, $output, $return_var);
        }

        return $bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '0';
    }
}

function getting_xdc_status($hash)
{
    try {
        $url = "https://rpc.xinfin.network";
        $data = array("jsonrpc" => "2.0", "method" => "eth_getTransactionReceipt", "params" => [$hash], "id" => 1);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        \Log::info(["sendTransaction" => $response]);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
            print_r($result);
        */
        return $result->result->status;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function transfer_xdctransfer($fromaddress, $amount, $toaddr, $key)
{
    try {

        $server_path = $_SERVER["DOCUMENT_ROOT"];
//        $amount = $amount* 1000000000000000000;
//        $hexa_amount = '0x'.dechex($amount);
        $toaddress = '0x' . substr($toaddr, 3, 42);

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $raw_transaction = exec('cd ' . $server_path . '/erc20 && node sign_rawTransaction.js ' . $toaddress . ' ' . $key . ' ' . $amount, $output, $return_var);
        } else {
            $raw_transaction = exec('cd ' . $server_path . '/public/erc20; node sign_rawTransaction.js ' . $toaddress . ' ' . $key . ' ' . $amount, $output, $return_var);
        }

        $url = "https://rpc.xinfin.network";
        $data = array("jsonrpc" => "2.0", "method" => "eth_sendRawTransaction", "params" => [$raw_transaction], "id" => 1);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        \Log::info(["sendTransaction" => $response]);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
            print_r($result);
        */
        return $result->result;

    } catch (\Exception $e) {
        \Log::error(["error" => $e->getFile() . ' ' . $e->getLine() . ' ' . $e->getMessage()]);
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function getfee($currency)
{
    try {

        $data = Transactionfee::where('currency', $currency)->first();
        $fee = $data->withdrawal_fee;
        return $fee;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function create_xdc_address($userid)
{

}

function update_user_balance($userid, $curr, $val)
{
    try {
        $upt = Balance::where('user_id', $userid)->first();
        $upt->$curr = $val;
        $upt->save();
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

// Register XDC
function signup_XDC($email, $phone, $password)
{
    try {
        $url = "http://alphaex.xinfin.org/api/account/create";
        $data = array('email' => $email, 'phone' => $phone, 'password' => $password, 'IsCheckOnlyEmailExistance' => '0', 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        if ($result->status == 'FAILED') {
            $result = login_xdc_fun($email, $password);
        }
        return $result;
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//Register ET
function signup_ET($email, $phone, $password)
{
    try {
        $url = "http://api.energyecochain.com/api/account/create";
        $data = array('email' => $email, 'phone' => $phone, 'password' => $password, 'IsCheckOnlyEmailExistance' => '0', 'MerchantCode' => 'MA', 'MerchantName' => 'AlphaExAPIET', 'APIKey' => 'f004a4c5-bdb7-4099-bbcd-9eb508-0d4993');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        if ($result->status == 'FAILED') {
            $result = login_et_fun($email, $password);
        }
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

// Register XDCE
function signup_XDCE($email, $phone, $password)
{
    try {
        $url = "http://xdce.xinfin.org/api/account/create";
        $data = array('email' => $email, 'phone' => $phone, 'password' => $password, 'IsCheckOnlyEmailExistance' => '0', 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        if ($result->status == 'FAILED') {
            $result = login_xdce_fun($email, $password);
        }
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return "";
    }
}

function get_market_price($currency, $currency1)
{
    try {
        $res = Marketprice::where('currency', $currency)->first();
        $result = $res->$currency1;
        return (float)$result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function create_eth_address()
{
    try {
        $password = "alphaex";
        $output = shell_exec('curl -H "Content-Type: application/json" -X POST --data' . " '" . '{"jsonrpc":"2.0","method":"personal_newAccount","params":["alphaex"],"id":1}' . "'" . ' 78.129.229.18:8545');
        $abc = json_decode($output);
        if ($abc) {
            $createAddress = $abc->result;
            $checkAddress_eth = $createAddress;
            return $checkAddress_eth;
        } else {
            return "";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function send_eth_fund($from_address, $amount, $purse)
{
    try {
        $address = '"' . trim($from_address) . '"';
        $to = '"' . trim($purse) . '"';

        /* $gasprice= exec('cd /var/www/html/public/crypto; node eth_gasprice.js ');*/

        $amount1 = exec('cd /var/www/html/public/crypto; node hex.js ' . $amount);

        $lastnumber = shell_exec('curl -X POST --data \'{"jsonrpc":"2.0","method":"personal_unlockAccount","params":[' . $address . ',"password",null],"id":1}\' "http://78.129.229.18:8545"');

        $output = shell_exec('curl -X POST --data \'{"jsonrpc":"2.0","method":"eth_sendTransaction","params":[{"from":' . $address . ',"to":' . $to . ',"value":"' . $amount1 . '"}],"id":22}\' "http://78.129.229.18:8545"');

        $abc = json_decode($output);
        /* echo "<pre>";
                        print_r($output);
        */
        $isvalid = $abc->result;
        return $isvalid;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

// xdcBalance

function get_livexdc_bal($address)
{
    try {
        $url = "http://alphaex.xinfin.org/api/balance";
        $data = array('address' => $address);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        try {
            return $result->balance;
        } catch (\Exception $e) {
            return 0;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

//function get_liveet_bal($address)
//{
//    try {
//        $url = "http://api.energyecochain.com/api/balance";
//        $data = array('address' => $address);
//        $data_string = json_encode($data);
//        $ch = curl_init($url);
//        curl_setopt($ch, CURLOPT_POST, true);
//        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
//        curl_setopt($ch, CURLOPT_HEADER, false);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//        $response = curl_exec($ch);
//        $result = json_decode($response);
//        curl_close($ch);
//        /*echo "<pre>";
//        print_r($result);*/
//        return $result->balance;
//    } catch (\Exception $e) {
//        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
//        return 0;
//    }
//}

function upload()
{
    try {
        $info = pathinfo($_FILES['userFile']['name']);
        $ext = $info['extension']; // get the extension of the file
        $newname = "newname." . $ext;

        $target = 'images/' . $newname;
        move_uploaded_file($_FILES['userFile']['tmp_name'], $target);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


//get xdceBalance
//function get_livexdce_bal($address) {
//
//    $url = "http://xdce.xinfin.org/api/balance";
//    $data = array('address' => $address);
//    $data_string = json_encode($data);
//    $ch = curl_init($url);
//    curl_setopt($ch, CURLOPT_POST, true);
//    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
//    curl_setopt($ch, CURLOPT_HEADER, false);
//    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
//    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
//    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//    $response = curl_exec($ch);
//    $result = json_decode($response);
//    curl_close($ch);
//    /*echo "<pre>";
//    print_r($result);*/
//    return $result->balance;
//}

function get_livexdce_bal($address)
{
    try {
//        $url = 'https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress=0x41AB1b6fcbB2fA9DCEd81aCbdeC13Ea6315F2Bf2&address=' . $address . '&tag=latest&apikey=CFZ6I82KM2ZRW5XXR84YZBXYAR2JRPM4RY';
//        $ch = curl_init($url);
//        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
//        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        $data = curl_exec($ch);
//
//        $dataresult = json_decode($data);
//
//        curl_close($ch);

        $eurl = 'https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress=0x41AB1b6fcbB2fA9DCEd81aCbdeC13Ea6315F2Bf2&address=' . $address . '&tag=latest&apikey=CFZ6I82KM2ZRW5XXR84YZBXYAR2JRPM4RY';

        $cObj = curl_init();
        curl_setopt($cObj, CURLOPT_URL, $eurl);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($cObj);
        $curlinfos = curl_getinfo($cObj);
        $result = json_decode($output);

        curl_close($cObj);
//
//        /*echo "<pre>";
//        print_r($result);*/
        try {
            return ($result->result) / 1000000000000000000;

        } catch (\Exception $e) {
            return 0;
        }

//        $bal = get_token_balance_api($address, '0x41AB1b6fcbB2fA9DCEd81aCbdeC13Ea6315F2Bf2', '18');
//        return $bal;

    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

// create btc address

function create_btc_address($userid)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $checkAddress = "";
        $gusermail = get_usermail($userid);
        $bitcoin_username = owndecrypt(get_wallet_keydetail('BTC', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('BTC', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('BTC', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('BTC', 'host'));

        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");
        if ($bitcoin) {
//            $checkAddress = $bitcoin->getaccountaddress($gusermail);
            $checkAddress = $bitcoin->getnewaddress($gusermail);
        }

        return $checkAddress;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//create usdt address
function create_usdt_address($userid)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $checkAddress = "";
        $gusermail = get_usermail($userid);
        $bitcoin_username = 'USDTExNet';
        $bitcoin_password = 'USDTExNetCash@2018%';
        $bitcoin_portnumber = '9556';
        $bitcoin_host = '109.169.40.126';
        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");
        if ($bitcoin) {
            $checkAddress = $bitcoin->getnewaddress();
        }

        return $checkAddress;
    } catch (\Exception $e) {
//        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return '';
    }
}

//create bch address
function create_bch_address($userid)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $checkAddress = "";
        $gusermail = get_usermail($userid);
        $bch_username = owndecrypt(get_wallet_keydetail('BCH', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCH', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCH', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCH', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");
        if ($bitcoin) {
            $checkAddress = $bitcoin->getaccountaddress($gusermail);
        }
        return $checkAddress;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//create bchsv address
function create_bchsv_address($userid)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $checkAddress = "";
        $gusermail = get_usermail($userid);
        $bch_username = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCHSV', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCHSV', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");
        if ($bitcoin) {
            $checkAddress = $bitcoin->getaccountaddress($gusermail);
        }
        return $checkAddress;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_userid_btcaddr($addr)
{
    try {
        $res = Users::where('BTC_addr', $addr)->first();
        return $res ? $res->id : 'no';
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_userid_usdtaddr($addr)
{
    try {
        $res = Users::where('USDT_addr', $addr)->first();
        return $res ? $res->id : 'no';
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//get last mined block from node
function get_last_block($ip, $port)
{
    try {
        $output = array();
        $return_var = -1;
        $sever_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $sever_path . '/crypto && node xdc_blockNumber.js ' . $ip . ' ' . $port, $output, $return_var);
        } else {
            $result = exec('cd ' . $sever_path . '/public/crypto; node xdc_blockNumber.js ' . $ip . ' ' . $port, $output, $return_var);
        }

        $out = json_decode($result);
        return $out;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_last_block_et($ip, $port)
{
    try {
        $output = array();
        $return_var = -1;
        $sever_path = $_SERVER["DOCUMENT_ROOT"];
        $result = exec('cd ' . $sever_path . '/crypto; node et_blockNumber.js ' . $ip . ' ' . $port, $output, $return_var);

        $out = json_decode($result);
        return $out;
    } catch (\Exception $exception) {
        echo $exception->getFile() . ' ' . $exception->getLine() . ' ' . $exception->getMessage();
    }
}

//get last mined etherscan block
function get_etherscan_block()
{
    try {

    } catch (\Exception $exception) {

    }
}

function get_userid_bchaddr($addr)
{
    try {
        $res = Users::where('BCHABC_addr', $addr)->first();
        return $res ? $res->id : 'no';
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_userid_bchsvaddr($addr)
{
    try {
        $res = Users::where('BCHSV_addr', $addr)->first();
        return $res ? $res->id : 'no';
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'no';
    }
}

function transfer_xdctoken($fromaddress, $amount, $toaddr, $userid, $pass)
{
    try {
        $email = get_usermail($userid);
        $url = "http://alphaex.xinfin.org/api/sendxdc";
        $data = array('xdc' => $amount, 'address' => $fromaddress, 'email' => $email, 'password' => $pass, 'account' => $toaddr, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
            print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//transfer et tokens
function transfer_ettoken($fromaddress, $amount, $toaddr, $userid, $pass)
{
    $email = get_usermail($userid);
    $url = "http://api.energyecochain.com/api/sendcoin";
    $data = array('coin' => $amount, 'address' => $fromaddress, 'email' => $email, 'password' => $pass, 'account' => $toaddr, 'MerchantCode' => 'MA', 'MerchantName' => 'AlphaExAPIET', 'APIKey' => 'f004a4c5-bdb7-4099-bbcd-9eb508-0d4993');
    $data_string = json_encode($data);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $result = json_decode($response);
    curl_close($ch);
    /*echo "<pre>";
        print_r($result);
    */
    return $result;

}

//transfer xdcetoken
function transfer_xdcetoken($fromaddress, $amount, $toaddr, $userid, $pass)
{
    try {
        $email = get_usermail($userid);
        $url = "http://xdce.xinfin.org/api/sendxdc";
        $data = array('xdc' => $amount, 'address' => $fromaddress, 'email' => $email, 'password' => $pass, 'account' => $toaddr, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
            print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_spendinglimit($userid)
{
    try {
        $today = date('Y-m-d');
        $btclimit = Transaction::where('user_id', $userid)->where('created_at', 'like', '%' . $today . '%')->where('currency_name', 'BTC')->Orwhere('second_currency', 'BTC')->sum('paid_amount');
        return $btclimit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function login_xdc_fun($email, $password)
{
    try {
        $url = "http://alphaex.xinfin.org/api/signin";
        $data = array('username' => $email, 'password' => $password, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function login_et_fun($email, $password)
{
    $url = "http://api.energyecochain.com/api/signin";
    $data = array('username' => $email, 'password' => $password, 'MerchantCode' => 'MA', 'MerchantName' => 'AlphaExAPIET', 'APIKey' => 'f004a4c5-bdb7-4099-bbcd-9eb508-0d4993');
    $data_string = json_encode($data);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $result = json_decode($response);
    curl_close($ch);
    /*echo "<pre>";
    print_r($result);*/
    return $result;
}

//login validation xdce
function login_xdce_fun($email, $password)
{
    try {
        $url = "http://xdce.xinfin.org/api/signin";
        $data = array('username' => $email, 'password' => $password, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return "";
    }
}

function get_recent_block()
{
    try {
        $eurl = 'https://api.etherscan.io/api?module=proxy&action=eth_blockNumber&apikey=YourApiKeyToken';

        $cObj = curl_init();
        curl_setopt($cObj, CURLOPT_URL, $eurl);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($cObj);
        $curlinfos = curl_getinfo($cObj);

        $result = json_decode($output);

        if ($result) {
            $block = (hexdec($result->result));
        } else {
            $block = 0;
        }
        return $block;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function sendBlocklagMail($name, $difference)
{
    try {
        $emails = array('anil@xinfin.org', 'rahul@xinfin.org', 'raj@xinfin.org',
            'hrishikesh@xinfin.org',
            'omkar@xinfin.org', 'ronak@xinfin.org');
        foreach ($emails as $email) {
            $to = $email;
            $subject = get_template('13', 'subject');
            $message = get_template('13', 'template');
            $mailarr = array(
                '###CURRENCY###' => $name,
                '###DIFFERENCE###' => $difference,
                '###LINK###' => url('userverification/' . ''),
                '###SITENAME###' => get_config('site_name'),

            );
            $message = strtr($message, $mailarr);
            $subject = strtr($subject, $mailarr);
            sendmail($to, $subject, ['content' => $message]);
        }

    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function eth_transfer_fun($fromaddr, $amount, $toaddr, $userid)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = "78.129.229.18";
        $wallet_port = "8545";
        $password = "alphaex";

        $server_path = $_SERVER["DOCUMENT_ROOT"];

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/crypto && node sent_eth.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/crypto; node sent_eth.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
        }

        $out = json_decode($result);
        if ($out->status == 0) {
            return 'error';
        } else {
            return $out->hash;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//for testing
function eth_transfer_fund($fromaddr, $amount, $toaddr, $userid)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = "78.129.229.18";
        $wallet_port = "8545";
        $password = "alphaex";

        $result = exec('cd /var/www/html/public/crypto; node sent_eth1.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
//    echo $result;0x06B3ebC6732542A5c6D3b84e5E5e73665311086F
        $out = json_decode($result);
//        echo $out;
        return $out;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function eth_transfer_fun_admin($fromaddr, $amount, $toaddr)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = "78.129.229.18";
        $wallet_port = "8545";
        $password = decrypt(get_config('eth_secret'));

        $server_path = $_SERVER["DOCUMENT_ROOT"];

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/crypto && node sent_eth_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/crypto; node sent_eth_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
        }

        /*echo "<pre>";
            print_r($result);
            echo "<br>";
            print_r($output);
            echo "<br>";
            print_r($return_var);
        */

        $out = json_decode($result);
        return $out->hash;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function blockip_list($ip)
{
    try {
        $check = DB::table('whitelist')->where('ip', $ip)->first();
        if (count($check) > 0) {
            abort(404);
            exit;
        }
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


function deposit_mail($userid, $amount, $txid, $currency)
{
    try {
        $to = get_usermail($userid);
        $username = get_user_details($userid, 'enjoyer_name');
        $subject = get_template('6', 'subject');
        $message = get_template('6', 'template');
        $mailarr = array(
            '###USERNAME###' => $username,
            '###CURRENCY###' => $currency,
            '###AMOUNT###' => $amount,
            '###TXD###' => $txid,
            '###STATUS###' => 'Completed',
            '###SITENAME###' => get_config('site_name'),
        );
        $message = strtr($message, $mailarr);
        $subject = strtr($subject, $mailarr);
        sendmail($to, $subject, ['content' => $message]);
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function verify_xdc_addr($addr)
{
    try {
        $url = "http://alphaex.xinfin.org/api/verifyxdcaddress";
        $data = array('account' => $addr, 'xdc' => '0', 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function verify_et_addr($addr)
{
    try {
        $url = "http://api.energyecochain.com//api/verifycoinaddress";
        $data = array('account' => $addr, 'coin' => '0', 'MerchantCode' => 'MA', 'MerchantName' => 'AlphaExAPIET', 'APIKey' => 'f004a4c5-bdb7-4099-bbcd-9eb508-0d4993');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify xdce address
function verify_xdce_addr($addr)
{
    try {
        $url = "http://xdce.xinfin.org/api/verifyxdceaddress";
        $data = array('account' => $addr, 'xdce' => '0', 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

// send btc

function btc_transfer_fun($toaddr, $btc_amount)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('BTC', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('BTC', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('BTC', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('BTC', 'host'));

        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");

        $isvalid = "";

        if ($bitcoin) {
            $isvalid = $bitcoin->sendtoaddress($toaddr, $btc_amount);
        }
        return $isvalid;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


//send usdt


// send bch
function bch_transfer_fun($toaddr, $bch_amount)
{
    try {
        require_once app_path('jsonRPCClient.php');

        $bch_username = owndecrypt(get_wallet_keydetail('BCH', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCH', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCH', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCH', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");

        $isvalid = "";

        if ($bitcoin) {
            $isvalid = $bitcoin->sendtoaddress($toaddr, $bch_amount);
        }
        return $isvalid;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

// send bchsv
function bchsv_transfer_fun($toaddr, $bch_amount)
{
    try {
        require_once app_path('jsonRPCClient.php');

        $bch_username = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCHSV', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCHSV', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");

        $isvalid = "";

        if ($bitcoin) {
            $isvalid = $bitcoin->sendtoaddress($toaddr, $bch_amount);
        }
        return $isvalid;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//btc wallet info
function get_btc_wallet_info()
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('BTC', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('BTC', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('BTC', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('BTC', 'host'));

        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");
        if ($bitcoin) {
            $checkAddress = $bitcoin->getwalletinfo();
        }

        return $checkAddress;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}


//usdt fund transfer
function usdt_fun_transfer($from, $to, $amount)
{
    try {
        require_once app_path('jsonRPCClient.php');
//        $bitcoin_username = owndecrypt(get_wallet_keydetail('USDT', 'XDC_username'));
//        $bitcoin_password = owndecrypt(get_wallet_keydetail('USDT', 'XDC_password'));
//        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('USDT', 'portnumber'));
//        $bitcoin_host = owndecrypt(get_wallet_keydetail('USDT', 'host'));

        $bitcoin_username = 'USDTExNet';
        $bitcoin_password = 'USDTExNetCash@2018%';
        $bitcoin_portnumber = '9556';
        $bitcoin_host = '109.169.40.126';
        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");
        $gas_address = '';

        if ($bitcoin) {
            $address = encrypt('13btDig1JPAbnmbUnDsBwZJXybnuheCixG');


            $usdt = $bitcoin->omni_listtransactions();
            return json_encode($usdt);
            $get_tx_fee = $bitcoin->estimatefee(8);


            $get_sender_trans = $bitcoin->omni_gettradehistoryforaddress($from);


            $create_payload = $bitcoin->omni_createpayload_simplesend(31, $amount);

            $list_unspent = $bitcoin->listunspent(6, 9999999);
            $unspent_array = array();
            $miner_array = array();
            if ($list_unspent != null) {
                $i = 0;
                $amount = 0;
                $hash = '';
                foreach ($list_unspent as $unspent) {

                    if ($amount < $get_tx_fee) {
                        if ($amount == 0) {
                            $hash = $bitcoin->omni_createrawtx_input("", $unspent['txid'], $i);
                            $miner_array[$i] = array('txid' => $unspent['txid'], 'vout' => $unspent['vout'], 'scriptPubKey' => $unspent['scriptPubKey'], 'value' => $unspent['amount']);

                        } else {
                            $hash = $bitcoin->omni_createrawtx_input($hash, $unspent['txid'], $i);
                            $miner_array[$i] = array('txid' => $unspent['txid'], 'vout' => $unspent['vout'], 'scriptPubKey' => $unspent['scriptPubKey'], 'value' => $unspent['amount']);
                        }
                    }

                    $i++;
                    $amount = $amount + $unspent['amount'];


                }

                $usdt_bal = ($bitcoin->omni_getbalance('1DrCCkSkh1QDh4BMX245e2oZBRjrXHFE2H', 31));


                $payload_output = $bitcoin->omni_createrawtx_opreturn($hash, $create_payload);


                $reciever_output = $bitcoin->omni_createrawtx_reference($payload_output, $to);

                $sign_trans = $bitcoin->signrawtransaction($reciever_output);

                print_r($miner_array);

                $re = $bitcoin->omni_createrawtx_change("0100000002de95b97cf4c67ec01485fd698ec154a325ff69dd3e58435d7024bae7f69534c20000000000ffffffffb3b60aaa69b860c9bf31e742e3b37e75a2a553fd0bebf8aaf7da0e9bb07316ee0200000000ffffffff020000000000000000166a146f6d6e690000000000000002000000000098968022020000000000001976a914ee692ea81da1b12d3dd8f53fd504865c9d843f5288ac00000000",
                    '[{"txid":"c23495f6e7ba24705d43583edd69ff25a354c18e69fd8514c07ec6f47cb995de","vout":0,"scriptPubKey":"76a914c6734676a08e3c6438bd95fa62c57939c988a17b88ac","value":0.001},{"txid":"ee1673b09b0edaf7aaf8eb0bfd53a5a2757eb3e342e731bfc960b869aa0ab6b3","vout":2,"scriptPubKey":"76a914c6734676a08e3c6438bd95fa62c57939c988a17b88ac","value":0.0083566}]',
                    "1K6JtSvrHtyFmxdtGZyZEF7ydytTGqasNc", 0.0006);

                echo $re;


                $result = json_encode(array('Unspent' => $list_unspent, 'fee' => $get_tx_fee,
                    'payload' => $create_payload, 'miner' => $miner_array, 'transaction' => $hash,
                    'payload_output' => $payload_output, 'reciever_output' => $reciever_output, 'sign' => $sign_trans));

            }


        } else {
            $result = 'error';
        }

        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//get usdt wallet balance
function usdt_bal()
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('USDT', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('USDT', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('USDT', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('USDT', 'host'));
        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");

        if ($bitcoin) {
            $address_list = $bitcoin->omni_getwalletbalances();
            $bal = 0;
            if ($address_list) {
                foreach ($address_list as $list) {
                    if ($list['propertyid'] == 31) {
                        $bal = $list['balance'];
                    }
                }
            }
            return $bal;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

//usdt admin transfer
function usdt_admin_transfer_fun($sender, $reciever_address, $bal)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('USDT', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('USDT', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('USDT', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('USDT', 'host'));
        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");

        if ($bitcoin) {
            \Log::error("bitcoin inside");
            $address = $bitcoin->omni_funded_send($sender, $reciever_address, 31, $bal, $sender);
            \Log::error("bitcoin outside" . $address);
            return $address;
        }

    } catch (\Exception $exception) {
        \Log::error([$exception->getMessage(), $exception->getFile(), $exception->getLine()]);
        return 'error';
    }

}

function usdt_transfer($sender, $admin_address)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('USDT', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('USDT', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('USDT', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('USDT', 'host'));
        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");

        if ($bitcoin) {

            \Log::error("bitcoin inside");
            $address = $bitcoin->omni_funded_sendall($sender, $admin_address, 1, $admin_address);
            \Log::error("bitcoin outside" . $address);
            return $address;
        }

    } catch (\Exception $exception) {
        \Log::error([$exception->getMessage(), $exception->getFile(), $exception->getLine()]);
        return 'error';
    }

}

//usdt wallet infoweb
function get_usdt_balance($addr)
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('USDT', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('USDT', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('USDT', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('USDT', 'host'));
        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");
        if ($bitcoin) {
            $result = $bitcoin->omni_getbalance($addr, 31);

            if ($result) {
                $bal = $result['balance'];
            } else {
                $bal = 0;
            }

        } else {
            $bal = 0;
        }

        return $bal;

    } catch (\Exception $exception) {
        $bal = 0;
        return $bal;
    }
}


//btc wallet info
function get_usdt_wallet_info()
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('USDT', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('USDT', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('USDT', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('USDT', 'host'));

        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");
        if ($bitcoin) {
            $checkAddress = $bitcoin->getwalletinfo();
        }

        return $checkAddress;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//bch wallet info
function get_bch_wallet_info()
{
    try {
        require_once app_path('jsonRPCClient.php');


        $bch_username = owndecrypt(get_wallet_keydetail('BCH', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCH', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCH', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCH', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");
        if ($bitcoin) {
            $checkAddress = $bitcoin->getwalletinfo();
        }

        return $checkAddress;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

//bch wallet info
function get_bchsv_wallet_info()
{
    try {
        require_once app_path('jsonRPCClient.php');

        $bch_username = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCHSV', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCHSV', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");
        if ($bitcoin) {
            $checkAddress = $bitcoin->getwalletinfo();
        }

        return $checkAddress;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

// create ripple address
function create_ripple_address()
{
    try {
        $output = array();
        $return_var = -1;
        $address = exec('cd /var/www/html/public/crypto; node xrp_createaddress.js ', $output, $return_var);
        return json_decode($address);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function check_ripple_balance()
{
    try {
        $output = array();
        $return_var = -1;
        $path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $address = exec('cd ' . $path . '/crypto && node xrp.js ', $output, $return_var);
        } else {
            $address = exec('cd ' . $path . '/public/crypto; node xrp.js ', $output, $return_var);
        }
        $result = json_decode($address);
        // \Log::info(["<<<<<",$result->xrpBalance]);
        $bal = $result->xrpBalance;
        return $bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }

}

// transaction list XRP
function get_list_transactions($address)
{
    try {
        $output = array();
        $return_var = -1;
        $server_path = $_SERVER["DOCUMENT_ROOT"];

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/crypto && node xrp_transactions.js ' . $address, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/crypto; node xrp_transactions.js ' . $address, $output, $return_var);
        }
        return json_decode($result);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function owner_activity($email, $activity)
{
    try {
        //$ip_address = $_SERVER['REMOTE_ADDR'];
        $ip = \Request::ip();
        $ins = [
            'user_email' => $email,
            'ip_address' => $ip,
            'activity' => $activity,
            'browser_name' => getBrowser(),
            'os_name' => getOS(),
        ];
        DB::table('owner_activity')->insert($ins);
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function getting_eth_balance($address)
{
    try {
        $output = array();
        $return_var = -1;
        $ip = "78.129.229.18";
        $port = "8545";
        $server_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $balance = exec('cd ' . $server_path . '/crypto && node eth_balance.js ' . $ip . ' ' . $port . ' ' . $address, $output, $return_var);
        } else {
            $balance = exec('cd ' . $server_path . '/public/crypto; node eth_balance.js ' . $ip . ' ' . $port . ' ' . $address, $output, $return_var);
        }
        $bal = $balance / 1000000000000000000;
        return $bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function getting_eth_block()
{
    try {
//    $output = array();
        $return_var = -1;
        $ip = "78.129.229.18";
        $port = "8545";

        $server_path = $_SERVER["DOCUMENT_ROOT"];

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $balance = exec('cd ' . $server_path . '/crypto && node eth_block.js ' . $ip . ' ' . $port . ' ', $return_var);
        } else {
            $balance = exec('cd ' . $server_path . '/public/crypto; node eth_block.js ' . $ip . ' ' . $port . ' ', $return_var);
        }
        $decode_balance = json_decode($balance);
        return $decode_balance;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_wallet_keydetail($type, $key)
{
    try {
        $result = DB::table('wallet')->where('type', $type)->first();
        return $result->$key;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
        return '';
    }
}

//get btc transactions
function get_btc_transactionlist()
{
    try {
        require_once app_path('jsonRPCClient.php');
        $bitcoin_username = owndecrypt(get_wallet_keydetail('BTC', 'XDC_username'));
        $bitcoin_password = owndecrypt(get_wallet_keydetail('BTC', 'XDC_password'));
        $bitcoin_portnumber = owndecrypt(get_wallet_keydetail('BTC', 'portnumber'));
        $bitcoin_host = owndecrypt(get_wallet_keydetail('BTC', 'host'));

        $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");

        return $bitcoin;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//get bch transactions
function get_bch_transactionlist()
{
    try {
        require_once app_path('jsonRPCClient.php');

        $bch_username = owndecrypt(get_wallet_keydetail('BCH', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCH', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCH', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCH', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");

        return $bitcoin;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//get bchsv transactions
function get_bchsv_transactionlist()
{
    try {
        require_once app_path('jsonRPCClient.php');

        $bch_username = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_username'));
        $bch_password = owndecrypt(get_wallet_keydetail('BCHSV', 'XDC_password'));
        $bch_portnumber = owndecrypt(get_wallet_keydetail('BCHSV', 'portnumber'));
        $bch_host = owndecrypt(get_wallet_keydetail('BCHSV', 'host'));

        $bitcoin = new jsonRPCClient("http://$bch_username:$bch_password@$bch_host:$bch_portnumber/");

        return $bitcoin;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_xrp_balance($address)
{
    try {
        $url = "https://data.ripple.com/v2/accounts/" . $address . "/balances?currency=XRP";
        $cObj = curl_init();
        curl_setopt($cObj, CURLOPT_URL, $url);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($cObj);
        $curlinfos = curl_getinfo($cObj);

        $result = json_decode($output);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

// trade helpers

function get_buy_market_rate($first, $second)
{
    try {
        $currency = $first . '-' . $second;
        $check = Trade::where(['pair' => $currency, 'type' => 'Sell'])->where(function ($query) {
            $query->where('status', 'active')->Orwhere('status', 'partially');
        })->min('price');
        /*$query = "SELECT Price FROM `XDC_trade_order` WHERE firstCurrency='$first' AND secondCurrency='$second' AND Type='Sell' AND (status='active' OR status='partially') ORDER BY id ASC LIMIT 1";
        $check = DB::select(DB::raw($query));*/

        if ($check > 0) {
            return $check;
        } else {
            return get_market_price($first, $second);
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_sell_market_rate($first, $second)
{
    try {
        $currency = $first . '-' . $second;
        $check = Trade::where(['pair' => $currency, 'type' => 'Buy'])->where(function ($query) {
            $query->where('status', 'active')->Orwhere('status', 'partially');
        })->max('price');
        /*$query = "SELECT Price FROM `XDC_trade_order` WHERE firstCurrency='$first' AND secondCurrency='$second' AND Type='Buy' AND (status='active' OR status='partially') ORDER BY id desc LIMIT 1";
        $check = DB::select(DB::raw($query));*/
        if ($check > 0) {
            return $check;
        } else {
            return get_market_price($first, $second);
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_trading_volume($first, $second, $userid)
{
    try {
        $currency = $first . '-' . $second;
        $fee = Trade::where(['pair' => $currency, 'user_id' => $userid])->sum('Total');
        return $fee;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function transfer_xdctokenadmin($fromaddress, $amount, $toaddr, $email, $pass)
{
    try {
        $url = "http://alphaex.xinfin.org/api/sendxdc";
        $data = array('xdc' => $amount, 'address' => $fromaddress, 'email' => $email, 'password' => $pass, 'account' => $toaddr, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
            print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//transfer et token admin
function transfer_ettokenadmin($fromaddress, $amount, $toaddr, $email, $pass)
{

    $url = "http://api.energyecochain.com/api/sendcoin";
    $data = array('coin' => $amount, 'address' => $fromaddress, 'email' => $email, 'password' => $pass, 'account' => $toaddr, 'MerchantCode' => 'MA', 'MerchantName' => 'AlphaExAPIET', 'APIKey' => 'f004a4c5-bdb7-4099-bbcd-9eb508-0d4993');
    $data_string = json_encode($data);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $result = json_decode($response);
    curl_close($ch);
    /*echo "<pre>";
        print_r($result);
    */
    return $result;

}

//transfer xdce token admin
function transfer_xdcetokenadmin($fromaddress, $amount, $toaddr, $email, $pass)
{
    try {
        $url = "http://xdce.xinfin.org/api/sendxdc";
        $data = array('xdc' => $amount, 'address' => $fromaddress, 'email' => $email, 'password' => $pass, 'account' => $toaddr, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function transfer_erc20admin($fromaddress, $amount, $toaddr, $contractaddress, $token_deciamls)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = '78.129.229.18';
        $wallet_port = '8545';
        $password = decrypt(get_config('eth_secret'));

        $server_path = $_SERVER["DOCUMENT_ROOT"];

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/erc && node send_erc20_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddress . ' ' . $toaddr . ' ' . $amount . ' ' . $contractaddress . ' ' . $password . ' ' . $token_deciamls, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/erc; node send_erc20_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddress . ' ' . $toaddr . ' ' . $amount . ' ' . $contractaddress . ' ' . $password . ' ' . $token_deciamls, $output, $return_var);
        }

//            echo "<pre>";
//            print_r($result);
//            echo "<br>";
//            print_r($output);
//            echo "<br>";
//            print_r($return_var);

        $out = json_decode($result);
        return $out->hash;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'error';
    }
}

function transfer_erc20($fromaddress, $amount, $toaddr, $contractaddress, $tokendecimal, $password)
{
    try {
        $wallet_ip = '78.129.229.18';
        $wallet_port = '8545';
        $server_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/erc && node send_erc20.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddress . ' ' . $toaddr . ' ' . $amount . ' ' . $contractaddress . ' ' . $password . ' ' . $tokendecimal, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/erc; node send_erc20.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddress . ' ' . $toaddr . ' ' . $amount . ' ' . $contractaddress . ' ' . $password . ' ' . $tokendecimal, $output, $return_var);
        }
        $out = json_decode($result);
        return $out->hash;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'error';
    }
}

function transfer_ripple_xrp($from_address, $from_secret, $to_addr, $amount, $tag = "")
{
    try {
        $output = array();
        $return_var = -1;
        $tag = $tag ? $tag : '123456';

        $server_path = $_SERVER["DOCUMENT_ROOT"];

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/crypto && node xrp_sent.js ' . $from_address . ' ' . $from_secret . ' ' . $to_addr . ' ' . $amount . ' ' . $tag, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/crypto; node xrp_sent.js ' . $from_address . ' ' . $from_secret . ' ' . $to_addr . ' ' . $amount . ' ' . $tag, $output, $return_var);
        }

        $res = json_decode($output[1]);
        return $res->txid;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_meta_title()
{
    try {
        $uri = Request::segment(1);
        $uri = $uri ? $uri : 'home';
        $check = Metacontent::where('link', $uri)->first();
        if ($check) {
            return $check->title;
        } else {
            $check1 = Metacontent::where('link', 'home')->first();
            return $check1->title;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_meta_description()
{
    try {
        $uri = Request::segment(1);
        $uri = $uri ? $uri : 'home';
        $check = Metacontent::where('link', $uri)->first();
        if ($check) {
            return $check->meta_description;
        } else {
            $check1 = Metacontent::where('link', 'home')->first();
            return $check1->meta_description;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_meta_keywords()
{
    try {
        $uri = Request::segment(1);
        $uri = $uri ? $uri : 'home';
        $check = Metacontent::where('link', $uri)->first();
        if ($check) {
            return $check->meta_keywords;
        } else {
            $check1 = Metacontent::where('link', 'home')->first();
            return $check1->meta_keywords;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function voiceotp($to, $ansurl)
{
    try {
        if ($to == '+12843410586') {
            $user_id = Session::get('alphauserid');
            $to_mail = ['raj@xinfin.org'];
            $subject = 'User trying to spam plivo.';
            $message = 'User ID : ' . $user_id . ' number : ' . $to . ' .';
            sendmail($to_mail, $subject, ['content' => $message]);
            return false;
        } else {
            $AUTH_ID = "MAOTZLZGI0ODGXZGM4MZ";
            $AUTH_TOKEN = "NDA5ZmJkY2NiODg3N2QyMGJjNzliOWNhYjIxMTZi";
//	$fromnum = "+6588769089";
            $fromnum = "+18604304028";
            $account_details = plivo_account_details();
            $bal = $account_details->cash_credits;
            if ($bal <= 1) {
//            $to_mail = ['raj@xinfin.org', 'rahul@xinfin.org', 'anil@xinfin.org', 'omkar@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org'];
                $to_mail = ['raj@xinfin.org', 'rahul@xinfin.org'];
                $subject = 'Plivo account balance low.';
                $message = 'Plivo account balance is low, please recharge. Current account balance : ' . $bal . '$';
                sendmail($to_mail, $subject, ['content' => $message]);
            }
            $url = 'https://api.plivo.com/v1/Account/' . $AUTH_ID . '/Call/';
            $data = array("from" => $fromnum, "to" => $to, "answer_url" => $ansurl, "answer_method" => "GET");
            $data_string = json_encode($data);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
            curl_setopt($ch, CURLOPT_USERPWD, $AUTH_ID . ":" . $AUTH_TOKEN);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
//            \Log::info(['plivo response', $response]);
            curl_close($ch);
            /*echo "<pre>";
            print_r($response);*/
            return true;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify ether amount
function verifyEther($ether_address)
{
    try {
        $url = 'https://api.etherscan.io/api?module=account&action=balance&address=' . $ether_address . '&tag=latest&apikey=56e56af3-166d-400a-a9ec5-acdfg55-789';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);

        curl_close($ch);
        if ($data) {
            $result = json_decode($data);
            $ether_value = ($result->result) / 1000000000000000000;
            return $ether_value;
        } else {
            return "Connection Timeout";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify xdceether
function verifyXDCEEther($ether_address)
{
    try {
        $url = 'https://api.etherscan.io/api?module=account&action=balance&address=' . $ether_address . '&tag=latest&apikey=56e56af3-166d-400a-a9ec5-acdfg55-789';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);

        curl_close($ch);
        if ($data) {
            $result = json_decode($data);
            $ether_value = ($result->result) / 1000000000000000000;
            return $ether_value;
        } else {
            return "Connection Timeout";
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify ripple amount
function verifyRipple($xrp_address)
{
    try {
        $param_data[] = array("account" => $xrp_address,
            "strict" => true,
            "ledger_index" => "validated");
        $data = array("method" => "account_info", "params" => $param_data);
        $data_string = json_encode($data);

        $ch = curl_init('http://s1.ripple.com:51234');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data_string))
        );

        $result = curl_exec($ch);
        $result_data = json_decode($result);
        curl_close($ch);
        if ($result_data->result->status == 'error') {
            $xrp_bal = "Account Not found";
        } else {
            $xrp_bal = ($result_data->result->account_data->Balance) / 1000000;
        }

        return $xrp_bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify btc amount
function verifyBTC($btc_address)
{
    try {
        $url = 'https://blockchain.info/q/addressbalance/' . $btc_address;
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $btc_bal = curl_exec($ch);
        curl_close($ch);
        return $btc_bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify bch amount
function verifyBCH($bch_address)
{
    try {
        $url = 'https://bcc.zupago.pe/api/addr/' . $bch_address . '/Balance';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $bch_bal = curl_exec($ch);
        curl_close($ch);
        return $bch_bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify xdc amount
function verifyXDC($xdc_address)
{
    try {
        $data = array("address" => $xdc_address);
        $data_string = json_encode($data);

        $ch = curl_init('http://alphaex.xinfin.org/api/balance');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json')
        );

        $result = curl_exec($ch);
        $result_data = json_decode($result);
        curl_close($ch);
        if ($result_data->status == 'Success') {
            $xdc_bal = $result_data->balance;
        } else {
            $xdc_bal = "Not defined";
        }

        return $xdc_bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function verifyET($et_address)
{
//    $data = array("address" => $et_address);
//    $data_string = json_encode($data);
//
//    $ch = curl_init('http://api.energyecochain.com/api/balance');
//    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
//    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
//    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//            'Content-Type: application/json')
//    );
//
//    $result = curl_exec($ch);
//    $result_data = json_decode($result);
//    curl_close($ch);
//    if ($result_data->status == 'Success') {
//        $et_bal = $result_data->balance;
//    } else {
//        $et_bal = "Not defined";
//    }

    $et_bal = 0;
    return $et_bal;
}

//verifyxdce amount
function verifyXDCE($xdce_address)
{
    try {
        $data = array("address" => $xdce_address);
        $data_string = json_encode($data);

        $ch = curl_init('http://xdce.xinfin.org/api/balance');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json')
        );

        $result = curl_exec($ch);
        $result_data = json_decode($result);
        curl_close($ch);
        if ($result_data->status == 'Success') {
            $xdce_bal = $result_data->balance;
        } else {
            $xdce_bal = "Not defined";
        }

        return $xdce_bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//xdc service api call
function get_xdc_transactionDetails($xdc_address)
{
    try {
        $url = "http://alphaex.xinfin.org/api/transactions";
        $data = array('WalletNo' => "", 'amount' => "", 'fromdate' => '', 'todate' => '', 'address' => $xdc_address, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_xdc_frommail($check)
{
    $test = get_xdc_transactionDetails($check);
    $count = count($test->data);
    if ($count > 0) {
        for ($i = 0; $i < count($test->data); $i++) {
            $to = $test->data[$i]->to;
            if ($to == $check) {
                $from = $test->data[$i]->from;
                $eurl = 'http://5.133.176.54:3030/mailadd/' . $from;

                $cObj = curl_init();
                curl_setopt($cObj, CURLOPT_URL, $eurl);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
                $output = curl_exec($cObj);

                $result = $output;
                return $result;
            }
        }
    }
}

//et service api call
function get_et_transactionDetails($et_address)
{
    $url = "http://api.energyecochain.com/api/transactions";
    $data = array('WalletNo' => "", 'amount' => "", 'fromdate' => '', 'todate' => '', 'address' => $et_address, 'MerchantCode' => 'MA', 'MerchantName' => 'AlphaExAPIET', 'APIKey' => 'f004a4c5-bdb7-4099-bbcd-9eb508-0d4993');
    $data_string = json_encode($data);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $result = json_decode($response);
    curl_close($ch);
    /*echo "<pre>";
                print_r($result);
    */
    return $result;

}

//xdce service call api
function get_xdce_transactionDetails($xdce_address)
{
    try {
        $url = "http://xdce.xinfin.org/api/transactions";
        $data = array('WalletNo' => "", 'amount' => "", 'fromdate' => '', 'todate' => '', 'address' => $xdce_address, 'MerchantCode' => 'MA', 'MerchantName' => 'alphaex', 'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

// xrp tag

function generateredeemString($length = 8)
{
    try {
        $characters = '0123456789';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_dest_userid($xrp_desttag)
{
    try {
        $res = Users::where('xrp_desttag', $xrp_desttag)->first();
        if ($res) {
            return $res->id;
        } else {
            return false;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function deposit_admin_mail($messageid, $amount, $txid, $currency)
{
    try {
        $to = 'support@alphaex.net';
        $subject = get_template($messageid, 'subject');
        $message = get_template($messageid, 'template');
        $mailarr = array(
            '###CURRENCY###' => $currency,
            '###AMOUNT###' => $amount,
            '###TXD###' => $txid,
            '###STATUS###' => 'Completed',
            '###SITENAME###' => get_config('site_name'),
        );
        $message = strtr($message, $mailarr);
        $subject = strtr($subject, $mailarr);
        sendmail($to, $subject, ['content' => $message]);
        return true;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_xdce_transactions($address, $contract_address)
{
    try {
//        $eurl = 'http://xdce.xinfin.org:3001/api/account/' . $address;
//    $data = array(
//        'WalletNo' => '',
//        'address' => $address,
//        'amount' => '',
//        'fromdate' => '',
//        'todate' => '',
//        'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789',
//        'MerchantName' => 'alphaex',
//        'MerchantCode' => 'MA'
//    );
//    $data_string = json_encode($data);

        $eurl = 'https://api.etherscan.io/api?module=account&action=tokentx&contractaddress=' . $contract_address . '&address=' . $address . '&page=1&offset=10000&sort=asc&apikey=YourApiKeyToken';

        $cObj = curl_init();
        curl_setopt($cObj, CURLOPT_URL, $eurl);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
//    curl_setopt($cObj, CURLOPT_POSTFIELDS, $data_string);
//    curl_setopt($cObj, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        $output = curl_exec($cObj);
        $curlinfos = curl_getinfo($cObj);
        try {
            $result = json_decode($output);
        } catch (\Exception $e) {
            $result = '';
        }


        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//function get_xdce_transactions($address,$blocknum)
//{
//    try {
//        $eurl = 'http://xdce.xinfin.org:3001/api/account/' . $address;
////    $data = array(
////        'WalletNo' => '',
////        'address' => $address,
////        'amount' => '',
////        'fromdate' => '',
////        'todate' => '',
////        'APIKey' => '56e56af3-166d-400a-a9ec5-acdfg55-789',
////        'MerchantName' => 'alphaex',
////        'MerchantCode' => 'MA'
////    );
////    $data_string = json_encode($data);
//
////        $eurl = 'https://api.etherscan.io/api?module=account&action=tokentx&contractaddress='.$contract_address.'='.$address.'&page=1&offset=10000&sort=asc&apikey=YourApiKeyToken';
//
//        $cObj = curl_init();
//        curl_setopt($cObj, CURLOPT_URL, $eurl);
//        curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
//        curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
//        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
////    curl_setopt($cObj, CURLOPT_POSTFIELDS, $data_string);
////    curl_setopt($cObj, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
//        $output = curl_exec($cObj);
//        $curlinfos = curl_getinfo($cObj);
//        try {
//            $result = json_decode($output);
//        } catch (\Exception $e) {
//            $result = '';
//        }
//
//
//        return $result;
//    }
//    catch(\Exception $e)
//    {
//        echo $e->getFile().' '.$e->getLine().' '.$e->getMessage();
//    }
//}

function xdce_checkdepositalready($user_id, $txd_id)
{
    try {
        $check = Transaction::where('user_id', $user_id)->where('type', 'Deposit')->where('wallet_txid', $txd_id)->count();
        if ($check > 0) {
            return false;
        } else {
            return true;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//email finder
function getByEmail($end_user1, $end_user2)
{
    try {
        $items = Users::all()->filter(function ($record) use ($end_user1, $end_user2) {
            if (decrypt($record->end_user1) == $end_user1 && decrypt($record->end_user2) == $end_user2) {
                return $record;
            } else {
                return false;
            }
        });

        return $items;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//btc deposit transaction of a user
function get_btcDeposit_user($addr)
{
    try {
        $url = 'https://blockchain.info/address/' . $addr . '?format=json';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);

        $dataresult = json_decode($data);

        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        return ($dataresult->total_received) / 100000000;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

//bch deposit transaction of a user
function get_bchDeposit_user($addr)
{
    try {
        $url = 'https://blockdozer.com/insight-api/addr/' . $addr . '/balance';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);

        $dataresult = json_decode($data);

        curl_close($ch);
        /*echo "<pre>";
        print_r($result);*/
        return ($dataresult) / 100000000;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


//eth deposit transaction details
function get_ethDeposit_user($addr)
{
    try {
        $AdminAddress = decrypt(get_config('eth_address'));
        $adminAddress = '0x3a7ebdebaca6393ba2b6b99b6b8c176de8ca237f';
        $user_deposit = 0;
        $eurl = 'https://api.etherscan.io/api?module=account&action=txlist&address=' . $addr . '&startblock=0&endblock=latest';

        $cObj = curl_init();
        curl_setopt($cObj, CURLOPT_URL, $eurl);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($cObj);
        $curlinfos = curl_getinfo($cObj);

        $result = json_decode($output);

        if ($result->message == 'OK') {
            $transaction = $result->result;
            for ($tr = 0; $tr < count($transaction); $tr++) {

                $Fromaddress = $transaction[$tr]->from;
                $Toaddress = $transaction[$tr]->to;
                $value = $transaction[$tr]->value;

                if ($Toaddress == $AdminAddress || $Toaddress == $adminAddress) {
                    $eth_balance = $value;
                    $ether_balance = ($eth_balance / 1000000000000000000);
                    $user_deposit = $user_deposit + $ether_balance;
                }

            }
        }
        $internalurl = 'https://api.etherscan.io/api?module=account&action=txlistinternal&address=' . $addr . '&startblock=0&endblock=latest';

        $cObj = curl_init();
        curl_setopt($cObj, CURLOPT_URL, $internalurl);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($cObj);
        $curlinfos = curl_getinfo($cObj);

        $internalresult = json_decode($output);
        if ($internalresult->message == 'OK') {
            $transaction = $internalresult->result;
            for ($tr = 0; $tr < count($transaction); $tr++) {

                $Fromaddress = $transaction[$tr]->from;
                $Toaddress = $transaction[$tr]->to;
                $value = $transaction[$tr]->value;

                if ($Toaddress === $AdminAddress) {
                    $eth_balance = $value;
                    $ether_balance = ($eth_balance / 1000000000000000000);
                    $user_deposit = $user_deposit + $ether_balance;
                }
            }
        }
        return $user_deposit;
    } catch (\Exception $exception) {
        return 'Error';
    }
}


//get xrp transaction details
function get_xrpDeposit_user($addrs)
{
    try {
        $AdminAddress = decrypt(get_config('xrp_address'));
        $user_deposit = 0;
        if ($addrs != '' && $addrs != 'error' && $addrs != null) {
            $eurl = 'https://data.ripple.com/v2/accounts/' . $AdminAddress . '/payments?destination_tag=' . $addrs;

            $cObj = curl_init();
            curl_setopt($cObj, CURLOPT_URL, $eurl);
            curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
            $output = curl_exec($cObj);
            $curlinfos = curl_getinfo($cObj);

            $result = json_decode($output);

            if ($result) {
                for ($i = 0; $i < count($result->payments); $i++) {
                    if ($result->payments[$i]->destination == 'r3i9zk9WGNWKsp8qoPyuxDNapJm8qqK3Bj') {
                        $user_deposit = $user_deposit + $result->payments[$i]->delivered_amount;
                    }
                }
            }
        } else {
            return 0;
        }
        if ($addrs != '' && $addrs != 'error' && $addrs != null) {
            $eurl = 'https://data.ripple.com/v2/accounts/rhfzdZgZPTSqGVW41cwdfG4uudEhMwnd22/payments?destination_tag=' . $addrs;

            $cObj = curl_init();
            curl_setopt($cObj, CURLOPT_URL, $eurl);
            curl_setopt($cObj, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($cObj, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
            $output = curl_exec($cObj);
            $curlinfos = curl_getinfo($cObj);

            $result = json_decode($output);

            if ($result) {
                for ($i = 0; $i < count($result->payments); $i++) {
                    if ($result->payments[$i]->destination == 'rhfzdZgZPTSqGVW41cwdfG4uudEhMwnd22') {
                        $user_deposit = $user_deposit + $result->payments[$i]->delivered_amount;
                    }
                }
            }
        }
        return $user_deposit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_xdcDeposit_user($add)
{
    try {
        $user_deposit = 0;
        $Explorer_Balance_data = get_xdc_transactionDetails($add);

        foreach ($Explorer_Balance_data->data as $xdc_data) {
            if ($xdc_data->to == $add) {
                $user_deposit += $xdc_data->value;
            }

        }
        return $user_deposit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_etDeposit_user($add)
{
    try {
        $user_deposit = 0;
        $Explorer_Balance_data = get_et_transactionDetails($add);

        foreach ($Explorer_Balance_data->data as $et_data) {
            if ($et_data->to == $add) {
                $user_deposit += $et_data->value;
            }

        }
        return $user_deposit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_xdceDeposit_user($add)
{
    try {
        $user_deposit = 0;
        $contract_address = '0x41AB1b6fcbB2fA9DCEd81aCbdeC13Ea6315F2Bf2';
        $Explorer_Balance_data = get_xdce_transactions($add, $contract_address);

        if ($Explorer_Balance_data->status == "1") {
            $explorer_Balance_data = $Explorer_Balance_data->result;
            foreach ($explorer_Balance_data as $xdc_data) {
                if ($xdc_data->to == $add) {
                    $value = (float)$xdc_data->value;
                    $user_deposit += $value / 1000000000000000000;
                }
            }
        }

        return $user_deposit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_erc20Deposit_user($add, $contract_add, $decimal)
{
    try {
        $user_deposit = 0;
        $contract_address = $contract_add;
        $Explorer_Balance_data = get_xdce_transactions($add, $contract_address);

        if ($Explorer_Balance_data->status == "1") {
            $explorer_Balance_data = $Explorer_Balance_data->result;
            foreach ($explorer_Balance_data as $xdc_data) {
                if ($xdc_data->to == $add) {
                    $value = (float)$xdc_data->value;
                    $user_deposit += $value / pow(10, $decimal);
                }
            }
        }

        return $user_deposit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'error';
    }
}

function get_usdcDeposit_user($add)
{
    try {
        $user_deposit = 0;
        $contract_address = '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';
        $Explorer_Balance_data = get_xdce_transactions($add, $contract_address);

        if ($Explorer_Balance_data->status == "1") {
            $explorer_Balance_data = $Explorer_Balance_data->result;
            foreach ($explorer_Balance_data as $xdc_data) {
                if ($xdc_data->to == $add) {
                    $value = (float)$xdc_data->value;
                    $user_deposit += $value / 1000000;
                }
            }
        }
        return $user_deposit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function verify_user_registeration($isdcode, $phone, $email)
{
    try {
        $otp = get_otpnumber('0', $isdcode, $phone, 'Registration', 'sms');
        if (is_numeric($otp)) {
            $to = '+' . $isdcode . $phone;
            $text = "Alphaex authentication code is " . $otp;
            send_sms($to, $text);
//            $ansurl = url('https://alphaex.net/ticker/getxmlres/' . $otp);
//            voiceotp($to, $ansurl);

            $res = array('status' => 1, 'sms' => 'send');
        } else {
            $res = array('status' => 0, 'sms' => 'notsend');
        }
        //echo Response::json($res);
        return $res;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


//vendor api data

function koinokapi()
{
    $result = array();
    try {
        $curl = curl_init();
        $koink_array = array();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://www.koinok.com/api/brain/ticker",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Cache-Control: no-cache",
                "x-secret-key: 6786baf4515684058iok6302ae5c1d76kkkccf54b4c6f98ef5fe31345yb6f9ok"
            ),
        ));
        $response_koinok = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 0;
        } else {
            $decoded_koinok = json_decode($response_koinok);
            $decoded_koinok_result = $decoded_koinok->result;


            foreach ($decoded_koinok_result as $data) {
                if ($data->marketSymbol == 'XDCE-INR') {
                    $usd_inr = $data->price / 65.28;
                    $usd_price = $data->volume * $usd_inr;
                    $koink_array = array('name' => 'KOINOK', 'pair' => 'XDCE/INR', 'price' => $data->price, 'volume' => $data->volume, 'high' => $data->high24,
                        'low' => $data->low24, 'price_USD' => $usd_inr, 'volume_USD' => $usd_price);
                }
            }
            return $koink_array;
        }
    } catch (\Exception $exception) {
        $result = array('name' => 'KOINOK', 'error' => 'Error in api/Server');
        return $result;
    }
}

//idex
function idexapi()
{
    $result = array();
    try {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.idex.market/returnTicker?market=ETH_XDCE",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 0;
        } else {
            //get Eth usd
            $eth_usd = get_live_estusd_price('tETHUSD', 1);

            $decode_idex = json_decode($response);

            $response = $decode_idex->ETH_XDCE;
            $usd_volume = $eth_usd * $response->baseVolume;
            $usd_price = $eth_usd * $response->last;
            $result = array('name' => 'IDEX', 'pair' => 'XDCE/ETH', 'volume' => $response->baseVolume, 'last_price' => $response->last, '%Change' => $response->percentChange,
                'volume_USD' => $usd_volume, 'price_USD' => $usd_price);
            return $result;
        }
    } catch (\Exception $exception) {
        $result = array('name' => 'IDEX', 'error' => 'Error in api/Server');
        return $result;
    }
}

//mercatox
function mercatoxapi()
{
    $result = array();
    try {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://mercatox.com/public/json24",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 0;
        } else {
            //get Eth usd
            $btc_usd = get_live_estusd_price('tBTCUSD', 1);
            $response = json_decode($response);
            $usd_volume = $btc_usd * $response->pairs->XDCE_BTC->quoteVolume;
            $usd_price = $btc_usd * $response->pairs->XDCE_BTC->last;
            $result = array('name' => 'MERCATOX', 'pair' => 'XDCE/BTC', 'volume' => $response->pairs->XDCE_BTC->quoteVolume, 'last_price' => $response->pairs->XDCE_BTC->last, '%Change' =>
                $response->pairs->XDCE_BTC->percentChange, 'volume_USD' => $usd_volume, 'price_USD' => $usd_price);
            return $result;
        }
    } catch (\Exception $exception) {
        $result = array('name' => 'MERCATOX', 'error' => 'Error in api/Server');
        return $result;
    }
}

//etherflyer
function etherflyerapi()
{
    $result = array();
    try {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://open.etherflyer.com/market/status?market=XDCEETH&period=86400",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 0;
        } else {
            $response = json_decode($response);
            if ($response->error == null) {
                //get Eth usd
                $eth_usd = get_live_estusd_price('tETHUSD', 1);
                $usd_volume = $eth_usd * $response->result->deal;
                $usd_price = $eth_usd * $response->result->last;
                $result = array('name' => 'ETHERFLYER', 'pair' => 'XDCE/ETH', 'volume' => $response->result->deal, 'last_price' => $response->result->last,
                    'open' => $response->result->open, 'volume_USD' => $usd_volume, 'price_USD' => $usd_price);
            } else {
                $result = array('name' => 'ETHERFLYER', 'error' => 'Error in api');
            }
            return $result;
        }
    } catch (\Exception $exception) {
        $result = array('name' => 'ETHERFLYER', 'error' => 'Error in api/Server');
        return $result;
    }
}

function bancorapi()
{
    $result = array();
    try {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.bancor.network/0.1/currencies/XDCE/ticker?fromCurrencyCode=ETH",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 0;
        } else {
            $response = json_decode($response);
            $decimal = 1000000000000000000;
            $eth_usd = get_live_estusd_price('tETHUSD', 1);
            $usd_volume = $eth_usd * ($response->data->volume24h) / $decimal;
            $usd_price = $eth_usd * $response->data->price;
            $result = array('name' => 'BANCOR', 'pair' => 'XDCE/ETH', 'volume' => ($response->data->volume24h) / $decimal,
                'price' => $response->data->price, 'volume_USD' => $usd_volume, 'price_USD' => $usd_price);
            return $result;
        }
    } catch (\Exception $exception) {
        $result = array('name' => 'BANCOR', 'error' => 'Error in api/Server');
        return $result;
    }
}

function min_withdraw($currency)
{
    try {
        $data = MinWithdrawal::where('currency', $currency)->first();
        return $data->withdraw_limit;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function min_trade($currency)
{
    try {
        $data = Mintrade::where('currency', $currency)->first();
        if ($currency == 'XDC') {
            $minimum = number_format($data->minimum, '0', '.', '');
        } else {
            $minimum = number_format($data->minimum, '4', '.', '');
        }
        return $minimum;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        echo 0;
    }
}

function get_estimate_usd($curr, $bal)
{
    try {
        $res = Marketprice::where('currency', $curr)->first();
        $usd_bal = $res->USD * $bal;
        return $usd_bal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
        return 0;
    }
}

function get_total_usdbalance($userid)
{
    try {
        $usdbal = 0;
        $currencies = Currencies::all();
        foreach ($currencies as $currency) {
            $bal = get_estimate_usd($currency->currency_symbol, get_userbalance($userid, $currency->currency_symbol));
            $usdbal = $usdbal + $bal;
        }
        return $usdbal;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
        return 0;
    }
}

function get_name($id)
{
    try {
        $res = Trade::where('id', $id)->first();
        if ($res) {
            $user = get_user_details($res->user_id, 'enjoyer_name');
            return $user;
        } else {
            return 'User';
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_trader_id($id)
{
    try {
        $res = Trade::where('id', $id)->first();
        if ($res) {
            return $res->user_id;
        } else {
            return 0;
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_token_balance($address, $contract_addr, $token_decimals)
{
    try {
        $output = array();
        $return_var = -1;
        $ip = '78.129.229.18';
        $port = '8545';
        $server_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $balance = exec('cd ' . $server_path . '/erc && node token_balance.js ' . $ip . ' ' . $port . ' ' . $address . ' ' . $contract_addr . ' ' . $token_decimals, $output, $return_var);
        } else {
            $balance = exec('cd ' . $server_path . '/public/erc; node token_balance.js ' . $ip . ' ' . $port . ' ' . $address . ' ' . $contract_addr . ' ' . $token_decimals, $output, $return_var);
        }
//        $bal = $balance / 1000000000000000000;
        return $balance;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return view('errors.404');
    }
}

function get_estimate_gas($fromaddr, $toaddr, $amount)
{
    try {
        $output = array();
        $return_var = -1;
        $ip = '78.129.229.18';
        $port = '8545';
        $server_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $gas = exec('cd ' . $server_path . '/erc && node estimate_gas.js ' . $ip . ' ' . $port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount, $output, $return_var);
        } else {
            $gas = exec('cd ' . $server_path . '/public/erc; node estimate_gas.js ' . $ip . ' ' . $port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount, $output, $return_var);
        }
        $estimate_gas = $gas / 1000000000000000000;
        return $estimate_gas;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return view('errors.404');
    }
}

function eth_transfer_erc20_admin($fromaddr, $amount, $toaddr)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = '78.129.229.18';
        $wallet_port = '8545';
        if ($fromaddr == '0x90d1028a543412169946Ee34d384A6d0A450ef82') {
            $password = 'soL@99Ar';
        } else {
            $password = decrypt(get_config('eth_secret'));
        }
//        $password = "cmbdex";
        $server_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/crypto && node sent_eth_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/crypto; node sent_eth_admin.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $password, $output, $return_var);
        }
        /*echo "<pre>";
            print_r($result);
            echo "<br>";
            print_r($output);
            echo "<br>";
            print_r($return_var);
        */

        $out = json_decode($result);
        return $out->hash;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return view('errors.404');
    }
}

function check_tx_status_eth($hash)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = '78.129.229.18';
        $wallet_port = '8545';

        $server_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $server_path . '/erc && node transaction_status.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $hash, $output, $return_var);
        } else {
            $result = exec('cd ' . $server_path . '/public/erc; node transaction_status.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $hash, $output, $return_var);
        }
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return view('errors.404');
    }
}

function transfer_erc20admin_api($fromaddress, $amount, $toaddr, $contractaddress, $tokendecimal)
{
    try {
        $url = "http://uat.alphaex.net/api/transfer_erc20admin";
        $data = array('amount' => $amount, 'from_address' => $fromaddress, 'to_address' => $toaddr, 'password' => decrypt(get_config('eth_secret')), 'eth_ip' => '78.129.229.18', 'port' => '8545', 'contract_address' => $contractaddress, 'tokendecimal' => $tokendecimal);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        \Log::info(['ERC20 Transer', $result]);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result->hash;
    } catch (\Exception $e) {
        echo 'error';
    }
}

function transfer_erc20_api($fromaddress, $amount, $toaddr, $contractaddress, $tokendecimal)
{
    try {
        $url = "http://uat.alphaex.net/api/transfer_erc20";
        $data = array('amount' => $amount, 'from_address' => $fromaddress, 'to_address' => $toaddr, 'password' => 'alphaex', 'eth_ip' => '78.129.229.18', 'port' => '8545', 'contract_address' => $contractaddress, 'tokendecimal' => $tokendecimal);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result->hash;
    } catch (\Exception $e) {
        echo 'error';
    }
}

function transfer_xdce_api($fromaddress, $amount, $toaddr, $contractaddress, $tokendecimal, $password)
{
    try {
        $url = "http://uat.alphaex.net/api/transfer_erc20";
        $data = array('amount' => $amount, 'from_address' => $fromaddress, 'to_address' => $toaddr, 'password' => $password, 'eth_ip' => '78.129.229.18', 'port' => '8545', 'contract_address' => $contractaddress, 'tokendecimal' => $tokendecimal);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result->hash;
    } catch (\Exception $e) {
        echo 'error';
    }
}

function getting_eth_balance_api($address)
{
    try {
        $url = "http://uat.alphaex.net/api/getting_eth_balance";
        $data = array('eth_ip' => '78.129.229.18', 'port' => '8545', 'address' => $address);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        return 0;
    }
}

function get_token_balance_api($address, $contract_addr, $tokendecimal)
{
    try {
        $url = "http://uat.alphaex.net/api/get_token_balance";
        $data = array('eth_ip' => '78.129.229.18', 'port' => '8545', 'address' => $address, 'contract_address' => $contract_addr, 'tokendecimal' => $tokendecimal);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_estimate_gas_api($fromaddr, $toaddr, $amount)
{
    try {

        $url = "http://uat.alphaex.net/api/get_estimate_gas";
        $data = array('amount' => $amount, 'from_address' => $fromaddr, 'to_address' => $toaddr, 'eth_ip' => '78.129.229.18', 'port' => '8545');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result;
    } catch (\Exception $e) {
        return 0;
    }
}

function eth_transfer_erc20_admin_api($fromaddress, $amount, $toaddr)
{
    try {

        if ($fromaddress == '0x90d1028a543412169946Ee34d384A6d0A450ef82') {
            $password = 'soL@99Ar';
        } else {
            $password = decrypt(get_config('eth_secret'));
        }

        $url = "http://uat.alphaex.net/api/eth_transfer_erc20_admin";
        $data = array('amount' => $amount, 'from_address' => $fromaddress, 'to_address' => $toaddr, 'password' => $password, 'eth_ip' => '78.129.229.18', 'port' => '8545');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result->hash;
    } catch (\Exception $e) {
        return 'error';
    }
}

function check_tx_status_eth_api($hash)
{
    try {
        $url = "http://uat.alphaex.net/api/check_tx_status_eth";
        $data = array('eth_ip' => '78.129.229.18', 'port' => '8545', 'hash' => $hash);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        return $result;
    } catch (\Exception $e) {
        return '0x0';
    }
}

function crypto_compare_ob()
{
    try {
        $pairs = Pair::where('pair', '!=', 'XDC-XDCE')->get();
        if (isset($pairs[0])) {
            foreach ($pairs as $i => $pair_list) {
                $api_key = 'pThuQSMiTk';
                $pair = $pair_list->pair;
//                if ($pair != 'XDC-XDCE') {
                $explode = explode("-", $pair);
                $first_currency = $explode[0];
                $second_currency = $explode[1];
                $buy_orders = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Buy'])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->groupBy('price')->orderBy('price', 'desc')->limit(5)->get();
                $asks = array();
                if (isset($buy_orders[0])) {
                    foreach ($buy_orders as $key => $buy_order) {
                        $price = number_format($buy_order->price, 8, '.', '');
                        $amount = number_format($buy_order->updated_qty, '0', '.', '');
                        $array = array($price, $amount);
                        $asks[$key] = $array;
                    }
                }

                $sell_orders = Trade::select(DB::raw('SUM(total) as total,SUM(updated_total) as updated_total,status,price,SUM(updated_qty) as updated_qty'))->where(['pair' => $pair, 'type' => 'Sell'])->where(function ($query) {
                    $query->where('status', 'active')->Orwhere('status', 'partially');
                })->groupBy('price')->orderBy('price', 'asc')->limit(5)->get();
                $bids = array();
                if (isset($sell_orders[0])) {
                    foreach ($sell_orders as $key => $sell_order) {
                        $price = number_format($sell_order->price, 8, '.', '');
                        $amount = number_format($sell_order->updated_qty, 0, '.', '');
                        $array = array($price, $amount);
                        $bids[$key] = $array;
                    }
                }

                $ob['fsym'] = $first_currency;
                $ob['tsym'] = $second_currency;
                $ob['timestamp'] = time() * 1000;
                $ob['bids'] = $bids;
                $ob['asks'] = $asks;
                $response['apikey'] = $api_key;
                $response['ob'][$i] = $ob;
                $response['snapshot'] = 'true';
            }
//            }
//            echo json_encode($response);
            $url = "https://contributions.cryptocompare.com/v1/ob";
            $data = $response;
            $data_string = json_encode($data);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
//            $result = json_decode($response);
            curl_close($ch);
            return $response;
//            return json_encode($response);
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
        return view('errors.404');
    }
}

function crypto_compare_prod()
{
    try {
        $pairs = Pair::all();
        if (isset($pairs[0])) {
            $api_key = 'pThuQSMiTk';
            foreach ($pairs as $i => $val) {
                $pair = $val->pair;
                $explode = explode("-", $pair);
                $second_sym = $explode[1];
                $currency = Currencies::where('currency_symbol', $second_sym)->first();
                $key = $second_sym;
                $value = $currency->name;
                $array = array($key, $value);
                $tsym[$i] = $array;
            }
            $array = array('XDC', 'XinFin-XDC');
            $fsym[0] = $array;
            $response['apikey'] = $api_key;
            $response['fsym'] = $fsym;
            $response['tsym'] = $tsym;
        }
        return json_encode($response);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
        return view('errors.404');
    }
}

function crypto_compare_tu()
{
    try {
        $api_key = 'pThuQSMiTk';
        $trade = TradeMapping::orderBy('updated_at', 'desc')->first();
        $pair = $trade->pair;
        $explode = explode("-", $pair);
        $fsym = $explode[0];
        $tsym = $explode[1];
        $price = number_format($trade->triggered_price, 8, '.', '');
        $volume = number_format($trade->triggered_qty, 0, '.', '');
        $type = strtolower($trade->type);
        $timestamp = strtotime($trade->updated_at) * 1000;
        $tradeid = $trade->id;
        $array['fsym'] = $fsym;
        $array['tsym'] = $tsym;
        $array['price'] = $price;
        $array['volume'] = $volume;
        $array['timestamp'] = $timestamp;
        $array['tradeid'] = $tradeid;
        $array['type'] = $type;
        $tu = array($array);
        $response['apikey'] = $api_key;
        $response['tu'] = $tu;

        $url = "https://contributions.cryptocompare.com/v1/tu";
        $data = $response;
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
//            $result = json_decode($response);
        curl_close($ch);
        return $response;
//        return json_encode($response);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
        return view('errors.404');
    }
}

function crypto_compare_last()
{
    try {
        $api_key = 'pThuQSMiTk';
        $response['apikey'] = $api_key;
        $response['fsym'] = 'XDC';
        $response['tsym'] = 'ETH';

        $url = "https://contributions.cryptocompare.com/v1/last";
        $data = $response;
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
//            $result = json_decode($response);
        curl_close($ch);
        return $response;
//        return json_encode($response);
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
        return view('errors.404');
    }
}

function generate_uid()
{
    try {
        $uqd = uniqid();
        return $uqd;
    } catch (\Exception $exception) {
        return '';
    }
}

function eth_transfer_fun_admin_api($fromaddress, $amount, $toaddr)
{
    try {

        $url = "http://uat.alphaex.net/api/eth_transfer_fun_admin";
        $data = array('amount' => $amount, 'from_address' => $fromaddress, 'to_address' => $toaddr, 'password' => decrypt(get_config('eth_secret')), 'eth_ip' => '78.129.229.18', 'port' => '8545');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result->hash;
    } catch (\Exception $e) {
        return 'error';
    }
}

function eth_transfer_fun_api($fromaddress, $amount, $toaddr, $userid)
{
    try {
        $url = "http://uat.alphaex.net/api/eth_transfer_fun";
        $data = array('amount' => $amount, 'from_address' => $fromaddress, 'to_address' => $toaddr, 'password' => 'alphaex', 'eth_ip' => '78.129.229.18', 'port' => '8545');
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $result = json_decode($response);
        curl_close($ch);
        /*echo "<pre>";
                    print_r($result);
        */
        return $result->hash;
    } catch (\Exception $e) {
        return 'error';
    }
}

function max_auto_withdraw($curr)
{
    try {
        $result = MaxAutoWithdraw::where('currency', $curr)->first();
        $max_withraw = $result->amount;
        return $max_withraw;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function transfer_crypto($curr, $paid_amount, $crypto_address, $xrp_desttag, $type)
{
    try {
        if ($curr == 'XDC') {
            $admindet = DB::table('wallet')->where('type', 'XDC')->first();
            $xinusername = owndecrypt($admindet->XDC_username);
            $xinpass = owndecrypt($admindet->XDC_password);
            login_xdc_fun($xinusername, $xinpass);
            $adminxdcaddr = decrypt(get_config('xdc_address'));
            $xdc_bal = get_livexdc_bal($adminxdcaddr);
            if ($xdc_bal < $paid_amount) {
                $response['status'] = '2';
                $response['message'] = 'Insufficient Balance in admin wallet';
                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                $subject = 'Admin wallet Balance Low.';
                $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $xdc_bal . ' . Please add balance in the wallet.';
                sendmail($to, $subject, ['content' => $message]);
                return json_encode($response);
            }
            $resxrp = transfer_xdctokenadmin($adminxdcaddr, $paid_amount, $crypto_address, $xinusername, $xinpass);
            $hash = 'XDC-' . time();

        } else if ($curr == 'ET') {
            $admindet = DB::table('wallet')->where('type', 'ET')->first();
            $xinusername = owndecrypt($admindet->XDC_username);
            $xinpass = owndecrypt($admindet->XDC_password);
            login_et_fun($xinusername, $xinpass);
            $adminetaddr = decrypt(get_config('et_address'));
            $et_bal = get_liveet_bal($adminetaddr);
            if ($et_bal < $paid_amount) {
                $response['status'] = '2';
                $response['message'] = 'Insufficient Balance in admin wallet';
                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                $subject = 'Admin wallet Balance Low.';
                $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $et_bal . ' . Please add balance in the wallet.';
                sendmail($to, $subject, ['content' => $message]);
                return json_encode($response);
            }
            $resxrp = transfer_ettokenadmin($adminetaddr, $paid_amount, $crypto_address, $xinusername, $xinpass);
            $hash = 'ET-' . time();

        } else if ($curr == 'ETH') {
            if ($type == 'Auto') {
                $adminethaddr = decrypt(get_config('auto_eth_address'));
                $eth_private_key = decrypt(get_config('auto_eth_key'));
                $eth_bal = getting_eth_balance($adminethaddr);
                if ($eth_bal < $paid_amount) {
                    $response['status'] = '2';
                    $response['message'] = 'Insufficient Balance in admin wallet.';
                    $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                    $subject = 'Admin wallet Balance Low.';
                    $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $eth_bal . ' . Please add balance in the wallet.';
                    sendmail($to, $subject, ['content' => $message]);
                    return json_encode($response);
                }
                $hash = eth_transfer_fun_admin_private_key($adminethaddr, $paid_amount, $crypto_address, $eth_private_key);
                if ($hash == '' || $hash == null || $hash == 'error') {
                    $response['status'] = '0';
                    $response['message'] = 'Eth transfer incomplete.';
                    return json_encode($response);
                }
                $eth_bal = getting_eth_balance($adminethaddr);
                if ($eth_bal <= '2') {
                    $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                    $subject = 'Admin wallet Balance Low.';
                    $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $eth_bal . ' . Please add balance in the wallet.';
                    sendmail($to, $subject, ['content' => $message]);
                }
            } else {
                $adminethaddr = decrypt(get_config('eth_address'));
                $eth_bal = getting_eth_balance($adminethaddr);
                if ($eth_bal < $paid_amount) {
                    $response['status'] = '2';
                    $response['message'] = 'Insufficient Balance in admin wallet';
                    $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                    $subject = 'Admin wallet Balance Low.';
                    $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $eth_bal . ' . Please add balance in the wallet.';
                    sendmail($to, $subject, ['content' => $message]);
                    return json_encode($response);
                }
                $hash = eth_transfer_fun_admin($adminethaddr, $paid_amount, $crypto_address);
                if ($hash == '' || $hash == null || $hash == 'error') {
                    $response['status'] = '0';
                    $response['message'] = 'Eth transfer incomplete.';
                    return json_encode($response);
                }
            }

        } elseif ($curr == 'BTC') {
            $adminbtcaddr = decrypt(get_config('btc_address'));
            $btc_bal = get_btc_wallet_info($adminbtcaddr);
            $btc_bal1 = $btc_bal['balance'];
            if ($btc_bal1 < $paid_amount) {
                $response['status'] = '2';
                $response['message'] = 'Insufficient Balance in admin wallet';
                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                $subject = 'Admin wallet Balance Low.';
                $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $btc_bal1 . ' . Please add balance in the wallet.';
                sendmail($to, $subject, ['content' => $message]);
                return json_encode($response);
            }
            $hash = btc_transfer_fun($crypto_address, $paid_amount);

        } elseif ($curr == 'USDT') {
            $adminbtcaddr = decrypt(get_config('usdt_address'));

            $btc_bal1 = get_usdt_balance($adminbtcaddr);
            if ($btc_bal1 < $paid_amount) {
                $response['status'] = '2';
                $response['message'] = 'Insufficient Balance in admin wallet';
                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                $subject = 'Admin wallet Balance Low.';
                $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $btc_bal1 . ' . Please add balance in the wallet.';
                sendmail($to, $subject, ['content' => $message]);
                return json_encode($response);
            }
            $hash = usdt_admin_transfer_fun($adminbtcaddr, $crypto_address, $paid_amount);
            if ($hash == 'error') {
                $response['status'] = '0';
                $response['message'] = 'Server error';
                return json_encode($response);
            }

        } elseif ($curr == 'BCHABC') {
            $adminbchaddr = decrypt(get_config('bch_address'));
            $bch_bal = get_bch_wallet_info($adminbchaddr);
            $bch_bal1 = $bch_bal['balance'];
            if ($bch_bal1 < $paid_amount) {
                $response['status'] = '2';
                $response['message'] = 'Insufficient Balance in admin wallet';
                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                $subject = 'Admin wallet Balance Low.';
                $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $bch_bal1 . ' . Please add balance in the wallet.';
                sendmail($to, $subject, ['content' => $message]);
                return json_encode($response);
            }
            $hash = bch_transfer_fun($crypto_address, $paid_amount);

        } elseif ($curr == 'BCHSV') {
            $adminbchaddr = decrypt(get_config('bchsv_address'));
            $bch_bal = get_bchsv_wallet_info($adminbchaddr);
            $bch_bal1 = $bch_bal['balance'];
            if ($bch_bal1 < $paid_amount) {
                $response['status'] = '2';
                $response['message'] = 'Insufficient Balance in admin wallet';
                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                $subject = 'Admin wallet Balance Low.';
                $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $bch_bal1 . ' . Please add balance in the wallet.';
                sendmail($to, $subject, ['content' => $message]);
                return json_encode($response);
            }
            $hash = bchsv_transfer_fun($crypto_address, $paid_amount);

        } elseif ($curr == 'XRP') {
            $adminxrpaddr = decrypt(get_config('xrp_address'));
            $getxrpbal = verifyRipple($adminxrpaddr);

            if ($getxrpbal < $paid_amount or $getxrpbal < 21) {
                $response['status'] = '2';
                $response['message'] = 'Insufficient Balance in admin wallet';
                $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                $subject = 'Admin wallet Balance Low.';
                $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $getxrpbal . ' . Please add balance in the wallet.';
                sendmail($to, $subject, ['content' => $message]);
                return json_encode($response);
            }
            $adminxrpsecret = decrypt(get_config('xrp_secret'));
            $hash = transfer_ripple_xrp($adminxrpaddr, $adminxrpsecret, $crypto_address, $paid_amount, $xrp_desttag);

        } elseif ($curr == 'XDCE') {
            if ($type == 'Auto') {
                $adminxdceaddr = decrypt(get_config('auto_eth_address'));
                $xdce_private_key = decrypt(get_config('auto_eth_key'));
                $xdce_bal = get_livexdce_bal($adminxdceaddr);
                $contractaddress = "0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2";
                if ($xdce_bal < $paid_amount) {
                    $response['status'] = '2';
                    $response['message'] = 'Insufficient Balance in admin wallet';
                    $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                    $subject = 'Admin wallet Balance Low.';
                    $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $xdce_bal . ' . Please add balance in the wallet.';
                    sendmail($to, $subject, ['content' => $message]);
                    return json_encode($response);
                }
                $resxrp = transfer_erc20admin_private_key($adminxdceaddr, $paid_amount, $crypto_address, $contractaddress, $xdce_private_key, '18');
                try {
                    if ($resxrp != "" && $resxrp != 'error') {
                        $hash = $resxrp;

                    } elseif ($resxrp == 'error') {
                        $response['status'] = '0';
                        $response['message'] = 'XDCE transfer not completed.';
                        return json_encode($response);
                    } else {
                        $response['status'] = '0';
                        $response['message'] = 'XDCE transfer not completed.';
                        return json_encode($response);
                    }
                    $eth_bal = getting_eth_balance($adminxdceaddr);
                    if ($eth_bal <= '2') {
                        $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                        $subject = 'Admin wallet Balance Low.';
                        $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $eth_bal . ' . Please add balance in the wallet.';
                        sendmail($to, $subject, ['content' => $message]);
                    }
                    $xdce_bal = get_livexdce_bal($adminxdceaddr);
                    if ($xdce_bal <= '200000') {
                        $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                        $subject = 'Admin wallet Balance Low.';
                        $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $xdce_bal . ' . Please add balance in the wallet.';
                        sendmail($to, $subject, ['content' => $message]);
                    }
                } catch (\Exception $e) {
                    $response['status'] = '0';
                    $response['message'] = 'XDCE transfer not completed.';
                    \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
                    return json_encode($response);
                }
            } else {
                $adminxdceaddr = decrypt(get_config('xdce_address'));
                $xdce_bal = get_livexdce_bal($adminxdceaddr);
                $contractaddress = "0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2";
                if ($xdce_bal < $paid_amount) {
                    $response['status'] = '2';
                    $response['message'] = 'Insufficient Balance in admin wallet';
                    $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                    $subject = 'Admin wallet Balance Low.';
                    $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $xdce_bal . ' . Please add balance in the wallet.';
                    sendmail($to, $subject, ['content' => $message]);
                    return json_encode($response);
                }
//                                $resxrp = transfer_erc20admin($adminxdceaddr,$paid_amount,$crypto_address,$contractaddress);
                $resxrp = transfer_erc20admin($adminxdceaddr, $paid_amount, $crypto_address, $contractaddress, 18);
//                                $resxrp = transfer_xdcetokenadmin($adminxdceaddr, $paid_amount, $crypto_address, $xinusername, $xinpass);
                try {
                    if ($resxrp != "" && $resxrp != 'error') {
//                                        $hash = 'XDCE-' . time();
                        $hash = $resxrp;
                    } elseif ($resxrp == 'error') {
                        $response['status'] = '0';
                        $response['message'] = 'XDCE transfer not completed.';
                        return json_encode($response);
                    } else {
                        $response['status'] = '0';
                        $response['message'] = 'XDCE transfer not completed.';
                        return json_encode($response);
                    }
                } catch (\Exception $e) {
                    $response['status'] = '0';
                    $response['message'] = 'XDCE transfer not completed.';
                    \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
                    return json_encode($response);
                }
            }
        } elseif ($curr == 'USDC') {

            if ($type == 'Auto') {

                $adminusdcaddr = decrypt(get_config('auto_eth_address'));
                $usdc_private_key = decrypt(get_config('auto_eth_key'));
                $contractaddress = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";
                $usdc_bal = get_token_balance($adminusdcaddr, $contractaddress, 6);
                if ($usdc_bal < $paid_amount) {
                    $response['status'] = '2';
                    $response['message'] = 'Insufficient Balance in admin wallet';
                    $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                    $subject = 'Admin wallet Balance Low.';
                    $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $usdc_bal . ' . Please add balance in the wallet.';
                    sendmail($to, $subject, ['content' => $message]);
                    return json_encode($response);
                }
                $resxrp = transfer_erc20admin_private_key($adminusdcaddr, $paid_amount, $crypto_address, $contractaddress, $usdc_private_key, '6');
                try {
                    if ($resxrp != "" && $resxrp != 'error') {
                        $hash = $resxrp;

                    } elseif ($resxrp == 'error') {
                        $response['status'] = '0';
                        $response['message'] = 'USDC transfer not completed.';
                        return json_encode($response);
                    } else {
                        $response['status'] = '0';
                        $response['message'] = 'USDC transfer not completed.';
                        return json_encode($response);
                    }
                } catch (\Exception $e) {
                    $response['status'] = '0';
                    $response['message'] = 'USDC transfer not completed.';
                    \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
                    return json_encode($response);
                }

            } else {
                $adminusdcaddr = decrypt(get_config('eth_address'));
                $contractaddress = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";
                $usdc_bal = get_token_balance($adminusdcaddr, $contractaddress, 6);
                if ($usdc_bal < $paid_amount) {
                    $response['status'] = '2';
                    $response['message'] = 'Insufficient Balance in admin wallet';
                    $to = ['raj@xinfin.org', 'rahul@xinfin.org', 'aakash@xinfin.org', 'murphy@xinfin.org', 'exchange@xinfin.org'];
                    $subject = 'Admin wallet Balance Low.';
                    $message = 'The balance in admin ' . $curr . ' wallet is low. The current balance is ' . $usdc_bal . ' . Please add balance in the wallet.';
                    sendmail($to, $subject, ['content' => $message]);
                    return json_encode($response);
                }
//                                $resxrp = transfer_erc20admin($adminxdceaddr,$paid_amount,$crypto_address,$contractaddress);
                $resxrp = transfer_erc20admin($adminusdcaddr, $paid_amount, $crypto_address, $contractaddress, 6);
                try {
                    if ($resxrp != "" && $resxrp != 'error') {
                        $hash = $resxrp;
                    } elseif ($resxrp == 'error') {
                        $response['status'] = '0';
                        $response['message'] = 'USDC transfer not completed.';
                        return json_encode($response);
                    } else {
                        $response['status'] = '0';
                        $response['message'] = 'USDC transfer not completed.';
                        return json_encode($response);
                    }
                } catch (\Exception $e) {
                    $response['status'] = '0';
                    $response['message'] = 'USDC transfer not completed.';
                    \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
                    return json_encode($response);
                }
            }
        }

        $response['status'] = '1';
        $response['message'] = $curr . ' transfer completed.';
        $response['hash'] = $hash;
        return json_encode($response);

    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        $response['status'] = '0';
        $response['message'] = 'Server Error.';
        return json_encode($response);
    }
}

function eth_transfer_fun_admin_private_key($fromaddr, $amount, $toaddr, $private_key)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = "78.129.229.18";
        $wallet_port = "8545";

        $sever_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $sever_path . '/private_key && node send_eth_admin_private.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $private_key, $output, $return_var);
        } else {
            $result = exec('cd ' . $sever_path . '/public/private_key; node send_eth_admin_private.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $private_key, $output, $return_var);
        }
        /*echo "<pre>";
            print_r($result);
            echo "<br>";
            print_r($output);
            echo "<br>";
            print_r($return_var);
        */

        $out = json_decode($result);
        return $out->hash;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'error';
    }
}

function transfer_erc20admin_private_key($fromaddr, $amount, $toaddr, $contract_address, $private_key, $token_decimals)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = "78.129.229.18";
        $wallet_port = "8545";

        $sever_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $sever_path . '/private_key && node send_erc20_admin_private.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $contract_address . ' ' . $private_key . ' ' . $token_decimals, $output, $return_var);
        } else {
            $result = exec('cd ' . $sever_path . '/public/private_key; node send_erc20_admin_private.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $fromaddr . ' ' . $toaddr . ' ' . $amount . ' ' . $contract_address . ' ' . $private_key . ' ' . $token_decimals, $output, $return_var);
        }
        /*echo "<pre>";
            print_r($result);
            echo "<br>";
            print_r($output);
            echo "<br>";
            print_r($return_var);
        */

        $out = json_decode($result);
        return $out->hash;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'error';
    }
}

function unlock_account($address, $pass)
{
    try {
        $output = array();
        $return_var = -1;
        $wallet_ip = "78.129.229.18";
        $wallet_port = "8545";

        $sever_path = $_SERVER["DOCUMENT_ROOT"];
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $result = exec('cd ' . $sever_path . '/crypto && node unlock.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $address . ' ' . $pass, $output, $return_var);
        } else {
            $result = exec('cd ' . $sever_path . '/public/crypto; node unlock.js ' . $wallet_ip . ' ' . $wallet_port . ' ' . $address . ' ' . $pass, $output, $return_var);
        }
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 'error';
    }
}

function get_total_intradebalance($curr)
{
    try {
        $pending_transaction = Trade::query()->whereIn('trade_order.status', ['partially', 'active'])->get();
        $pending_transaction_buy = $pending_transaction->where('type', 'Buy')->where('secondCurrency', $curr)->sum('total');
        $pending_transaction_sell = $pending_transaction->where('type', 'Sell')->where('firstCurrency', $curr)->sum('updated_qty');
        $intrade_total = $pending_transaction_buy + $pending_transaction_sell;
        return number_format($intrade_total, '4', '.', '');
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '0';
    }
}

function get_total_userbalance($curr)
{
    try {
        $user_balance_result = Balance::all();
        $user_total = $user_balance_result->sum($curr);
        return number_format($user_total, '4', '.', '');
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '0';
    }
}

function get_all_pairs()
{
    try {
        $pairs = Pair::all();
        $array = [];
        foreach ($pairs as $pair) {
            $array[] = $pair->pair;
        }
        return $array;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return '';
    }
}

function get_all_currencies()
{
    try {
        $currencies = Currencies::all();
        $array = [];
        foreach ($currencies as $currency) {
            $array[] = $currency->currency_symbol;
        }
        return $array;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return '';
    }
}

function get_reserve_balance($curr)
{
    try {
        $reserve_balance = ReserveBalances::where('currency_symbol', $curr)->first();
        return $reserve_balance->amount;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return 0;
    }
}

function get_admin_bal($curr)
{
    try {
        if ($curr == 'XDC') {
            $adminxdcaddr = decrypt(get_config('xdc_address'));
            $bal = number_format(get_livexdc_bal($adminxdcaddr), 4, '.', '');
        } elseif ($curr == 'M-XDC') {
            $adminxdcaddr = decrypt(get_config('newxdc_address'));
            $bal = number_format(getting_xdc_balance($adminxdcaddr), 4, '.', '');
        } elseif ($curr == 'XDCE') {
            $adminxdceaddr = decrypt(get_config('xdce_address'));
            $bal = number_format(get_livexdce_bal($adminxdceaddr), 4, '.', '');
        } elseif ($curr == 'ETH') {
            $adminethaddr = decrypt(get_config('eth_address'));
            $bal1 = number_format(getting_eth_balance($adminethaddr), 4, '.', '');
            $bitfinex_bal = get_admin_bitfinex_bal('ETH');
            $liquid_bal = get_admin_liquid_bal('ETH');
            $bal = number_format(($bitfinex_bal + $bal1 + $liquid_bal), 4, '.', '');
        } elseif ($curr == 'BTC') {
            $adminbtcaddr = decrypt(get_config('btc_address'));
            $btc_bal = get_btc_wallet_info($adminbtcaddr);
            $bal1 = number_format($btc_bal['balance'], 4, '.', '');
            $bitfinex_bal = get_admin_bitfinex_bal('BTC');
            $liquid_bal = get_admin_liquid_bal('BTC');
            $bal = number_format(($bitfinex_bal + $bal1 + $liquid_bal), '4', '.', '');
        } elseif ($curr == 'BCHABC') {
            $adminbchaddr = decrypt(get_config('bch_address'));
            $bch_bal = get_bch_wallet_info($adminbchaddr);
            $bal = number_format($bch_bal['balance'], 4, '.', '');
        } elseif ($curr == 'BCHSV') {
            $adminbchaddr = decrypt(get_config('bch_address'));
            $bchsv_bal = get_bchsv_wallet_info($adminbchaddr);
            $bal = number_format($bchsv_bal['balance'], 4, '.', '');
        } elseif ($curr == 'USDC') {
            $adminethaddr = decrypt(get_config('eth_address'));
            $bal1 = number_format(get_token_balance($adminethaddr, '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', 6), 4, '.', '');
            $liquid_bal = get_admin_liquid_bal('USDC');
            $bal = number_format(($bal1 + $liquid_bal), '4', '.', '');
        } elseif ($curr == 'USDT') {
            $bal1 = usdt_bal();
            $bitfinex_bal = get_admin_bitfinex_bal('USDT');
            $bal = number_format(($bitfinex_bal + $bal1), '4', '.', '');
        } elseif ($curr == 'XRP') {
            $bal = check_ripple_balance();
        } else {
            $bal = 0;
        }
        return number_format($bal, 4, '.', '');
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return 0;
    }
}

function get_admin_bal_new($curr)
{
    try {
        if ($curr == 'XDC') {
            $adminxdcaddr = decrypt(get_config('xdc_address'));
        //    $bal = number_format(get_livexdc_bal($adminxdcaddr), 4, '.', '');
            $bal = number_format('731362343.5266', 4, '.', '');
        } elseif ($curr == 'M-XDC') {
            $adminxdcaddr = decrypt(get_config('newxdc_address'));
            $bal = number_format(getting_xdc_balance($adminxdcaddr), 4, '.', '');
        } elseif ($curr == 'XDCE') {
            $adminxdceaddr = decrypt(get_config('xdce_address'));
            // $indodax_bal = get_admin_indodax_bal('XDCE');
            $bal = number_format((get_livexdce_bal($adminxdceaddr)), 4, '.', '');
        } elseif ($curr == 'ETH') {
            $adminethaddr = decrypt(get_config('eth_address'));
            $bal = number_format(getting_eth_balance($adminethaddr), 4, '.', '');
            // $bitfinex_bal = get_admin_bitfinex_bal('ETH');
            // $liquid_bal = get_admin_liquid_bal('ETH');
            // $indodax_bal = get_admin_indodax_bal('ETH');
            // $bal = number_format(($bitfinex_bal + $bal1 + $liquid_bal + $indodax_bal), 4, '.', '');
        } elseif ($curr == 'BTC') {
            $adminbtcaddr = decrypt(get_config('btc_address'));
            $btc_bal = get_btc_wallet_info($adminbtcaddr);
            $bal = number_format($btc_bal['balance'], 4, '.', '');
            // $bitfinex_bal = get_admin_bitfinex_bal('BTC');
            // $liquid_bal = get_admin_liquid_bal('BTC');
            // $indodax_bal = get_admin_indodax_bal('BTC');
            // $bal = number_format(($bitfinex_bal + $bal1 + $liquid_bal + $indodax_bal), '4', '.', '');
        } elseif ($curr == 'BCHABC') {
            $adminbchaddr = decrypt(get_config('bch_address'));
            $bch_bal = get_bch_wallet_info($adminbchaddr);
            $bal = number_format($bch_bal['balance'], 4, '.', '');
        } elseif ($curr == 'BCHSV') {
            $adminbchaddr = decrypt(get_config('bch_address'));
            $bchsv_bal = get_bchsv_wallet_info($adminbchaddr);
            $bal = number_format($bchsv_bal['balance'], 4, '.', '');
        } elseif ($curr == 'USDC') {
            $adminethaddr = decrypt(get_config('eth_address'));
            $bal = number_format(get_token_balance($adminethaddr, '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', 6), 4, '.', '');
            // $liquid_bal = get_admin_liquid_bal('USDC');
            // \Log::info(['USDC',$bal1]);
            // $bal = number_format(($bal1 + $liquid_bal), '4', '.', '');
        } elseif ($curr == 'USDT') {
            $bal = usdt_bal();
            // $bitfinex_bal = get_admin_bitfinex_bal('USDT');
            // \Log::info(['USDT',$bal1]);
            // $bal = number_format(($bitfinex_bal + $bal1), '4', '.', '');
        } elseif ($curr == 'XRP') {
            $bal = check_ripple_balance();
            // $indodax_bal = get_admin_indodax_bal('XRP');
            // $liquid_bal = get_admin_liquid_bal('XRP');
            // $bal = number_format(($indodax_bal + $bal1 + $liquid_bal), '4', '.', '');
        } else {
            $bal = 0;
        }
        return number_format($bal, 4, '.', '');
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return 0;
    }
}

function get_admin_indodax_bal($currency)
{
    try {

        if ($currency == 'ETH') {
            $bal = get_config('indodax_eth_balance');
        } else if ($currency == 'BTC') {
            $bal = get_config('indodax_btc_balance');
        } else if ($currency == 'XDCE') {
            $bal = get_config('indodax_xdce_balance');
        } else if ($currency == 'XRP') {
            $bal = get_config('indodax_xrp_balance');
        } else if ($currency == 'idr') {
            $bal = get_config('indodax_idr_balance');
        } else {
            $bal = 0;
        }
        return number_format($bal, '4', '.', '');

    } catch (\Exception $e) {
        \Log::info([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_admin_auto_bal($curr)
{
    try {

        if ($curr == 'ETH') {
            $adminethaddr = decrypt(get_config('auto_eth_address'));
            $bal = number_format(getting_eth_balance($adminethaddr), 4, '.', '');
        } elseif ($curr == 'XDCE') {
            $adminxdceaddr = decrypt(get_config('auto_eth_address'));
            $bal = number_format(get_livexdce_bal($adminxdceaddr), 4, '.', '');
        } elseif ($curr == 'USDC') {
            $adminethaddr = decrypt(get_config('auto_eth_address'));
            $bal = number_format(get_token_balance($adminethaddr, '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', 6), 4, '.', '');
        } else {
            $bal = 0;
        }
        return number_format($bal, 4, '.', '');
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return 0;
    }
}

function generate_currency_address($userid, $currency)
{
    try {
        if ($currency == 'XDC') {
            $xdc = get_user_details($userid, 'XDC_addr');
            $email = get_usermail($userid);
            $phone = get_user_details($userid, 'mobile_no');
            if ($phone == "" || $phone == null) {
                $phone = "";
            } else {
                $phone = owndecrypt($phone);
            }
            $pass = owndecrypt(get_user_details($userid, 'xinpass'));

            if ($xdc == "") {
                $xdcaddr = signup_XDC($email, $phone, $pass);
                $ins = Users::where('id', $userid)->first();
                $ins->XDC_addr = $xdcaddr->public;
                $ins->save();
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDC')->first();
                if ($count != null) {
                    $count->currency_addr = $xdcaddr->public;
                    $count->save();
                } else {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $userid;
                    $addr->currency_id = 1;
                    $addr->currency_name = 'XDC';
                    $addr->currency_addr = $xdcaddr->public;
                    $addr->save();
                }
                return $xdcaddr->public;
            }
        } elseif ($currency == 'ETH') {
            $eth = get_user_details($userid, 'ETH_addr');
            if ($eth == "") {
                $val = create_eth_address();
                $ins = Users::where('id', $userid)->first();

                $ins->ETH_addr = $val;
                $ins->save();
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'ETH')->first();
                if ($count != null) {
                    $count->currency_addr = $val;
                    $count->save();
                } else {
                    $addr = new UserCurrencyAddresses();
                    $addr->user_id = $userid;
                    $addr->currency_id = 2;
                    $addr->currency_name = 'ETH';
                    $addr->currency_addr = $val;
                    $addr->save();
                }
                return $val;
            }
        } elseif ($currency == 'BTC') {
            $btc = get_user_details($userid, 'BTC_addr');
            if ($btc == "") {
                $btcaddr = create_btc_address($userid);
                $ins = Users::where('id', $userid)->first();
                $ins->BTC_addr = $btcaddr;
                $ins->save();
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'BTC')->first();
                if ($count != null) {
                    $count->currency_addr = $btcaddr;
                    $count->save();
                } else {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $userid;
                    $addr->currency_id = 3;
                    $addr->currency_name = 'BTC';
                    $addr->currency_addr = $btcaddr;
                    $addr->save();
                }
                return $btcaddr;
            }
        } elseif ($currency == 'XRP') {
            $xrp_tag = get_user_details($userid, 'xrp_desttag');
            if ($xrp_tag == "") {
                $xrp_desttag = generateredeemString();
                $checktag = get_dest_userid($xrp_desttag);
                if ($checktag != "") {
                    $xrp_desttag = generateredeemString();
                }
                $ins = Users::where('id', $userid)->first();
                $ins->xrp_desttag = $xrp_desttag;
                $ins->save();
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XRP')->first();
                if ($count != null) {
                    $count->currency_addr = $xrp_desttag;
                    $count->save();
                } else {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $userid;
                    $addr->currency_id = 6;
                    $addr->currency_name = 'XRP';
                    $addr->currency_addr = $xrp_desttag;
                    $addr->save();
                }
                return $xrp_desttag;
            }
        } elseif ($currency == 'BCHABC') {
            $bch = get_user_details($userid, 'BCHABC_addr');
            if ($bch == "") {
                $bchaddress = create_bch_address($userid);
                $ins = Users::where('id', $userid)->first();
                $ins->BCHABC_addr = $bchaddress;
                $ins->save();
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'BCHABC')->first();
                if ($count != null) {
                    $count->currency_addr = $bchaddress;
                    $count->save();
                } else {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $userid;
                    $addr->currency_id = 4;
                    $addr->currency_name = 'BCHABC';
                    $addr->currency_addr = $bchaddress;
                    $addr->save();
                }
                return $bchaddress;
            }
        } elseif ($currency == 'BCHSV') {
            $bchsv = get_user_details($userid, 'BCHSV_addr');
            if ($bchsv == "") {
                $bchaddress = create_bchsv_address($userid);
                $ins = Users::where('id', $userid)->first();
                $ins->BCHSV_addr = $bchaddress;
                $ins->save();
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'BCHSV')->first();
                if ($count != null) {
                    $count->currency_addr = $bchaddress;
                    $count->save();
                } else {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $userid;
                    $addr->currency_id = 9;
                    $addr->currency_name = 'BCHSV';
                    $addr->currency_addr = $bchaddress;
                    $addr->save();
                }
                return $bchaddress;
            }
        } elseif ($currency == 'USDT') {
            $usdt = get_user_details($userid, 'USDT_addr');
            if ($usdt == "") {
                $btcaddr = create_usdt_address($userid);
                $ins = Users::where('id', $userid)->first();
                $ins->USDT_addr = $btcaddr;
                $ins->save();
                $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDT')->first();
                if ($count != null) {
                    $count->currency_addr = $btcaddr;
                    $count->save();
                } else {
                    $addr = new UserCurrencyAddresses;
                    $addr->user_id = $userid;
                    $addr->currency_id = 8;
                    $addr->currency_name = 'USDT';
                    $addr->currency_addr = $btcaddr;
                    $addr->save();
                }
                return $btcaddr;
            }
        } elseif ($currency == 'XDCE' || $currency == 'USDC') {
            $xdce = get_user_details($userid, 'XDCE_addr');
            $usdc = get_user_details($userid, 'USDC_addr');

            if ($xdce == "" || $xdce == 'error' || $xdce == null || $usdc == "" || $usdc == "error" || $usdc == null) {
                if ($xdce == "" && $usdc == "") {
                    $val = create_eth_address();
                    if ($val != '' && $val != 'error') {
                        $ins = Users::where('id', $userid)->first();
                        $ins->XDCE_addr = $val;
                        $ins->USDC_addr = $val;
                        $ins->save();
                        $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDCE')->first();
                        if ($count != null) {
                            $count->currency_addr = $val;
                            $count->save();
                        } else {
                            $addr = new UserCurrencyAddresses();
                            $addr->user_id = $userid;
                            $addr->currency_id = 5;
                            $addr->currency_name = 'XDCE';
                            $addr->currency_addr = $val;
                            $addr->save();
                        }
                        $count1 = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDC')->first();
                        if ($count1 != null) {
                            $count1->currency_addr = $val;
                            $count1->save();
                        } else {
                            $addr = new UserCurrencyAddresses();
                            $addr->user_id = $userid;
                            $addr->currency_id = 10;
                            $addr->currency_name = 'USDC';
                            $addr->currency_addr = $val;
                            $addr->save();
                        }
                    }
                    return $val;
                } else if ($xdce == "") {
                    $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDC')->first();
                    if ($count != null) {
                        $ins = Users::where('id', $userid)->first();
                        $ins->XDCE_addr = $count->currency_addr;
                        $ins->save();
                        $count1 = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDCE')->first();
                        if ($count1 != null) {
                            $count1->currency_addr = $count->currency_addr;
                            $count1->save();
                        } else {
                            $addr = new UserCurrencyAddresses();
                            $addr->user_id = $userid;
                            $addr->currency_id = 5;
                            $addr->currency_name = 'XDCE';
                            $addr->currency_addr = $count->currency_addr;
                            $addr->save();
                        }
                        return $count->currency_addr;
                    }
                } else if ($usdc == "") {
                    $count = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'XDCE')->first();
                    if ($count != null) {
                        $ins = Users::where('id', $userid)->first();
                        $ins->USDC_addr = $count->currency_addr;
                        $ins->save();
                        $count1 = UserCurrencyAddresses::where('user_id', $userid)->where('currency_name', 'USDC')->first();
                        if ($count1 != null) {
                            $count1->currency_addr = $count->currency_addr;
                            $count1->save();
                        } else {
                            $addr = new UserCurrencyAddresses();
                            $addr->user_id = $userid;
                            $addr->currency_id = 10;
                            $addr->currency_name = 'USDC';
                            $addr->currency_addr = $count->currency_addr;
                            $addr->save();
                        }
                        return $count->currency->addr;
                    }
                }
            }
        }
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return 0;
    }
}

function test()
{
    require_once app_path('jsonRPCClient.php');
    $checkAddress = "";
    $bitcoin_username = 'alphaexbtc';
    $bitcoin_password = 'AlpH861ExBtC15';
    $bitcoin_portnumber = '9555';
    $bitcoin_host = '78.159.100.156';

    $bitcoin = new jsonRPCClient("http://$bitcoin_username:$bitcoin_password@$bitcoin_host:$bitcoin_portnumber/");

//    $bitcoin = new jsonRPCClient("http://alphaexbtc:AlpH861ExBtC153@78.159.100.156:8333/");
    if ($bitcoin) {
        $checkAddress = $bitcoin->getwalletinfo();
    }

    return $checkAddress['balance'];

//    require_once app_path('easybitcoin.php');
//    $bitcoin = new Bitcoin($bitcoin_username,$bitcoin_password,$bitcoin_host,$bitcoin_portnumber);
//
//    $check = $bitcoin->getblockchaininfo();
//    return $check;

}

//liquid ticker
function get_liquid_ticker()
{
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.liquid.com/products/443/");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);


        $result = curl_exec($ch);
        \Log::info(["error", $result]);

        return $result;

    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//liquid trade history
function get_liquid_history()
{
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.liquid.com/executions?product_id=443&limit=20");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify bitfinex order cancel
function bitfinex_order_cancel($bitfinex_id)
{
    try {
        $date = new DateTime();
        $nonce = (string)round(microtime(true) * 1000);
        \Log::info(["bitfinex timestamp", $nonce]);
        $body = json_encode(array("request" => '/v1/order/cancel', "nonce" => $nonce, "order_id" => $bitfinex_id));
        \Log::info(["bitfinex order body", $body]);
        $data['apikey'] = 'hWduQ4g8ZOpIHaskwzYEZnmZVmjNO6zw39u20kVIKF4';//live

        $data['payload'] = base64_encode($body);
        $data['signature'] = hash_hmac('sha384', $data['payload'], 'zrZiskcp2xzvOuYIdopRAiYQqWlW4ZgU7sBEY7pLVsd');//live
        //new order in bitfinex
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.bitfinex.com/v1/order/cancel");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'X-BFX-APIKEY:' . $data['apikey'],
            'X-BFX-PAYLOAD:' . $data['payload'],
            'X-BFX-SIGNATURE:' . $data['signature'],
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);
        \Log::info(["bitfinex cancel", $result]);
        $datacurl = json_decode($result);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function indodax_order_cancel($bitfinex_id, $pair, $type)
{
    try {
        if ($pair == 'XDC-XRP') {
            $date = new DateTime();
            $indodax_data ['nonce'] = (string)round(microtime(true) * 1000);

            $indodax_data['pair'] = "xdce_idr";
            $indodax_data['order_id'] = $bitfinex_id;
            $indodax_data['type'] = $type;
            $indodax_data['method'] = 'cancelOrder';
            \Log::info(['Indodax data', $indodax_data]);

            $data['apikey'] = 'IXMEHSLV-EXI19ALG-JBDAHWEO-T8KVL126-ZZOZZHQQ';//live
            $data['secret'] = '64300bcc4022ad5b07fcc49592a66287e7a729ff056c00a2ce3137297dca1a44b6a3830071f7d6c3';//live
            // generate the POST data string
            $data['payload'] = http_build_query($indodax_data, '', '&');
            $data['signature'] = hash_hmac('sha512', $data['payload'], $data['secret']);//live
            //new order in bitfinex
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://indodax.com/tapi/");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Sign:' . $data['signature'],
                'Key:' . $data['apikey'],
            ));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, FALSE);
            curl_setopt($ch, CURLOPT_POST, TRUE);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data['payload']);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
            $result = curl_exec($ch);
            $datacurl = json_decode($result, true);
            if (curl_errno($ch)) {
                $errorMessage = curl_error($ch);
                return response()->json(['status' => 0, 'message' => 'Error in place order => ' . $errorMessage, 'data' => []]);
            } else {
                return response()->json(['status' => 1, 'message' => 'Sucessfully', 'data' => $datacurl]);

            }
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}


//trade chart
function trade_chart($pair)
{

    $pair = $pair ? $pair : 'XDC-ETH';
    //high value
    $charts = Charts::where('pair', $pair)->orderBy('datetime', 'desc')->first();
    if ($charts != '' || $charts != null) {
        $startdate = $charts->datetime;
    } else {
        $startdate = '2017-11-15';
    }
    $high = "SELECT DATE(updated_at) as dateval, SUM(triggered_qty) as volume, MAX(triggered_price) as total FROM XDC_trade_mapping where pair='$pair' AND DATE(updated_at) >= DATE('$startdate')  GROUP BY YEAR(updated_at), MONTH(updated_at), DATE(updated_at) ORDER BY DATE(updated_at) ASC";

    $result = DB::select(DB::raw($high));
    $arr = "";
    if ($result) {
        $arr .= "[";
        foreach ($result as $key => $val) {
            $vdate = $val->dateval;
            $high = $val->total;
            $millsec = strtotime($vdate) * 1000;
            $open = trade_open_value($vdate, $pair);
            $close = trade_close_value($vdate, $pair);
            $low = trade_min_value($vdate, $pair);
            $volume = $val->volume;

            $check = Charts::where('pair', $pair)->whereDate('datetime', '=', $vdate)->first();

            if (count($check) > 0) {
                $xdc_charts = $check;
            } else {
                //xdc charts
                $xdc_charts = new Charts();
            }

            $xdc_charts->datetime = $vdate;
            $xdc_charts->high = $high;
            $xdc_charts->millsec = strtotime($vdate) * 1000;
            $xdc_charts->open = $open;
            $xdc_charts->low = $low;
            $xdc_charts->volume = $volume;
            $xdc_charts->close = $close;
            $xdc_charts->pair = $pair;

            $xdc_charts->save();
            $arr .= "[" . $millsec . "," . $open . "," . $high . "," . $low . "," . $close . "," . $volume . "]";
            if (count($result) != ($key + 1)) {
                $arr .= ",";
            }

        }
        $arr .= "]";
    } else {
        $vdate = date('Y-m-d');
        $millsec = strtotime($vdate) * 1000;
        $eval = 0;
        $arr .= "[[" . $millsec . "," . $eval . "," . $eval . "," . $eval . "," . $eval . "," . $eval . "]]";
    }
//        echo $arr;

}

function trade_open_value($date, $pair)
{
    try {
        $res = TradeMapping::select('triggered_price')->whereDate('updated_at', '=', $date)->where(['pair' => $pair])->orderBy('id', 'asc')->limit(1)->first();
        //$value = ($res->Type == 'Buy') ? $res->Price : $res->opt_price;
        //return $value;
        return $res->triggered_price;
    } catch (\Exception $e) {
        echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
    }
}

function trade_close_value($date, $pair)
{
    try {
        $res = TradeMapping::select('triggered_price')->whereDate('updated_at', '=', $date)->where(['pair' => $pair])->orderBy('id', 'desc')->limit(1)->first();
        //$value = ($res->Type == 'Buy') ? $res->Price : $res->opt_price;
        //return $value;
        return $res->triggered_price;
    } catch (\Exception $e) {
        echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
    }
}

function trade_min_value($date, $pair)
{
    try {
        $res = TradeMapping::whereDate('updated_at', '=', $date)->where(['pair' => $pair])->min('triggered_price');
        return $res;
    } catch (\Exception $e) {
        echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
    }
}

function trade_max_value($date, $pair)
{
    try {
        $res = TradeMapping::whereDate('updated_at', '=', $date)->where(['pair' => $pair])->max('triggered_price');
        return $res;
    } catch (\Exception $e) {
        echo $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine();
    }
}


//bitfinex wallet balance
function bitfinex_wallet_balance()
{
    try {
        $date = new DateTime();
        $nonce = (string)round(microtime(true) * 1000);
        $body = json_encode(array("request" => '/v1/balances', "nonce" => $nonce));
        $data['apikey'] = 'hWduQ4g8ZOpIHaskwzYEZnmZVmjNO6zw39u20kVIKF4';//live

        $data['payload'] = base64_encode($body);
        $data['signature'] = hash_hmac('sha384', $data['payload'], 'zrZiskcp2xzvOuYIdopRAiYQqWlW4ZgU7sBEY7pLVsd');//live
        //new order in bitfinex
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.bitfinex.com/v1/balances");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'X-BFX-APIKEY:' . $data['apikey'],
            'X-BFX-PAYLOAD:' . $data['payload'],
            'X-BFX-SIGNATURE:' . $data['signature'],
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);
        $datacurl = json_decode($result);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

//verify bitfinex order status
function bitfinex_order_status_check($bitfinex_id)
{
    try {
        $date = new DateTime();
        $nonce = (string)round(microtime(true) * 1000);
        \Log::info(["bitfinex timestamp", $nonce]);
        $body = json_encode(array("request" => '/v1/order/status', "nonce" => $nonce, "order_id" => $bitfinex_id));
        \Log::info(["bitfinex order body", $body]);
        $data['apikey'] = 'hWduQ4g8ZOpIHaskwzYEZnmZVmjNO6zw39u20kVIKF4';//live

        $data['payload'] = base64_encode($body);
        $data['signature'] = hash_hmac('sha384', $data['payload'], 'zrZiskcp2xzvOuYIdopRAiYQqWlW4ZgU7sBEY7pLVsd');//live
        //new order in bitfinex
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.bitfinex.com/v1/order/status");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'X-BFX-APIKEY:' . $data['apikey'],
            'X-BFX-PAYLOAD:' . $data['payload'],
            'X-BFX-SIGNATURE:' . $data['signature'],
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);
        \Log::info(["bitfinex response", $result]);
        $datacurl = json_decode($result);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function indodax_order_status_check($bitfinex_id, $pair)
{
    try {
        if ($pair == 'XDC-XRP') {
            $date = new DateTime();
            $indodax_data['nonce'] = (string)round(microtime(true) * 1000);
            \Log::info(["Indodax timestamp", $indodax_data['nonce']]);

            $indodax_data['method'] = 'getOrder';
            $indodax_data['pair'] = 'xdce_idr';
            $indodax_data['order_id'] = $bitfinex_id;

            $data['apikey'] = 'IXMEHSLV-EXI19ALG-JBDAHWEO-T8KVL126-ZZOZZHQQ';//live
            $data['secret'] = '64300bcc4022ad5b07fcc49592a66287e7a729ff056c00a2ce3137297dca1a44b6a3830071f7d6c3';//live
            // generate the POST data string
            $data['payload'] = http_build_query($indodax_data, '', '&');
            $data['signature'] = hash_hmac('sha512', $data['payload'], $data['secret']);//live
            //new order in bitfinex
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://indodax.com/tapi/");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Sign:' . $data['signature'],
                'Key:' . $data['apikey'],
            ));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, FALSE);
            curl_setopt($ch, CURLOPT_POST, TRUE);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data['payload']);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
            $result = curl_exec($ch);
            $datacurl = $result;
            // \Log::info(["Indodax Getorder", $datacurl]);
            if (curl_errno($ch)) {
                $errorMessage = curl_error($ch);
                return response()->json(['status' => 0, 'message' => 'Error in place order => ' . $errorMessage, 'data' => []]);
            } else {
                // $result = response()->json([$datacurl]);
                \Log::info(["response of getorder", $datacurl]);
                return $result;

            }
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

function get_admin_bitfinex_bal($currency)
{
    try {
//        $balance = bitfinex_wallet_balance();
//        if (isset($balance)) {
//            $balance = json_decode($balance);
//            foreach ($balance as $val) {
//                $curr = $val->currency;
//                $bal = $val->available;
//                $arr = array('currency' => $curr, 'balance' => $bal);
//                $data[] = $arr;
//                if ($currency == 'BTC') {
//                    if ($curr == 'btc') {
//                        return $bal;
//                    }
//                } else if ($currency == 'ETH') {
//                    if ($curr == 'eth') {
//                        return $bal;
//                    }
//                } else if ($currency == 'USDT') {
//                    if ($curr == 'ust') {
//                        return $bal;
//                    }
//                }
//            }
//            return json_encode($data);
//        }

        if ($currency == 'ETH') {
            $bal = get_config('bitfinex_eth_balance');
        } else if ($currency == 'BTC') {
            $bal = get_config('bitfinex_btc_balance');
        } else if ($currency == 'USDT') {
            $bal = get_config('bitfinex_usdt_balance');
        } else {
            $bal = 0;
        }
        return number_format($bal, '4', '.', '');

    } catch (\Exception $e) {
        \Log::info([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function bitfinex_order_mapping($buyer_type, $Reciever_type, $qty, $price, $reciever_user_id, $reciever_txid, $buyer_txid, $pair_id, $pair, $bitfinex_id)
{
    try {
        $cur = explode("-", $pair);
        $first_currency = $cur[0];
        $second_currency = $cur[1];
        if ($Reciever_type == 'Buy') {
            $currency = $first_currency;
            $user_balance = get_userbalance($reciever_user_id, $currency) + $qty;
            $deduct_bal = get_userbalance($reciever_user_id, $second_currency) - $price * $qty;
            $deduct_currency = $second_currency;
        } else {
            $currency = $second_currency;
            $total = $price * $qty;
            $user_balance = get_userbalance($reciever_user_id, $currency) + $total;
            $deduct_bal = get_userbalance($reciever_user_id, $first_currency) - $qty;
            $deduct_currency = $first_currency;
        }
        $trade = new Trade();
        $trade->unique_id = $reciever_txid;
        $trade->trade_id = $reciever_txid;
        $trade->trade_type = 'limit_order';
        $trade->user_id = $reciever_user_id;
        $trade->pair_id = $pair_id;
        $trade->pair = $pair;
        $trade->firstCurrency = $first_currency;
        $trade->secondCurrency = $second_currency;
        $trade->price = $price;
        $trade->total = $price * $qty;
        $trade->updated_total = $price * $qty;
        $trade->type = $Reciever_type;
        $trade->process = '0';
        $trade->bitfinex_id = $bitfinex_id;
        $trade->fee = 0;
        $trade->original_qty = $qty;
        $trade->updated_qty = 0;
        $trade->status = 'completed';
        if ($trade->save()) {
            $user_bal = UserBalance::where('user_id', $reciever_user_id)->first();
            $user_bal->$currency = $user_balance;
            $user_bal->$deduct_currency = $deduct_bal;
            $user_bal->save();

            $trade_mapping = new TradeMapping();
            $trade_mapping->unique_id = 'MTX' . time();
            $trade_mapping->pair = $pair;
            if ($buyer_type == 'Buy') {
                $trade_mapping->buy_trade_order_id = $buyer_txid;
                $trade_mapping->sell_trade_order_id = $trade->id;
            } else {
                $trade_mapping->buy_trade_order_id = $trade->id;
                $trade_mapping->sell_trade_order_id = $buyer_txid;
            }

            $trade_mapping->type = $buyer_type;
            $trade_mapping->triggered_price = $price;
            $trade_mapping->triggered_qty = $qty;
            $trade_mapping->total = $qty * $price;
            $trade_mapping->save();
            trade_chart($pair);
        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
    }
}

//verify order status
function liquid_order_status_check($bitfinex_id)
{
    try {

        $token_id = "1011394";
        $token_secret = "RYsoJoKL3humfI6gc2jX5V/mNcA9PxLjnm/Xrfcu4ms4mgroFYJRRcujoaJvU0fTVcDPz40G1l9aCJTBHrfeIQ==";
        $path = 'https://api.liquid.com/orders/' . $bitfinex_id;
        $nonce = $nonce = (string)round(microtime(true) * 1000);

        $auth = array("path" => $path, "nonce" => $nonce, "token_id" => $token_id);
        $payload = JWT::encode($auth, $token_secret);

        // $body = json_encode(array("order"=>array("order_type"=>'limit',"product_id"=>"443","side"=>$said,"quantity"=>$amount,"price"=>$price)));

        // \Log::info(["liquid body", $auth,$body,$payload]);
        //new order in bitfinex
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $path);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'X-Quoine-API-Version:' . '2',
            'X-Quoine-Auth:' . $payload,
            'Content-Type:' . 'application/json',
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);
        \Log::info(["liquid order response", $result]);
        $datacurl = json_decode($result);
        if (curl_errno($ch)) {
            $isError = true;
            $errorMessage = curl_error($ch);
            \Log::info(["liquid error response", $errorMessage]);
            return json_encode(['id' => 0, 'status' => 0, 'message' => 'Error from api side']);
        }
        curl_close($ch);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return json_encode(['id' => 0, 'status' => 0, 'message' => 'Error from server side']);
    }
}

//liquid wallet balance
function liquid_wallet_balance()
{
    try {

        $token_id = "1011394";
        $token_secret = "RYsoJoKL3humfI6gc2jX5V/mNcA9PxLjnm/Xrfcu4ms4mgroFYJRRcujoaJvU0fTVcDPz40G1l9aCJTBHrfeIQ==";
        $path = 'https://api.liquid.com/accounts/balance/';
        $nonce = $nonce = (string)round(microtime(true) * 1000);

        $auth = array("path" => $path, "nonce" => $nonce, "token_id" => $token_id);
        $payload = JWT::encode($auth, $token_secret);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $path);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'X-Quoine-API-Version:' . '2',
            'X-Quoine-Auth:' . $payload,
            'Content-Type:' . 'application/json',
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);
        $datacurl = json_decode($result);
        if (curl_errno($ch)) {
            $isError = true;
            $errorMessage = curl_error($ch);
            \Log::info(["liquid error response", $errorMessage]);
            return json_encode(['id' => 0, 'status' => 0, 'message' => 'Error from api side']);
        }
        curl_close($ch);
        return $result;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return json_encode(['id' => 0, 'status' => 0, 'message' => 'Error from server side']);
    }
}

function get_admin_liquid_bal($currency)
{
    try {
        if ($currency == 'ETH') {
            $bal = get_config('liquid_eth_balance');
        } else if ($currency == 'BTC') {
            $bal = get_config('liquid_btc_balance');
        } else if ($currency == 'USDC') {
            $bal = get_config('liquid_usdc_balance');
        } else {
            $bal = 0;
        }
        return number_format($bal, '4', '.', '');

    } catch (\Exception $e) {
        \Log::info([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return 0;
    }
}

function get_indodax_price($convert_pair)
{
    try {
        $url = "https://indodax.com/api/" . $convert_pair . "/ticker";
        $data = 'convert_pair=' . $convert_pair;
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => array(

                "Cache-Control: no-cache",
                "cache-control: no-cache"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        // \Log::info(["indodax", $response]);
        // $result = json_decode($response);
        curl_close($curl);

        return $response;
    } catch (\Exception $e) {
        \Log::error([$e->getMessage(), $e->getLine(), $e->getFile()]);
        return '';
    }
}

function indodax_wallet_balance()
{
    try {
        $date = new DateTime();
        $indodax_data['nonce'] = (string)round(microtime(true) * 1000);
        \Log::info(["Indodax timestamp", $indodax_data['nonce']]);

        $indodax_data['method'] = 'getInfo';
        // $indodax_data['pair'] = 'xdce_idr';
        // $indodax_data['order_id'] = $bitfinex_id;
        $data['apikey'] = 'IXMEHSLV-EXI19ALG-JBDAHWEO-T8KVL126-ZZOZZHQQ';//live
        $data['secret'] = '64300bcc4022ad5b07fcc49592a66287e7a729ff056c00a2ce3137297dca1a44b6a3830071f7d6c3';//live
        // generate the POST data string
        $data['payload'] = http_build_query($indodax_data, '', '&');
        $data['signature'] = hash_hmac('sha512', $data['payload'], $data['secret']);//live
        //new order in bitfinex
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://indodax.com/tapi/");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Sign:' . $data['signature'],
            'Key:' . $data['apikey'],
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data['payload']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);

        if (curl_errno($ch)) {
            $errorMessage = curl_error($ch);
            return response()->json(['status' => 0, 'message' => 'Error in place order => ' . $errorMessage, 'data' => []]);
        } else {
            return $result;

        }
    } catch (\Exception $e) {
        \Log::error([$e->getFile(), $e->getLine(), $e->getMessage()]);
        return '';
    }
}

?>
