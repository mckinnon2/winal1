<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ICOTrade extends Model
{
    //

    protected $table = 'ico_buy_trade';
    public $timestamps = false;
}
