<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ICORate  extends Model
{
    //

    protected $table = 'ico_rate';
    public $timestamps = false;

}
