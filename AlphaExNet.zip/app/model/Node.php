<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Node extends Model
{
    //
    protected $table = 'nodes';
}
