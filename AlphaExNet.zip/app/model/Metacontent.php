<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Metacontent extends Model
{
    //
     protected $table = 'meta_content';
}
