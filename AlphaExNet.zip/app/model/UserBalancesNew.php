<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class UserBalancesNew extends Model
{
    //
    protected $table = 'user_balance_new';
}
