<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Charts extends Model
{
    //

    protected $table = 'charts';
}
