<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class XinfinDetails extends Model
{
    //
    protected $table = 'xinfin_details';
}
