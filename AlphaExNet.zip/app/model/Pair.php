<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Pair extends Model {
	//
	protected $table = 'pair';
}
