<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class UserCurrencyAddresses extends Model
{
    //
    protected $table = 'user_currency_addresses';
}
