<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Adminwallet extends Model {
	//
	protected $table = 'wallet_login';
}
