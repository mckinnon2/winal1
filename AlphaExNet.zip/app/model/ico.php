<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ico extends Model
{
    //
    protected $table = 'ico';
}
