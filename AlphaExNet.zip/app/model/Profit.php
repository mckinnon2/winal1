<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Profit extends Model
{
    //

     protected $table = 'coin_theft';
}
