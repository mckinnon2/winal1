<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class XinfinRequests extends Model
{
    //
    protected $table = 'xinfin_requests';
}
