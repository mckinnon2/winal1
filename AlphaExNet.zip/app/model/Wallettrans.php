<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Wallettrans extends Model {
	//

	protected $table = 'wallettrans';
}
