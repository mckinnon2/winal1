<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Transactionfee extends Model
{
    //
    protected $table = 'transaction_fee';
}
