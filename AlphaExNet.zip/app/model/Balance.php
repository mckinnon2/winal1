<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Balance extends Model
{
    //

    protected $table = 'userbalance';
}
