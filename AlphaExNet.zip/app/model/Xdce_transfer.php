<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Xdce_transfer extends Model {
    //
    protected $table = 'xdce_transfer';
}
