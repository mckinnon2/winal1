<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ExtraBonus extends Model
{
    //

    protected $table = 'referral_extra_earning';
}