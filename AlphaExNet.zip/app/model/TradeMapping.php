<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class TradeMapping extends Model
{
    //

    protected $table = 'trade_mapping';
}
