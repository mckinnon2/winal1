<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class UserBalance extends Model
{
    //

    protected $table = 'userbalance';
}
