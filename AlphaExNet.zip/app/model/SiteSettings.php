<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class SiteSettings extends Model
{
    //

    protected $table = 'site_settings';
}
