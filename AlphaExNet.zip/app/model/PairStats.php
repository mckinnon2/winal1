<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class PairStats extends Model {
    //
    protected $table = 'pair_stats';
}
