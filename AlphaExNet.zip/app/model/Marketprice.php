<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Marketprice extends Model
{
    //
      protected $table = 'liveprice';
}
