<?php

 namespace App\model;

 use Illuminate\Database\Eloquent\Model;

 class Mintrade extends Model
 {
     //

     protected $table = 'min_trade';
 }