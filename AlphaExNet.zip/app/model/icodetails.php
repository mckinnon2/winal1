<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class icodetails extends Model
{
    //
    protected $table = 'icoDetails';
}
