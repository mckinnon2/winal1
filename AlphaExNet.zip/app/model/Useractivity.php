<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Useractivity extends Model
{
    //

    protected $table = 'user_activity';
}
