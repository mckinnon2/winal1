<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Cms extends Model
{
    //
     protected $table = 'cms';
}
