<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Coinorder extends Model
{
    //

    protected $table = 'coin_order';
}
