<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class MinWithdrawal extends Model
{
    //

    protected $table = 'min_withdrawal';
}
