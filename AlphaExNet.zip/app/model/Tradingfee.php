<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Tradingfee extends Model
{
    //
     protected $table = 'trading_fee';
}
