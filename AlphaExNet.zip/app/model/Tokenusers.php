<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Tokenusers extends Model
{
    //
    protected $table = 'tokenusers';
}
