<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class OTP extends Model
{
    //

    protected $table = 'otp';
}
