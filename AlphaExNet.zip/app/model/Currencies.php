<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Currencies extends Model
{
    //
    protected $table = 'currencies';
}
