<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Erc20Details extends Model
{
    //
    protected $table = 'erc20_details';
}
