<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ReserveBalances extends Model
{
    //

    protected $table = 'reserve_balances';
}
