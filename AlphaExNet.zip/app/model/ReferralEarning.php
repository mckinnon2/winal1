<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ReferralEarning extends Model
{
    //

    protected $table = 'referral_earning';
}
