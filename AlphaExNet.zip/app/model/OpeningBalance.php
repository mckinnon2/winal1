<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class OpeningBalance extends Model
{
    //

    protected $table = 'useropeningbalance';
    public $timestamps = false;
}
