<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class XDCChart extends Model
{
    //

     protected $table = 'xdcchartprice';
}
