<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ClosingBalance extends Model
{
    //

    protected $table = 'userclosingbalance';
    public $timestamps = false;
}
