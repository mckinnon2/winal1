<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ReferralExtra extends Model
{
    //

    protected $table = 'referral_extra';
}
