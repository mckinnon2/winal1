<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Template extends Model
{
    //
    protected $table = 'email_template';
}
