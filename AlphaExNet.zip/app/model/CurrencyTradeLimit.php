<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class CurrencyTradeLimit extends Model
{
    //

    protected $table = 'currency_tradelimitprice';
}
