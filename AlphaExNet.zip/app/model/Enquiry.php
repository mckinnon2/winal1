<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Enquiry extends Model
{
    //
    protected $table = 'enquiry';
}
