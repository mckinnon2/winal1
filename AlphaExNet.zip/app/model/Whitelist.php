<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Whitelist extends Model
{
    //
     protected $table = 'whitelist';
}
