@extends('front.layout.front')

@section('content')

    <!-- trade home data and datatables -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">


                <div class="col-sm-12">
                    <div class="alert-static" style="display: block">
                        <span class="closebtn" onclick="this.parentElement.style.display='none'">&times;</span>
                        <p>Due to ongoing Xinfin ICO,We have been instructed by Xinfin Management to suspend trading of XDC and XDCe Token on AlphaEX with effect from 27 Feb, 2018. All other functions of AlphaEx except trade like withdrawal, deposits, opening account would be available for users. The trading of XDC and XDCe would resume after the ongoing ICO is completed.</p>
                    </div>
                    <div>
                        <p>How to contribute In XDCe ICO  <a  href="{{URL::asset('front')}}/assets/ICO_{{$second_currency}}.pdf" target="_blank">click here.</a></p>
                    </div>
                    @include('front.alert')
                    @if(Session::has('Success'))
                        <div class="alert alert-info">
                            <a class="close" data-dismiss="alert">×</a>
                            <strong>Heads Up!</strong> {!!Session::get('Success')!!}
                        </div>
                    @endif
                    <div class="page-header page-header-panel">
                        <div class="col-md-9 text-center" >
                            <h3>ICO {{$currency}} :&nbsp;1 {{$second_currency}} = {{$amount}} {{$currency}}</h3>

                        </div>

                        <div class="col-md-3 text-right"><strong>Contribute XDCe using&nbsp;</strong><span id="book_selector">
                        <div class="tab-navigation">
                            <ul class="nav" role="tablist">
                            <li role="presentation" class="dropdown open">

                            <select id="select-box" onchange="change_ico(this.value)">

                                <option value="ETH" @if($second_currency == 'ETH') selected @endif>ETH</option>

                                <option value="BTC" @if($second_currency == 'BTC') selected @endif>BTC</option>

                                <option value="XRP"  @if($second_currency == 'XRP') selected @endif>XRP</option>

                                 <option value="BCH" @if($second_currency == 'BCH') selected @endif>BCH</option>


                            </select>
                            </li>
                            </ul>
                        </div>
                    </span></div>

                    </div>
                </div>
                <div>
                    <form style="display: hidden" action="{{url("/testico")}}" method="POST" id="ico_form">
                        <input type="hidden" id="ico_currency" name="ico_currency" value="XDCE"/>
                        <input type="hidden" id="sell_currency" name="sell_currency" value=""/>
                        {{csrf_field()}}
                    </form>
                </div>


                <div id="col-sm-12">

                    <!-- XDC/BTC chart and all data and datatables -->
                    <div id="tab-1" class="tab--content">
                        <div class="col-md-8 mt10">
                            <h4>{{$currency}}-{{$second_currency}}</h4>

                        </div>

                        {{--<div class="col-md-8">--}}
                        {{--<div id="background-img" class="img" style="height: 400px; min-width: 310px"></div>--}}

                        {{--</div>--}}
                        <div class="card card-inverse col-md-7 mb40">
                            <img src="{{URL::asset('front')}}/assets/imgs/ico-banner.jpg" class="img-responsive" alt="Cinque Terre">
                            {{--<img class="card-img" width="650" height="400"  alt="Card image">--}}
                        </div>


                    </div>

                    <!-- buy sell box data -->
                    <div class="col-md-5">

                        <div class="panel panel-buy qb-selector">
                            <div class="panel-heading">
                                <p class="text-center">Contribute For XDCe</p>
                                <p class="text-center">Minimum contribution: {{$sell_limit}} {{$second_currency}} </p>

                            </div>
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div id="load_message" class="text-center">
                                    </div>

                                    <div class="tab-pane active" id="buy">
                                        <label class="pull-left"><strong>{{$second_currency}}:</strong><br>
                                            {{$second_currency_bal}}&nbsp;</label>
                                        <label class="pull-right">&nbsp;<strong>{{$currency}}:</strong><br>
                                            {{$currency_bal}}</label>
                                        <form class="tradeinput form-horizontal" data-tradedirection="buy"
                                              role="form" autocomplete="off" id="buy_ico_form"
                                              action="{{url('/buyico1')}}" method="post">
                                            <div>
                                                {{csrf_field()}}
                                                <input type="hidden" name="first_currency" id="first_currency" value="{{$currency}}">
                                                <input type="hidden" name="second_currency" id="second_currency" value="{{$second_currency}}">
                                                <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i
                                                                    class="fa"><img
                                                                        src="{{URL::asset('front')}}/assets/icons/{{$second_currency}}.png"
                                                                        width="16px" height="16px"></i></span>
                                                    <input id="second_currency_amount"
                                                           name="second_currency_amount"
                                                           onkeyup="validate_ETH()"
                                                           class="form-control block_non_numbers"
                                                           value="0">
                                                </div>
                                                <label id ='error-msg' style="display: none;color: red">Insufficent Balance but you can still click contribute</label>
                                                <br>
                                                <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i
                                                                    class="fa"><img
                                                                        src="{{URL::asset('front')}}/assets/icons/{{$currency}}.png"
                                                                        width="16px" height="16px"></i></span>
                                                    <input readonly id ='{{$currency}}_amount' class="form-control block_non_numbers"
                                                           value="0">

                                                </div>


                                            </div>
                                            <div>
                                                <br>
                                                <input type="checkbox" name="terms" id="terms" onchange="activateButton(this)"><a href="{{URL::asset('front')}}/assets/XDCE Token Contribution Agreement.pdf" target="_blank">&nbsp;&nbsp; I Agree Terms & Conditions</a>

                                            </div>
                                            <div class="qb-button">
                                                <button type="button"
                                                        class="btn btn-green btn-action" id="btn-buy" onclick="submit_confirm_modal()" disabled="true">Contribute
                                                </button>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-error"></div>
                            <div class="panel-footer">
                                <div class="row">
                                    <input type="hidden" id="trade_frm_id" value="">
                                    <div class="col-xs-6">
                                        <div>Fee: 0</div>
                                        <span id="trade_fee">0 %</span>
                                    </div>
                                    <div class="col-xs-6">
                                        <div> Total :</div>
                                        <span id="swapTotal">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- / buy sell box data -->


                </div>
                <!-- / XDC/BTC chart and all data and datatables -->


            </div>

            <div class="col-md-12 mb40">

                <div class="head">
                    <div class="name">ICO Buy Orders</div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-bordered tableBorder" id="ico_buy_table">
                        <thead>
                        <tr>
                            <th class="text-center">ICO</th>
                            <th class="text-center">Currency</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Price</th>
                            <th class="text-center">Total</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">DateTime</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody id="sell_ord_tbl_data">
                        @if($Trade)
                            @foreach($Trade as $single_trade)
                                <tr>
                                    <td class="text-center">{{$single_trade->FirstCurrency}}</td>
                                    <td class="text-center">{{$single_trade->SecondCurrency}}</td>
                                    <td class="text-center price">{{sprintf('%.8f',$single_trade->Amount)}}</td>
                                    <td class="text-center price">{{$single_trade->Price}}</td>
                                    <td class="text-center price">{{$single_trade->Total}}</td>
                                    <td class="text-center">{{$single_trade->Status}}</td>
                                    <td class="text-center">{{$single_trade->created_at}}</td>
                                    @if($single_trade->Status == 'Pending')
                                        <td>&nbsp;<a href="{{url('/cancel_ico_trade/'.$single_trade->id)}}"><i class="fa fa-times" style="color: red"></i></a></td>
                                    @else
                                        <td></td>
                                    @endif
                                </tr>
                            @endforeach

                        @endif

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <!-- / trade home data and datatables -->

    <div id="confirm_modal" class="modal danger fade modal_1"  role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><strong>{{$second_currency}} Deposit Address</strong></h4>
                </div>
                <div class="modal-body">
                    <label id="info">Your  Order will be pending since you don't have enough balance.<br>
                        Once you deposit remaining balance to your {{$second_currency}} Address.Your order will be completed automatically.
                    </label>
                    <label id="bal_confirmation">Please deposit .
                    </label>
                    @if($second_currency == 'BCH')
                        <div class="profile-desk">
                            <div id="btcaddr_mess"></div>
                            <h4 style="font: bold">This is {{$second_currency}} Address</h4>
                            <div class="text-center">
                                <img id="barcode" src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=" alt="" class="mb20">
                                <h5 class="center"><strong>Address:</strong><h5 class="center" id="bchaddr">{{get_user_details($user_id,'BCH_addr')}}</h5></h5>
                                <h5 class="center"><strong>Legacy Address:&nbsp;</strong><h5 class="center" id="legacy_address"></h5></h5>
                                <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('bchaddr')">Copy Address</button>
                                <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('legacy_address')">Copy Legacy</button>

                            </div>
                        </div>
                    @elseif($second_currency == 'XRP')
                        <div class="profile-desk">

                            <div id="xrpaddr_mess"></div>
                            <h4 style="font: bold">This is Ripple-XRP Address</h4>
                            <div class="text-center">
                                <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={{decrypt(get_config('xrp_address'))}}" alt="" class="mb20">
                                <h5 class="center" id="xrpaddr">{{decrypt(get_config('xrp_address'))}}</h5>
                                <h5 class="center">Destination Tag :{{get_user_details($user_id,'xrp_desttag')}} </h5>
                                <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('xrpaddr')">Copy Address</button>
                            </div>
                            <br>
                            <label><strong>Note:</strong></label>
                            <label style="font-size: smaller"><strong>1.</strong> Please only transfer ripple tokens to this wallet address. Sending any others token may result into a loss and no wallet credit.<br><br><strong>2.</strong>
                                Enter your destination tag in the source wallet (from where you are sending XRP tokens to Alphaex wallet) along with the wallet address as mentioned above. If your wallet doesn’t ask for a destination tag, please transfer your XRP tokens to a local wallet first and then transfer it to Alphaex using your destination tag as a unique and compulsory identifier.<br><br>
                                <strong>3.</strong>If you send XRP tokens without mentioning your destination tag, your deposit will not be processed and Alphaex will not be responsible for the loss of tokens in that case.</label>
                        </div>
                    @else
                        <div id="btcdeposit" class="tab-pane {{admin_class('BTC')}}">
                            <div class="profile-desk">

                                <h4>{{$second_currency}} Deposit</h4>
                                <div id="btcaddr_mess"></div>
                                <h4 style="font: bold">{{$second_currency}} Deposit Address</h4>
                                <div class="text-center">
                                    <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={{get_user_details($user_id,$second_currency.'_addr')}}" alt="" class="mb20">
                                    <h5 class="center" id="btcaddr">{{get_user_details($user_id,$second_currency.'_addr')}}</h5>
                                    <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('btcaddr')">Copy Address</button>

                                </div>
                            </div>
                        </div>
                    @endif


                </div>
                <div class="modal-footer">
                    <a id="cancel_confirm" class="btn btn-danger" data-dismiss="modal">Ok</a>
                    <button type="button" class="btn btn-blue" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <div id="cancel_confirm_modal" class="modal danger fade"  role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><strong>Ico Contribute</strong></h4>
                </div>
                <div class="modal-body">
                    <p id="pending-msg">Your order will be under pending state Do you want to continue.?</p>
                </div>
                <div class="modal-footer">
                    <a id="cancel_confirm" class="btn btn-danger" onclick="submitForm()">Ok</a>
                    <button type="button" class="btn btn-blue" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

@endsection

@section('xscript')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

    <script>
        function activateButton(element) {

            if(element.checked) {
                document.getElementById("btn-buy").disabled = false;
            }
            else  {
                document.getElementById("btn-buy").disabled = true;
            }

        }
    </script>
    <script src="{{URL::asset('front')}}/assets/js/Bchaddress.js"></script>

    <script>
        function change_ico(pair)
        {
            $("#ico_currency").val('XDCE');
            $("#sell_currency").val(pair);
            $("#ico_form").submit();

        }

    </script>

    <script>
        $.validator.addMethod('adecimal', function (value, element) {
            var RE = /^\d*(\.\d{1})?\d{0,2}$/;
            if(RE.test(value)){
                return true;
            }else{
                return false;
            }

        }, "Please enter a correct number");

        function submitModal()
        {




            if(ETH <= {{$second_currency_bal}})
            {

                var amount = ETH*'{{$amount}}';
                document.getElementById('{{$currency}}_amount').value = amount;
                document.getElementById('swapTotal').innerHTML = amount;
            }
            else
            {

                if({{$second_currency_bal}} >= 0)
                {
                    var amount = ETH - {{$second_currency_bal}};

                    document.getElementById('bal_confirmation').innerHTML = "Please Deposit "+amount+" "+ '{{$second_currency}}'+" to the below mentioned address to complete your order";
                    $('#cancel_confirm_modal').modal('show');
                }
            else
                {
                    document.getElementById('bal_confirmation').innerHTML = "You Have already one pending order.Please complete the pending order by depositing the remaining amount to below mentioned address"
                    $('#confirm_modal').modal('show');
                }




            }
        }

        function submitForm() {
            var ETH = document.getElementById('second_currency_amount').value;
            if({{$second_currency_bal}} >= 0)
            {
                var amount = ETH - {{$second_currency_bal}};
                document.getElementById('bal_confirmation').innerHTML = "Please Deposit minimum "+amount+" "+ '{{$second_currency}}'+" to the below mentioned address to process your transaction.<br>Additional amount will be added to your wallet balance";


                $('#cancel_confirm_modal').modal('hide');
                $('#confirm_modal').modal('show');
            }
        else
            {
                document.getElementById("info").style.display = "none";
                document.getElementById('bal_confirmation').innerHTML = "You Have already one pending order.Please complete the pending order by depositing the remaining amount to below mentioned address";
                $('#cancel_confirm_modal').modal('hide');
                $('#confirm_modal').modal('show');
            }

        }
        //event will be fired whenever deposit modal closes
        $("#confirm_modal").on("hidden.bs.modal", function ()
        {
            if({{$second_currency_bal}} >= 0)
            {
                $("#buy_ico_form").submit();
            }
        });

        function submit_confirm_modal()
        {
            var ETH = document.getElementById('second_currency_amount').value;
            var difference = {{$second_currency_bal}}-ETH;
            if('{{$second_currency}}' == 'BCH')
            {
                var toLegacyAddress = bchaddr.toLegacyAddress('{{get_user_details($user_id,'BCH_addr')}}');
                console.log('{{get_user_details($user_id,'BCH_addr')}}');
                console.log(toLegacyAddress);

                document.getElementById('barcode').src = "https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl="+toLegacyAddress;

                document.getElementById('legacy_address').innerHTML = toLegacyAddress;
            }
            if(difference < 0)
            {
                if({{$second_currency_bal}} >= 0)

                {
                    document.getElementById('pending-msg').innerHTML = "Your order will be processed once the funds are received.Click ok to get deposit address"


                    $('#cancel_confirm_modal').modal('show');
                }
            else
                {

                    document.getElementById('pending-msg').innerHTML = "Sorry this order cannot be processed since you already have one pending order";

                    $('#cancel_confirm_modal').modal('show');
                }
            }
            else
                {
                    $("#buy_ico_form").submit();
                }

        }

        $(document).ready( function () {
            $("#buy_ico_form").validate({
                rules:
                    {
                        second_currency_amount: {required: true, min: {{$sell_limit}}, adecimal: true}
                    },
                messages:
                    {
                        second_currency_amount: {
                            required: '{{$second_currency}} amount is required',
                            min: 'Minimum buy amount is {{$sell_limit}}',
                            adecimal: 'ecimal point cannot be greater than 3'
                        }
                    }
            });
        });
    </script>

    <script>
        function validate_ETH()
        {
            var ETH = document.getElementById('second_currency_amount').value;

            if(ETH <= {{$second_currency_bal}})
            {
                document.getElementById('error-msg').style.display = 'none';
                var amount = ETH*'{{$amount}}';
                document.getElementById('{{$currency}}_amount').value = amount;
                document.getElementById('swapTotal').innerHTML = amount;
            }
            else
            {
                var amount = ETH*'{{$amount}}';
                document.getElementById('{{$currency}}_amount').value = amount;
                document.getElementById('swapTotal').innerHTML = amount;
                document.getElementById('error-msg').style.display = 'block';



            }
        }
    </script>
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        function copyToClipboard(elementId) {


            var aux = document.createElement("input");
            aux.setAttribute("value", document.getElementById(elementId).innerHTML);
            document.body.appendChild(aux);
            aux.select();
            document.execCommand("copy");

            document.body.removeChild(aux);

            document.getElementById(elementId+'_mess').innerHTML = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Address Copied</div>';

        }
    </script>
    <style>
        .alert-static {
            padding: 20px;
            background-color: lightskyblue;
            color: white;
        }

        .closebtn {
            margin-left: 15px;
            color: white;
            font-weight: bold;
            float: right;
            font-size: 22px;
            line-height: 20px;
            cursor: pointer;
            transition: 0.3s;
        }

        .closebtn:hover {
            color: black;
        }

        .modal_1 {
            overflow-y:scroll;
        }
    </style>

    <script>
        jQuery(window).on("load", function(){
            console.log("dfgh");
        });
        $(document).on('ready', function () {
            $('#ico_buy_table').DataTable({
                "scrollY": "250px",
                "scrollCollapse": true,
                "paging": false,
                "ordering": false,
                "info": false,
            });

        });
    </script>
@endsection
