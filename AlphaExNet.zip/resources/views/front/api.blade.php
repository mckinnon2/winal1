@extends('front.layout.front')
@section('content')
    <div class="clearfix"></div>
    <div class="main-flex">
        <div class="main-content inner_content">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-md-12">
                        <div class="panel panel-default panel-heading-space">
                            <div class="panel-heading">Cryptocurrencies exchange rates API</div>
                            <div class="panel-body">
                                <p>AlphaEx provides unique volume of cryptocurrency exchange rates data, which is delivered in easy-to-integrate JSON format via simple HTTPS requests. Prices are updated every 30 seconds.</p>
                                <hr>
                                <h4>XDC-BTC Ticker</h4>
                                <p>Returns actual volume-weighted price with respect to last executed XDC-BTC Trade, total 24h volume,US$ price and the price change. </p>
                                <br>
                                <h5>XDC-BTC API</h5>
                                <div class="col-md-12 noLeftpadding">
                                    <div class="col-sm-4 noLeftpadding">
                                        <div class="form-group">
                                            <a class="form-control" href="https://alphaex.net/ticker/info/XDC-BTC" target="_blank">https://alphaex.net/ticker/info/XDC-BTC</a>
                                        </div>
                                    </div>
                                </div>
                                <p>Returns</p>
                                <div class="col-md-12 noLeftpadding">
                                    <div class="form-group">
                                        <textarea class="form-control" name="text" style="overflow:hidden;" readonly>{"status":"success","message":"XDC-BTC Market information","markets":[{"bid":"0.00000040","last_price":"0.00000045","volume24h":"628000","currency":"BTC","marketname":"XDC-BTC","ask":"0.00000000","low24h":"0.00000045","change24h":"0.00000017","high24h":"0.00000062","usd_price":"0.00383850","basecurrency":"XDC"}]}</textarea>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <hr>
                                <h4>XDC-ETH Ticker</h4>
                                <p>Returns actual volume-weighted price with respect to last executed XDC-ETH Trade, total 24h volume,US$ price and the price change. </p>
                                <br>
                                <h5>XDC-ETH API</h5>
                                <div class="col-md-12 noLeftpadding">
                                    <div class="col-sm-4 noLeftpadding">
                                        <div class="form-group">
                                            <a class="form-control" href="https://alphaex.net/ticker/info/XDC-ETH" target="_blank">https://alphaex.net/ticker/info/XDC-ETH</a>
                                        </div>
                                    </div>
                                </div>
                                <p>Returns</p>
                                <div class="col-md-12 noLeftpadding">
                                    <div class="form-group">
                                        <textarea class="form-control" name="text" style="overflow:hidden;" readonly="">{"status":"success","message":"XDC-ETH Market information","markets":[{"bid":"0.00000577","last_price":"0.00000599","volume24h":"4851952","currency":"ETH","marketname":"XDC-ETH","ask":"0.00000002","low24h":"0.00000599","change24h":"0.00000177","high24h":"0.00000776","usd_price":"0.00311726","basecurrency":"XDC"}]}</textarea>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <hr>
                                <h4>XDC-XRP Ticker</h4>
                                <p>Returns actual volume-weighted price with respect to last executed XDC-XRP Trade, total 24h volume,US$ price and the price change. </p>
                                <br>
                                <h5>XDC-ETH API</h5>
                                <div class="col-md-12 noLeftpadding">
                                    <div class="col-sm-4 noLeftpadding">
                                        <div class="form-group">
                                            <a class="form-control" href="https://alphaex.net/ticker/info/XDC-XRP" target="_blank">https://alphaex.net/ticker/info/XDC-XRP</a>
                                        </div>
                                    </div>
                                </div>
                                <p>Returns</p>
                                <div class="col-md-12 noLeftpadding">
                                    <div class="form-group">
                                        <textarea class="form-control" name="text" style="overflow:hidden;" readonly="">{"status":"success","message":"XDC-XRP Market information","markets":[{"bid":"0.00720000","last_price":"0.00800000","volume24h":"430270","currency":"XRP","marketname":"XDC-XRP","ask":"0.00610000","low24h":"0.00800000","change24h":"0.00060000","high24h":"0.00860000","usd_price":"0.00504000","basecurrency":"XDC"}]}</textarea>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <hr>
                                <h4>Other Resources</h4>
                                <p>
                                    <span class="api-firstword">XinFin Explorer</span> - XDC Explorer Site<br>
                                    <span class="api-firstword">XinFin</span> - XinFin-XDC website and White paper<br>
                                    <span class="api-firstword">Announcement</span> - Xinfin-XDC Announcements site<br>
                                    <span class="api-firstword">Source Code</span> - Xinfin-XDC Source Code Link<br>
                                    <span class="api-firstword">Message Board</span> - Xinfin-XDC Message Board Link

                                </p>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="clearfix"></div>
    </div>
@endsection
@section('xscript')

    <script type="text/javascript">
        $(document).ready(function () {
            $('.bar-toggle').on('click', function () {
                $('.leftbar').toggleClass('open');
            });
        })
    </script>
    <script>
        function apicall(callname) {
            console.log("called");
            var displaypre = document.getElementById(callname);
            $.getJSON("https://alphaex.net/ticker/info/XDC-" + callname, function (result) {
                var json = JSON.stringify(result);
                displaypre.innerHTML = json;
            })
        }
    </script>
@endsection