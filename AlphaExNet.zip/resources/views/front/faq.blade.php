@extends('front.layout.front')
@section('content')
    <div class="clearfix"></div>
    <div class="main-flex">
        <div class="main-content inner_content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default panel-heading-space">
                            <div class="panel-heading">Friend Asked Questions</div>
                            <div class="panel-body">
                                <div class="wrapper center-block">
                                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                        @if($data)
                                            @foreach($data as $val)
                                        <div class="panel panel-default custom-bg">
                                            <div class="panel-heading accordion-toggle question-toggle collapsed" role="tab" id="heading">
                                                <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse" data-target="#question{{$val->id}}" aria-expanded="false" aria-controls="collapse">
                                                        Q : {{$val->question}}
                                                    </a>
                                                </h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="question{{$val->id}}" role="tabpanel">
                                                <div class="panel-body custom-padding">
                                                    {!! $val->description !!}
                                                </div>
                                            </div>
                                        </div>
                                            @endforeach
                                            @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="clearfix"></div>
    </div>
@endsection
@section('xscript')
    <script type="text/javascript">
        $(document).ready(function () {
            $('.bar-toggle').on('click', function () {
                $('.leftbar').toggleClass('open');
            });
            $('.panel-collapse').on('hide.bs.collapse', function () {
                $(this).siblings('.panel-heading').removeClass('active');
            });
            $('.panel-collapse').on('show.bs.collapse', function () {
                $(this).siblings('.panel-heading').addClass('active');
            });
        })
    </script>
@endsection