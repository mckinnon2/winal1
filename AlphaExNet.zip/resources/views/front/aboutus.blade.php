@extends('front.layout.front')
@section('content')
    <div class="clearfix"></div>
    <div class="main-flex">
        <div class="main-content inner_content">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-md-12">
                        <div class="panel panel-default panel-heading-space">
                            <div class="panel-heading">About us</div>
                            <div class="panel-body">
                                <p>A secure & dependable trading platform, Alphaex is created for competent investors, businesses, and everyone, who wants to purchase or sell XDC, Ether and Bitcoin worldwide. Our objective at this exchange is to offer the top-notch, cost-effective, fastest, and simplified buying experience for buyers looking to amass Blockchain backed assets, beginning with XDC, Ether and Bitcoin.</p>
                                <p>A reliable and reputed party in the entire exchange ecosystem, Alphaex is, undeniably, your safest way to exchange XDC, Ether and Bitcoin. According to us, blockchain technology is a dominant innovation that is sure to bring a revolutionary change in the complete financial industrya fact that inspires us to deliver ace solutions, aimed to overcome the challenges of such a speedy transformation.</p>
                                <p>At Alphaex, the team of experts embraces highly-experienced members having core financial knowledge, IT professionals skilled in areas like software development, automated payment processing, network security, blockchain integration, and champions in domain of web security and cloud based services.</p>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="clearfix"></div>
    </div>
@endsection