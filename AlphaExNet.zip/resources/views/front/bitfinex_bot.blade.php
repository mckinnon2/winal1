<html>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://alphaex.net/front/assets/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="https://alphaex.net/front/assets/css/responsive.bootstrap.min.css">
<body>
<div class="row">
    <div class="col-md-6">
        <table id="buyOrderBook" class="display">
            <thead>
            <tr>
                <th class="col-md-4">price</th>
                <th class="col-md-4">count</th>
                <th class="col-md-4">amount</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
            <tfoot>
            <tr>
                <th class="col-md-4">price</th>
                <th class="col-md-4">count</th>
                <th class="col-md-4">amount</th>
            </tr>
            </tfoot>
        </table>
    </div>
    <div class="col-md-6">
        <table id="sellOrderBook" class="display">
            <thead>
            <tr>
                <th class="col-md-4">price</th>
                <th class="col-md-4">count</th>
                <th class="col-md-4">amount</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
            <tfoot>
            <tr>
                <th class="col-md-4">price</th>
                <th class="col-md-4">count</th>
                <th class="col-md-4">amount</th>
            </tr>
            </tfoot>
        </table>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>
    var buyorderTable ='';
    var sellorderTable='';

    // sellorderTable.row.add([1,2,3]).draw();
    var selectedTable ='';
    var istableupdated = 0;
    console.log("Hi");
    const wss = new WebSocket('wss://api-pub.bitfinex.com/ws/2')
    // wss.onmessage = (msg) => console.log(msg.data)
    buyorderTable = $('#buyOrderBook').DataTable(
        {
            "searching": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "bAutoWidth": false
        }
    );
    sellorderTable = $('#sellOrderBook').DataTable(
        {
            "searching": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "bAutoWidth": false
        }
    );
    wss.onmessage = function(msg){
        msgs = JSON.parse(msg.data)
        console.log(msgs[1]);
        // console.log(msgs[1].length);
        // // console.log("data",msgs[1]);
        istableupdated =0;
        if(msgs[1] !="hb" && msgs[1].length < 4){
            console.log("array")
            rowData = msgs[1];
            if(rowData[2]<0){
                sellData = rowData
                sellOderBook(sellData);
            }
            else{
                buyData = rowData;
                buyOrderBook(buyData);
            }
        }
        else if(msgs[1] != "hb"){
            console.log("arrays")
            temp = msgs[1].length;
            dataArray = msgs[1];
            for(var i = 0;i<temp;i++){
                rowData = dataArray[i];
                if(rowData[2]<0){
                    sellData = rowData
                    sellOderBook(sellData)
                }
                else{
                    buyData = rowData;
                    buyOrderBook(buyData)
                }
            }

        }
        //orderBook(msgs,istableupdated);

    };

    var orders = JSON.stringify({
        event: 'subscribe',
        channel: 'book',
        symbol: 'tBTCUSD' ,
        len:25,
    })
    wss.onopen = function(){
        // API keys setup here (See "Authenticated Channels")
        wss.send(orders);
    }

    //buyorderbook
    function buyOrderBook(buyorderData){
        console.log("buyData",buyorderData);
        if(buyorderData[2] > 0){
            count = buyorderTable.rows().count();
            if(count == 0 && buyorderData[1] != 0){
                var node = buyorderTable.row.add([buyorderData[0],buyorderData[1],buyorderData[2]]).draw().node();
                $(node).css('color', 'green').animate({color: 'green'});
                setTimeout(function () {
                    $(node).css('color', '#909699')
                }, 550);
            }
            updation =0;
            buyorderTable.column(0).data().filter(function(value,index){
                if(value == buyorderData[0] && updation == 0){
                    if(buyorderData[1] == 0){
                        buyorderTable.row(index).remove();
                        updation =1;
                    }
                    if(updation == 0){
                        updatingRow = buyorderTable.row(index).data();
                        node = buyorderTable.row(index).node();
                        updatingRow[2] = buyorderData[2];
                        buyorderTable.row(index).data(updatingRow);
                        updation = 1;
                        $(node).css('color', 'green').animate({color: 'green'});
                        setTimeout(function () {
                            $(node).css('color', '#909699')
                        }, 550);
                    }
                }
                else if(value < buyorderData[0] && updation == 0){
                    if(count >= 5){
                        var removeRow = buyorderTable.row(':last');
                        removeRow.remove();
                    }
                    if(buyorderData[1]==0){
                        buyorderTable.row(index).remove();
                        updation =1;
                    }
                    if(updation == 0){
                        newRowData = [buyorderData[0],buyorderData[1],buyorderData[2]];
                        buyorderDataTable = buyorderTable.data().toArray();
                        buyorderDataTable.splice(index,0,newRowData);
                        buyorderTable.clear();
                        buyorderTable.rows.add(buyorderDataTable).draw();
                        updation = 1;
                        node = buyorderTable.row(index).node();
                        $(node).css('color', 'green').animate({color: 'green'});
                        setTimeout(function () {
                            $(node).css('color', '#909699')
                        }, 550);
                    }
                }

            })

            if(updation == 0 && count < 5){
                var node = buyorderTable.row.add([buyorderData[0],buyorderData[1],buyorderData[2]]).draw(false).node();
                $(node).css('color', 'green').animate({color: 'green'});
                setTimeout(function () {
                    $(node).css('color', '#909699')
                }, 550);
            }


        }
    }

    //sellorder book
    function sellOderBook(sellorderData){
        console.log("sellData",sellorderData)
        if(sellorderData[2] < 0){
            count = sellorderTable.rows().count();
            if(count == 0){
                var node = sellorderTable.row.add([sellorderData[0],sellorderData[1],sellorderData[2]]).draw().node();
                $(node).css('color', 'red').animate({color: 'red'});
                setTimeout(function () {
                    $(node).css('color', '#909699')
                }, 550);
            }
            updation =0;
            sellorderTable.column(0).data().filter(function(value,index){
                if(value == sellorderData[0] && updation == 0){
                    if(sellorderData[1] == 0){
                        sellorderTable.row(index).remove();
                        updation = 1;
                    }
                    if(updation == 0){
                        updatingRow = sellorderTable.row(index).data();
                        node = sellorderTable.row(index).node();
                        updatingRow[2] = sellorderData[2];
                        sellorderTable.row(index).data(updatingRow);
                        $(node).css('color', 'red').animate({color: 'red'});
                        setTimeout(function () {
                            $(node).css('color', '#909699')
                        }, 550);
                        updation = 1

                    }
                }
                else if(value > sellorderData[0] && updation == 0){
                    if(count >= 5){
                        var removeRow = sellorderTable.row(':last');
                        removeRow.remove();
                    }
                    if(sellorderData[1] == 0){
                        sellorderTable.row(index).remove();
                        updation = 1;
                    }
                    if(updation == 0){
                        newRowData = [sellorderData[0],sellorderData[1],sellorderData[2]];
                        sellorderDataTable = sellorderTable.data().toArray();
                        sellorderDataTable.splice(index,0,newRowData);
                        sellorderTable.clear();
                        sellorderTable.rows.add(sellorderDataTable).draw();
                        updation = 1;
                        node = sellorderTable.row(index).node();
                        $(node).css('color', 'red').animate({color: 'red'});
                        setTimeout(function () {
                            $(node).css('color', '#909699')
                        }, 550);
                    }
                }
            });
            if(updation == 0 && count < 5){
                var node = sellorderTable.row.add([sellorderData[0],sellorderData[1],sellorderData[2]]).draw(false).node();
                $(node).css('color', 'red').animate({color: 'red'});
                setTimeout(function () {
                    $(node).css('color', '#909699')
                }, 550);
            }
        }
    }
</script>
</body>
</html>