@extends('front.layout.front')
@section('content')
    <div class="clearfix"></div>
    <div class="main-flex">
        <div class="leftbar">
            <div class="trading">
                @foreach($pairs as $val)
                    @if($pair == $val['Pair'])
                        <div class="flex-bit" id="{{$val['Pair']}}" style="display:">
                            <div class="bit-icon">
                                <img src="{{URL::asset('front')}}/assets/imgs/XDC.png"/>
                                <div><span>{{$val['Pair']}}</span>
                                    <p>VOL <span id="{{$val['Pair']}}_volume" class="{{$val['Colour']}}">{{$val['Volume']}}</span> <br><span>LOW </span><span id="{{$val['Pair']}}_low">{{$val['Low']}}</span></p>
                                </div>
                            </div>
                            <div class="rate">
                                <span id="{{$val['Pair']}}_last">{{$val['Last']}}</span>
                                <p><span id="{{$val['Pair']}}_colour" class="{{$val['Colour']}}"><span id="{{$val['Pair']}}_change">{{$val['Change']}}</span>    (<span id="{{$val['Pair']}}_percent">{{$val['Percentage']}}</span>)</span> <br>HIGH  <span id="{{$val['Pair']}}_high">{{$val['High']}}</span></p>
                            </div>
                        </div>
                    @else
                        <div class="flex-bit" id="{{$val['Pair']}}" style="display:none">
                            <div class="bit-icon">
                                <img src="{{URL::asset('front')}}/assets/imgs/XDC.png"/>
                                <div><span>{{$val['Pair']}}</span>
                                    <p>VOL <span id="{{$val['Pair']}}_volume" class="{{$val['Colour']}}">{{$val['Volume']}}</span> <br><span>LOW </span><span id="{{$val['Pair']}}_low">{{$val['Low']}}</span></p>
                                </div>
                            </div>
                            <div class="rate">
                                <span id="{{$val['Pair']}}_last">{{$val['Last']}}</span>
                                <p><span id="{{$val['Pair']}}_colour" class="{{$val['Colour']}}"><span id="{{$val['Pair']}}_change">{{$val['Change']}}</span>    (<span id="{{$val['Pair']}}_percent">{{$val['Percentage']}}</span>)</span> <br>HIGH  <span id="{{$val['Pair']}}_high">{{$val['High']}}</span></p>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
            <div class="search-head">
                <img src="{{URL::asset('front')}}/assets/imgs/search.png">
                <input id="search_input" class="form-control" type="text" placeholder="Search by name" onkeyup="search()">
            </div>
            <div class="table-responsive">
                <table id="currencytable" class="table">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th><span class="star"><img src="{{URL::asset('front')}}/assets/imgs/star3.png"></span></th>
                        {{--<th>fav</th>--}}
                    </tr>
                    </thead>
                    <tbody id="currencyTable">
                    @if(isset($fav_pairs[0]))
                        @foreach($fav_pairs as $key=>$val)
                            <tr id="{{$val['Pair']}}">
                                {{--<td><strong class="icon-style"><a href="{{url('/trade')}}/{{$val['Pair']}}" style="color: #ADADAD">{{$val['Pair']}}</a></strong></td>--}}
                                <td><strong class="icon-style"><a href="#" style="color: #adadad;" onclick="pair_change('{{$val['Pair']}}')">{{$val['Pair']}}</a></strong></td>
                                <td><span id="{{$val['Pair']}}_td_last" class="{{$val['Colour']}}">{{$val['Last']}}</span></td>
                                <td><span class="star"><a href="#" id="{{$key}}r" class="fav active" title="[-] Remove from favorites" data-pair="{{$val['pair_id']}}" data-id="{{$key}}r">&nbsp;</a></span></td>
                                {{--<td><span id="{{$val['pair_id']}}">1</span></td>--}}
                            </tr>
                        @endforeach
                    @endif
                    @if(isset($remain_pairs))
                        @foreach($remain_pairs as $key=>$val)
                            <tr id="{{$val['Pair']}}">
                                {{--<td><strong class="icon-style"><a href="{{url('/trade')}}/{{$val['Pair']}}" style="color: #ADADAD">{{$val['Pair']}}</a></strong></td>--}}
                                <td><strong class="icon-style"><a href="#" style="color: #adadad;" onclick="pair_change('{{$val['Pair']}}')">{{$val['Pair']}}</a></strong></td>
                                <td><span id="{{$val['Pair']}}_td_last" class="{{$val['Colour']}}">{{$val['Last']}}</span></td>
                                <td><span class="star"><a href="#" id="{{$key}}a" class="fav" title="[+] Add as favorite" data-pair="{{$val['pair_id']}}" data-id="{{$key}}a">&nbsp;</a></span></td>
                                {{--<td><span id="{{$val['pair_id']}}">0</span></td>--}}
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </table>
                @if(isset($user_id))
                    <h4 class="table-title">Balances</h4>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Currency</th>
                            <th class="text-right">Balance</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($currency as $val)
                            <tr>
                                <td><strong class="icon-style"><img src="{{URL::asset('front')}}/assets/imgs/{{$val->currency_symbol}}.png"> {{$val->currency_symbol}}</strong></td>
                                <td class="text-right"><span id="{{$val->currency_symbol}}_bal">{{get_userbalance($user_id,$val->currency_symbol)}}</span></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>

        <div class="main-content">
            <!-- <div id="chartdiv"></div>     -->
            <div class="container-fluid">
                <div id="high_chartdiv" style="margin-bottom: 10px"></div>
                <div class="row trade-limit-order">
                    <div class="col-lg-7">
                        <div id="trade_tabs" class="block-radius mb-30">
                            <ul  class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#limit-order">Limit Order</a></li>
                                {{--<li><a data-toggle="tab" href="#stop-order">Stop Order</a></li>--}}
                                {{--<li><a data-toggle="tab" href="#market-order">Market Order</a></li>--}}
                            </ul>

                            <div class="tab-content">
                                <div id="limit-order" class="tab-pane fade in active">
                                    <div class="flex-row relative">
                                        @if(!isset($user_id))
                                            <div class="login-popup">
                                                <div class="login-wrap">
                                                    <a href="{{url('/login')}}" class="btn btn-lg yellow-btn-outline">Login</a>
                                                    <span>Or</span>
                                                    <a href="{{url('/register')}}" class="btn btn-lg yellow-btn">Signup</a>
                                                    <div class="buy-sell">To Buy / Sell</div>
                                                </div>
                                            </div>
                                        @endif
                                        @if($pair!='XDC-XDCE')
                                            <div class="col-md-6 form-small border-right">
                                                <form id="limit_buy_order">
                                                    {{csrf_field()}}
                                                    <div class="heading flex-bit">
                                                        <input type="hidden" id="tradetype" name="tradetype" value="limit_order">
                                                        <input type="hidden" id="type" name="type" value="Buy">
                                                        <input type="hidden" id="pair-buy" name="pair-buy" value="{{$pair}}">
                                                        <h3 class="green">Buy <span id="first_curr_buy">{{$first_currency}}</span></h3>
                                                        <span class="amount"><span id="second_curr_bal">{{$second_cur_balance}}</span> <span id="second_curr">{{$second_currency}}</span></span>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Amount</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="buy_amount" name ="buy_amount" onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"' onkeyup="calculate_total('buy')" class="custom-input-text" value="1000">
                                                                    <span class="opacity-down" id="first_curr_input">{{$first_currency}}</span>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix">

                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Price</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="buy_price"  name="buy_price" onkeypress='return event.charCode==46 || event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"' onkeyup="calculate_total('buy')" class="custom-input-text" value="{{sprintf('%.8f',$buy_rate)}}">
                                                                    <span class="opacity-down" id="second_curr_input">{{$second_currency}}</span>

                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Total</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id="buy_total" class="custom-input-text" value="{{(1000*(sprintf('%.8f',$buy_rate)))+((1000*(sprintf('%.8f',$buy_rate))))*0.005}}" disabled>
                                                                    <span class="opacity-down">Total</span>

                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                        <div class="form-group">

                                                            <div class="col-xs-12">
                                                                <p class="opacity-down fs" style="color: whitesmoke;"><strong>Note - The total is included with Fee(0.5%)</strong></p>
                                                                <div class="box-hover">
                                                                    <button class="btn btn-success btn-click btn-block" type="submit" onclick="submitForm('limit_buy_order',event)">Buy</button>
                                                                    {{--<div class="box-open">--}}
                                                                    {{--<p>Are you sure want to buy the Bitcoin 1 BTC for 10000 XDC</p>--}}
                                                                    {{--<div class="row">--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-success btn-cancel btn-sm btn-block">Cancel</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-primary btn-confirm btn-sm btn-block" data-toggle="modal" data-target="#myModal">Confirm</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                            <div class="col-md-6 form-small">
                                                <form id="limit_sell_order">
                                                    {{csrf_field()}}
                                                    <div class=" col-md-12 heading flex-bit">
                                                        <input type="hidden" id="tradetype" name="tradetype" value="limit_order">
                                                        <input type="hidden" id="type" name="type" value="Sell">
                                                        <input type="hidden" id="pair-sell" name="pair-sell" value="{{$pair}}">
                                                        <h3 class="red">Sell <span id="first_curr_sell">{{$first_currency}}</span></h3>
                                                        <span class="amount"><span id="first_curr_bal">{{$first_cur_balance}}</span> <span id="second_curr">{{$first_currency}}</span></span>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Amount</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="sell_amount" name="sell_amount" onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"' onkeyup="calculate_total('sell')" class="custom-input-text" value="1000">
                                                                    <span class="opacity-down" id="first_curr_input_1">{{$first_currency}}</span>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Price</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="sell_price" name="sell_price" onkeypress='return event.charCode == 46 || event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"' onkeyup="calculate_total('sell')" class="custom-input-text" value="{{sprintf('%.8f',$sell_rate)}}">
                                                                    <span class="opacity-down" id="second_curr_input_1">{{$second_currency}}</span>

                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Total</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id="sell_total" name="sell_total" class="custom-input-text" value="{{(1000*(sprintf('%.8f',$sell_rate)))-((1000*(sprintf('%.8f',$sell_rate))))*0.017}}" disabled>
                                                                    <span class="opacity-down">Total</span>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                        <div class="form-group">

                                                            <div class="col-xs-12">
                                                                <p class="opacity-down fs pull-left" style="color: whitesmoke;"><strong>Note - The total is included with Fee(0.5%)</strong></p>
                                                                <div class="box-hover">
                                                                    <button class="btn btn-danger btn-click btn-block" onclick="submitForm('limit_sell_order',event)">Sell</button>
                                                                    {{--<div class="box-open">--}}
                                                                    {{--<p>Are you sure want to buy the Bitcoin 1 BTC for 10000 XDC</p>--}}
                                                                    {{--<div class="row">--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-success btn-cancel btn-sm btn-block">Cancel</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-primary btn-confirm btn-sm btn-block" >Confirm</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        @else
                                            <div class="col-md-6 form-small border-right">
                                                <form id="swap_xdce">
                                                    {{csrf_field()}}
                                                    <div class="heading flex-bit">
                                                        <input type="hidden" id="currency" name="currency" value="XDCE">
                                                        <div class="col-md-12">
                                                            <h3 class="green"> Buy {{$first_currency}}<br></h3>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                        <div class="col-md-12">
                                                            {{--<span id="buy_rate" class="amount">{{sprintf('%.8f',$buy_rate)}}</span>&nbsp;--}}
                                                            <span class="amount"><span id="second_curr_bal">{{$second_cur_balance}}</span> {{$second_currency}}</span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Amount</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="swap_amount_xdce" name ="swap_amount" onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"' onkeyup="calculate_total_swap('xdce')" class="custom-input-text" value="1000">
                                                                    <span class="opacity-down">{{$first_currency}}</span>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Price</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="swap_price" class="custom-input-text" value="{{sprintf('%.8f',$buy_rate)}}" disabled>
                                                                    <span class="opacity-down">{{$second_currency}}</span>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Total</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id="swap_total_xdce" class="custom-input-text" value="{{1000*(sprintf('%.8f',$buy_rate))}}" disabled>
                                                                    <span class="opacity-down">Total</span>

                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                        <div class="form-group">

                                                            <div class="col-xs-12">
                                                                <div class="box-hover">
                                                                    <button class="btn btn-success btn-click btn-block" onclick="submitswap('xdce',event)">Swap XDCE</button>
                                                                    {{--<div class="box-open">--}}
                                                                    {{--<p>Are you sure want to buy the Bitcoin 1 BTC for 10000 XDC</p>--}}
                                                                    {{--<div class="row">--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-success btn-cancel btn-sm btn-block">Cancel</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-primary btn-confirm btn-sm btn-block" data-toggle="modal" data-target="#myModal">Confirm</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                            <div class="col-md-6 form-small">
                                                <form id="swap_xdc">
                                                    {{csrf_field()}}
                                                    <div class=" col-md-12 heading flex-bit">
                                                        <input type="hidden" id="currency" name="currency" value="XDC">
                                                        <div class="col-md-12">
                                                            <h3 class="red"> Sell {{$first_currency}}<br></h3>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                        <div class="col-md-12">
                                                            {{--<span id="sell_rate" class="amount">{{sprintf('%.8f',$sell_rate)}}</span>&nbsp;--}}
                                                            <span class="amount"><span id="first_curr_bal">{{$first_cur_balance}}</span> {{$first_currency}}</span>
                                                        </div>

                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Amount</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="swap_amount_xdc" name="swap_amount" onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"' onkeyup="calculate_total_swap('xdc')" class="custom-input-text" value="1000">
                                                                    <span class="opacity-down">{{$first_currency}}</span>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Price</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id ="swap_price" class="custom-input-text" value="{{sprintf('%.8f',$sell_rate)}}" disabled>
                                                                    <span class="opacity-down">{{$second_currency}}</span>

                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="control-label col-xs-3" for="email">Total</label>
                                                            <div class="col-xs-9">
                                                                <div class="flex-bit input-desc">
                                                                    <input id="swap_total_xdc" class="custom-input-text" value="{{1000*(sprintf('%.8f',$sell_rate))}}" disabled>
                                                                    <span class="opacity-down">Total</span>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                        <div class="form-group">

                                                            <div class="col-xs-12">
                                                                <div class="box-hover">
                                                                    <button class="btn btn-danger btn-click btn-block" onclick="submitswap('xdc',event)">Swap XDC</button>
                                                                    {{--<div class="box-open">--}}
                                                                    {{--<p>Are you sure want to buy the Bitcoin 1 BTC for 10000 XDC</p>--}}
                                                                    {{--<div class="row">--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-success btn-cancel btn-sm btn-block">Cancel</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--<div class="col-xs-6">--}}
                                                                    {{--<button class="btn btn-primary btn-confirm btn-sm btn-block" >Confirm</button>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                    {{--</div>--}}
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="flex-row">
                                        <div class="panel col-md-6 pm-0 block-bg border-right panel-default">
                                            <div class="panel-heading order-trade">Sell order</div>
                                            <div class="panel-body">
                                                <div class="table-responsive">
                                                    <table id="limit_sell_table" class="table no-space">
                                                        <thead>
                                                        <tr>
                                                            <th>Price</th>
                                                            <th>Volume</th>
                                                            <th>Total</th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        @if(isset($buy_order_list[0]))
                                                            @foreach($buy_order_list as $buy_list)
                                                                <tr>
                                                                    <td>{{number_format($buy_list->price,8,'.','')}}</td>
                                                                    <td>{{number_format($buy_list->updated_qty,0,'.','')}}</td>
                                                                    <td>{{number_format($buy_list->total,2,'.','')}}</td>
                                                                </tr>
                                                            @endforeach
                                                        @endif
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel col-md-6 pm-0 block-bg panel-default">
                                            <div id ='limit_buy_order' class="panel-heading order-trade">Buy order</div>
                                            <div class="panel-body">
                                                <div class="table-responsive">
                                                    <table id="limit_buy_table" class="table no-space">
                                                        <thead>
                                                        <tr>
                                                            <th>Price</th>
                                                            <th>Volume</th>
                                                            <th>Total</th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        @if(isset($sell_order_list[0]))
                                                            @foreach($sell_order_list as $sell_list)
                                                                <tr>
                                                                    <td>{{number_format($sell_list->price,8,'.','')}}</td>
                                                                    <td>{{number_format($sell_list->updated_qty,0,'.','')}}</td>
                                                                    <td>{{number_format($sell_list->total,2,'.','')}}</td>
                                                                </tr>
                                                            @endforeach
                                                        @endif
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                                {{--<div id="market-order" class="tab-pane fade">--}}
                                {{--<div class="flex-row relative">--}}
                                {{--@if(!isset($user_id))--}}
                                {{--<div class="login-popup">--}}
                                {{--<div class="login-wrap">--}}
                                {{--<a href="{{url('/login')}}" class="btn btn-lg yellow-btn-outline">Login</a>--}}
                                {{--<span>Or</span>--}}
                                {{--<a href="{{url('/register')}}" class="btn btn-lg yellow-btn">Signup</a>--}}
                                {{--<div class="buy-sell">To Buy / Sell</div>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--@endif--}}
                                {{--<div class="col-md-6 form-small border-right">--}}
                                {{--<div class="heading flex-bit">--}}
                                {{--<h3 class="green"><span class="icon-round plus"><i></i></span> Buy {{$first_currency}}</h3>--}}
                                {{--<span class="amount">0.05047285</span>--}}
                                {{--</div>--}}
                                {{--<div class="row">--}}
                                {{--<div class="form-group">--}}
                                {{--<label class="control-label col-xs-3" for="email">Amount</label>--}}
                                {{--<div class="col-xs-9">--}}
                                {{--<div class="flex-bit input-desc">--}}
                                {{--<span>1.00000000</span>--}}
                                {{--<span class="opacity-down">{{$first_currency}}</span>--}}

                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}
                                {{--<div class="form-group">--}}
                                {{--<label class="control-label col-xs-3" for="email">Price</label>--}}
                                {{--<div class="col-xs-9">--}}
                                {{--<div class="flex-bit input-desc">--}}
                                {{--<span>Market Price</span>--}}
                                {{--<span class="opacity-down">{{$second_currency}}</span>--}}

                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}

                                {{--<div class="form-group">--}}

                                {{--<div class="col-xs-12">--}}
                                {{--<p class="opacity-down fs">Note - This included with Fee(0.2%) & Total+Fee</p>--}}
                                {{--<button class="btn btn-success btn-block">Buy</button>--}}
                                {{--</div>--}}
                                {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}


                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="col-md-6 form-small">--}}
                                {{--<div class="heading flex-bit">--}}
                                {{--<h3 class="red"><span class="icon-round minus"><i></i></span> Sell {{$first_currency}}</h3>--}}
                                {{--<span class="amount">0.05047285</span>--}}
                                {{--</div>--}}
                                {{--<div class="row">--}}
                                {{--<div class="form-group">--}}
                                {{--<label class="control-label col-xs-3" for="email">Amount</label>--}}
                                {{--<div class="col-xs-9">--}}
                                {{--<div class="flex-bit input-desc">--}}
                                {{--<span>1.00000000</span>--}}
                                {{--<span class="opacity-down">{{$first_currency}}</span>--}}

                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}
                                {{--<div class="form-group">--}}
                                {{--<label class="control-label col-xs-3" for="email">Price</label>--}}
                                {{--<div class="col-xs-9">--}}
                                {{--<div class="flex-bit input-desc">--}}
                                {{--<span>Market Price</span>--}}
                                {{--<span class="opacity-down">{{$second_currency}}</span>--}}

                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}

                                {{--<div class="form-group">--}}

                                {{--<div class="col-xs-12">--}}
                                {{--<p class="opacity-down fs">Note - This included with Fee(0.2%) & Total+Fee</p>--}}
                                {{--<button class="btn btn-danger btn-block">Sell</button>--}}
                                {{--</div>--}}
                                {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}


                                {{--</div>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="flex-row">--}}
                                {{--<div class="panel col-md-6 pm-0 block-bg border-right panel-default">--}}
                                {{--<div class="panel-heading order-trade">Sell order</div>--}}
                                {{--<div class="panel-body">--}}
                                {{--<div class="table-responsive">--}}
                                {{--<table class="table no-space">--}}
                                {{--<thead>--}}
                                {{--<tr>--}}
                                {{--<th>Price</th>--}}
                                {{--<th>Volume</th>--}}
                                {{--<th>Total</th>--}}
                                {{--</tr>--}}
                                {{--</thead>--}}
                                {{--<tbody>--}}
                                {{--@if(isset($buy_order_list[0]))--}}
                                {{--@foreach($buy_order_list as $buy_list)--}}
                                {{--<tr>--}}
                                {{--<td>{{sprintf('%.8f',$buy_list->price)}}</td>--}}
                                {{--<td>{{ number_format($buy_list->updated_qty,2,'.','') }}</td>--}}
                                {{--<td>{{sprintf('%f',($buy_list->updated_qty * $buy_list->price))}}</td>--}}
                                {{--</tr>--}}
                                {{--@endforeach--}}
                                {{--@endif--}}
                                {{--</tbody>--}}
                                {{--</table>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="panel col-md-6 pm-0 block-bg panel-default">--}}
                                {{--<div class="panel-heading order-trade">Buy order</div>--}}
                                {{--<div class="panel-body">--}}
                                {{--<div class="table-responsive">--}}
                                {{--<table class="table no-space">--}}
                                {{--<thead>--}}
                                {{--<tr>--}}
                                {{--<th>Price</th>--}}
                                {{--<th>Volume</th>--}}
                                {{--<th>Total</th>--}}
                                {{--</tr>--}}
                                {{--</thead>--}}
                                {{--<tbody>--}}
                                {{--@if(isset($sell_order_list[0]))--}}
                                {{--@foreach($sell_order_list as $sell_list)--}}
                                {{--<tr>--}}
                                {{--<td>{{number_format($sell_list->price,8,'.','')}}</td>--}}
                                {{--<td>{{ number_format($sell_list->updated_qty,2,'.','') }}</td>--}}
                                {{--<td>{{number_format($sell_list->updated_qty*$sell_list->price,4,'.','')}}</td>--}}
                                {{--</tr>--}}
                                {{--@endforeach--}}
                                {{--@endif--}}
                                {{--</tbody>--}}
                                {{--</table>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--</div>--}}

                                {{--</div>--}}

                                {{--</div>--}}

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="panel panel-default">
                            <div class="panel-heading order-trade">Trade History</div>
                            <div class="panel-body">

                                <div class="table-responsive">
                                    <table id="alphaex_trade_table" class="table no-space">
                                        <thead>
                                        <tr>
                                            <th>Time</th>
                                            {{--<th>Type</th>--}}
                                            <th>Volume</th>
                                            <th>Price</th>
                                            <th> </th>
                                            {{--<th>Total</th>--}}
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if(isset($trade_history[0]))
                                            @foreach($trade_history as $tradehis)
                                                <tr>
                                                    <td>{{$tradehis->updated_at}}</td>
                                                    {{--@if($tradehis->type=='Buy')--}}
                                                    {{--<td><span class="green">{{$tradehis->type}}</span></td>--}}
                                                    {{--@else--}}
                                                    {{--<td><span class="red">{{$tradehis->type}}</span></td>--}}
                                                    {{--@endif--}}
                                                    <td>{{number_format($tradehis->triggered_qty,0,'.','')}}</td>
                                                    @if($tradehis->type=='Buy')
                                                        <td><span class="green">{{number_format($tradehis->triggered_price,8,'.','')}}</span></td>
                                                    @else
                                                        <td><span class="red">{{number_format($tradehis->triggered_price,8,'.','')}}</span></td>
                                                    @endif
                                                    <td> </td>
                                                    {{--<td>{{number_format($tradehis->total,8,'.','')}}</td>--}}
                                                </tr>
                                            @endforeach
                                        @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading order-trade"> My Open Orders</div>
                            <div class="panel-body">

                                <div class="table-responsive">
                                    <table id="open_order_table" class="table no-space">
                                        <thead>
                                        <tr>

                                            {{--<th>Pair</th>--}}
                                            <th>Type </th>
                                            <th>Volume</th>
                                            {{--<th>{{$second_currency}}</th>--}}
                                            <th>Price</th>
                                            <th>Total</th>
                                            <th></th>
                                            <th>id</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if(isset($active_orders[0]))
                                            @foreach($active_orders as $key=>$active_ord)
                                                <tr>
                                                    @if($active_ord->type=='Buy')
                                                        <td><span class="green">{{$active_ord->type}}</span></td>
                                                    @else
                                                        <td><span class="red">{{$active_ord->type}}</span></td>
                                                    @endif
                                                    <td>{{number_format($active_ord->updated_qty,0,'.','')}}</td>
                                                    <td>{{number_format($active_ord->price,8,'.','')}}</td>
                                                    <td>{{number_format($active_ord->total,4,'.','')}}</td>
                                                    <td></td>
                                                    <td>{{base64_encode($active_ord->id)}}</td>
                                                </tr>
                                            @endforeach
                                        @endif
                                        </tbody>
                                    </table>
                                </div>
                                <div class="show-more"><a href="{{url('/history')}}/{{$second_currency}}">Show More</a></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading order-trade"> My Trade History</div>
                            <div class="panel-body">

                                <div class="table-responsive">
                                    <table id="my_trade_order_table" class="table no-space">
                                        <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Type</th>
                                            <th>Volume</th>
                                            <th>Price</th>
                                            <th>Total</th>
                                            {{--<th>Status</th>--}}
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if(isset($user_trade[0]))
                                            @foreach($user_trade as $usertrade)
                                                @if($usertrade->type=='Buy')
                                                    <tr class="green">
                                                @else
                                                    <tr class="red">
                                                        @endif
                                                        <td>{{$usertrade->updated_at}}</td>
                                                        @if($usertrade->type=='Buy')
                                                            <td><span class="green">{{$usertrade->type}}</span></td>
                                                        @else
                                                            <td><span class="red">{{$usertrade->type}}</span></td>
                                                        @endif
                                                        {{--@if($usertrade->Type=='Buy')--}}
                                                        {{--<td><span class="green">{{sprintf('%.8f',$usertrade->opt_price ? $usertrade->opt_price : $tradehis->Price)}}</span></td>--}}
                                                        {{--@else--}}
                                                        {{--<td><span class="green">{{sprintf('%.8f',$usertrade->opt_price ? $usertrade->opt_price : $usertrade->Price)}}</span></td>--}}
                                                        {{--@endif--}}
                                                        @if($usertrade->status=='partially')
                                                            <td>{{number_format(($usertrade->original_qty-$usertrade->updated_qty),0,'.','')}}</td>
                                                        @else
                                                            <td>{{number_format($usertrade->original_qty,0,'.','')}}</td>
                                                        @endif
                                                        <td>{{number_format($usertrade->price,8,'.','')}}</td>
                                                        <td>{{number_format($usertrade->updated_total,2,'.','')}}</td>
                                                    </tr>
                                                    @endforeach
                                                @endif
                                        </tbody>
                                    </table>
                                </div>
                                <div class="show-more"><a href="{{url('/history')}}/{{$second_currency}}">Show More</a></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div><br>
    <div id="cancel_single" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content custom-modal-background text-center">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Cancel Trade</h4>
                </div>
                <input value="" id="cancelsingle" hidden>
                <div class="modal-body">
                    <p>Are you sure you want to cancel the trade?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel min-width-btn" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn yellow-btn min-width-btn" onclick="cancel_single()">Yes</button>
                </div>
            </div>
        </div>
    </div>
    <div id="modify_order" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content custom-modal-background text-center">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modify Trade Order</h4>
                </div>
                <input value="" id="modifyorder" hidden>
                <div class="modal-body">
                    <p>Are you sure you want to modify the trade?</p>
                </div>
                <form id="modify_order_form">
                    {{csrf_field()}}
                    <h6 class="text-center"><span id="type_m">Type</span> {{$first_currency}}</h6>
                    <input id="m_type" name="m_type" value="" hidden>
                    <input id="pair_m" name="pair_m" value="{{$pair}}" hidden>
                    <div class="row">
                        <div class="form-group">
                            <label class="control-label col-xs-3" for="email">Amount</label>
                            <div class="col-xs-9">
                                <div class="flex-bit input-desc">
                                    <input id ="amount_m" name ="amount_m" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="custom-input-text" value="1000">
                                    <span class="opacity-down">{{$first_currency}}</span>
                                </div>
                            </div>
                            <div class="clearfix">

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-xs-3" for="email">Price</label>
                            <div class="col-xs-9">
                                <div class="flex-bit input-desc">
                                    <input id ="price_m"  name="price_m" onkeypress='return event.charCode==46 || event.charCode >= 48 && event.charCode <= 57' class="custom-input-text" value="{{sprintf('%.8f',$buy_rate)}}">
                                    <span class="opacity-down">{{$second_currency}}</span>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-xs-3" for="email">Total</label>
                            <div class="col-xs-9">
                                <div class="flex-bit input-desc">
                                    <input id="total_m" class="custom-input-text" value="{{(1000*(sprintf('%.8f',$buy_rate)))+((1000*(sprintf('%.8f',$buy_rate))))*0.017}}" disabled>
                                    <span class="opacity-down">Total</span>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-cancel min-width-btn" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn yellow-btn min-width-btn" onclick="submit_modifyForm()">Modify</button>
                        </div>
                </form>
            </div>
        </div>
    </div>
    </div>


    <div id="market-order-info" class="col-md-2 market-order-info" style="display:none">
        <div class="market-order-info-text">
            <span id="market_info_text">0</span>
        </div>
    </div>

@endsection
@section('xscript')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>
        var Pair = '{{$pair}}';
        var First_currency = '{{$first_currency}}';
        var Second_currency = '{{$second_currency}}';
        var BuyFee = 0;
        var SellFee = 0;
    </script>

    <script type="text/javascript">
        function pair_change(pair)
        {
            Pair = pair;
            BuyFee = get_trade_fee('Buy',Pair);
            SellFee = get_trade_fee('Sell',Pair);
            var array = Pair.split("-");
            First_currency = array[0];
            Second_currency = array[1];
            $('#pair-buy').val(Pair);
            $('#pair-sell').val(Pair);
            $('#first_curr').html(First_currency);
            $('#second_curr').html(Second_currency);
            $('#first_curr_buy').html(First_currency);
            $('#first_curr_sell').html(First_currency);
            $('#first_curr_input').html(First_currency);
            $('#first_curr_input_1').html(First_currency);
            $('#second_curr_input').html(Second_currency);
            $('#second_curr_input_1').html(Second_currency);
            buy_order_list();
            sell_order_list();
            history_table();
            highcharts();
            if('{{Session::get('alphauserid')}}' != '') {
                open_orders(parseInt('{{$user_id}}'), Pair);
                trade_history(parseInt('{{$user_id}}'), Pair);
            }
            updatebalance();
            updateprice();
            updaterate();
            var buy_form = $('#limit_buy_order').validate();
            buy_form.resetForm();
            var sell_form = $('#limit_sell_order').validate();
            sell_form.resetForm();
        }
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('.bar-toggle').on('click', function () {
                $('.leftbar').toggleClass('open');
            });
            $('.btn-click').on('click', function () {
                $(this).parent().toggleClass('is-active');
            });
        });
    </script>

    <script src="https://js.pusher.com/4.2/pusher.min.js"></script>

    <style>
        td.highlight { color: #909699; }
        @-webkit-keyframes invalid {
            from { background-color: red; }
            to { background-color: inherit; }
        }
        @-moz-keyframes invalid {
            from { background-color: red; }
            to { background-color: inherit; }
        }
        @-o-keyframes invalid {
            from { background-color: red; }
            to { background-color: inherit; }
        }
        @keyframes invalid {
            from { background-color: red; }
            to { background-color: inherit; }
        }
        .invalid {
            -webkit-animation: invalid 5s ; /* Safari 4+ */
            -moz-animation:    invalid 5s ; /* Fx 5+ */
            -o-animation:      invalid 5s ; /* Opera 12+ */
            animation:         invalid 5s ; /* IE 10+ */
        }

        td {
            padding: 1em;
        }

        td.buyhistory {
            color: green;
        }
        td.sellhistory {
            color: red;
        }

    </style>

    <script type="text/javascript">
        // $.validator.addMethod('adecimal', function (value, element) {
        //     return this.optional(element) || (value > 0);
        // }, "Please enter a correct number");

        $('#limit_buy_order').validate({
            rules:
                {
                    buy_amount : {required: true, min: 1000, digits: true},
                    buy_price: {required: true, number: true},
                },
            messages:
                {
                    buy_amount : {
                        required: First_currency + ' amount is required',
                        min: 'Minimum 1000 XDC',
                        digits: 'Decimal value not allowed'
                    },
                    buy_price: {
                        required: 'Buy price not entered',
                        number: 'Enter valid price format',
                    },
                }
        });
        $('#limit_sell_order').validate({
            rules:
                {
                    sell_amount : {required: true, min: 1000, digits: true},
                    sell_price: {required: true, number: true,},
                },
            messages:
                {
                    sell_amount : {
                        required: First_currency+' amount is required',
                        min: 'Minimum 1000 XDC',
                        digits: 'Decimal value not allowed'
                    },
                    sell_price: {
                        required: 'Sell price not entered',
                        number: 'Enter valid price format',
                    },
                }
        });

        $('#swap_xdce').validate({
            rules:
                {
                    swap_amount : {required: true, min: 1000, digits: true,},
                },
            messages:
                {
                    swap_amount : {
                        required: '{{$first_currency}} amount is required',
                        min: 'Minimum 1000 XDCE',
                        digits: 'Decimal value not allowed'
                    },
                }
        });
        $('#swap_xdc').validate({
            rules:
                {
                    swap_amount : {required: true, min: 1000, digits: true,},
                },
            messages:
                {
                    swap_amount : {
                        required: '{{$first_currency}} amount is required',
                        min: 'Minimum 1000 XDC',
                        digits: 'Decimal value not allowed'
                    },
                }
        });

        $('#modify_order_form').validate({
            rules:
                {
                    amount_m : {required: true, min: 1000, digits: true},
                    price_m: {required: true, number: true,},
                },
            messages:
                {
                    amount_m : {
                        required: '{{$first_currency}} amount is required',
                        min: 'Minimum 1000 XDC',
                        digits: 'Decimal value not allowed'
                    },
                    price_m: {
                        required: 'Enter {{$second_currency}} Price',
                        number: 'Enter valid price format',
                    },
                }
        });
        $('#amount_m').keyup(function(){
            var text = $('#type_m').text();
            calculate_total_modify(text);
        });
        $('#price_m').keyup(function(){
            var text = $('#type_m').text();
            calculate_total_modify(text);
        });
    </script>

    {{--for submiting form--}}
    <script type="text/javascript">
        function submitForm(id,event)
        {
            event.preventDefault();
            if($('#'+id).valid())
            {
                $.ajax({
                    type: 'POST',
                    url: '{{url('/test_trade')}}',
                    data: $('#'+id).serialize(),
                    success: function(response)
                    {
                        updatebalance();
                        updateprice();
                        var data = JSON.parse(response);
                        if(data.status === '1')
                        {
                            toastr.success(data.message);
                            trade_history(data.id,Pair);
                        }
                        else if(data.status === '2')
                        {
                            toastr.info(data.message);
                        }
                        else if(data.status === '3')
                        {
                            toastr.info(data.message);
                        }
                        else if(data.status === '4')
                        {
                            toastr.error(data.message);
                        }
                        else
                        {
                            toastr.error(data.message);
                        }
                    }
                });
            }
            else
            {
                return false;
            }
        }
    </script>

    <script type="text/javascript">
        function submitswap(currency,event)
        {
            event.preventDefault();
            var user_id = parseInt('{{$user_id}}');
            var pair = Pair;
            if($('#swap_'+currency).validate())
            {
                $.ajax({
                    type:'get',
                    url:'{{url('/swap')}}',
                    data: $('#swap_'+currency).serialize(),
                    success:function(response)
                    {
                        updatebalance();
                        updateprice();
                        trade_history(user_id,pair);
                        var data = JSON.parse(response);
                        if(data.status === '1')
                        {
                            toastr.success(data.message);
                        }
                        else if(data.status === '2')
                        {
                            toastr.info(data.message);
                        }

                        else if(data.status === '3')
                        {
                            toastr.info(data.message);
                        }

                        else if(data.status === '4')
                        {
                            toastr.error(data.message);
                        }

                        else
                        {
                            toastr.error(data.message);
                        }

                    }
                });
            }
        }
    </script>

    {{--<script type="text/javascript">--}}
    {{--function submit_modifyForm()--}}
    {{--{--}}
    {{--event.preventDefault();--}}
    {{--if($('#modify_order_form').validate())--}}
    {{--{--}}
    {{--$.ajax({--}}
    {{--type: 'POST',--}}
    {{--url: '{{url('/modify_trade')}}',--}}
    {{--data: $('#modify_order_form').serialize(),--}}
    {{--success: function(response)--}}
    {{--{--}}
    {{--updatebalance();--}}
    {{--var data = JSON.parse(response);--}}
    {{--if(data.status === '1')--}}
    {{--{--}}
    {{--toastr.success(data.message);--}}
    {{--trade_history(data.id,'{{$pair}}');--}}
    {{--}--}}
    {{--else if(data.status === '2')--}}
    {{--{--}}
    {{--toastr.info(data.message);--}}
    {{--}--}}

    {{--else if(data.status === '3')--}}
    {{--{--}}
    {{--toastr.info(data.message);--}}
    {{--}--}}

    {{--else if(data.status === '4')--}}
    {{--{--}}
    {{--toastr.error(data.message);--}}
    {{--}--}}

    {{--else--}}
    {{--{--}}
    {{--toastr.error(data.message);--}}
    {{--}--}}

    {{--}--}}

    {{--});--}}
    {{--}--}}
    {{--else--}}
    {{--{--}}
    {{--return false;--}}
    {{--}--}}
    {{--}--}}
    {{--</script>--}}

    <!--  High chart -->
    <script src="https://code.highcharts.com/stock/highstock.js"></script>
    <script src="https://code.highcharts.com/stock/modules/boost.js"></script>
    <script src="https://code.highcharts.com/stock/modules/exporting.js"></script>
    <!-- Chart code -->
    <script type="text/javascript">
        var table;
            var total;
            var sell_table;
            var trade_history_table;

            //for pusher and datatable intialization
            table =  $('#limit_buy_table').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,
                "bAutoWidth": false
            });

            sell_table = $('#limit_sell_table').DataTable(
                {
                    "searching": false,
                    "paging": false,
                    "ordering": false,
                    "info": false,
                    "bAutoWidth": false
                });

            //trade history
            trade_history_table =  $('#alphaex_trade_table').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,
                "bAutoWidth": false,
                "columnDefs":[
                    {
                        "targets":[3],
                        "visible": false,
                        "searchable": false
                    }],
                rowCallback: function(row,data,index) {
                    if (data[3] == 'Buy') {
                        $(row).find('td:eq(2)').css('color', '#47a14c');
                    }
                    else {
                        $(row).find('td:eq(2)').css('color', '#b74745');
                    }
                },
            });

            $(document).ready(function () {

                buy_order_list();
                sell_order_list();
                history_table();
                if('{{Session::get('alphauserid')}}' != '') {
                    open_orders(parseInt('{{$user_id}}'), Pair);
                    trade_history(parseInt('{{$user_id}}'), Pair);
                }

                $("#limit_buy_table tbody").on("click", "tr", function(event){
                    var price = $(this).closest('tr').find('td:eq(0)').text();
                    var amount = $(this).closest('tr').find('td:eq(1)').text();
                    price = parseFloat(price).toFixed(8);
                    amount = parseFloat(amount).toFixed(0);
                    if(price>0&&amount>0) {
                        sell_click_value(price, amount);
                    }
                });

                $("#limit_sell_table tbody").on("click", "tr", function(event){
                    var price = $(this).closest('tr').find('td:eq(0)').text();
                    var amount = $(this).closest('tr').find('td:eq(1)').text();
                    price = parseFloat(price).toFixed(8);
                    amount = parseFloat(amount).toFixed(0);
                    if(price>0&&amount>0) {
                        buy_click_value(price, amount);
                    }
                });

            var pusher = new Pusher('65e7479879516d8836d9',
                {
                    cluster: 'ap2'
                });

            var channel = pusher.subscribe('demo1');


            channel.bind('demo-event', function(data)
            {
                total = data.Total;
                amount = data.Amount;
                price = data.Price;
                type = data.Type;
                pair  = data.Pair;
                user_id = data.User_id;
                var update = 0;
                if(pair === Pair)
                {
                    if(type ==='Buy')
                    {
                        var filteredData = table
                            .column( 0 )
                            .data()
                            .filter( function ( value, index ) {
                                if(value === price && update === 0)
                                {
                                    var data = table.row(index).data();
                                    data[1] = parseFloat(data[1]) + parseFloat(amount);
                                    data[2] = parseFloat(data[2])+ parseFloat(total);
                                    var rownode3 = table.row(index).data(data).draw().node();

                                    update =1;

                                    $(rownode3).css('color','red').animate({color:'red'});
                                    setTimeout(function ()
                                    {
                                        $(rownode3).css('color','#909699')
                                    },550);
                                }
                                else if(value < price && update === 0)
                                {
                                    var rownode1 =[price,amount,total];
                                    var currentrows = table.data().toArray();

                                    currentrows.splice(index,0,rownode1);
                                    table.clear();
                                    table.rows.add(currentrows).draw();
                                    var rownode = table.row(index).node();
                                    $(rownode).css('color','green').animate({color:'green'});
                                    setTimeout(function ()
                                    {
                                        $(rownode).css('color','#909699')
                                    },550);

                                    update =1;


                                }

                            } );
                        if(update === 0)
                        {
                            rownode = table.row.add([price,amount,total]).draw().node();

                            $(rownode).css('color','green').animate({color:'green'});
                            setTimeout(function ()
                            {
                                $(rownode).css('color','#909699')
                            },550);
                        }
                        update =0;

                    }
                    else
                    {
                        var filteredData = sell_table
                            .column( 0 )
                            .data()
                            .filter( function ( value, index ) {
                                if(value === price && update === 0)
                                {
                                    var data = sell_table.row(index).data();
                                    data[1] = parseFloat(data[1]) + parseFloat(amount);
                                    data[2] = parseFloat(data[2])+ parseFloat(total);
                                    var rownode3 = sell_table.row(index).data(data).draw().node();
                                    update =1;
                                    $(rownode3).css('color','red').animate({color:'red'});
                                    setTimeout(function ()
                                    {
                                        $(rownode3).css('color','#909699')
                                    },550);


                                }
                                else if(value > price && update === 0)
                                {
                                    var rownode1 =[price,amount,total];
                                    var currentrows = sell_table.data().toArray();

                                    currentrows.splice(index,0,rownode1);
                                    sell_table.clear();
                                    sell_table.rows.add(currentrows).draw();
                                    var rownode = sell_table.row(index).node();
                                    $(rownode).css('color','red').animate({color:'red'});
                                    setTimeout(function ()
                                    {
                                        $(rownode).css('color','#909699')
                                    },550);
                                    update =1;
                                }
                            } );
                        if(update === 0)
                        {
                            rownode = sell_table.row.add([price,amount,total]).draw().node();
                            $(rownode).css('color','red').animate({color:'red'});
                            setTimeout(function ()
                            {
                                $(rownode).css('color','#909699')
                            },550);
                        }
                        update =0;
                    }
                    open_orders(user_id,pair);
                    trade_history(user_id,pair);
                    updaterate();
                    updatebalance();
                    updateprice();
                }
            });

            //completed order history
            var completed_order = pusher.subscribe('order');

            completed_order.bind('order-history',function(data)
                {
                    var pair = data.Pair;
                    if(pair === Pair)
                    {
                        type = data.Type;
                        var updated_table;
                        var executed_price = data.Price;
                        amount = data.Amount;
                        var fee = data.Fee;
                        var user_id = data.user_id;
                        var trade_id = data.trade_id;
                        var trader_status = data.trade_status;
                        var up_total;
                        if(type === 'Buy')
                        {
                            updated_table  = sell_table;
                        }
                        else
                        {
                            updated_table = table;
                        }
                        filterdata = updated_table.column( 0 )
                            .data()
                            .filter( function ( value, index ) {
                                if(value === executed_price)
                                {
                                    var data = updated_table.row(index).data();
                                    if(parseFloat(data[1]) <= parseFloat(amount))
                                    {
                                        var rownode3 = updated_table.row(index).node();
                                        $(rownode3).css('color','red').animate({color:'red'});
                                        setTimeout(function ()
                                        {
                                            $(rownode3).css('color','#909699');
                                            updated_table.row(index).remove().draw();
                                        },550);
                                    }
                                    else
                                    {
                                        var up_amt = parseFloat(data[1]) - parseFloat(amount);
                                        if(type === 'Buy')
                                        {
                                            up_total = (up_amt*parseFloat(executed_price)) - (up_amt*parseFloat(executed_price)*fee);
                                        }
                                        else
                                        {
                                            up_total= (up_amt*parseFloat(executed_price)) + (up_amt*parseFloat(executed_price)*fee);
                                        }
                                        data[1] = parseFloat(data[1]) - parseFloat(amount);
                                        data[2] = up_total.toFixed(4);
                                        var rownode3 = updated_table.row(index).data(data).draw().node();
                                        if(type === 'Buy')
                                        {
                                            $(rownode3).css('color','red').animate({color:'red'});
                                        }
                                        else
                                        {
                                            $(rownode3).css('color','green').animate({color:'green'});
                                        }
                                        setTimeout(function ()
                                        {
                                            $(rownode3).css('color','#909699')
                                        },550);
                                    }
                                }
                            });
                        //for user open orders
                        open_orders(user_id,pair);
                        trade_history(user_id,pair);
                        updaterate();
                        updatebalance();
                        updateprice();
                        //for trader
                        open_orders(trade_id,pair);
                        trade_history(trade_id,pair);
                        if(parseInt('{{Session::get('alphauserid')}}') === trade_id)
                        {
                            if(trader_status === 'partially')
                            {
                                toastr.info('Your order is being partially executed');

                            }
                            else
                            {
                                toastr.success('Your order is been completed');
                            }
                        }
                    }
                }
            );

            //pusher for cancelled order
            var cancel_order = pusher.subscribe('order');
            cancel_order.bind('order-cancel',function(data)
            {
                var pair = data.Pair;
                if(pair === Pair)
                {
                    type = data.Type;
                    var updated_table;
                    var executed_price = data.Price;
                    amount = data.Amount;
                    var fee = data.Fee;
                    var user_id = data.user_id;
                    var trade_id = data.trade_id;
                    var trader_status = data.trade_status;
                    var up_total;
                    if(type === 'Buy')
                    {
                        updated_table  = table;
                    }
                    else
                    {
                        updated_table =  sell_table;
                    }
                    filterdata = updated_table.column( 0 )
                        .data()
                        .filter( function ( value, index ) {
                            if(value === executed_price)
                            {
                                var data = updated_table.row(index).data();
                                if(parseFloat(data[1]) <= parseFloat(amount))
                                {
                                    var rownode3 = updated_table.row(index).node();
                                    $(rownode3).css('color','orange').animate({color:'orange'});
                                    setTimeout(function ()
                                    {
                                        $(rownode3).css('color','#909699');
                                        updated_table.row(index).remove().draw();
                                    },550);
                                }
                                else
                                {
                                    var up_amt = parseFloat(data[1]) - parseFloat(amount);
                                    if(type === 'Buy')
                                    {
                                        up_total = (up_amt*executed_price) - (up_amt*executed_price*fee);
                                    }
                                    else
                                    {
                                        up_total= (up_amt*executed_price) + (up_amt*executed_price*fee);
                                    }
                                    data[1] = parseFloat(data[1]) - parseFloat(amount);
                                    data[2] = parseFloat(up_total).toFixed(4);
                                    var rownode3 = updated_table.row(index).data(data).draw().node();
                                    $(rownode3).css('color','orange').animate({color:'orange'});
                                    setTimeout(function ()
                                    {
                                        $(rownode3).css('color','#909699')
                                    },550);
                                }
                            }
                        });
                }
            });

            //trade history pusher
            var trade  = pusher.subscribe('trade');
            trade.bind('trade-history', function(tradedata)
            {
                if(tradedata.Pair==Pair) {
                    var trade_type = tradedata.Type;
                    var trade_total = tradedata.Total;
                    var trade_price = tradedata.Price;
                    var trade_volume = tradedata.Amount;
                    var time = tradedata.Time;
                    var rownode1 = [time, trade_volume, trade_price, trade_type];
                    var currentrows = trade_history_table.data().toArray();
                    currentrows.splice(0, 0, rownode1);
                    trade_history_table.clear();
                    var rownode3 = trade_history_table.rows.add(currentrows).draw();
                }
            });
            highcharts();
            var id ='';
            $('#currencyTable tr').
            hover(function() {
                id = this.id;
                $(".flex-bit").each(function () {
                    if ((this.id) != id) {
                        $(".flex-bit"+'#'+this.id).css('display', 'none');
                    }
                    else {
                        $(".flex-bit"+'#'+this.id).css('display', '');
                    }
                });
            },function() {
                $(".flex-bit"+'#'+id).css('display','none');
                $(".flex-bit"+'#'+Pair).css('display','');
            });

        });

        function buy_order_list()
        {
            var pair = Pair;
            var total;
            var price;
            var qty;
            $.ajax({
                url: '/ajax/buy_order_list',
                method:'get',
                data:{'pair':pair},
                success: function(data)
                {
                    data  = JSON.parse(data);
                    sell_table.clear();
                    $.each(data, function(index,value) {
                        total = parseFloat(data[index].total).toFixed(2);
                        price = parseFloat(data[index].price).toFixed(8);
                        qty = parseFloat(data[index].updated_qty).toFixed(0);
                        rownodel = [price,qty,total];
                        sell_table.row.add(rownodel);
                    });
                    sell_table.draw();
                }
            });
        }

        function sell_order_list()
        {
            var pair = Pair;
            var total;
            var price;
            var qty;
            $.ajax({
                url: '/ajax/sell_order_list',
                method:'get',
                data:{'pair':pair},
                success: function(data)
                {
                    data  = JSON.parse(data);
                    table.clear();
                    $.each(data, function(index,value) {
                        total = parseFloat(data[index].total).toFixed(2);
                        price = parseFloat(data[index].price).toFixed(8);
                        qty = parseFloat(data[index].updated_qty).toFixed(0);
                        rownodel = [price,qty,total];
                        table.row.add(rownodel);
                    });
                    table.draw();
                }
            });
        }

        function history_table()
        {
            var pair = Pair;
            var type;
            var total;
            var time;
            var price;
            $.ajax({
                url:'/ajax/trade_history_table',
                method:'get',
                data:{'pair':pair},
                success: function(data)
                {
                    data = JSON.parse(data);
                    trade_history_table.clear();
                    $.each(data, function(index,value){
                        total = parseFloat(data[index].triggered_qty).toFixed(0);
                        time = data[index].updated_at;
                        type = data[index].type;
                        price = parseFloat(data[index].triggered_price).toFixed(8);
                        rownodel = [time,total,price,type];
                        trade_history_table.row.add(rownodel);
                    });
                    trade_history_table.draw();
                }
            });
        }

    </script>

    {{--open order update--}}
    <script type="text/javascript">
        var open_order = $('#open_order_table').DataTable(
            {
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,
                "bAutoWidth": false,
                "columnDefs":[
                    {
                        "targets":[5],
                        "visible": false,
                        "searchable": false
                    }],
                rowCallback: function(row,data,index) {
                    if (data[0] == 'Buy') {
                        $(row).find('td:eq(0)').css('color', '#47a14c');
                    }
                    else {
                        $(row).find('td:eq(0)').css('color', '#b74745');
                    }
                },
                fnCreatedRow: function(row,data,index) {
                    $('td:eq(4)',row).append('<button class="btn btn-danger btn-xs" style="padding:1px 5px; background-color: rgba(0,0,0,0); border-color: rgba(0,0,0,0);">X</button>')
                }
            });

        $('#open_order_table tbody').on('click','button',function() {
            var data = open_order.row( $(this).parents('tr') ).data();
            $('#cancel_single').modal('show');
            $('#cancelsingle').val(data[5]);
        });

        // trade_hist
        var time;
        var type;
        var volume;
        var price;
        var total;
        var rownodel;
        var id;
        var abc;
        function open_orders(userid,pair)
        {
            var user_id = '{{Session::get('alphauserid')}}';
            if(userid === parseInt(user_id))
            {
                $.ajax({
                    url: "/ajax/openorders",
                    method : 'post',
                    data: {'user_id': user_id,'pair': pair},
                    success: function(data) {
                        data = JSON.parse(data);
                        open_order.clear();
                        $.each(data, function(index,value) {
                            type = data[index].type;
                            volume = parseFloat(data[index].updated_qty).toFixed(2);
                            price = parseFloat(data[index].price).toFixed(8);
                            total = parseFloat(data[index].total).toFixed(4);
                            abc = "";
                            id = btoa(data[index].id);
                            rownodel = [type,volume,price,total,abc,id];
                            open_order.row.add(rownodel);
                        });
                        open_order.draw();
                    }
                });
            }
        }
    </script>

    <script type="text/javascript">
        var time;
        var type;
        var volume;
        var price;
        var total;
        var rownodel;
        var my_trade_order = $('#my_trade_order_table').DataTable(
            {
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,
                "bAutoWidth": false,
                "columnDefs":[
                    {
                        "targets":[1],
                        "visible": false,
                        "searchable": false
                    }],
                rowCallback: function(row,data,index) {
                    if (data[1] == 'Buy') {
                        $(row).addClass("green");
                    }
                    else {
                        $(row).addClass("red");
                    }
                },
            });

        function trade_history(userid,pair)
        {
            var user_id = '{{Session::get('alphauserid')}}';
            if(userid === parseInt(user_id))
            {
                $.ajax({
                    url: "/ajax/mytradehistory",
                    method : 'post',
                    data: {'user_id': user_id,'pair': pair},
                    success: function(data) {
                        data = JSON.parse(data);
                        my_trade_order.clear();
                        $.each(data, function(index,value) {
                            time = data[index].created_at;
                            type = data[index].type;
                            volume = parseFloat(data[index].original_qty).toFixed(2);
                            price = parseFloat(data[index].price).toFixed(8);
                            total = parseFloat(data[index].updated_total).toFixed(4);
                            rownodel = [time,type,volume,price,total];
                            my_trade_order.row.add(rownodel);
                        });
                        my_trade_order.draw();
                    }
                });
            }
        }
    </script>

    <script>
        function highcharts()
        {
            Highcharts.theme = {
                colors: ['#b74745', '#90ee7e', '#f45b5b', '#7798BF', '#aaeeee', '#ff0066',
                    '#eeaaee', '#55BF3B', '#DF5353', '#7798BF', '#aaeeee', '#808080'],
                chart: {
                    backgroundColor: {
                        linearGradient: {x1: 0, y1: 0, x2: 1, y2: 1},
                        stops: [
                            [0, '#1a2632'],
                            [1, '#1a2632']
                        ]
                    },
                    style: {
                        fontFamily: '\'Unica One\', sans-serif'
                    },
                    plotBorderColor: '#606063'
                },
                title: {
                    style: {
                        color: '#E0E0E3',
                        textTransform: 'uppercase',
                        fontSize: '20px'
                    }
                },
                subtitle: {
                    style: {
                        color: '#E0E0E3',
                        textTransform: 'uppercase'
                    }
                },
                xAxis: {
                    gridLineColor: '#707073',
                    labels: {
                        style: {
                            color: '#E0E0E3'
                        }
                    },
                    lineColor: '#707073',
                    minorGridLineColor: '#505053',
                    tickColor: '#707073',
                    title: {
                        style: {
                            color: '#A0A0A3'

                        }
                    }
                },
                yAxis: {
                    gridLineColor: '#707073',
                    labels: {
                        style: {
                            color: '#E0E0E3'
                        }
                    },
                    lineColor: '#707073',
                    minorGridLineColor: '#505053',
                    tickColor: '#707073',
                    tickWidth: 1,
                    title: {
                        style: {
                            color: '#A0A0A3'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.85)',
                    style: {
                        color: '#F0F0F0'
                    }
                },
                plotOptions: {
                    series: {
                        dataLabels: {
                            color: '#B0B0B3'
                        },
                        marker: {
                            lineColor: '#333'
                        }
                    },
                    boxplot: {
                        fillColor: '#505053'
                    },
                    candlestick: {
//                        lineColor: 'white'
                        upLineColor: '#47a14c',
                        lineColor: '#b74745'
                    },
                    errorbar: {
                        color: 'white'
                    },
                },
                legend: {
                    itemStyle: {
                        color: '#E0E0E3'
                    },
                    itemHoverStyle: {
                        color: '#FFF'
                    },
                    itemHiddenStyle: {
                        color: '#606063'
                    }
                },
                credits: {
                    style: {
                        color: '#666'
                    }
                },
                labels: {
                    style: {
                        color: '#707073'
                    }
                },

                drilldown: {
                    activeAxisLabelStyle: {
                        color: '#F0F0F3'
                    },
                    activeDataLabelStyle: {
                        color: '#F0F0F3'
                    }
                },

                navigation: {
                    buttonOptions: {
                        symbolStroke: '#DDDDDD',
                        theme: {
                            fill: '#505053'
                        }
                    }
                },

                // scroll charts
                rangeSelector: {
                    buttonTheme: {
                        align: 'left',
                        fill: '#1a2632',
                        stroke: '#000000',
                        style: {
                            color: '#CCC',
                        },
                        height: 2,
                        borderColor: 'green',
                        padding: 10,
                        states: {
                            hover: {
                                fill: '#1a2632',
                                stroke: '#000000',
                                style: {
                                    color: '#eda40d'
                                }
                            },
                            select: {
                                fill: '#1a2632',
                                stroke: '#000000',
                                style: {
                                    color: '#eda40d',
                                },

                            }
                        }
                    },
                    inputBoxBorderColor: '#505053',
                    inputStyle: {
                        backgroundColor: '#333',
                        color: 'silver'
                    },
                    labelStyle: {
                        color: 'silver'
                    }
                },

                navigator: {
                    handles: {
                        backgroundColor: '#666',
                        borderColor: '#AAA'
                    },
                    outlineColor: '#CCC',
                    maskFill: 'rgba(255,255,255,0.1)',
                    series: {
                        color: '#7798BF',
                        lineColor: '#A6C7ED'
                    },
                    xAxis: {
                        gridLineColor: '#505053'
                    }
                },

                scrollbar: {
                    barBackgroundColor: '#808083',
                    barBorderColor: '#808083',
                    buttonArrowColor: '#CCC',
                    buttonBackgroundColor: '#606063',
                    buttonBorderColor: '#606063',
                    rifleColor: '#FFF',
                    trackBackgroundColor: '#404043',
                    trackBorderColor: '#404043'
                },

                // special colors for some of the
                legendBackgroundColor: 'rgba(0, 0, 0, 0.5)',
                background2: '#505053',
                dataLabelsColor: '#B0B0B3',
                textColor: '#C0C0C0',
                contrastTextColor: '#F0F0F3',
                maskColor: 'rgba(255,255,255,0.3)'
            };

            // Apply the theme
            Highcharts.setOptions(Highcharts.theme);
            Highcharts.setOptions({
                lang: {
                    rangeSelectorZoom: ''
                }
            });

            //            $.getJSON('https://cdn.rawgit.com/highcharts/highcharts/v6.0.4/samples/data/new-intraday.json', function (data) {
            $.getJSON('{{url("/charts")}}/'+Pair, function (data) {


                var sellprice = [],
                    volume = [],
                    dataLength = data.length,

                    // set the allowed units for data grouping
                    groupingUnits = [[
                        'week',                         // unit name
                        [1]                             // allowed multiples
                    ], [
                        'month',
                        [1, 2, 3, 4, 6]
                    ]],
                    i = 0;
                for (i; i < dataLength; i += 1) {
                    sellprice.push([
                        data[i].millsec*1, // the date
                        data[i].open*1, // open
                        data[i].high*1, // high
                        data[i].low*1, // low
                        data[i].close*1 // close
                    ]);

                    volume.push([
                        data[i].millsec*1, // the date
                        data[i].volume*1 // the volume
                    ]);
                }

                // create the chart
                Highcharts.stockChart('high_chartdiv', {

                    rangeSelector: {
                        verticalAlign: 'top',
                        buttonPosition: {
                            align: 'left'
                        },
                        buttons: [{
                            //     type: 'day',
                            //     count: 1,
                            //     text: '1Day'
                            // }, {
                            type: 'day',
                            count: 5,
                            text: '5Day'
                        }, {
                            type: 'month',
                            count: 1,
                            text: '1Month'
                        },
                            {
                                type: 'month',
                                count: 3,
                                text: '3Month'
                            },
                            {
                                type: 'month',
                                count: 6,
                                text: '6Month'
                            }
                            // {
                            //     type: 'month',
                            //     count: 9,
                            //     text: '9Month'
                            // },
                            // {
                            //     type: 'year',
                            //     count: 1,
                            //     text: '1Year'
                            // },
                        ],
                        selected: 2,
                        inputEnabled:false
                    },

                    chart: {
                        zoomType: 'x'
                    },

                    {{--title: {--}}
                            {{--text: '{{$pair}}'--}}
                            {{--},--}}

                    navigator: {
                        enabled: false
                    },

                    exporting: {
                        enabled: false
                    },

                    yAxis: [{
                        height: '100%',
                        title: {
                            text: 'Price'
                        },
                        resize: {
                            enabled: true
                        }
                    }, {
                        opposite: false,
                        title: {
                            text: 'Volume'
                        },
                        top:'70%',
                        height: '30%',
                    }],

                    series: [
                        {
                            type: 'candlestick',
                            name: 'Alphaex Sell Price',
                            data: sellprice,
                            dataGrouping: {
                                units: groupingUnits
                            }
                        },
                        {
                            type: 'column',
                            name: 'Volume',
                            data: volume,
                            yAxis: 1,
                            color: 'rgba(128,128,128,0.4)',
                            opacity: 0.5,
                            dataGrouping:
                                {
                                    units: groupingUnits
                                }
                        }],
                });
            });
        }
    </script>

    <script type="text/javascript">
        // var currency_table =  $('#currencytable').DataTable({
        //     "searching": false,
        //     "paging": false,
        //     "ordering": false,
        //     "info": false,
        //     // "columnDefs":[
        //     //     {
        //     //         "targets":[4],
        //     //         "visible": false,
        //     //         "searchable": false
        //     //     }],
        // });

        function addFav(){
            var user_id = {{$user_id}};
            var pair_id = $(this).data("pair");
            var key = $(this).data("id");

            $.ajax({
                url: "/ajax/favorites/add",
                method : 'get',
                data: {'user_id': user_id,'pair_id': pair_id},
                success: function(data) {
                    obj = JSON.parse(data);
                    if (obj == '1') {
                        $('a#'+key)
                            .addClass('active')
                            .attr('title', '[-] Remove from favorites')
                            .unbind('click')
                            .bind('click', removeFav)
                        ;
                        // $('#'+pair_id).text('1');
                        //
                        //
                        // var row_node = currency_table.row(tr).node();
                        // currency_table.row(tr).remove().draw();
                        //
                        // var filteredData = currency_table
                        //     .column(5)
                        //     .data()
                        //     .filter( function ( value, index ) {
                        //         if(value != 1)
                        //         {
                        //             console.log(index);
                        //             var currentrows = table.data().toArray();
                        //             currentrows.splice(index,0,row_node);
                        //             table.clear();
                        //             table.rows.add(currentrows).draw();
                        //         }
                        //
                        //     } );
                    }
                }
            });
        }

        function removeFav(){
            var user_id = {{$user_id}};
            var pair_id = $(this).data("pair");
            var key = $(this).data("id");
            $.ajax({
                url: "/ajax/favorites/remove",
                method : 'get',
                data: {'user_id': user_id,'pair_id': pair_id},
                success: function(data) {
                    obj = JSON.parse(data);
                    if (obj == '1') {
                        $('a#'+key)
                            .removeClass('active')
                            .attr('title', '[+] Add as favorite')
                            .unbind('click')
                            .bind('click', addFav)
                        ;
                        $('#'+pair_id).text('0');
                    }
                    // currency_table.order([4,'desc']).draw();
                }
            });
        }
        //this will make the link listen to function addFav (you might know this already)
        $('.fav').bind('click', addFav);
        $('.fav.active').bind('click',removeFav);
    </script>

    <script>
        function search()
        {
            var input = $('#search_input').val();
            input = input.toUpperCase();
            var table = document.getElementById("currencyTable");
            var tr = table.getElementsByTagName("tr");
            for (var i=0;i<tr.length;i++)
            {
                td=tr[i].id;
                if(td)
                {
                    var td1 = td.split("-");
                    if(td1[0].indexOf(input)>-1||td1[1].indexOf(input)>-1)
                        tr[i].style.display = "";
                    else
                        tr[i].style.display = "none";
                }
            }
        }

        //for calculating total
        function calculate_total(type)
        {
            var fee = 0;
            var amount = document.getElementById(type+'_amount').value;
            var price = document.getElementById(type+'_price').value;
            if(amount !='' && price != '')
            {
                if(type=='buy') {
                    fee = parseFloat(BuyFee);
                    // var total = (amount * price) + (amount * price * (fee / 100));
                    var total = (amount * price) + (amount * price * fee);
                }
                else {
                    fee = parseFloat(SellFee);
                    // var total = (amount * price) - (amount * price * (fee / 100));
                    var total = (amount * price) - (amount * price * fee);
                }
                document.getElementById(type+'_total').value = total.toFixed(4);
            }
            else
            {
                document.getElementById(type+'_total').value = 0;
            }
        }

        function get_trade_fee(type,pair)
        {
            var fee = 0;
            $.ajax({
                async:false,
                url:'/ajax/get_trading_fee',
                method:'get',
                data:{'type':type,'pair':pair},
                success: function(data)
                {
                    fee=parseFloat(JSON.parse(data));
                }
            });
            return fee;
        }

        function calculate_total_modify(type)
        {
            var price = $('#price_m').val();
            var amount = $('#amount_m').val();
            if(amount!=''&&price!='')
            {
                if(type=='Buy') {
                    var total = (amount * price) + (amount * price * (fee / 100));
                }
                else {
                    var total = (amount * price) - (amount * price * (fee / 100));
                }
                document.getElementById('total_m').value = total.toFixed(4);
            }
            else
            {
                document.getElementById('total_m').value = 0;
            }
        }

        function calculate_total_swap(currency)
        {
            var amount = $('#swap_amount_'+currency).val();
            $('#swap_total_'+currency).val(amount*1);
        }

        function buy_click_value(price,amount)
        {
            if(price>0&&amount>0) {
                $('#buy_price').val(price);
                $('#buy_amount').val(amount);
                calculate_total('buy');
            }
        }

        function sell_click_value(price,amount)
        {
            if(price>0&&amount>0) {
                $('#sell_price').val(price);
                $('#sell_amount').val(amount);
                calculate_total('sell');
            }
        }

        function cancel_single()
        {
            var id = $('#cancelsingle').val();
            var result;
            $.ajax({
                url: "/ajax/cancel_order",
                method : 'post',
                data: {'id':id},
                success: function(data) {
                    result = JSON.parse(data);
                    $('#cancel_single').modal('hide');
                    if(result.status ==='200')
                    {
                        toastr.success(result.message);
                        open_orders(parseInt('{{$user_id}}'),Pair);
                        trade_history(parseInt('{{$user_id}}'),Pair);
                        updatebalance();
                        updateprice();
                    }
                    else
                    {
                        toastr.error(result.message);
                        open_orders(parseInt('{{$user_id}}'),Pair);
                        trade_history(parseInt('{{$user_id}}'),Pair);
                    }
                }
            });
        }
    </script>

    <script type="text/javascript">
        function updateprice()
        {
            var pair;
            $.ajax({
                url: "/ajax/updateprice",
                method : 'get',
                data: {},
                success: function(data) {
                    $.each(data, function(index)
                    {
                        pair =data[index].Pair;
                        $('#'+pair+'_volume').text(data[index].Volume).attr('class',data[index].Colour);
                        $('#'+pair+'_low').text(data[index].Low);
                        $('#'+pair+'_colour').attr('class',data[index].Colour);
                        $('#'+pair+'_change').text(data[index].Change);
                        $('#'+pair+'_percent').text(data[index].Percentage);
                        $('#'+pair+'_high').text(data[index].High);
                        $('#'+pair+'_last').text(data[index].Last);
                        $('#'+pair+'_td_change').text(parseFloat(data[index].Change).toFixed(4)).attr('class',data[index].Colour);
                        $('#'+pair+'_td_last').text(data[index].Last).attr('class',data[index].Colour);
                    });
                }
            });
        }
        function updaterate()
        {
            var pair = Pair;
            $.ajax({
                url: "/ajax/updaterate",
                method: "get",
                data:{'pair':pair},
                success: function(data)
                {
                    $('#buy_rate').text(parseFloat(data.buy_rate).toFixed(8));
                    $('#sell_rate').text(parseFloat(data.sell_rate).toFixed(8));
                    $('#buy_price').val(parseFloat(data.buy_rate).toFixed(8));
                    $('#sell_price').val(parseFloat(data.sell_rate).toFixed(8));
                    if(pair!='XDC-XDCE') {
                        calculate_total('buy');
                        calculate_total('sell');
                    }
                }
            });
        }
        function updatebalance()
        {
            var userid = '{{$user_id}}';
            var first_curr = First_currency;
            var second_curr = Second_currency;
            userid = btoa(userid);
            $.ajax({
                url:"/ajax/updatebalance",
                method:'get',
                data: {'userid':userid},
                success: function(data)
                {
                    $.each(data, function(index){
                        $('#'+data[index].curr+'_bal').text(data[index].bal);
                        if(data[index].curr==first_curr)
                        {
                            $('#first_curr_bal').text(data[index].bal);
                        }
                        else if(data[index].curr==second_curr)
                        {
                            $('#second_curr_bal').text(data[index].bal);
                        }
                    });
                }
            });
        }
        updateprice();
        updaterate();
        setInterval(function(){
            updateprice();
        },10000);
    </script>


    {{--for avialable market order--}}
    <script type="text/javascript">
        var active_tabs = 0;
        $("#trade_tabs").tabs(
            {
                activate: function(event, ui) {
                    var id = ui.newPanel.attr('id');
                    if(id === 'market-order')
                    {
                        active_tabs =1;
                        $('#market-order-info').css('display','none');
                        available_market_data();
                    }
                    else
                    {
                        active_tabs = 0;
                        $('#market-order-info').css('display','none');
                    }
                    setInterval(function(){
                        if(active_tabs == 1)
                        {
                            $('#market-order-info').css('display','none');
                            available_market_data();
                            // $('#market-order-info').css('display','none');
                        }
                        //code goes here that will be run every 5 seconds.
                    }, 5000);
                }
            });

        function available_market_data()
        {
            $.ajax({
                url:"/ajax/available_market_data",
                method:'post',
                data: {'pair':Pair},
                success: function(data)
                {
                    result = JSON.parse(data);

                    if(result.status === 200 || result.status === 422)
                    {
                        $('#market-order-info').css('display','block');
                        $('#market_info_text').css('color','green').text("Available Amount: "+result.amount+"\n Available Total: "+result.total);
                    }
                    else if(result.status === 500 || result.status === 401)
                    {
                        $('#market-order-info').css('display','block');
                        $('#market_info_text').css('color','red').text(result.message);
                    }
                }
            });
        }
    </script>
@endsection