
@extends('front.layout.front')
@section('content')

    <!-- Order book data table -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <div class="panel panel-default noBorder">

                        <div class="panel-body">
                            <!-- <h4 class="uppercase">Transaction History</h4> -->
                            @include('front.history_top')
                            <br>
                            @if($getpair != 'XDC-XDCE' || $getpair != 'XDC-ICO')
                                <div class="row">
                                    <form id="trade_filters_form">
                                        <div class="col-md-3">
                                            <b>Pair :</b>
                                            <select class="form-control" name="pair" onchange="trade_filters()">
                                                <option value="all" @if($getpair=='all') selected @endif >All</option>
                                                <option value="XDC-ETH" @if($getpair=='XDC-ETH') selected @endif>XDC-ETH</option>
                                                <option value="XDC-BTC" @if($getpair=='XDC-BTC') selected @endif>XDC-BTC</option>
                                                <option value="XDC-XRP" @if($getpair=='XDC-XRP') selected @endif>XDC-XRP</option>
                                                <option value="XDC-BCH" @if($getpair=='XDC-BCH') selected @endif>XDC-BCH</option>
                                                <option value="XDC-XDCE" @if($getpair=='XDC-XDCE') selected @endif>XDC-XDCE</option>
                                            </select>
                                        </div>

                                        <div class="col-md-3">
                                            <b>Status :</b>
                                            <select class="form-control" name="status" onchange="trade_filters()">
                                                <option value="all" @if($getstatus=='all') selected @endif >All</option>
                                                <option value="active" @if($getstatus=='active') selected @endif >Pending</option>
                                                <option value="partially" @if($getstatus=='partially') selected @endif >Partially</option>
                                                <option value="cancelled" @if($getstatus=='cancelled') selected @endif >Cancelled</option>
                                                <option value="completed" @if($getstatus=='completed') selected @endif >Completed</option>
                                            </select>
                                        </div>
                                    </form>
                                </div>
                            @endif


                            <div class="table-responsive">
                                @if($getpair == 'XDC-ICO')
                                    <table id="icotable" class="table table-striped table-bordered tableBorder" cellspacing="0" width="100%">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Date &amp; Time</th>
                                            <th class="text-center">Type</th>
                                            <th class="text-center">FirstCurrency</th>
                                            <th class="text-center">SecondCurrency</th>
                                            <th class="text-center">Amount</th>
                                            <th class="text-center">Price</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">Status</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if(isset($result[0]))
                                            @foreach($result as $val)
                                                <tr>
                                                    <td class="text-center price">{{$val->created_at}}</td>
                                                    <td class="text-center price">{{$val->Type}}</td>
                                                    <td class="text-center price">{{$val->FirstCurrency}}</td>
                                                    <td class="text-center price">{{$val->SecondCurrency}}</td>
                                                    <td class="text-center price">{{$val->Amount}}</td>
                                                    <td class="text-center price">{{$val->Price}}</td>
                                                    <td class="text-center price">{{$val->Total}}</td>
                                                    <td class="text-center price">{{$val->Status}}</td>
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td class="text-center" colspan="9">No Record Found</td>
                                            </tr>
                                        @endif
                                        </tbody>
                                    </table>
                                @else
                                    <table id="mytable" class="table table-striped table-bordered tableBorder" cellspacing="0" width="100%">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Date &amp; Time</th>
                                            <th class="text-center">Type</th>
                                            <th class="text-center">Pair</th>
                                            <th class="text-center">Currency</th>
                                            <th class="text-center">Amount</th>
                                            <th class="text-center">Price</th>
                                            <th class="text-center">Total Price</th>
                                            <th class="text-center">Fee</th>
                                            <th class="text-center">Status</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if(isset($result[0]))
                                            @foreach($result as $val)
                                                <tr>
                                                    <td class="text-center price">{{$val->updated_at}}</td>
                                                    <td class="text-center price">{{$val->Type}}</td>
                                                    <td class="text-center price">{{$val->pair}}</td>
                                                    <td class="text-center price">{{$val->firstCurrency}}</td>
                                                    <td class="text-center price">{{$val->Amount}}</td>
                                                    <td class="text-center price">{{sprintf('%.8f',$val->opt_price ? $val->opt_price : $val->Price)}}</td>
                                                    <td class="text-center price">{{sprintf('%.8f',($val->Amount * $val->Price))}}</td>
                                                    <td class="text-center price">{{$val->Fee}}</td>
                                                    @if($val->status=='active')
                                                        <td class="text-center price">Pending</td>
                                                    @else
                                                        <td class="text-center price">{{ucfirst($val->status)}}</td>
                                                    @endif
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td class="text-center" colspan="9">No Record Found</td>
                                            </tr>
                                        @endif
                                        </tbody>
                                    </table>
                                @endif
                                <div class="row pull-right">
                                    @include('front.pagination', ['paginator' => $result])
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- / Order book data table -->

@endsection

@section('xscript')
    @include('front.history_script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#mytable').DataTable({
                "paging":   false,
                "ordering": false,
                "info":     false,
                "searching": true
            });

            $('#icotable').DataTable({
                "paging":   false,
                "ordering": false,
                "info":     false,
                "searching": true
            });
        });
    </script>

    <script type="text/javascript">
        function history_page_load(id)
        {
            if(id=='1')
            {
                window.location.href="<?php echo e(url('deposit_history')); ?>";
            }
            if(id=='2')
            {
                window.location.href="<?php echo e(url('transfer_history')); ?>";
            }
            if(id=='3')
            {
                window.location.href="<?php echo e(url('exchange_history')); ?>";
            }
            if(id=='4')
            {
                window.location.href="<?php echo e(url('trade_history')); ?>";
            }
            if(id=='5')
            {
                window.location.href="<?php echo e(url('swap_history')); ?>";
            }

            if(id=='6')
            {
                window.location.href="<?php echo e(url('ico_history')); ?>";
            }


        }
    </script>

    <script type="text/javascript">
        function trade_filters()
        {
            var seri=$("#trade_filters_form").serialize();
            window.location.href='{{url("trade_history?")}}'+seri;
        }
    </script>
@endsection
