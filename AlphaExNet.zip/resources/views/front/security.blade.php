@extends('front.layout.front')
@section('content')

<!-- Profile, Edit Profile & Change Password -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <!-- left navigation -->
                @include('front.sidebar')
                <!-- / left navigation -->

                <!--  right panel - profile, edit profile & change password data -->
                 <div class="col-md-9">
                 @include('front.alert')
                    <h3 class="noMarg">Google Two-Factor Authentication</h3>

                    <div class="col-md-4 mt40">
                        <div class="text-center">
                            <img src="{{$tfa_url}}" alt="" class="mb20">

                            <h5 class="center fontW400">GOOGLE AUTHENTICATION KEY :</h5>
                            <h4 class="center">{{$secret_code}}</h4>
                        </div>

                        <div class="col-md-10 col-sm-offset-1 mt20 text-center">
                            <form action="{{url('/security')}}" id="securityForm" method="post" accept-charset="utf-8" novalidate="novalidate">
                            {{csrf_field()}}
                                <input class="form-control" name="onecode" id="onecode" placeholder=" 6 digit code" data-bv-field="onecode" type="text">
                                @if($result->tfa_status=='disable')
                                <button type="submit" name="submit" class="btn btn-primary mt20">Enable Security</button>
                                @else
                                 <button type="submit" name="submit" class="btn btn-primary mt20">Disable Security</button>
                                @endif
                            </form>
                        </div>
                    </div>

                    <div class="col-md-7 col-sm-offset-1 mt40">
                        <p class="medium">We recommend to switch to Google Authenticator as more convenient, secure and faster method.In case of method change don't forget to enter new code and save selection.</p>

                        <p class="medium">Q. What does Google Authenticator do?
                            <br> A. Google Authenticator is an application that implements two-step verification services using the Time-based One-time Password Algorithm(HOTP), for authenticating users of mobile application by Google.</p>

                        <p class="medium">Q. How do i install Google Authenticator?
                            <br> A. Android Users (Click) <a href="https://tinyurl.com/coinspilotGAandroid">https://tinyurl.com/coinspilotGAandroid</a>
                            <br> IOS Users(Click) <a href="https://tinyurl.com/coinspilotGAios">https://tinyurl.com/coinspilotGAios</a></p>

                        <p class="medium">Q. How do you use the QR code?
                            <br> A. Simple open the installed app, click "+" add button and scan the given QR to generate code.</p>
                    </div>

                </div>
                <!-- / right panel - profile, edit profile & change password data -->
            </div>
        </div>
    </section>
    <!-- / Profile, Edit Profile & Change Password -->


   

@endsection

@section('xscript')

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

<script type="text/javascript">
    $("#securityForm").validate({
        rules:
        {
            onecode:{required:true,number:true,},
        },
        messages:
        {
            onecode:{required:'Please enter otp code',number:'Enter digit only',},
        },
    });
</script>

@endsection