
@extends('front.layout.front')
@section('content')

<!-- Order book data table -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <div class="panel panel-default noBorder">

                        <div class="panel-body">
                            <!-- <h4 class="uppercase">Transaction History</h4> -->
                          @include('front.history_top')


                                <div class="col-md-3 pull-right">
                                <b>Filters :</b>
                                <select class="form-control" onchange="exchange_filters(this.value)">
                                    <option value="all">All</option>
                                    <option value="XDC-ETH" {{second_selected('XDC-ETH')}}>XDC-ETH</option>
                                    <option value="XDC-BTC" {{second_selected('XDC-BTC')}}>XDC-BTC</option>
                                    <option value="XDC-XRP" {{second_selected('XDC-XRP')}}>XDC-XRP</option>
                                </select>
                                </div>


                            <div class="table-responsive">
                                <table id="mytable" class="table table-striped table-bordered tableBorder" cellspacing="0" width="100%">
                                   <thead>
                                        <tr>
                                            <th class="text-center">Date</th>
                                            <th class="text-center">Transaction ID</th>
                                            <th class="text-center">Type</th>
                                            <th class="text-center">Exchange Ratio</th>
                                            <th class="text-center">Pair</th>
                                            <th class="text-center">Ex-Ratio</th>
                                            <th class="text-center">Ex-Amount</th>
                                            <th class="text-center">Fee</th>
                                            <th class="text-center">Total Value</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @if($result)
                                    @foreach($result as $val)
                                         <tr>
                                             <td class="text-right price">{{$val->created_at}}</td>
                                             <td class="text-right price">{{$val->transaction_id}}</td>
                                             <td class="text-right price">{{$val->type}} {{$val->currency_name}}</td>
                                             <td class="text-right price">{{$val->amount}}</td>
                                            <td class="text-right price">{{$val->pair}}</td>
                                            <td class="text-right price">{{$val->ex_price}}</td>
                                            <td class="text-right price">{{$val->paid_amount}} {{$val->second_currency}}</td>
                                            <td class="text-right price">{{$val->fee}} {{$val->second_currency}}</td>
                                            <td class="text-right price">{{$val->paid_amount + $val->fee}} {{$val->second_currency}}</td>
                                            <td class="text-right price">{{$val->status}}</td>
                                        </tr>
                                    @endforeach
                                    @endif
                                    </tbody>
                                </table>
                                <div class="row pull-right">
                                      @include('front.pagination', ['paginator' => $result])
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- / Order book data table -->

@endsection

@section('xscript')
@include('front.history_script')
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
    $('#mytable').DataTable({
        "paging":   false,
        "ordering": false,
        "info":     false,
         "searching": true
    });
});
</script>
<script type="text/javascript">
    function exchange_filters(id)
    {
        window.location.href='{{url("exchange_history")}}/'+id;
    }
</script>
@endsection

