@extends('front.layout.front')
@section('css')
    <link href="https://snatchbot.me/sdk/webchat.css" rel="stylesheet" type="text/css">
@endsection
@section('content')
    <div class="clearfix"></div>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="shadow">
                        <div class="table-responsive front-table">
                            <table class="table ">
                                <thead>
                                <tr>
                                    <th>Currency</th>
                                    <th>Last Price</th>
                                    <th>Lowest Ask</th>
                                    <th>Highest Bid </th>
                                    <th>Change(24H)  </th>
                                    <th>Volume(24H) </th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($results as $result)
                                <tr id="{{$result['id']}}">
                                    <td><strong class="icon-style"><img src="{{URL::asset('front')}}/assets/imgs/{{$result['first_currency']}}.png">{{$result['Pair']}}</strong></td>
                                    <td id="{{$result['Pair']}}_last">{{$result['Last']}}</td>
                                    <td id="{{$result['Pair']}}_low"><span>{{$result['Low']}}</span></td>
                                    <td id="{{$result['Pair']}}_high"><span>{{$result['High']}}</span></td>
                                    <td class="text-center"><span id="{{$result['Pair']}}_change" class="{{$result['Colour']}}">{{$result['Percentage']}}</span></td>
                                    <td id="{{$result['Pair']}}_volume" class="text-center">{{$result['Volume']}} {{$result['first_currency']}}</td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="login-bar">
                        <form action="{{url('/login')}}" method="POST" id="login_form">
                            {{ csrf_field() }}
                            <h3>LOGIN</h3>
                            <div class="form-group">
                                <input type="text" class="form-control" id="login_mail" name="login_mail" placeholder="Email" required="required">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required="required">
                            </div>
                            <div class="logincapcha">
                                {{--<div class="g-recaptcha" data-sitekey="6Lfbu1IUAAAAAAblvqe08OxhlaFwHu2-uD2mYHbO" data-callback="recaptchaCallback"></div>--}}
                                {{--{!! NoCaptcha::display() !!}--}}
                                {{--<p id="grecaptcha_error" class="error" hidden>Please verify that you are human.</p>--}}
                                <span id="capimg" style="margin-bottom: 20px; display: inline-block;">{!! captcha_img() !!}
                                                    </span>
                                <a href="javascript:;" onclick="change_captcha()" class="m_tl">
                                    <i class="fa fa-refresh fa-3x"></i></a>
                                <input type="text" class="form-control input-lg" name="captcha" placeholder="Captcha code">
                            </div>
                            <div class="clearfix">
                                <label class="pull-left checkbox-inline"><input type="checkbox" name="remember_me"> Remember me</label>
                            </div>
                            <div class="">
                                <button type="submit" class="btn btn-primary yellow-btn btn-block btn-lg" onclick="">Log in</button>
                            </div>
                            <div class="form-group forgot-password">
                                <a href="{{url('/forgotpass')}}">Forgot your Password?</a>
                            </div>
                            <div class="already-have">
                                <div class="">
                                    <p>Don't have an Account? <a href="{{url('/register')}}">Create Now</a></p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <div class="feaured-box">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="h3-heading">Feature for AlphaEx </h3>
                        <div class="row">
                            <div class="col-md-7">
                                <img src="{{URL::asset('front')}}/assets/imgs/featured.png" class="shadow_img" />
                            </div>
                            <div class="col-md-5">
                                <ul class="icon-list">
                                    <li><i><img src="{{URL::asset('front')}}/assets/imgs/time.png"></i> Super Fast Real-Time  </li>
                                    <li><i><img src="{{URL::asset('front')}}/assets/imgs/web.png"></i> Easy to Use Interface (Mobile & Web) </li>
                                    <li><i><img src="{{URL::asset('front')}}/assets/imgs/major.png"></i> Major Crypto Pairs : XDC XDCE BTC BCH ETH XRP ET USDT </li>
                                    {{--<li><i><img src="{{URL::asset('front')}}/assets/imgs/lock.png"></i> Major Crypto Pairs : BTC BCH ETH XRP </li>--}}
                                    <li><i><img src="{{URL::asset('front')}}/assets/imgs/coin.png"></i> Simple Fees Structure </li>
                                    <li><i><img src="{{URL::asset('front')}}/assets/imgs/support.png"></i> Excellent Customer Support </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h3 class="h3-heading">ANNOUNCEMENTS  </h3>
                        <div class="announcements">
                            <div class="annunce-item">
                                <h4>Version 2.0 Live</h4>
                                <p>Beta Version 2 is currently Live, New update comes with host of features, security enhancements and simpler navigation.</p>
                                <span class="date">May, 17, 2018 </span>
                            </div>

                            <div class="annunce-item">
                                <h4>KYC Compliant</h4>
                                <p>Registered users can now complete their KYC in User Profile section. All users are now requested to complete their KYC formalities.</p>
                                <span class="date">April, 10, 2018</span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section2">
            <div class="container">
                <div class="hading-text">With blockchain technology continuing to innovate, alphaex supports established and emerging
                    Digital currencies like Bitcoin-BTC, Ethereum-ETH, Ripple-XRP, Xinfin XDC, Bitcoin Cash-BCH, Xinfin XDCE, Energy Token-ET, USD Tether-USDT at this moment.</div>
                <div class="traning-share">
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand1.png"></a>
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand2.png"></a>
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand3.png"></a>
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand4.png"></a>
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand5.png"></a>
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand6.png"></a>
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand7.png"></a>
                    <a><img src="{{URL::asset('front')}}/assets/imgs/trand8.png"></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="clearfix"></div>
@endsection
@section('xscript')
    <script>
        window.intercomSettings = {
            app_id: "yeyaby2w"
        };
    </script>
    <script>(function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic('reattach_activator');ic('update',intercomSettings);}else{var d=document;var i=function(){i.c(arguments)};i.q=[];i.c=function(args){i.q.push(args)};w.Intercom=i;function l(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/yeyaby2w';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);}if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})()</script>
    <script>
        function change_captcha()
        {
            $("#capimg").html('Loading....');
            $.post('{{url("ajax/refresh_capcha")}}',function(data,result)
            {
                $("#capimg").html(data);
            });
        }
    </script>
    <script type="text/javascript">
        $("#login_form").validate({
            rules:
            {
                login_mail:{required:true,email:true,},
                password:{required:true,},
                captcha:{required:true,regex:"^[a-zA-Z0-9]+$"}
            },
            messages:
            {
                login_mail:{required:'Email is required',email:'Enter valid email address',},
                password:{required:'Password is required',},
                captcha:{required:'Captcha is required',regex:"No special characters or spaces"}
            },
        });

        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Number Not valid."
        );

    </script>

    <script type="text/javascript">
        $(document).ready(function(){
            fillByMemory();
        });
        function fillByMemory(){
            if(!!$.cookie('email'))
                $('#login_mail').val($.cookie('email'));

            if(!!$.cookie('password'))
                $('#password').val($.cookie('password'));
        }
    </script>

    <script type="text/javascript">
        function updateprice()
        {
            var pair;
            $.ajax({
                url: "/ajax/updateprice",
                method : 'get',
                data: {},
                success: function(data) {
                    $.each(data, function(index)
                    {
                        pair =data[index].Pair;
                        $('#'+pair+'_volume').text(data[index].Volume+' '+data[index].first_currency);
                        $('#'+pair+'_low').text(data[index].Low);
                        $('#'+pair+'_change').text(data[index].Percentage).attr('class',data[index].Colour);
                        $('#'+pair+'_high').text(data[index].High);
                        $('#'+pair+'_last').text(data[index].Last);
                    });
                }
            });
        }
        updateprice();
        setInterval(function(){
            updateprice();
        },10000);
    </script>
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d1da2bc22d70e36c2a411f5/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
@endsection