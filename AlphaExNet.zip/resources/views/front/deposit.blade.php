@extends('front.layout.front')
@section('content')

<!-- Profile, Edit Profile & Change Password -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <!-- left navigation -->
                @include('front.sidebar')
                <!-- / left navigation -->

                <!--  right panel - profile, edit profile & change password data -->
                <div class="col-md-9">
                @include('front.alert')
                    <span><strong>Note:</strong>Deposits to AlphaEx can take upto 2 - 6 hours depending upon transaction and processing speed in public networks.</span>
                    <br>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="panel-body noPadd">
                                <ul class="nav nav-tabs profile-tabs">
                                <li class="{{admin_class('XDC')}}"><a data-toggle="tab" href="#xdcdeposit" aria-expanded="false">XDC</a></li>
                               <li class="{{admin_class('ETH')}}"><a data-toggle="tab" href="#aboutme" aria-expanded="false">ETH</a></li>
                                  <li class="{{admin_class('BTC')}}"><a data-toggle="tab" href="#btcdeposit" aria-expanded="false">BTC</a></li>

                                     <li class="{{admin_class('XRP')}}"><a data-toggle="tab" href="#xrpdeposit" aria-expanded="false">XRP</a></li>
                                    <li class="{{admin_class('XDCE')}}"><a data-toggle="tab" href="#xdcedeposit" aria-expanded="false">XDCE</a></li>
                                    <li class="{{admin_class('BCH')}}"><a data-toggle="tab" href="#bchdeposit" aria-expanded="false">BCH</a></li>

                                </ul>

                                <div class="tab-content m-0">

                                    <!-- Profile -->
                                    <div id="aboutme" class="tab-pane {{admin_class('ETH')}}">
                                        <div class="profile-desk">

                                            <h4>ETH Deposit</h4>
                                            <div id="ethaddr_mess"></div>
                                             <h4 style="font:bold">This is Ethereum-ETH Address</h4>
                                        <div class="text-center">
                            <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={{$result->ETH_addr}}" alt="" class="mb20">
                            <h5 class="center" id="ethaddr">{{$result->ETH_addr}}</h5>
                            <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('ethaddr')">Copy Address</button>

                                     </div>






                                        </div>
                                    </div>

                                    <div id="btcdeposit" class="tab-pane {{admin_class('BTC')}}">
                                        <div class="profile-desk">

                                            <h4>BTC Deposit</h4>
                                            <div id="btcaddr_mess"></div>
                                            <h4 style="font: bold">This is Bitcoin-BTC Address</h4>
                                        <div class="text-center">
                            <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={{$result->BTC_addr}}" alt="" class="mb20">
                            <h5 class="center" id="btcaddr">{{$result->BTC_addr}}</h5>
                            <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('btcaddr')">Copy Address</button>

                                     </div>
                                        </div>
                                    </div>




                                 <div id="xdcdeposit" class="tab-pane {{admin_class('XDC')}}">
                                        <div class="profile-desk">

                                            <h4>XDC Deposit</h4>
                                            <div id="xdcaddr_mess"></div>
                                        <h4 style="font: bold">This is Xinfin-XDC Address</h4>
                                        <div class="text-center">
                            <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={{$result->XDC_addr}}" alt="" class="mb20">
                            <h5 class="center" id="xdcaddr">{{$result->XDC_addr}}</h5>
                            <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('xdcaddr')">Copy Address</button>

                                     </div>

                                        </div>
                                    </div>



                                     <div id="xrpdeposit" class="tab-pane {{admin_class('XRP')}}">
                                        <div class="profile-desk">

                                            <h4>XRP Deposit</h4>
                                            <div id="xrpaddr_mess"></div>
                                        <h4 style="font: bold">This is Ripple-XRP Address</h4>
                                        <div class="text-center">
                            <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={{decrypt($Xrpresult->xrp_address)}}" alt="" class="mb20">
                            <h5 class="center" id="xrpaddr">{{decrypt($Xrpresult->xrp_address)}}</h5>
                            <h5 class="center">Destination Tag :{{$result->xrp_desttag}} </h5>
                            <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('xrpaddr')">Copy Address</button>
                                     </div>
                                            <br>
                                            <label><strong>Note:</strong></label>
                                            <label style="font-size: smaller"><strong>1.</strong> Please only transfer ripple tokens to this wallet address. Sending any others token may result into a loss and no wallet credit.<br><br><strong>2.</strong>
                                         Enter your destination tag in the source wallet (from where you are sending XRP tokens to Alphaex wallet) along with the wallet address as mentioned above. If your wallet doesn’t ask for a destination tag, please transfer your XRP tokens to a local wallet first and then transfer it to Alphaex using your destination tag as a unique and compulsory identifier.<br><br>
                                                <strong>3.</strong>If you send XRP tokens without mentioning your destination tag, your deposit will not be processed and Alphaex will not be responsible for the loss of tokens in that case.</label>
                                        </div>
                                    </div>
                                    <!-- / Profile -->

                                    <div id="xdcedeposit" class="tab-pane {{admin_class('XDCE')}}">
                                        <div class="profile-desk">

                                            <h4>XDCE Deposit</h4>
                                            <div id="xdceaddr_mess"></div>
                                            <h4 style="font: bold">This is Xinfin-ERC20 XDCE Address</h4>
                                            <div class="text-center">
                                                <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={{$result->XDCE_addr}}" alt="" class="mb20">
                                                <h5 class="center" id="xdceaddr">{{$result->XDCE_addr}}</h5>
                                                <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('xdceaddr')">Copy Address</button>

                                            </div>

                                        </div>
                                    </div>

                                    <div id="bchdeposit" class="tab-pane {{admin_class('BCH')}}">
                                        <div class="profile-desk">

                                            <h4>BCH Deposit</h4>
                                            <div id="btcaddr_mess"></div>
                                            <h4 style="font: bold">This is BitcoinCash-BCH Address</h4>
                                            <div class="text-center">
                                                <img id="barcode" src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=" alt="" class="mb20">
                                                <h5 class="center"><strong>Address:</strong><h5 class="center" id="bchaddr">{{$result->BCH_addr}}</h5>
                                                <h5 class="center"><strong>Legacy Address:&nbsp;</strong><h5 class="center" id="legacy_address"></h5></h5>
                                                <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('bchaddr')">Copy Address</button>
                                                    <button class="center btn btn-primary btn-sm" onclick="copyToClipboard('legacy_address')">Copy Legacy</button>

                                            </div>
                                        </div>
                                    </div>




                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / right panel - profile, edit profile & change password data -->
            </div>
        </div>
    </section>
    <!-- / Profile, Edit Profile & Change Password -->



@endsection

@section('xscript')
    <script src="{{URL::asset('front')}}/assets/js/Bchaddress.js"></script>
<script>

    var toLegacyAddress = bchaddr.toLegacyAddress('{{$result->BCH_addr}}');

    document.getElementById('barcode').src = "https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl="+toLegacyAddress;

    document.getElementById('legacy_address').innerHTML = toLegacyAddress;
</script>

<script type="text/javascript">
    function copyToClipboard(elementId) {


  var aux = document.createElement("input");
  aux.setAttribute("value", document.getElementById(elementId).innerHTML);
  document.body.appendChild(aux);
  aux.select();
  document.execCommand("copy");

  document.body.removeChild(aux);

  document.getElementById(elementId+'_mess').innerHTML = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Address Copied</div>';

}
</script>

@endsection
