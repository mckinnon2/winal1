 <ul class="nav nav-tabs profile-tabs">
  <li class="{{second_class('xdc')}}"><a href="{{url('transfercrypto/xdc')}}" >XDC</a></li>
                                    <li class="{{second_class('eth')}}"><a href="{{url('transfercrypto/eth')}}">ETH </a></li>
                                     <li class="{{second_class('btc')}}"><a href="{{url('transfercrypto/btc')}}">BTC </a></li>

                                     <li class="{{second_class('xrp')}}"><a href="{{url('transfercrypto/xrp')}}">XRP </a></li>
                                     <li class="{{second_class('xdce')}}"><a href="{{url('transfercrypto/xdce')}}">XDCE </a></li>
                                     <li class="{{second_class('bch')}}"><a href="{{url('transfercrypto/bch')}}">BCH </a></li>

                                </ul>
