<div class="col-md-3 mb40">
                    <div class="panel panel-default noBorder bg-reverse">
                        <div class="panel-body">
                            <ul class="nav nav-pills nav-stacked">
                                <li class="{{front_class('dashboard')}}"><a href="{{url('dashboard')}}" class="list-group-item">Dashboard</a></li>
                                <li class="{{front_class('profile')}}"><a href="{{url('profile')}}" class="list-group-item">Profile</a></li>
                                <li class="{{front_class('security')}}"><a href="{{url('security')}}" class="list-group-item">Security</a></li>
                                <li class="{{front_class('deposit')}}"><a href="{{url('deposit/XDC')}}" class="list-group-item">Deposit</a></li>
                                <li class="{{front_class('transfercrypto')}}"><a href="{{url('transfercrypto/xdc')}}" class="list-group-item">Fund Withdrawal</a></li>
                                 <li class="{{front_class('deposit_history')}}"><a href="{{url('deposit_history')}}" class="list-group-item">Transaction History</a></li>
                            </ul>
                        </div>
                    </div>
                </div>