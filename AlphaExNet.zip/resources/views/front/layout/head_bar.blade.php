<header>
    <nav class="navbar navbar-inverse manu-row">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="bar-toggle"><span class="icon-bar"></span><span
                            class="icon-bar"></span><span class="icon-bar"></span></button>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar"><span
                            class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                </button>
                @if(Session::has('alphauserid'))
                    <a class="navbar-brand" href="{{url('/trade')}}"><img
                                src="{{URL::asset('front')}}/assets/imgs/logo.png"/></a>
                @else
                    <a class="navbar-brand" href="{{url('/home')}}"><img
                                src="{{URL::asset('front')}}/assets/imgs/logo.png"/></a>
                @endif
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    @if(Session::has('alphauserid'))
                        <li><a href="{{url('/trade')}}">Trade</a></li>
                        {{--<li><a href="{{url('/ico')}}">ICO</a></li>--}}
                        <li><a href="{{url('/wallet')}}">Wallets</a></li>
                        <li><a href="{{url('/history')}}">Orders</a></li>
                        <li><a href="{{url('/referral')}}">Referral Program</a></li>
                        <li><a href="{{url('/profile')}}" class="user-name"><span class=""><img
                                            src="{{URL::asset('uploads/users/profileimg')}}/{{get_user_details(Session::get('alphauserid'), 'profile_image')}}"></span> {{get_user_details(Session::get('alphauserid'), 'first_name')}}
                                &nbsp;&nbsp;{{get_user_details(Session::get('alphauserid'), 'last_name')}}</a></li>
                        <li><a href="{{url('/logout')}}"><i class="fa  fa fa-sign-out-alt"></i></a></li>
                    @else
                        <li><a href="{{url('/home')}}">Home</a></li>
                        <li><a href="{{url('/trade')}}">Trade</a></li>
                        <li><a href="{{url('/referral')}}">Referral Program</a></li>
                        <li><a href="{{url('/howtostart')}}">How to start</a></li>
                        <li><a href="{{url('/contact_us')}}">Support</a></li>
                        <li><a href="{{url('/login')}}">Login</a></li>
                        <li><a href="{{url('/register')}}">SignUp</a></li>
                        {{--<li><a href="#" class=""><span class=""> <img src="{{URL::asset('front')}}/assets/imgs/noti.png"> </span></a></li>--}}
                    @endif
                </ul>
            </div>
        </div>
    </nav>
</header>