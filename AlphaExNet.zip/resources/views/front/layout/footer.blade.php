<footer class="footer">
    <div class="footer-wrap">
        <div class="container">
            <div class="flexbox">
                <div class="footer-logo">
                    @if(Session::has('alphauserid'))
                        <a href="{{url('/trade')}}"><img src="{{URL::asset('front')}}/assets/imgs/logo.png"/></a>
                    @else
                        <a href="{{url('/home')}}"><img src="{{URL::asset('front')}}/assets/imgs/logo.png"/></a>
                    @endif
                </div>
                <div class="footer-menu">
                    <ul>
                        <li><a href="{{url('/api')}}">API</a></li>
                        <li><a href="{{url('/faq')}}">FAQs</a></li>
                        <li><a href="{{url('/aboutus')}}">About us</a></li>
                        <li><a href="{{url('/privacy')}}">Privacy Policy</a></li>
                        <li><a href="{{url('/terms')}}">Terms of Service</a></li>
                        <li><a href="{{url('/contact_us')}}">Contact us</a></li>
                        <li><a href="{{url('/add_asset')}}">Add Asset</a></li>
                    </ul>
                </div>
                <div class="footer-social">
                    <a href="https://www.facebook.com/Alphaexnet/" target="_blank"><img
                                src="{{URL::asset('front')}}/assets/imgs/facebook.png"></a>
                    <a href="https://twitter.com/AlphaExNet" target="_blank"><img
                                src="{{URL::asset('front')}}/assets/imgs/twitter.png"></a>
                    <a href="https://plus.google.com/u/3/114785592823745749538" target="_blank"><img
                                src="{{URL::asset('front')}}/assets/imgs/google_plus.png"></a>
                </div>
            </div>
        </div>
    </div>
    <div class="copy-right">
        <p>Copyright © 2018, AlphaEx All Rights reserved. </p>
    </div>
    <div id="toTop"><img src="{{URL::asset('front')}}/assets/imgs/go_to_top.png"></div>
</footer>