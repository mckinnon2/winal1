
@extends('front.layout.front')
@section('content')

<!-- trade home data and datatables -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <div class="col-sm-12">
                    <div class="page-header page-header-panel">
                        <div class="col-md-8">
                            <h3>Exchange Pair</h3></div>
                        <div class="col-md-4 text-right"><span id="book_selector">
                        <div class="tab-navigation">
                            <ul class="nav" role="tablist">
                            <li role="presentation" class="dropdown open">
                            <select id="select-box" onchange="change_exchange(this.value);">
                                <option value="XDC-ETH" {{second_selected('XDC-ETH')}} >XDC / ETH</option>
                                <option value="XDC-BTC" {{second_selected('XDC-BTC')}}>XDC / BTC</option>
                                <option value="XDC-XRP" {{second_selected('XDC-XRP')}}>XDC / XRP</option>
                            </select>
                            </li>
                            </ul>
                        </div>
                    </span></div>
                    </div>
                </div>

                <div id="col-sm-12">

                    <!-- XDC/BTC chart and all data and datatables -->
                    <div id="tab-1" class="tab--content">
                        <div class="col-md-8 mt10">
                            <h4>{{$pair}}</h4>
                           <!--  <p>Minimum Exchange Limit for XDC : {{$min_ex_limit}}</p>
                            <p>Maximum Exchange Limit for XDC : {{$max_ex_limit}}</p> -->
                        </div>

                        <div class="col-md-8 mb40">
                           <div id="container" style="height: 400px; min-width: 310px"></div>

                        </div>

                        <!-- buy sell box data -->
                        <div class="col-md-4">
                            <div class="panel panel-buy qb-selector">

                                <div class="panel-heading">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="active"><a href="#buy" role="tab" data-toggle="tab" class="tab-buy">Buy {{$first_currency}}</a></li>
                                        <li><a href="#sell" role="tab" data-toggle="tab" class="tab-sell">Sell {{$first_currency}}</a></li>
                                    </ul>
                                </div>
                                <div class="panel-body">
                                    <div class="tab-content">
                                     <div id="load_message" class="text-center">
                                    </div>
                                        <div class="tab-pane active" id="buy">

                                        <p class="text-center">Balance : {{$second_cur_balance}} {{$second_currency}}</p>
                                            <form class="tradeinput form-horizontal" data-tradedirection="buy" id="buy_ex_from" role="form" autocomplete="off">
                                                <div>
                                                {{csrf_field()}}
                                                <input type="hidden" name="total_final_{{$second_currency}}" id="total_final_{{$second_currency}}" value="0">
                                                    <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i class="fa"><img src="{{URL::asset('front')}}/assets/icons/{{$first_currency}}.png" width="16px" height="16px"></i></span>
                                                        <input class="form-control block_non_numbers" id="buy_{{$first_currency}}" name="buy_{{$first_currency}}" onkeyup="firstcurrency_calc_buy();" placeholder="XDC">
                                                    </div>

                                                    <div class="mt10 mb10"><i class="fa fa-exchange"></i></div>

                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa"><img src="{{URL::asset('front')}}/assets/icons/{{$second_currency}}.png" width="16px" height="16px"></i></span>

                                                        <input class="form-control block_non_numbers" id="buy_{{$second_currency}}" name="buy_{{$second_currency}}" placeholder="Amount {{$second_currency}}" onkeyup="secondcurrency_calc_buy();">
                                                    </div>

                                                    <div class="mt5 mb5">
                                                    &nbsp;
                                                    </div>

                                                    <div class="input-group" id="buy_col_otp" style="display: none;">


                                                        <input class="form-control block_non_numbers" id="buy_otp" name="buy_otp" placeholder="Enter OTP">
                                                    </div>

                                                </div>
                                                <div class="qb-button">
                                                    <button type="submit" class="btn btn-green btn-action" id="btn-buy">Buy XDC</button>

                                                </div>
                                            </form>
                                        </div>
                                        <div class="tab-pane" id="sell">
                                            <p class="text-center">Balance : {{$first_cur_balance}} {{$first_currency}}</p>
                                            <form class="tradeinput form-horizontal" data-tradedirection="sell" role="form" id="sell_ex_from" autocomplete="off">
                                                <div>
                                                {{csrf_field()}}
                                                <input type="hidden" name="total_final_sell_{{$second_currency}}" id="total_final_sell_{{$second_currency}}" value="0">

                                                    <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i class="fa"><img src="{{URL::asset('front')}}/assets/icons/{{$first_currency}}.png" width="16px" height="16px"></i></span>
                                                        <input class="form-control block_non_numbers" id="sell_{{$first_currency}}" name="sell_{{$first_currency}}" placeholder="{{$first_currency}}" onkeyup="firstcurrency_calc_sell();">
                                                    </div>

                                                    <div class="mt10 mb10"><i class="fa fa-exchange"></i></div>

                                                    <div class="input-group">
                                                        <span class="input-group-addon">
                                                            <i class="fa"><img src="{{URL::asset('front')}}/assets/icons/{{$second_currency}}.png" width="16px" height="16px"></i>
                                                        </span>
                                                        <input class="form-control block_non_numbers" id="sell_{{$second_currency}}" name="sell_{{$second_currency}}" placeholder="Amount {{$second_currency}}" onkeyup="secondcurrency_calc_sell();">
                                                    </div>

                                                     <div class="input-group" id="sell_col_otp" style="display: none;">

                                                        <input class="form-control block_non_numbers" id="sell_otp" name="sell_otp" placeholder="Enter OTP">
                                                    </div>

                                                </div>
                                                <div class="qb-button">
                                                    <button type="submit" class="btn btn-warning btn-action" id="btn-sell">Sell XDC</button>

                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-error"></div>
                                <div class="panel-footer">
                                    <div class="row">
                                        <div class="col-xs-6">
                                            <div>Fee ({{$second_currency}}) :</div>
                                            <span id="fee_id">{{$ex_fee}} %</span>
                                        </div>
                                        <div class="col-xs-6">
                                            <div>Final {{$second_currency}}  :</div>
                                            <span id="total_pay_amt">0</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- / buy sell box data -->

                        <div class="col-md-12 mt80">
                            <div class="overview">
                                <h2>ORDER BOOK</h2>
                            </div>
                        </div>

                        <!-- Order book - bids table data -->
                        <div class="col-md-12 mb40">
                            <div class="head">
                                <div class="name font20">BUY EXCHANGE ORDERS</div>
                            </div>

                            <div class="table-responsive">
                                <table id="buy_orders" class="table table-striped table-bordered tableBorder" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Date</th>
                                            <th class="text-center">Transaction ID</th>
                                            <th class="text-center">Pair</th>
                                            <th class="text-center">Exchange Ration</th>
                                            <!-- <th class="text-center">{{$first_currency}}</th> -->
                                            <th class="text-center">Est value ( {{$second_currency}} )</th>
                                            <th class="text-center">Fee ( {{$second_currency}} )</th>
                                            <th class="text-center">Sum( {{$second_currency}} )</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @if($buy_order)
                                    @foreach($buy_order as $buy_val)
                                        <tr>
                                             <td class="text-right price">{{$buy_val->created_at}}</td>
                                             <td class="text-right price">{{$buy_val->transaction_id}}</td>
                                              <td class="text-right price">{{$buy_val->pair}}</td>
                                             <td class="text-right price">{{$buy_val->ex_price}}</td>
                                            <!-- <td class="text-right price">{{$buy_val->amount}}</td> -->
                                            <td class="text-right price">{{$buy_val->paid_amount}}</td>
                                            <td class="text-right price">{{$buy_val->fee}}</td>
                                            <td class="text-right price">{{$buy_val->paid_amount + $buy_val->fee}}</td>
                                            <td class="text-right price">{{$buy_val->status}}</td>
                                        </tr>
                                        @endforeach
                                    @endif
                                    </tbody>
                                </table>
                                <div class="row full-right">
                                      @include('front.pagination', ['paginator' => $buy_order])
                                </div>
                            </div>
                        </div>
                        <!-- / Order book - bids table data -->

                        <!-- Order book - bids asks table data -->
                        <div class="col-md-12 mb40">
                            <div class="head">
                                <div class="name font20">SELL EXCHANGE ORDERS</div>
                            </div>
                            <div class="table-responsive">
                                <table id="sell_orders" class="table table-striped table-bordered tableBorder" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Date</th>
                                            <th class="text-center">Transaction ID</th>
                                            <th class="text-center">Pair</th>
                                            <th class="text-center">Exchange Ration</th>
                                           <!--  <th class="text-center">{{$first_currency}}</th> -->
                                            <th class="text-center">Est Value ( {{$second_currency}} )</th>
                                            <th class="text-center">Fee ( {{$second_currency}} )</th>
                                            <th class="text-center">Sum( {{$second_currency}} )</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @if($sell_order)
                                    @foreach($sell_order as $sell_val)
                                        <tr>
                                             <td class="text-right price">{{$sell_val->created_at}}</td>
                                             <td class="text-right price">{{$sell_val->transaction_id}}</td>
                                             <td class="text-right price">{{$sell_val->pair}}</td>
                                             <td class="text-right price">{{$sell_val->ex_price}}</td>
                                           <!--  <td class="text-right price">{{$sell_val->amount}}</td> -->
                                            <td class="text-right price">{{$sell_val->paid_amount}}</td>
                                            <td class="text-right price">{{$sell_val->fee}}</td>
                                            <td class="text-right price">{{$sell_val->paid_amount + $sell_val->fee}}</td>
                                            <td class="text-right price">{{$sell_val->status}}</td>
                                        </tr>
                                        @endforeach
                                    @endif
                                    </tbody>
                                </table>
                                <div class="row full-right">
                                      @include('front.pagination', ['paginator' => $sell_order])
                                </div>
                            </div>
                        </div>
                        <!-- Order book - bids asks table data -->



                    </div>
                    <!-- / XDC/BTC chart and all data and datatables -->



                </div>

            </div>
        </div>
    </section>
    <!-- / trade home data and datatables -->

@endsection

@section('xscript')



 <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
    $('#buy_orders').DataTable({
          "paging":   false,
        "ordering": false,
        "info":     false,
         "searching": true
    });

    $('#sell_orders').DataTable({
          "paging":   false,
        "ordering": false,
        "info":     false,
         "searching": true
    });
});
</script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>

<script type="text/javascript">
    $.getJSON('{{url("ajax/exchange_chart/".$pair)}}', function (data) {

    Highcharts.chart('container', {
        chart: {
            zoomType: 'x'
        },
        title: {
            text: '{{$first_currency}} to {{$second_currency}} exchange rate over time'
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Exchange rate'
            }
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            area: {
                fillColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, Highcharts.getOptions().colors[0]],
                        [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                    ]
                },
                marker: {
                    radius: 2
                },
                lineWidth: 1,
                states: {
                    hover: {
                        lineWidth: 1
                    }
                },
                threshold: null
            }
        },

        series: [{
            type: 'area',
            name: '{{$pair}}',
            data: data
        }]
    });
});



</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

<script type="text/javascript">

    $("#buy_ex_from").validate({
        rules:
        {
            buy_{{$first_currency}}:{required:true,digits:true,},
            buy_{{$second_currency}}:{required:true},
           // buy_otp:{required:true},
        },
        messages:
        {
            buy_{{$first_currency}}:{required:'{{$first_currency}} amount is required',digits:'Decimal value not allowed',},
            buy_{{$second_currency}}:{required:'{{$second_currency}} amount is required'},
          // buy_otp:{required:'OTP is required'},
        },
        submitHandler:function(form)
        {
            /*$("#buy_col_otp").show();
            if(send_otp('buy')==false)
            {
                return false;
            }*/

            final_estimate();
            $("#btn-buy").hide();
            var buy_for_ser=$("#buy_ex_from").serialize();
            $.ajax({
                type:'post',
                data:buy_for_ser+'&pair={{$pair}}&type=Buy',
                url:'{{url("exchangepair/".$pair)}}',
                async:false,
                beforeSend:function()
                {
                    $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                },
                success:function(data)
                {
                    obj = JSON.parse(data);
                    if(obj.status=='0')
                    {
                        $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+obj.message+'</div>');
                    }
                    else if(obj.status=='1')
                    {
                        $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+obj.message+'</div>');
                        pagereload();
                    }
                     $("#btn-buy").show();

                    return false;

                }
            });
        }
    });


    $("#sell_ex_from").validate({
         rules:
        {
            sell_{{$first_currency}}:{required:true,digits:true,},
            sell_{{$second_currency}}:{required:true},
            //sell_otp:{required:true},
        },
        messages:
        {
            sell_{{$first_currency}}:{required:'{{$first_currency}} amount is required',digits:'Decimal value not allowed'},
            sell_{{$second_currency}}:{required:'{{$second_currency}} amount is required'},
            //sell_otp:{required:'OTP is required'},
        },
        submitHandler:function(form)
        {
            /*$("#sell_col_otp").show();
            if(send_otp('sell')==false)
            {
                return false;
            } */
            var buy_for_ser=$("#sell_ex_from").serialize();
            $("#btn-sell").hide();
            $.ajax({
                type:'post',
                data:buy_for_ser+'&pair={{$pair}}&type=Sell',
                url:'{{url("exchangepair/".$pair)}}',
                async:false,
                beforeSend:function()
                {
                    $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                },
                success:function(data)
                {
                    obj = JSON.parse(data);
                    if(obj.status=='0')
                    {
                        $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+obj.message+'</div>');
                    }
                    else if(obj.status=='1')
                    {
                        $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+obj.message+'</div>');
                        pagereload();
                    }
                    $("#btn-sell").show();
                    return false;


                }
            });
        }
    });


</script>

<script type="text/javascript">
      $("#buy_{{$first_currency}}").keydown(function (evt) {
  var charCode = (evt.which) ? evt.which : evt.keyCode
if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
return false;
return true;
});

       $("#buy_{{$second_currency}}").keydown(function (evt) {
  var charCode = (evt.which) ? evt.which : evt.keyCode
if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
return false;
return true;
});

        $("#sell_{{$second_currency}}").keydown(function (evt) {
  var charCode = (evt.which) ? evt.which : evt.keyCode
if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
return false;
return true;
});

        $("#sell_{{$first_currency}}").keydown(function (evt) {
  var charCode = (evt.which) ? evt.which : evt.keyCode
if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
return false;
return true;
});
</script>

<script type="text/javascript">
    function firstcurrency_calc_buy()
    {
        var first_currency=$("#buy_{{$first_currency}}").val();
        var second_currency=$("#buy_{{$second_currency}}").val();

        var second_box=parseFloat(first_currency) * {{$first_cur_ex_price}};
        $("#buy_{{$second_currency}}").val(parseFloat(second_box).toFixed(8));
        final_estimate();

    }

    function secondcurrency_calc_buy()
    {
        var first_currency=$("#buy_{{$first_currency}}").val();
        var second_currency=$("#buy_{{$second_currency}}").val();

        var first_box=parseFloat(second_currency) * {{$second_cur_ex_price}};
        $("#buy_{{$first_currency}}").val(parseFloat(first_box).toFixed(8));
        final_estimate();

    }

    function final_estimate()
    {
        var second_currency=$("#buy_{{$second_currency}}").val();
        var fee_amount= parseFloat(second_currency) * ({{$ex_fee}} / 100);
        var total_spend_amt= parseFloat(fee_amount) + parseFloat(second_currency);
        $("#total_pay_amt").html(parseFloat(total_spend_amt).toFixed(8));
        $("#total_final_{{$second_currency}}").val(parseFloat(total_spend_amt).toFixed(8));
    }

     function firstcurrency_calc_sell()
    {
        var first_currency=$("#sell_{{$first_currency}}").val();
        var second_currency=$("#sell_{{$second_currency}}").val();

        var second_box=parseFloat(first_currency) * {{$first_cur_ex_price}};
        $("#sell_{{$second_currency}}").val(parseFloat(second_box).toFixed(8));
        final_estimate_sell();


    }


    function secondcurrency_calc_sell()
    {
        var first_currency=$("#sell_{{$first_currency}}").val();
        var second_currency=$("#sell_{{$second_currency}}").val();

        var first_box=parseFloat(second_currency) * {{$second_cur_ex_price}};
        $("#sell_{{$first_currency}}").val(parseFloat(first_box).toFixed(8));
        final_estimate_sell();


    }

     function final_estimate_sell()
    {
        var second_currency=$("#sell_{{$second_currency}}").val();
        var fee_amount= parseFloat(second_currency) * ({{$ex_fee}} / 100);
        var total_spend_amt= parseFloat(second_currency) - parseFloat(fee_amount);
        $("#total_pay_amt").html(parseFloat(total_spend_amt).toFixed(8));
        $("#total_final_sell_{{$second_currency}}").val(parseFloat(total_spend_amt).toFixed(8));
    }

    function pagereload()
    {
        setTimeout(function(){ window.location.reload(); }, 1000);
    }

    function send_otp(type)
    {
        var code=$('#'+type+'_otp').val();
        if(code!="")
        {
            return true;
        }
        else
        {
            $.ajax({
            url:'{{url("ajax/generate_otp")}}',
            type:'post',
            data:'key={{time()}}&_token={{ csrf_token() }}&type='+type,
            beforeSend:function()
            {
                 $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
            },
            success:function(data)
            {
               $("#load_message").html('<div class="alert alert-info"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>OTP Sent your registered mobile</div>');
            }
        });
            return false;
        }
    }

</script>

<script type="text/javascript">
    function change_exchange(str)
    {
        window.location.href="{{url('exchange')}}/"+str
    }
</script>



@endsection

