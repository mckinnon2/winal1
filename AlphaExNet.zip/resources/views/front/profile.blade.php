@extends('front.layout.front')
@section('content')
    <div class="clearfix"></div>
    <div class="main-flex">


        <div class="main-content profile_content inner_content">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="block-radius">
                                    <ul class="nav nav-tabs">
                                        <li  class="active"><a data-toggle="tab" href="#profile-view">Profile</a></li>
                                        <li><a data-toggle="tab" href="#edit-profile">Edit Profile </a></li>
                                        <li><a data-toggle="tab" href="#change-password">Change Password </a></li>
                                        <li><a data-toggle="tab" href="#2fa">Security</a></li>
                                        <li><a data-toggle="tab" href="#kyc">KYC</a></li>
                                    </ul>

                                    <div class="tab-content">
                                        <div id="profile-view" class="tab-pane fade  in active">
                                            <div class="flex-row">
                                                <div class="col-md-4 col-sm-5  border-right profile-part">
                                                    <div class="heading profile_heading flex-bit">
                                                        <h4>Avatar</h4>
                                                    </div>
                                                    <div class="profile custom-profile-avatar">
                                                        <!--<input class="upload-hidden" type="file">-->
                                                        <div class="profile-thumb">
                                                            <img src="{{URL::asset('uploads/users/profileimg')}}/{{$result->profile_image}}" alt="">
                                                        </div>
                                                        <h3>{{$result->first_name}} {{$result->last_name}}</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="col-md-6 col-sm-6  border-right profile-part">
                                                    <div class="heading profile_heading flex-bit">
                                                        <h4>Personal Information</h4>

                                                    </div>
                                                    <table id="ico" class="dt-responsive">
                                                        <tbody>
                                                        <tr>
                                                            <td><i class="fa fa-envelope custom-margin-font" aria-hidden="true"></i> <strong>Email Id -</strong></td>
                                                            <td>{{get_usermail($result->id)}}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-user-circle custom-margin-font" aria-hidden="true"></i> <strong>Name -</strong>  </td>
                                                            <td>{{$result->first_name}} {{$result->last_name}}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-phone custom-margin-font" aria-hidden="true"></i> <strong>Contact No. -</strong></td>
                                                            <td>({{$result->mob_isd}}) {{owndecrypt($result->mobile_no)}}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fas fa-globe custom-margin-font"></i> <strong>Country -</strong></td>
                                                            <td>{{get_country_name($result->country)}}</td>
                                                        </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="col-md-6 col-sm-6 profile-part">
                                                    <div class="heading profile_heading flex-bit">
                                                        <h4>Status</h4>
                                                    </div>
                                                    <table id="ico" class="dt-responsive">
                                                        <tbody>
                                                        <tr>
                                                            <td>Email Status </td>
                                                            @if($result->verify_status=='1')
                                                                <td><img src="{{URL::asset('front')}}/assets/imgs/like.png" alt="like"/> <span class="green">Verified</span></td>
                                                            @else
                                                                <td><img src="{{URL::asset('front')}}/assets/imgs/dislike.png" alt="dislike"/> <span class="red">Un-Verified</span></td>
                                                            @endif
                                                        </tr>
                                                        <tr>
                                                            <td>Mobile Status </td>
                                                            @if($result->mobile_status=='1')
                                                                <td><img src="{{URL::asset('front')}}/assets/imgs/like.png" alt="like"/> <span class="green">Verified</span></td>
                                                            @else
                                                                <td><img src="{{URL::asset('front')}}/assets/imgs/dislike.png" alt="dislike"/> <span class="red">Un-Verified</span></td>
                                                            @endif
                                                        </tr>
                                                        <tr>
                                                            <td>TFA Status</td>
                                                            @if($result->tfa_status=='enable')
                                                                <td><i class="fas fa-toggle-on green"></i><span class="green"> Enabled</span></td>
                                                            @else
                                                                <td><i class="fas fa-toggle-off red"></i><span class="red"> Disabled</span></td>
                                                            @endif
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="edit-profile" class="tab-pane fade">
                                            <form id="profile-update" action="{{url('profile')}}" method="post" enctype="multipart/form-data">
                                                {{csrf_field()}}
                                            <div class="flex-row">
                                                <div class="col-md-3 col-sm-5  border-right profile-part">
                                                    {{--<div class="heading profile_heading flex-bit">--}}
                                                        {{--<h4>Avatar</h4>--}}
                                                    {{--</div>--}}
                                                    {{--<div class="profile upload-file">--}}
                                                        {{--<input id="imageUpload" type="file" accept="image/jpeg,image/jpg,image/png" name="imageUpload" class="upload-hidden" data-msg-accept="Only .jpg and .png images allowed.">--}}
                                                        {{--<div class="profile-thumb">--}}
                                                            {{--<img id="profileImage" src="{{URL::asset('uploads/users/profileimg')}}/{{$result->profile_image}}" alt="">--}}
                                                        {{--</div>--}}
                                                        {{--<span class="d-block white">Click to Select</span>--}}
                                                        {{--<label id="imageUpload-error" class="error" for="imageUpload" hidden></label>--}}
                                                    {{--</div>--}}
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="col-md-9 col-sm-7 ">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="heading profile_heading flex-bit">
                                                                <h4>Personal Information</h4>
                                                            </div>
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label >User Name</label>
                                                                            <input type="text" name="username" class="form-control" value="{{$result->enjoyer_name}}">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label >Email Id</label>
                                                                            <input value="{{get_usermail($result->id)}}" id="email_id" name="email_id" type="text" class="form-control" disabled>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <div class="form-group">
                                                                            <label >First Name</label>
                                                                            <input type="text" name="first_name" class="form-control"  value="{{$result->first_name}}">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <div class="form-group">
                                                                            <label >Last Name</label>
                                                                            <input type="text" name="last_name" class="form-control" value="{{$result->last_name}}">
                                                                        </div>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <div class="col-xs-4">
                                                                        <div class="form-group">
                                                                            <label >Contact No.</label>
                                                                            <select name="isdcode" id="isdcode" class="form-control">
                                                                                <option value="">ISD Code</option>
                                                                                @foreach($country as $val)
                                                                                    <option value="{{$val->phonecode}}" @if($val->phonecode==$result->mob_isd) selected
                                                                                            @endif data-id="{{strtolower($val->iso)}}">+{{$val->phonecode}}</option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xs-8">
                                                                        <div class="form-group">
                                                                            <label> &nbsp;</label>
                                                                            <input type="text" id="telephone" name="telephone" class="form-control" value="{{owndecrypt($result->mobile_no)}}" onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"'>
                                                                                <span id="otp" class="send-otp" @if($result->mobile_status!='1')style="display:" @else style="display: none;" @endif><a href="#" onclick="sendotp()" >Send OTP</a></span>
                                                                            <p id="phone_error" class="error" hidden>The number already exists.</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="heading profile_heading flex-bit">
                                                                <h4>Address</h4>
                                                            </div>
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label for="email">Street address</label>
                                                                            <input type="text" name="address" class="form-control" value="{{$result->address}}">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label for="email">City</label>
                                                                            <input type="text" name="city" class="form-control" value="{{$result->city}}">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label for="email">State</label>
                                                                            <input type="text" name="state" class="form-control" value="{{$result->state}}">
                                                                            <input type="hidden" id="profiletoken" name="profiletoken" value="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label for="email">Country</label>
                                                                            <select name="country_id" id="country_id" class="form-control">
                                                                                <option value="">Select Country</option>
                                                                                @foreach($country_name as $val)
                                                                                    <option value="{{$val->id}}" @if($val->id==$result->country) selected
                                                                                            @endif data-id="{{strtolower($val->iso)}}">{{$val->nicename}}</option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    </div>


                                                                    <div class="col-sm-12">
                                                                        <div class="form-group text-right">
                                                                            <button type="submit" class="btn yellow-btn min-width-btn">Save Changes</button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </form>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="change-password" class="tab-pane fade">
                                            <div class="flex-row">
                                                <div class="col-md-4 col-md-offset-4">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="heading profile_heading flex-bit">
                                                                <h4>Change Password</h4>
                                                            </div>
                                                            <form id="change_pass" action="{{url('/change_password')}}" method="post" role="form">
                                                                {{csrf_field()}}
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label >Old Password</label>
                                                                            <input type="password" class="form-control" name="old_password" placeholder="Current Password" >
                                                                            <input type="hidden" id="changepasswordtoken" name="changepasswordtoken" value="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label >New Password</label>
                                                                            <input type="password" class="form-control" id="new_pass" name="password" placeholder="New Password">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label >Re-type New Password</label>
                                                                            <input type="password" class="form-control" name="password_confirmation" placeholder="Re-type New Password">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group text-right">
                                                                            <button type="submit" class="btn yellow-btn min-width-btn">Save</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="2fa" class="tab-pane fade">
                                            <div class="clearfix"></div>
                                            <div class="main-flex">
                                                <div class="main-content inner_content">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="panel panel-default panel-heading-space">

                                                                <div class="panel-heading">Google Two-Factor Authentication</div>
                                                                <div class="panel-body">
                                                                    <div class="col-md-3 security-qrcode">
                                                                        <img src="{{$tfa_url}}" class="mb20" alt="qrcode" />
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <p>We recommend to switch to Google Authenticator as more convenient, secure and faster method.In case of method change don't forget to enter new code and save selection.</p>
                                                                        <p>
                                                                            <span class="white-color">Q. What does Google Authenticator do?</span><br>
                                                                            A. Google Authenticator is an application that implements two-step verification services using the Time-based One-time Password Algorithm(HOTP), for authenticating users of mobile application by Google.
                                                                        </p>
                                                                        <p>
                                                                            <span class="white-color">Q. How do i install Google Authenticator?</span><br>
                                                                            A. Android Users (Click) <span class="yellow"><a class="yellow custom-hover" href="https://tinyurl.com/coinspilotGAandroid">https://tinyurl.com/coinspilotGAandroid</a></span>   IOS Users(Click) <span class="yellow"><a class="yellow custom-hover" href="https://tinyurl.com/coinspilotGAios">https://tinyurl.com/coinspilotGAios</a></span>
                                                                        </p>
                                                                        <p>
                                                                            <span class="white-color">Q. How do you use the QR code?</span><br>
                                                                            A. Simple open the installed app, click "+" add button and scan the given QR to generate code.
                                                                        </p>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <hr>
                                                                    <form action="{{url('/security')}}" id="securityForm" method="post" accept-charset="utf-8" novalidate="novalidate">                                <div class="col-md-3">
                                                                            {{csrf_field()}}
                                                                            <div class="form-group custom-security">
                                                                                GOOGLE AUTHENTICATION KEY
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-2 white-color">
                                                                            <div class="form-group custom-security">
                                                                                {{$secret_code}}
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                                <input class="form-control" name="onecode" id="onecode" placeholder=" 6 digit code" data-bv-field="onecode" type="text">
                                                                                <input type="hidden" id="securitytoken" name="securitytoken" value="">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-5">
                                                                            <div class="form-group">
                                                                                @if($result->tfa_status=='disable')
                                                                                    <button type="submit" class="btn yellow-btn min-width-btn min-width-btn-security">ENABLE SECURITY</button>
                                                                                @else
                                                                                    <button type="submit" class="btn yellow-btn min-width-btn min-width-btn-security">DISABLE SECURITY</button>
                                                                                @endif
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>


                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        {{--<div id="kyc" class="tab-pane fade">--}}
                                            {{--<div class="flex-row">--}}
                                                {{--<div class="col-md-12">--}}
                                                    {{--<p style="text-align: center">KYC page is under going a few changes, we will be back shortly. Sorry for the inconvenience caused.</p>--}}
                                                {{--</div>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                        <div id="kyc" class="tab-pane fade">
                                            @if($result->document_status=='1')
                                                <div class="flex-row">
                                                    <div class="col-md-12">
                                                    <p style="text-align: center">Your KYC is Completed.</p>
                                                    </div>
                                                </div>
                                            @else
                                            <div class="flex-row">
                                                <div class="col-md-12">
                                                    <div class="panel panel-default panel-heading-space">
                                                        @if($result->document_status=='2')
                                                            <p class="red" style="text-align: center">Your KYC was rejected. Please check your mail for the reason.</p>
                                                            @elseif($result->document_status=='3')
                                                            <p class="green" style="text-align: center">Your KYC is under verification. You can change the uploaded files if you wish to.</p>
                                                        @endif
                                                        <div class="panel-heading">Personal Details</div>
                                                        <div class="panel-body">
                                                            <form id="kycform" method="post" action="{{url('/kyc')}}" enctype="multipart/form-data">
                                                                {{csrf_field()}}
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <p>Please make sure you use your real Identity to do this verification, We will protect your personal information.</p>
                                                                        <p>For completing KYC you can use any of the below mentioned documents.</p>
                                                                        <p><b>1. Passport &nbsp; &nbsp; 2. Driver's license &nbsp; &nbsp; 3. National ID Card</b></p><br>
                                                                    </div>
                                                                    <div class="col-sm-4">
                                                                        <div class="form-group">
                                                                            <label for="firstname">First Name<span class="required">*</span></label>
                                                                            <input type="text" id="first_name" class="form-control" placeholder="Enter First Name" name="first_name" @if(isset($verification)) @if(isset($verification->first_name)) value="{{$verification->first_name}}" @endif @else value="{{$result->first_name}}" @endif>
                                                                            <input type="hidden" id="kyctoken" name="kyctoken" value="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-4">
                                                                        <div class="form-group">
                                                                            <label for="lastname">Last Name<span class="required">*</span></label>
                                                                            <input type="text" id="last_name" class="form-control" placeholder="Enter Last Name" name="last_name" @if(isset($verification)) @if(isset($verification->last_name)) value="{{$verification->last_name}}" @endif @else value="{{$result->last_name}}" @endif>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-4">
                                                                        <div class="form-group">
                                                                            <label for="gender" class="gender-main-label">Gender<span class="required">*</span></label>
                                                                            <label class="radio-inline">
                                                                                <input type="radio" name="gender" value="M" class="gender-list" @if(isset($verification)) @if($verification->gender=='M')checked @endif @endif><span class="male-female">Male</span>
                                                                                <span class="checkmark"></span>
                                                                            </label>
                                                                            <label class="radio-inline">
                                                                                <input type="radio" name="gender" value="F" class="gender-list" @if(isset($verification)) @if($verification->gender=='F')checked @endif @endif><span class="male-female">Female</span>
                                                                                <span class="checkmark"></span>
                                                                            </label>
                                                                            <label for="gender" generated="true" class="error"></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-4">
                                                                        <div class="form-group">
                                                                            <label for="country">Country And Territory</label><span class="required">*</span>
                                                                            <select name="kyc_country_id" id="kyc_country_id" class="form-control">
                                                                                <option value="">Select Country</option>
                                                                                @foreach($country_name as $val)
                                                                                    <option value="{{$val->id}}" @if($val->id==$result->country) selected
                                                                                            @endif data-id="{{strtolower($val->iso)}}">{{$val->nicename}}</option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-4">
                                                                        <div class="form-group">
                                                                            <label for="document">Passport Id Or Driver's License Id Or National Id<span class="required">*</span></label>
                                                                            <input type="text" class="form-control" placeholder="Enter Id" name="document_id" id="document_id" @if(isset($verification))value="{{$verification->national_id}}"@endif>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <div class="col-md-12">
                                                                            <label for="documentfile">Passport Cover or Driver's License or National ID<span class="required">*</span></label>&nbsp;&nbsp;
                                                                            <small class="instraction">Please make sure that the photo is complete and clearly visible, in JPG format.</small>
                                                                        </div>
                                                                        <div class="col-md-5">
                                                                            <div class="form-group">
                                                                                @if(isset($verification))
                                                                                @if($verification->proof1!='')
                                                                                    <div>
                                                                                        <canvas id="cf_side" width="350" height="250" style="border:1px     solid #d3d3d3;background:#2B3542;display: none" ></canvas>
                                                                                        <img id="df_side" src="/src.php?name={{$verification->proof1}}" style="width: 350px;height: 250px; display:block">
                                                                                    </div>
                                                                                @endif
                                                                                    @else
                                                                                <!--<input type="file" class="form-control documentfile" name="documentfile">-->
                                                                                    <canvas id="cf_side" width="350" height="250" style="border:1px     solid #d3d3d3;background:#2B3542;display: none" ></canvas>
                                                                                    <div id="df_side" class="form-control documentfile" style="display: block">
                                                                                    </div>
                                                                                @endif
                                                                                <label  class="custom-file-input custom-upload" style="margin-top: 10px;">
                                                                                    <input id="f_side" type="file" accept="image/jpg,image/jpeg" name="f_side" data-msg-accept="Only .jpg images allowed.">
                                                                                </label>
                                                                                <label id="f_side-error" class="error" for="f_side" hidden></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-2">
                                                                            <div class="form-group example-main">
                                                        <span class="example">
                                                            <img src="{{URL::asset('front')}}/assets/imgs/example-arrow.png" alt="example-arrow" />
                                                            <span class="example-text">Example</span>
                                                            <img src="{{URL::asset('front')}}/assets/imgs/example-arrow.png" alt="example-arrow" />
                                                        </span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-5">
                                                                            <div class="form-group kyc-doc-cenrer">
                                                                                <img class="kyc-doc1" src="{{URL::asset('front')}}/assets/imgs/doc1.png" alt="doc1" />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <hr>
                                                                    <div class="col-md-12">
                                                                        <div class="col-md-12">
                                                                            <label for="documentfile1">Passport Personal Page or back of your Driver's License or National ID Document.<span class="required">*</span></label>
                                                                            <small class="instraction">Please make sure that the photo is complete and clearly visible, in JPG format.</small>
                                                                        </div>
                                                                        <div class="col-md-5">
                                                                            <div class="form-group">
                                                                                @if(isset($verification))
                                                                                    @if($verification->proof2!='')
                                                                                        <div>
                                                                                            <canvas id="cb_side" width="350" height="250" style="border:1px solid #d3d3d3;background:#2B3542;display: none" ></canvas>
                                                                                            <img id="db_side" src="/src.php?name={{$verification->proof2}}" style="width: 350px;height: 250px; display:block">
                                                                                        </div>
                                                                                    @endif
                                                                                @else
                                                                                <!--<input type="file" class="form-control documentfile" name="documentfile">-->
                                                                                    <canvas id="cb_side" width="350" height="250" style="border:1px     solid #d3d3d3;background:#2B3542;display: none" ></canvas>
                                                                                    <div id="db_side" class="form-control documentfile" style="display: block">
                                                                                    </div>
                                                                                @endif
                                                                                <label  class="custom-file-input custom-upload" style="margin-top: 10px;">
                                                                                    <input id="b_side" type="file" name="b_side" accept="image/jpg,image/jpeg" data-msg-accept="Only .jpg images allowed.">
                                                                                </label>
                                                                                    <label id="b_side-error" class="error" for="b_side" hidden></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-2">
                                                                            <div class="form-group example-main">
                                                        <span class="example">
                                                            <img src="{{URL::asset('front')}}/assets/imgs/example-arrow.png" alt="example-arrow" />
                                                            <span class="example-text">Example</span>
                                                            <img src="{{URL::asset('front')}}/assets/imgs/example-arrow.png" alt="example-arrow" />
                                                        </span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-5">
                                                                            <div  class="form-group kyc-doc-cenrer">
                                                                                <img class="kyc-doc1" src="{{URL::asset('front')}}/assets/imgs/doc2.png" alt="doc2" />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <label for="documentfile2">Selfie With Photo ID or front of Driver's License or National Id document & Note<span class="required">*</span></label>
                                                                        <small class="instraction">Please provide a photo of you holding your Identity card.<br> In the same picture, make a reference to AlphaEx and today's date displayed.<br> Make sure your face is clearly visible and that all Identity care details are clearly readable.</small>
                                                                        <ul class="kyc-list">
                                                                            <li>Face clearly visible</li>
                                                                            <li>Note with word 'AlphaEx'</li>
                                                                        </ul>
                                                                        <ul class="kyc-list1">
                                                                            <li>Photo ID clearly visible</li>
                                                                            <li>Note with today's date</li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-md-5">
                                                                        <div class="form-group">
                                                                            @if(isset($verification))
                                                                                @if($verification->proof3!='')
                                                                                    <div>
                                                                                        <canvas id="ch_side" width="350" height="250" style="border:1px     solid #d3d3d3;background:#2B3542;display: none" ></canvas>
                                                                                        <img id="dh_side" src="/src.php?name={{$verification->proof3}}" style="width: 350px;height: 250px; display:block">
                                                                                    </div>
                                                                                @endif
                                                                            @else
                                                                            <!--<input type="file" class="form-control documentfile" name="documentfile">-->
                                                                                <canvas id="ch_side" width="350" height="250" style="border:1px     solid #d3d3d3;background:#2B3542;display: none" ></canvas>
                                                                                <div id="dh_side" class="form-control documentfile" style="display: block">
                                                                                </div>
                                                                            @endif
                                                                            <label  class="custom-file-input custom-upload" style="margin-top: 10px;">
                                                                                <input id="h_side" type="file" name="h_side" accept="image/jpg,image/jpeg" data-msg-accept="Only .jpg images allowed.">
                                                                            </label>
                                                                                <label id="h_side-error" class="error" for="h_side" hidden></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                        <div class="form-group example-main">
                                                    <span class="example">
                                                        <img src="{{URL::asset('front')}}/assets/imgs/example-arrow.png" alt="example-arrow" />
                                                        <span class="example-text">Example</span>
                                                        <img src="{{URL::asset('front')}}/assets/imgs/example-arrow.png" alt="example-arrow" />
                                                    </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-5">
                                                                        <div class="form-group kyc-doc-cenrer">
                                                                            <img class="kyc-doc1" src="{{URL::asset('front')}}/assets/imgs/doc3.png" alt="doc3" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-4 col-sm-offset-8">
                                                                        <div class="form-group text-right">
                                                                            <button type="submit" class="btn yellow-btn min-width-btn">Submit</button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @endif
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    <div id="modal-otp" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content custom-modal-background text-center">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Mobile Number Verification</h4>
                </div>
                <div id="otp_message"></div>
                <div class="modal-body">
                    <form class="form-horizontal" id="otp_form" method="post" action="#">
                        {{csrf_field()}}
                        <div class="form-group"><label class="control-label col-md-3">Enter Verification
                                code</label>

                            <div class="col-md-9"><input id="verify_code" class="form-control" name="verify_code"
                                                         type="text">
                                <br>
                                <div id="countdown">
                                    <span style="float:left">OTP message sent to your mobile number. Resend Link: </span>
                                    <div id="minutes" style="float:left;color: red">00</div>
                                    <div style="float:left">:</div>
                                    <div id="seconds" style="float:left;color: red">00</div>
                                </div>
                                <div id="aftercount" style="display:none;">OTP via call:&nbsp;<a href="#" onclick="otp_call()" style="color: lightblue">Click Here</a></div>
                                <div id="aftercount_msg" style="display:none;">*If you do not recieve OTP within 15 minutes please contact support</div>
                            </div>
                        </div>
                        <div class="form-group">
                                <button type="button" class="btn btn-cancel min-width-btn"  data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn yellow-btn min-width-btn" onclick="verify_otp()">Submit</button>&nbsp;&nbsp;
                        </div>
                        <div class="modal-footer">
                            <label><strong>Note:</strong> &nbsp;Withdrawal cannot be done until mobile number is verified.<br>&nbsp;</label>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('xscript')
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    {{--form validation--}}
    <script type="text/javascript">

        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Number Not valid."
        );
        $('#profile-update').validate({
            rules:
                {
                    username:{required:true,minlength:2,regex:"^[a-zA-Z]+((\\s|\\-)[a-zA-Z]+)?$"},
                    first_name: {required:true,minlength:2,regex:"^[a-zA-Z]+((\\s|\\-)[a-zA-Z]+)?$"},
                    last_name: {required:true,minlength:2,regex:"^[a-zA-Z]+((\\s|\\-)[a-zA-Z]+)?$"},
                    isdcode: {required:true},
                    telephone:{ required:true,number:true,regex:"^[1-9][0-9]*$"},
                    address:{required:true,regex:"(?!^ +$)^.+$"},
                    state:{required:true,regex:"(?!^ +$)^.+$"},
                    city:{required:true,regex:"(?!^ +$)^.+$"},
                },
            messages:
                {
                    username:{required:'Username is required',minlength:'Username should contain atleast two alphabets',regex:'Only alphabets allowed and it should not start with space.'},
                    first_name:{required:'First name is required',minlength:'First name should contain atleast two alphabets',regex:'Only alphabets allowed and it should not start with space.'},
                    last_name:{required:'Last name is required',minlength:'Last name should contain atleast two alphabets',regex:'Only alphabets allowed and it should not start with space.'},
                    isdcode:{ required:'ISD code is required.'},
                    telephone:{required:'Mobile number is required',number: 'Digit only allowed',regex:'Number not valid should not start with zero'},
                    address:{required:'Address is required',regex:"Only spaces not allowed."},
                    state:{required:'State is required',regex:"Only spaces not allowed."},
                    city:{required:'City is required',regex:"Only spaces not allowed."},
                },
        })
    </script>

    <script type="text/javascript">
        $("#change_pass").validate({
            rules:
                {
                    old_password:{required:true,remote:{url:"{{url('ajax/checkoldpass')}}",type:'post',data:{'_token':"{{ csrf_token() }}"}}},
                    password:{
                        required:true,
                        minlength:8,
                        noSpace: true,
                        pwcheckallowedchars: true,
                        pwcheckspechars: true,
                        pwcheckuppercase: true,
                        pwchecklowercase: true,
                        maxlength:25
                    },
                    password_confirmation:{required:true,equalTo:'#new_pass',},
                },
            messages:
                {
                    old_password:{required:'Old Password is required',remote:'Old password is wrong',},
                    password:{required:'Password is required',minlength:'Minimum 8 characters are required',maxlength:'Password cannot contain more than 25 characters'},
                    password_confirmation:{required:'Confirm password is required',equalTo:'Password does not match',},
                },
        });

        jQuery.validator.addMethod("noSpace", function (value, element) {
            return value.indexOf(" ") < 0 && value != "";
        }, "No space please and don't leave it empty");

        jQuery.validator.addMethod("pwcheckallowedchars", function (value) {
            return /^[a-zA-Z0-9!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]+$/.test(value) // has only allowed chars letter
        }, "The password contains non-admitted characters");

        jQuery.validator.addMethod("pwcheckspechars", function (value) {
            return /[!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]/.test(value)
        }, "The password must contain at least one special character");

        jQuery.validator.addMethod("pwcheckuppercase", function (value) {
            return /[A-Z]/.test(value) // has an uppercase letter
        }, "The password must contain at least one uppercase letter");

        jQuery.validator.addMethod("pwchecklowercase", function (value) {
            return /[a-z]/.test(value) // has an uppercase letter
        }, "The password must contain at least one lowercase letter");

    </script>

    <script type="text/javascript">
        $("#securityForm").validate({
            rules:
                {
                    onecode:{required:true,number:true,},
                },
            messages:
                {
                    onecode:{required:'Please enter otp code',number:'Enter digit only',},
                },
        });
    </script>

    <script>
        $.validator.addMethod('filesize', function (value, element, arg) {

            return this.optional(element) || (element.files[0].size <= arg)
        }, 'File size must be less than {0}');

        $('#kycform').validate({
            rules:
                {
                    first_name: { required: true,minlength:2,regex:"^[a-zA-Z]+((\\s|\\-)[a-zA-Z]+)?$"},
                    last_name: { required: true,minlength:2,regex:"^[a-zA-Z]+((\\s|\\-)[a-zA-Z]+)?$"},
                    country_id: { required: true},
                    document_id: { required:true,regex:"^[a-zA-Z0-9_]*$"},
                    f_side: {required: true,filesize:3145728},
                    b_side: {required: true,filesize:3145728},
                    h_side: {required: true,filesize:3145728},
                    gender: {required: true}
                },
            messages:
                {
                    first_name: { required: 'First Name  is required',minlength:'First name should contain atleast two alphabets',regex:'Only alphabets allowed and it should not start with space.'},
                    last_name: { required: 'Last Name  is required',minlength:'Last name should contain atleast two alphabets',regex:'Only alphabets allowed and it should not start with space.'},
                    country_id: { required: 'Country  is required'},
                    document_id: { required: 'Document Number is required',regex:'No special characters allowed.'},
                    f_side: { required: 'Front Side is required.',filesize:"Maximum size is 3mb"},
                    b_side: { required: 'Back Side is required',filesize:"Maximum size is 3mb"},
                    h_side: { required: 'Selfie with ID is required',filesize:"Maximum size is 3mb"},
                    gender: { required: 'Please select a gender'}
                }
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.bar-toggle').on('click', function() {
                $('.leftbar').toggleClass('open');
            });
            $('#telephone').change(function(){
                var old_no = {{owndecrypt($result->mobile_no)}};
                var new_no = $('#telephone').val();
                if(old_no!=new_no)
                {
                    $('#otp').css('display','');
                }
                else
                {
                    $('#otp').css('display','none');
                }
            })
        })
    </script>

    {{--edit profile image--}}
    <script>
        function previewProfileImage( uploader ) {
            //ensure a file was selected
            if (uploader.files && uploader.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    var img = new Image();
                    img.src = e.target.result;
                    //set the image data as source
                    $('#profileImage').attr('src', e.target.result);
                }
                reader.readAsDataURL( uploader.files[0] );
            }
        }

        $("#imageUpload").change(function(){
            previewProfileImage( this );
        });
    </script>

    <script>
        function el(id){
            return document.getElementById(id);} // Get elem by ID

        var canvas1  = el("cf_side");
        var image1 = el("df_side");
        var context1 = canvas1.getContext("2d");
        function readImage1() {

            canvas1.style.display = 'block';
            image1.style.display='none';

            if ( this.files && this.files[0] ) {
                var FR= new FileReader();
                FR.onload = function(e)
                {
                    var img = new Image();

                    img.addEventListener("load", function() {
                        var x = 0;
                        var y = 0;
                        var width = 350;
                        var height = 250;

                        context1.drawImage(img,x,y,width,height);
                    });
                    img.src = e.target.result;
                };
                FR.readAsDataURL( this.files[0] );
            }
        }
        el("f_side").addEventListener("change", readImage1, false);
    </script>

    <script>
        function el(id){return document.getElementById(id);} // Get elem by ID

        var canvas2  = el("cb_side");
        var context2 = canvas2.getContext("2d");
        var image2 = el("db_side");
        function readImage2() {
            canvas2.style.display = 'block';
            image2.style.display = 'none';

            if ( this.files && this.files[0] ) {
                var FR= new FileReader();
                FR.onload = function(e) {
                    var img = new Image();

                    img.addEventListener("load", function() {
                        var x = 0;
                        var y = 0;
                        var width = 350;
                        var height = 250;

                        context2.drawImage(img,x,y,width,height);
                    });
                    img.src = e.target.result;
                };
                FR.readAsDataURL( this.files[0] );
            }
        }
        el("b_side").addEventListener("change", readImage2, false);
    </script>

    <script>
        function el(id){return document.getElementById(id);} // Get elem by ID

        var canvas3  = el("ch_side");
        var context3 = canvas3.getContext("2d");
        var image3 = el("dh_side");
        function readImage3() {
            canvas3.style.display = 'block';
            image3.style.display = 'none';

            if ( this.files && this.files[0] ) {
                var FR= new FileReader();
                FR.onload = function(e) {
                    var img = new Image();

                    img.addEventListener("load", function()
                    {
                        var x = 0;
                        var y = 0;
                        var width = 350;
                        var height = 250;
                        context3.drawImage(img,x,y,width,height);
                    });
                    img.src = e.target.result;
                };
                FR.readAsDataURL( this.files[0] );
            }
        }
        el("h_side").addEventListener("change", readImage3, false);
    </script>

    <script>
        function linkactivate()
        {
            try
            {
                var sTime = new Date().getTime();
                var countDown = 30;

                function UpdateTime() {
                    var cTime = new Date().getTime();
                    var diff = cTime - sTime;
                    var seconds = countDown - Math.floor(diff / 1000);
                    if (seconds >= 0) {
                        var minutes = Math.floor(seconds / 60);
                        seconds -= minutes * 60;
                        $("#minutes").text(minutes < 10 ? "0" + minutes : minutes);
                        $("#seconds").text(seconds < 10 ? "0" + seconds : seconds);
                    } else {
                        $("#countdown").hide();
                        $("#aftercount").show();
                        $('#aftercount_msg').show();
                        clearInterval(counter);
                    }
                }
                UpdateTime();
                var counter = setInterval(UpdateTime, 500);

            }
            catch(e)
            {
                console.log(e);
            }
        }
    </script>

    <script type="text/javascript">
        function sendotp() {
            var isdcode = $("#isdcode").val();
            var mobile = $("#telephone").val();
            var email = $('#email_id').val();
            var user_id = {{$result->id}};
            if (mobile != '' && isdcode !='') {
                $.ajax({
                    url: '{{url("ajax/checkphone")}}',
                    method: 'post',
                    data: {'mobile_no': mobile, 'user_id': user_id},
                    success: function (data) {
                        obj = JSON.parse(data);
                        if (obj.message == '1') {
                            $('#modal-otp').modal('hide');
                            $('#phone_error').show().delay(5000).fadeOut();
                        }
                        else {
                            $.ajax({
                                url: '{{url("ajax/registerotp")}}',
                                method: 'post',
                                data: {'isdcode': isdcode, 'phone': mobile, 'reg_email': email, 'type': 'Update'},
                                success: function (output) {
                                    obj = JSON.parse(output);
                                    if (obj.status == '1') {
                                        $('#modal-otp').modal('show');
                                        linkactivate();
                                        // $('#otp_msg1').delay(30000).fadeIn();
                                    }
                                    else {
                                        $("#otp_msg").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.sms + '</div>')
                                    }
                                }
                            });
                        }
                    }
                });
            }
            else
            {
                var $validator = $("#profile-update").validate();
                if(mobile!='') {
                    errors = {isdcode: "ISD code is required."};
                }
                else if(isdcode!='') {
                    errors = {telephone: "Phone number is required."};
                }
                else {
                    errors = {telephone: "Phone number is required.", isdcode: "ISD code is required."};
                }
                $validator.showErrors(errors);
            }
        }
    </script>

    <script type="text/javascript">

        $( document ).ready(function() {
            var value = "; " + document.cookie;
            // console.log(value);
            var parts = value.split("; token=");
            if (parts.length == 2) var $hiddentoken= parts.pop().split(";").shift();
           document.getElementById("profiletoken").value=$hiddentoken;
            document.getElementById("kyctoken").value=$hiddentoken;
            document.getElementById("changepasswordtoken").value=$hiddentoken;
            document.getElementById("securitytoken").value=$hiddentoken;
            // console.log(document.getElementById("changepasswordtoken").value)


        });

        function otp_call()
        {
            var isdcode = $("#isdcode").val();
            var mobile=$("#telephone").val();
            $.ajax({
                url:'{{url("ajax/otpcall")}}',
                method:'post',
                data:{'mobile':mobile,'isdcode':isdcode},
                success : function(data)
                {
                    document.getElementById('aftercount').innerHTML = 'Call request have been placed';
                }
            });
        }
    </script>

    <script>
        function verify_otp()
        {
            var code=$('#verify_code').val();
            var mobile=$('#telephone').val();
            var user_id={{$result->id}};
            $.ajax({
                url:'{{url("ajax/verify_otp")}}',
                method:'post',
                data:{'verify_code':code, 'mobile':mobile, 'user_id':user_id},
                success : function(data)
                {
                    data=JSON.parse(data);
                    $('#modal-otp').modal('hide');
                    if(data.status=='1')
                    {
                        toastr.success(data.message);
                    }
                    else {
                        toastr.error(data.message);
                    }
                }
            });
        }
    </script>

@endsection