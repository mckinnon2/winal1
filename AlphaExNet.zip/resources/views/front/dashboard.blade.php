@extends('front.layout.front')
@section('content')

    <!-- dashboard data -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <!-- left navigation -->
            @include('front.sidebar')
            <!-- / left navigation -->

                <!-- right panel - dashboard data -->
                <div class="col-md-9">
                    @include('front.alert')
                    <div class="row">
                        <!-- dashboard balance stats -->
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 mb20">
                                    <div class="panel bg-reverse">
                                        <div class="panel-body">
                                            <p class="text-center font16 fontW600">Your XDC Balance</p>
                                            <p class="text-center"><i class="fa font50"><img src="{{URL::asset('front')}}/assets/icons/XDC.png" class="stat-icon"></i></p>
                                            <h3 class="text-center mb20">{{round(get_userbalance($aid,'XDC'))}}</h3>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('deposit/XDC')}}" class="btn btn-xs btn-green btn-block">Deposit</a></p>
                                                </div>
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('transfercrypto/xdc')}}" class="btn btn-xs btn-green btn-block">Withdraw</a></p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 mb20">
                                    <div class="panel bg-reverse">
                                        <div class="panel-body">
                                            <p class="text-center font16 fontW600">Your Bitcoin Balance</p>
                                            <p class="text-center"><i class="fa font50"><img src="{{URL::asset('front')}}/assets/icons/Bitcoin.png" class="stat-icon"></i></p>
                                            <h3 class="text-center mb20">{{number_format(get_userbalance($aid,'BTC'),4,'.',',')}}</h3>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('deposit/BTC')}}" class="btn btn-xs btn-green btn-block">Deposit</a></p>
                                                </div>
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('transfercrypto/btc')}}" class="btn btn-xs btn-green btn-block">Withdraw</a></p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 mb20">
                                    <div class="panel bg-reverse">
                                        <div class="panel-body">
                                            <p class="text-center font16 fontW600">Your ETH Balance</p>
                                            <p class="text-center"><i class="fa font50"><img src="{{URL::asset('front')}}/assets/icons/Ethereum.png" class="stat-icon"></i></p>
                                            <h3 class="text-center mb20">{{number_format(get_userbalance($aid,'ETH'),4,'.',',')}}</h3>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('deposit/ETH')}}" class="btn btn-xs btn-green btn-block">Deposit</a></p>
                                                </div>
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('transfercrypto/eth')}}" class="btn btn-xs btn-green btn-block">Withdraw</a></p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                            </div>

                            <div class="row">


                                <div class="col-md-4 mb20">
                                    <div class="panel bg-reverse">
                                        <div class="panel-body">
                                            <p class="text-center font16 fontW600">Your Ripple Balance</p>
                                            <p class="text-center"><i class="fa font50"><img src="{{URL::asset('front')}}/assets/icons/Ripple.png" class="stat-icon"></i></p>
                                            <h3 class="text-center mb20">{{number_format(get_userbalance($aid,'XRP'),4,'.',',')}}</h3>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('deposit/XRP')}}" class="btn btn-xs btn-green btn-block">Deposit</a></p>
                                                </div>
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('transfercrypto/xrp')}}" class="btn btn-xs btn-green btn-block">Withdraw</a></p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 mb20">
                                    <div class="panel bg-reverse">
                                        <div class="panel-body">
                                            <p class="text-center font16 fontW600">Your XDCE Balance</p>
                                            <p class="text-center"><i class="fa font50"><img src="{{URL::asset('front')}}/assets/icons/XDCE.png" class="stat-icon"></i></p>
                                            <h3 class="text-center mb20">{{number_format(get_userbalance($aid,'XDCE'),4,'.',',')}}</h3>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('deposit/XDCE')}}" class="btn btn-xs btn-green btn-block">Deposit</a></p>
                                                </div>
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('transfercrypto/XDCE')}}" data-toggle="tooltip" title="Currently XDCE  is compatible with MyEtherWallet and MetaMask, &#013;Alphaex is not responsible if you are transferring XDCE to anyother wallet." class="btn btn-xs btn-green btn-block">Withdraw</a></p>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 mb20">
                                    <div class="panel bg-reverse">
                                        <div class="panel-body">
                                            <p class="text-center font16 fontW600">Your BCH Balance</p>
                                            <p class="text-center"><i class="fa font50"><img src="{{URL::asset('front')}}/assets/icons/BCH.png" class="stat-icon"></i></p>
                                            <h3 class="text-center mb20">{{number_format(get_userbalance($aid,'BCH'),4,'.',',')}}</h3>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('deposit/BCH')}}" class="btn btn-xs btn-green btn-block">Deposit</a></p>
                                                </div>
                                                <div class="col-lg-6">
                                                    <p><a href="{{url('transfercrypto/bch')}}" class="btn btn-xs btn-green btn-block">Withdraw</a></p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- dashboard balance stats -->

                        <!-- dashboard stats -->
                        <div class="col-md-6">
                            <div class="row">
                                <div class="dashboard-stats">
                                    <div class="col-md-12">
                                        <!-- user id stats -->
                                        <div class="widget widget-box">
                                            <div class="widget-left widget-item bg-success">
                                                <i class="fa fa-briefcase font50 stat-icon"></i>
                                            </div>
                                            <div class="widget-right widget-item bg-reverse">
                                                <p class="font32 no-margin">{{Session::get('alphauserid') + 10000}}</p>
                                                <p class="font16 text-grey no-margin">Your User ID</p>
                                            </div>
                                        </div>
                                        <!-- / user id stats -->
                                    </div>

                                    <div class="col-md-12">
                                        <!-- account status stats -->
                                        <div class="widget widget-box">
                                            <div class="widget-left widget-item bg-success">
                                                <i class="fa fa-user font50 stat-icon"></i>
                                            </div>
                                            <div class="widget-right widget-item bg-reverse">
                                                <p class="font32 no-margin">
                                                    @if($status==1)
                                                        Active
                                                    @else
                                                        Deactive
                                                    @endif

                                                </p>
                                                <p class="font16 text-grey no-margin">Your Account Status</p>
                                            </div>
                                        </div>
                                        <!-- account status stats -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- / dashboard stats -->

                        <!-- Trading limit stats -->
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="limitBox text-center widget widget-box">
                                        <p class="font32 text-green mt80 text-center">{{get_fee_settings('spend_limit_btc')}} BTC</p>
                                        <p class="font16 text-grey text-center">Your Trading Limit</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Trading limit stats -->

                        <div class="col-md-12">
                            <div class="row">
                                <div class="dashboard-stats">
                                    <div class="col-md-6">
                                        <!-- user id stats -->
                                        <div class="widget widget-box">
                                            <div class="widget-left widget-item bg-success">
                                                <i class="fa fa-mobile font50 stat-icon"></i>
                                            </div>
                                            <div class="widget-right widget-item bg-reverse">
                                                <p class="font32 no-margin">
                                                    @if($mobile_status==1)
                                                        Verified
                                                    @else
                                                    @endif
                                                </p>
                                                <p class="font16 text-grey no-margin">Your Mobile status</p>
                                            </div>
                                        </div>
                                        <!-- / user id stats -->
                                    </div>

                                    <div class="col-md-6">
                                        <!-- account status stats -->
                                    <!--  <div class="widget widget-box">
                                            <div class="widget-left widget-item bg-success">
                                                <i class="fa fa-file font50 stat-icon"></i>
                                            </div>
                                            <div class="widget-right widget-item bg-reverse">
                                                <p class="font32 no-margin">
                                                @if($document_status==1)
                                        Verified
@elseif($document_status==2)
                                        Rejected
@else
                                        Pending
@endif
                                            </p>
                                            <p class="font16 text-grey no-margin">Your KYC Status</p>
                                        </div>
                                    </div> -->
                                        <!-- account status stats -->
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                <!-- / right panel - dashboard data -->

            </div>
        </div>
    </section>
    <!-- / dashboard data -->
    <!-- Small modal -->
    <div id="modal-otp" tabindex="-1" role="dialog" aria-labelledby="modal-login-label" aria-hidden="true"
         class="modal fade" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 id="modal-login-label" class="modal-title">Mobile Number Verification </h4></div>
                <div id="otp_message"></div>
                <div class="modal-body">
                    <div class="form">
                        <form class="form-horizontal" id="otp_form">
                            {{csrf_field()}}
                            <div class="form-group"><label class="control-label col-md-3">Enter Verification
                                    code</label>

                                <div class="col-md-9"><input id="verify_code" class="form-control" name="verify_code"
                                                             type="text">
                                    <br>
                                    <div id="countdown">
                                        <span style="float:left">Resend Link:&nbsp;</span>
                                        <div id="minutes" style="float:left;color: red">00</div>
                                        <div style="float:left">:</div>
                                        <div id="seconds" style="float:left;color: red">00</div>
                                    </div>
                                    <div id="aftercount" style="display:none">OTP via call:&nbsp;<a href="#" onclick="otp_call()" style="color: lightblue">click Here</a></div>
                                    <div id="aftercount_msg" style="display:none">*If you do not recieve OTP within 15 minutes please contact support</div>

                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-9 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary reg_btn" onclick="verify_otp()">Submit</button>&nbsp;&nbsp;
                                    <button type="button" class="btn btn-danger reg_btn"  data-dismiss="modal">Cancel</button>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <label><strong>Note:</strong> &nbsp;Withdrawal cannot be done until mobile number is verified.<br>&nbsp;</label>
                            </div>


                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

@endsection

@section('xscript')

    {{--for countdown timer--}}
    <script>
        function linkactivate()
        {
            try
            {
                var sTime = new Date().getTime();
                var countDown = 2   ;
                function UpdateTime() {
                    var cTime = new Date().getTime();
                    var diff = cTime - sTime;
                    var seconds = countDown - Math.floor(diff / 1000);
                    if (seconds >= 0) {
                        var minutes = Math.floor(seconds / 60);
                        seconds -= minutes * 60;
                        $("#minutes").text(minutes < 10 ? "0" + minutes : minutes);
                        $("#seconds").text(seconds < 10 ? "0" + seconds : seconds);
                    } else {
                        $("#countdown").hide();
                        $("#aftercount").show();
                        $('#aftercount_msg').show();
                        clearInterval(counter);
                    }
                }
                UpdateTime();
                var counter = setInterval(UpdateTime, 500);
            }
            catch(e)
            {
                console.log(e);
            }
        }
    </script>

    {{--for otp via call--}}
    <script>
        function otp_call()
        {
            $.ajax({
                url:'{{url("ajax/otp_call/".$aid)}}',

                success : function(data)
                {
                    console.log(data);
                    document.getElementById('aftercount').innerHTML = 'Call request have been placed';

                }
            });
        }
    </script>

    {{--for verifying entered otp number--}}
    <script>
        function verify_otp()
        {
            var code=$('#verify_code').val();
            var mobile='{{owndecrypt(get_user_details($aid,'mobile_no'))}}';
            var user_id='{{$aid}}';
            $.ajax({
                url:'{{url("ajax/verify_otp")}}',
                method:'post',
                data:{'verify_code':code, 'mobile':mobile, 'user_id':user_id},
                success : function(data)
                {
                    location.reload();
                }
            });
        }
    </script>


    {{--<script>--}}
        {{--@if(Session::has('error'))--}}
        {{--linkactivate();--}}
        {{--show_modal();--}}
        {{--function show_modal()--}}
        {{--{--}}
            {{--$("#modal-otp").modal({--}}
                {{--backdrop: 'static',--}}
                {{--keyboard: false--}}
            {{--});--}}
        {{--}--}}
        {{--@endif--}}
    {{--</script>--}}


@endsection
