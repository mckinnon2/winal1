@extends('front.layout.front')
@section('content')
    <section class="mt60" style="min-height:740px;">
        <h1 class="text-center">KYC Verification</h1>
        <div class="container" style="background-color: white">
            <br>
            <form id="kyc" method="post" action="{{url('/kyc')}}" enctype="multipart/form-data">
                <div class="form-group col-md-12">
                    {{csrf_field()}}
                    <div class="col-md-1"><strong>Note:</strong></div>
                    <div class="col-md-11"><span>&nbsp;Please make sure you use your real identity to do this verification. We will protect your personal information.
                        <br>
                        you can use any one of the below metioned document for kyc verification:<br>
                        1.Passport<br>
                        2.Driver's License<br>
                        3.National ID Card
                    </span></div>
                </div>
                <div class="form-group col-md-5">
                    <label><strong>First Name:&nbsp;&nbsp;&nbsp;</strong></label>
                    <input type="text" name="first_name" id="first_name">
                    <br>
                    <br>
                    <label><strong>Last Name:&nbsp; &nbsp;&nbsp; </strong></label>
                    <input type="text" name="last_name" id="last_name">
                </div>
                <div class="col-md-7">
                <div class="form-group col-md-4">
                    <label><strong>Country:&nbsp; &nbsp;&nbsp; </strong></label>
                    <select name="country_id" id="country_id" class="form-control "
                            onchange="set_country()">
                        <option value="">Select Country</option>
                        @foreach($country as $val)
                            <option value="{{$val->id}}" @if($val->id==old('country_id')) selected
                                    @endif data-id="{{strtolower($val->iso)}}">{{$val->nicename}}</option>
                        @endforeach
                    </select>
                </div>
                </div>
                <div class="form-group col-md-12 ">

                    <label><strong>Identity Card Front Side:</strong></label>
                    <input type="file" accept="image/*" name="f_side" id="f_side"  />
                    <br>
                    <span>Please make sure that the photo is complete and clearly visible, in JPG format.
                    </span>
                    <br>
                    <div class="col-md-6">
                    <canvas id="cf_side" width="350" height="250" style="border:1px solid #d3d3d3;background:#ffffff;">
                    </canvas>
                    </div>
                    <div class="col-md-6">
                        <span style="padding-toptop: 250px">example</span>
                        <img  width="350" height="250" style="border:1px solid #d3d3d3;" src="{{URL::asset('front')}}/assets/imgs/idcard-f.jpg"/>
                    </div>


                </div>
                <div class="form-group col-md-12 ">

                    <label><strong>Identity Card Back Side:</strong></label>
                    <input type="file" accept="image/*" name="b_side" id="b_side"/>
                    <br>
                    <span>Please make sure that the photo is complete and clearly visible, in JPG format. Id card must be in the valid period</span>
                    <br>
                    <div class="col-md-6">
                        <canvas id="cb_side" width="350" height="250" style="border:1px solid #d3d3d3;background:#ffffff;">
                        </canvas>
                    </div>
                    <div class="col-md-6">
                        <span style="padding-toptop: 250px">example</span>
                        <img  width="350" height="250" style="border:1px solid #d3d3d3;" src="{{URL::asset('front')}}/assets/imgs/idcard-b.jpg"/>
                    </div>


                </div>

                <div class="form-group col-md-12 ">

                    <label><strong>Selfie With Photo ID And Note:</strong></label>
                    <input type="file" accept="image/*" name="h_side" id="h_side"/>
                    <br>
                    <span>Please provide a photo of you holding your Identity Card front side. In the same picture, make a reference to Binance and today's date displayed. Make sure your face is clearly visible and that all passport details are clearly readable.</span>
                    <br>
                    <div class="col-md-6">
                        <canvas id="ch_side" width="350" height="250" style="border:1px solid #d3d3d3;background:#ffffff;">
                        </canvas>
                    </div>
                    <div class="col-md-6">
                        <span style="padding-toptop: 250px">example</span>
                        <img  width="350" height="250" style="border:1px solid #d3d3d3;" src="{{URL::asset('front')}}/assets/imgs/idcard-h.jpg"/>
                    </div>


                </div>
                <div class="col-md-12">

                    <button type="submit" class="btn btn-success">Save</button>
                    <br>
                </div>p


            </form>
        </div>

    </section>



@endsection
@section('xscript')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>
    {{--form validation--}}
    <script>
        $.validator.addMethod('filesize', function (value, element, arg) {
            console.log(element.files[0].size);
            console.log(arg);
            return this.optional(element) || (element.files[0].size <= arg)
        }, 'File size must be less than {0}');

        $("#kyc").validate({
            rules:
                {
                    first_name: { required: true},
                    last_name: { required: true},
                    country_id: { required: true},
                    f_side: {required: true,filesize:3145728},
                    b_side: {required: true,filesize:3145728},
                    h_side: {required: true,filesize:3145728},
                },
            messages:
                {
                    first_name: { required: 'First Name  is required'},
                    last_name: { required: 'Last Name  is required'},
                    country_id: { required: 'Country  is required'},
                    f_side: { required: 'Front Side  is required',filesize:"Maximum size is 3mb"},
                    b_side: { required: 'Back Side  is required',filesize:"Maximum size is 3mb"},
                    h_side: { required: 'Selfie with ID is required',filesize:"Maximum size is 3mb"},

                }
        });
    </script>

    <script>
        function el(id){return document.getElementById(id);} // Get elem by ID

        var canvas1  = el("cf_side");
        var context1 = canvas1.getContext("2d");
        function readImage1() {
            if ( this.files && this.files[0] ) {
                var FR= new FileReader();
                FR.onload = function(e) {
                    var img = new Image();

                    img.addEventListener("load", function() {
                        var x = 0;
                        var y = 0;
                        var width = 350;
                        var height = 250;

                        context1.drawImage(img,x,y,width,height);
                    });
                    img.src = e.target.result;
                };
                FR.readAsDataURL( this.files[0] );
            }
        }

        el("f_side").addEventListener("change", readImage1, false);
    </script>

    <script>
        function el(id){return document.getElementById(id);} // Get elem by ID

        var canvas2  = el("cb_side");
        var context2 = canvas2.getContext("2d");
        function readImage2() {
            if ( this.files && this.files[0] ) {
                var FR= new FileReader();
                FR.onload = function(e) {
                    var img = new Image();

                    img.addEventListener("load", function() {
                        var x = 0;
                        var y = 0;
                        var width = 350;
                        var height = 250;

                        context2.drawImage(img,x,y,width,height);
                    });
                    img.src = e.target.result;
                };
                FR.readAsDataURL( this.files[0] );
            }
        }

        el("b_side").addEventListener("change", readImage2, false);
    </script>

    <script>
        function el(id){return document.getElementById(id);} // Get elem by ID

        var canvas3  = el("ch_side");
        var context3 = canvas3.getContext("2d");
        function readImage3() {
            if ( this.files && this.files[0] ) {
                var FR= new FileReader();
                FR.onload = function(e) {
                    var img = new Image();

                    img.addEventListener("load", function()
                    {
                        var x = 0;
                        var y = 0;
                        var width = 350;
                        var height = 250;
                        context3.drawImage(img,x,y,width,height);
                    });
                    img.src = e.target.result;
                };
                FR.readAsDataURL( this.files[0] );
            }
        }

        el("h_side").addEventListener("change", readImage3, false);
    </script>
    @endsection