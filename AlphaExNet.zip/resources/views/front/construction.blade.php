@extends('front.layout.front')




@section('content')

    <section>
        <br>
        <div>
            <p class="text-center">
                <br><br><br>
                Trading at AlphaEx would resume on 18 March 2018.<br> All other functions of AlphaEx except trade like Withdrawl, Deposits, Opening Account would be available for users.

            </p>
        </div>
    </section>


@endsection


