@extends('front.layout.front')
@section('content')
<div class="clearfix"></div>
<div class="main-flex">
    <div class="main-content inner_content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-md-12">
                    <div class="panel panel-default panel-heading-space">
                        <div class="panel-heading">{{$page->heading}}</div>
                        <div class="panel-body">
                            {!! $page->content !!}
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <div class="clearfix"></div>
</div>
@endsection
@section('xscript')
<script type="text/javascript">
    $(document).ready(function () {
        $('.bar-toggle').on('click', function () {
            $('.leftbar').toggleClass('open');
        });
        $('.panel-collapse').on('show.bs.collapse', function () {
            $(this).siblings('.panel-heading').addClass('active');
        });

        $('.panel-collapse').on('hide.bs.collapse', function () {
            $(this).siblings('.panel-heading').removeClass('active');
        });
    })

</script>
@endsection