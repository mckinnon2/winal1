@extends('front.layout.front')
@section('css')
    <link type="text/css" rel="Stylesheet"
          href="https://ajax.microsoft.com/ajax/jquery.ui/1.8.6/themes/smoothness/jquery-ui.css"/>
    <style>
        * {
        . border-radius(0) !important;
        }

        #field {
            margin-bottom: 20px;
        }

        .btn-facebook {
            color: #fff;
            background-color: #4C67A1;
        }

        .btn-facebook:hover {
            color: #fff;
            background-color: #405D9B;
        }

        .btn-facebook:focus {
            color: #fff;
        }

        .btn-twitter {
            background: #00ACEE;
            color: #fff;
        }

        .btn-twitter:focus {
            color: #fff;
        }

        .btn-twitter:hover {
            background: #0075a2;
            color: #fff;
        }

        .botao-wpp {
            color: #eee;
            background-color: #25d366;
        }

        .botao-wpp:hover {
            background-color: darken(#25d366, 5%);
        }

        .botao-wpp:focus {
            background-color: darken(#25d366, 15%);
        }
    </style>
@endsection
@section('content')
    <div class="clearfix"></div>
    <div class="main-flex">
        <div class="main-content inner_content">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-md-12">
                        <div class="panel panel-default panel-heading-space">
                            <div class="panel-heading">AlphaEx Referral Program</div>
                            <div class="panel-body">
                                <div class="col-md-12">
                                    <div style="font-size: 16px; padding-left:15px !important;">

                                        {{--<p style="text-align: center;">Thank you for the overwhelming response.<br><br>--}}
                                        {{--We here by announce that AlphaEx Referral Program has been closed.<br><br>--}}
                                        {{--For any queries, reach out our team on <a href="https://t.me/alphaexnet"--}}
                                        {{--target="_blank">Telegram</a>.</p>--}}
                                        {{--<br>--}}

                                        <p style="text-align: left;">AlphaEx Referral Program is here. Don’t lose the
                                            opportunity to make around 1Million XDC yours! Guaranteed rewards. <br><br>
                                            Here you go! Let’s know the steps to get you XDC tokens:<br><br>
                                            <strong>Steps:</strong><br>
                                            1. Register on AlphaEx Exchange and complete KYC procedure.<br>
                                            2. Share your referral links in your circle i.e. friends, colleagues
                                            etc.<br>
                                            3. Once Referee signs up and performs his/her first trade, Referrer and
                                            Referee get rewards worth 7500 XDC and 2500 XDC respectively.<br><br>
                                            <strong>Things to Remember:</strong><br>
                                            1. Referrer and Referee get rewards only after the user signs up with your
                                            referral link and performs his/her first trade.<br>
                                            2. Referrer gets 7500 XDC for each Referee signing up and making his/her
                                            first trade.<br>
                                            3. Referrer gets 10K XDC more as rewards after 10 Referees sign up with your
                                            referral link and does 1 trade each.<br>
                                            4. Referrer gets 25K XDC more as rewards after 25 Referees sign up with your
                                            referral link and does 1 trade each.<br>
                                            5. Referrer gets 50K XDC more as rewards after 50 Referees sign up with your
                                            referral link and does 1 trade each.<br>
                                            6. Referrer gets 100K XDC more as rewards after 100 Referees sign up with
                                            your referral link and does 1 trade each.<br><br>
                                            For any queries, reach out our team on <a href="https://t.me/alphaexnet"
                                                                                      target="_blank">Telegram</a>.
                                        </p><br>
                                    </div>

                                    @if(Session::has('alphauserid'))
                                        <div style="font-size: 16px; padding-left:15px !important;">
                                            <p><i class="fas fa-users custom-margin-font"></i> <strong>Referral
                                                    Code</strong> : <span id="referral_code">{{$referral_code}}</span>&nbsp;&nbsp;&nbsp;&nbsp;<a
                                                        href="#" onclick="copyToClipboard('referral_code')"><img
                                                            src="{{URL::asset('front')}}/assets/imgs/copy.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                            </p><br>

                                            <p><i class="fas fa-link"></i> <strong>Referral Link : </strong> <a
                                                        href="{{url('/register')}}?referral_code={{$referral_code}}"><span
                                                            id="referral_link">{{url('/register')}}
                                                        ?referral_code={{$referral_code}}</span></a>&nbsp;&nbsp;&nbsp;&nbsp;<a
                                                        href="#" onclick="copyToClipboard('referral_link')"><img
                                                            src="{{URL::asset('front')}}/assets/imgs/copy.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                            </p><br>

                                            <p><i class="fas fa-share-alt"></i> <strong>Share :</strong>
                                                <a href="https://www.facebook.com/sharer.php?u={{url('/register')}}?referral_code={{$referral_code}}"
                                                   target="_blank" data-toggle="tooltip" title="Share on Facebook">
                                                    <button type="button" class="btn btn-facebook"
                                                            style="font-size:12px !important;"><i
                                                                class="fab fa-facebook-f"></i> <span
                                                                style="font-family: 'Montserrat', sans-serif !important;">Invite over Facebook</span>
                                                    </button>
                                                </a>&nbsp;&nbsp;&nbsp;&nbsp;
                                                <a class="twitter-share-button"
                                                   href="https://twitter.com/intent/tweet?url={{url('/register')}}?referral_code={{$referral_code}}&text=Join+@AlphaExNet+cryptocurrency+Exchange+and+get+a+chance+to+win+upto+1+million+XDC+tokens.+Click+here+to+join+now+:+&hashtags=referral,cryptocurrency,exchange,trading,cryptotrading&related=AlphaExNet"
                                                   target="_blank" data-toggle="tooltip" title="Tweet">
                                                    <button type="button" class="btn btn-twitter "
                                                            style="font-size:12px !important;"><i
                                                                class="fab fa-twitter"> <span
                                                                    style="font-family: 'Montserrat', sans-serif !important;">Invite via Tweet</span></i>
                                                    </button>
                                                </a>&nbsp;&nbsp;&nbsp;&nbsp;
                                                <a href="https://wa.me/?text=Join%20AlphaEx%2C%20the%20Best%20Cryptocurrency%20Exchange%20and%20get%20a%20chance%20to%20win%20upto%201%20million%20XDC%20tokens.%20Click%20here%20to%20join%20now%20%3A%20{{url('/register')}}?referral_code={{$referral_code}}"
                                                   class="wa_btn wa_btn_s" target="_blank" data-toggle="tooltip"
                                                   title="Share on WhatsApp">
                                                    <button type="button" class="btn botao-wpp"
                                                            style="font-size:12px !important;"><i
                                                                class="fab fa-whatsapp"></i> <span
                                                                style="font-family: 'Montserrat', sans-serif !important;">Invite over WhatsApp</span>
                                                    </button>
                                                </a>&nbsp;&nbsp;&nbsp;&nbsp;
                                            </p>
                                        </div>


                                        <div class="clearfix"></div>
                                        <div class="panel-default panel-heading-space">
                                            <div class="panel-heading" style="padding-left:15px !important;">Send Invite
                                                over Email :
                                            </div>
                                        </div>

                                        <div class="container">
                                            <div class="row">
                                                <form method="post" action="{{url('/sendreferral')}}">
                                                    {{csrf_field()}}
                                                    <div id="field" class="col-md-6"><input class=" input "
                                                                                            id="mytext[]"
                                                                                            name="mytext[]" type="email"
                                                                                            placeholder="Enter Email"
                                                                                            style="width:50%; padding: 10px"/>
                                                        <i class="fas fa-plus add-more input"
                                                           style="font-size: 150%"></i>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <button type="submit" value="send" class="btn btn-primary"
                                                            style="margin-left: 15px">Send
                                                    </button>
                                                </form>
                                                <br>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel-default panel-heading-space">
                                                    <div class="panel-heading" style="padding-left: 15px !important;">
                                                        Referral History
                                                    </div>
                                                    <div class="panel-body">
                                                        <table id="referral"
                                                               class="table table-striped table-bordered dt-responsive nowrap"
                                                               style="width:100%">
                                                            <thead>
                                                            <tr>
                                                                <th>Date & Time</th>
                                                                <th>Referred User</th>
                                                                {{--<th>Refered Email</th>--}}
                                                                <th>Bonus</th>
                                                                <th>Currency</th>
                                                                <th>Status</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            @if(isset($referred))
                                                                @foreach($referred as $val)
                                                                    <tr>
                                                                        <td>{{$val->updated_at}}</td>
                                                                        <td>{{$val->referrer_name}}</td>
                                                                        {{--<td>{{$val->refrer_email}}</td>--}}
                                                                        <td>{{$val->referred_bonus}}</td>
                                                                        <td>{{$val->currency}}</td>
                                                                        <td>
                                                                            @if($val->referred_status == 1)
                                                                                Bonus added.
                                                                            @elseif($val->referred_status == 0)
                                                                                Your KYC Pending.
                                                                            @endif
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                            @endif

                                                            @if(isset($referrer))
                                                                @foreach($referrer as $val)
                                                                    <tr>
                                                                        <td>{{$val->updated_at}}</td>
                                                                        <td>{{$val->referred_name}}</td>
                                                                        {{--<td>{{$val->refered_email}}</td>--}}
                                                                        <td>{{$val->referrer_bonus}}</td>
                                                                        <td>{{$val->currency}}</td>
                                                                        <td>@if($val->referrer_status == 1 && $val->referred_status == 1)
                                                                                Bonus added.
                                                                            @elseif($val->referred_status == 0)
                                                                                User First Trade Pending.
                                                                            @elseif($val->referrer_status == 0)
                                                                                Your KYC Pending.
                                                                            @endif
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                            @endif

                                                            @if(isset($referred_users))
                                                                @foreach($referred_users as $val)
                                                                    <tr>
                                                                        <td>{{$val->updated_at}}</td>
                                                                        <td><p>Referred {{$val->referred_users}}
                                                                                users</p>
                                                                        </td>
                                                                        <td>{{$val->bonus}}</td>
                                                                        <td>{{$val->currency}}</td>
                                                                        <td>@if($val->status == 1)
                                                                                Bonus added.
                                                                            @else
                                                                                Bonus pending.
                                                                            @endif
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                            @endif

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    @endif
                                </div>
                                <div class="clearfix"></div>

                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="clearfix"></div>
    </div>
@endsection
@section('xscript')
    <script type="text/javascript">

        //for adding or removing email id text box in referral
        $(document).ready(function () {
            var max_fields = 10; //maximum input boxes allowed
            var wrapper = $("#field"); //Fields wrapper
            var add_button = $(".add-more"); //Add button ID

            var x = 1; //initlal text box count
            $(add_button).click(function (e) {//on add input button click
                console.log('hi');
                console.log(wrapper);
                e.preventDefault();
                if (x < max_fields) { //max input box allowed
                    x++; //text box increment
                    $(wrapper).append('<div><input class=" input" id="mytext[]" name="mytext[]" type="text" placeholder="Enter Email" style="width:50%; padding: 10px; margin-top: 5px "><i class="fas fa-minus remove-me" style="font-size: 150%; margin-left: 5px;"></i></div>'); //add input box

                }
            });

            $(wrapper).on("click", ".remove-me", function (e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            })

            $('#referral').DataTable(
                {
                    "ordering": false,
                    "pageLength": 10,
                    "lengthChange": false,
                    "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
                    "bInfo": false,
                });

        });

        function copyToClipboard(id) {
            var aux = document.createElement("input");
            aux.setAttribute("value", document.getElementById(id).innerHTML);
            document.body.appendChild(aux);
            aux.select();
            document.execCommand("copy");

            document.body.removeChild(aux);

            toastr.success('<div>Copied</div>');
        }

    </script>
@endsection