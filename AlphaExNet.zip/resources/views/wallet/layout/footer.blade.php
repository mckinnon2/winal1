<div id="footer">
                <div class="copyright">2017 © {{get_config('site_name')}}</div>
            </div>