<!DOCTYPE html>
<html lang="en">
@include("panel1.layout.header")
<body>
<div>
   @include("panel1.layout.admin_header_bar")
    <!--END TOPBAR-->
    <div id="wrapper"><!--BEGIN SIDEBAR MENU-->
        @include("panel1.layout.admin_sidebar")
        <!--END SIDEBAR MENU-->
       
      <!--BEGIN PAGE WRAPPER-->
        <div id="page-wrapper"><!--BEGIN TITLE & BREADCRUMB PAGE-->
            @yield("content")
            <!--END CONTENT--><!--BEGIN FOOTER-->
            @include('panel1.layout.footer')
            <!--END FOOTER--></div>
        <!--END PAGE WRAPPER--></div>
</div>
 @include('panel1.layout.footer_script')

 @yield("script")
<!--LOADING SCRIPTS FOR PAGE-->






</body>
</html>