 <nav id="sidebar" role="navigation" data-step="2" data-intro="Template has &lt;b&gt;many navigation styles&lt;/b&gt;" data-position="right" class="navbar-default navbar-static-side">
            <div class="sidebar-collapse menu-scroll">
                <ul id="side-menu" class="nav">
                    <li class="user-panel">
                        <div class="thumb"><img src="https://cdn4.iconfinder.com/data/icons/general24/png/128/administrator.png" alt="" class="img-circle"/></div>
                        <div class="info"><p>Admin</p>
                            <ul class="list-inline list-unstyled">
                                <li><a href="{{url('adminv3/admin_profile')}}" data-hover="tooltip" title="Profile"><i class="fa fa-user"></i></a></li>

                                <!-- <li><a href="{{url('adminv3/admin_site_settings')}}" data-hover="tooltip" title="Setting" ><i class="fa fa-cog"></i></a></li> -->
                                <li><a href="{{url('adminv3/logout')}}" data-hover="tooltip" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </li>

                    <li class="{{admin_class('adminhome').admin_class('')}}"><a href="{{url('adminv3/adminhome')}}"><i class="fa fa-tachometer fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Dashboard</span></a></li>


                    <?php
if (admin_class('user_list') != '' || admin_class('user_auto_flag') != '' ||admin_class('users_balance') != "" || admin_class('admin_kyc_users') != "") {
	$class = "active";
	$in = 'in';
	$style = "auto";
} else {
	$class = "";
	$in = '';
	$style = "0 px";
}

?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-user fa-fw"><div class="icon-bg bg-pink"></div>
                            </i><span class="menu-title">Manage Users</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                            <li ><a href="{{ url('adminv3/user_list/1') }}" @if(admin_class('user_list')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">User List</span></a></li>
                            <li ><a href="{{ url('adminv3/user_auto_flag/1') }}" @if(admin_class('user_auto_flag')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">User Auto Flag</span></a></li>
                            <li ><a href="{{ url('adminv3/admin_kyc_users/1') }}" @if(admin_class('admin_kyc_users')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">KYC verfication</span></a></li>
                            <li ><a href="{{ url('adminv3/users_balance/1') }}" @if(admin_class('users_balance')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">User Balance</span></a></li>
                        </ul>


                    </li>


                      <?php
if (admin_class('deposit_transactions') != ''|| admin_class('withdraw_transactions') != '' || admin_class('updated_transactions') != '' || admin_class('trade_orders') != '' || admin_class('trade_mappings') != "" ) {
	$class = "active";
	$in = 'in';
	$style = "auto";
} else {
	$class = "";
	$in = '';
	$style = "0 px";
}

?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-exchange fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Transactions</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                    <!--  <li ><a href="{{ url('adminv3/transactions') }}" @if(admin_class('transactions')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Exchange Transactions</span></a></li> -->

                        <li ><a href="{{ url('adminv3/deposit_transactions/1') }}" @if(admin_class('deposit_transactions')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Deposit Transactions</span></a></li>
                        <li ><a href="{{ url('adminv3/withdraw_transactions/1') }}" @if(admin_class('withdraw_transactions')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Withdraw Transactions</span></a></li>
                        <li ><a href="{{ url('adminv3/updated_transactions/1') }}" @if(admin_class('updated_transactions')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Updated Transactions</span></a></li>
                        <li ><a href="{{ url('adminv3/trade_orders/1') }}" @if(admin_class('trade_orders')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Trade Transactions</span></a></li>
                        <li ><a href="{{ url('adminv3/trade_mappings/1') }}" @if(admin_class('trade_mappings')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Trade Mapping</span></a></li>
                        
                     </ul>


                    </li>


                     <!-- <li class="{{admin_class('profit')}}"><a href="{{url('adminv3/admin_profit')}}"><i class="fa fa-signal fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Admin Profit</span></a></li> -->

                    <?php
                        if (admin_class('admin_wallet') != '' || admin_class('profit_wallet') != "" || admin_class('brokerage_wallet') != "") {
                            $class = "active";
                            $in = 'in';
                            $style = "auto";
                        } else {
                            $class = "";
                            $in = '';
                            $style = "0 px";
                        }

                    ?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-bank fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Wallets</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('adminv3/admin_wallet/1') }}" @if(admin_class('admin_wallet')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Admin Wallet</span></a></li>

                      <li ><a href="{{ url('adminv3/profit_wallet/1') }}" @if(admin_class('profit_wallet')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Profit Wallet</span></a></li>
                      <li ><a href="{{ url('adminv3/brokerage_wallet/1') }}" @if(admin_class('brokerage_wallet')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Brokerage Wallet</span></a></li>

                     </ul>


                    </li>


                    <!-- <?php
                        if (admin_class('market_price') != '' || admin_class('allprice') != "") {
                            $class = "active";
                            $in = 'in';
                            $style = "auto";
                        } else {
                            $class = "";
                            $in = '';
                            $style = "0 px";
                        }

                    ?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-money fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Market Price</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('adminv3/set_market_price') }}" @if(admin_class('set_market_price')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Market Price - XDC</span></a></li>

                      <li ><a href="{{ url('adminv3/all_prices') }}" @if(admin_class('all_prices')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">All Prices</span></a></li>



                     </ul>


                    </li> -->
                    <!-- <?php
                        if (admin_class('buy_package') != '' || admin_class('package_price') != "") {
                            $class = "active";
                            $in = 'in';
                            $style = "auto";
                        } else {
                            $class = "";
                            $in = '';
                            $style = "0 px";
                        }

                    ?> -->

                    <!-- <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-shopping-cart fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Buy Package</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('adminv3/buy_package') }}" @if(admin_class('buy_package')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Exchange Packages List</span></a></li>

                      <li ><a href="{{ url('adminv3/package_price') }}" @if(admin_class('package_price')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Package Price</span></a></li>
                      
                     </ul>


                    </li> -->

                    

                
                    <li class="{{admin_class('pair')}}"><a href="{{url('adminv3/pair_request/1')}}"><i class="fa fa-file-text fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Pair Request</span></a></li>
      

                    <li class="{{admin_class('set_trading_fee')}}"><a href="{{url('adminv3/set_trading_fee')}}"><i class="fa fa-money fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Trading Fee</span></a></li>

                    <!-- <li class="{{admin_class('fee_config')}}"><a href="{{url('adminv3/set_fee_config')}}"><i class="fa fa-money fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Fees / Limit Settings</span></a></li> -->

                    <li class="{{admin_class('partnership')}}"><a href="{{url('adminv3/partnership/1')}}"><i class="fa fa-file-text fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage Partnerhip</span></a></li>

                    <li class="{{admin_class('otc_list')}}"><a href="{{url('adminv3/otc_list/1')}}"><i class="fa fa-file-text fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage OTC</span></a></li>


                    <?php
                        if (admin_class('user_activities') != '' || admin_class('user_activity') != "" || admin_class('subadmin_activities') != "" || admin_class('subadmin_activity') != "") {
                            $class = "active";
                            $in = 'in';
                            $style = "auto";
                        } else {
                            $class = "";
                            $in = '';
                            $style = "0 px";
                        }

                    ?>
                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-user  fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Activity Logs</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('adminv3/user_activities') }}" @if(admin_class('user_activities')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">User Activity</span></a></li>

                      <li ><a href="{{ url('adminv3/subadmin_activities') }}" @if(admin_class('subadmin_activities')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Sub Admin Activity</span></a></li>
                       
                      </ul>


                    </li>               

                    <li class="{{admin_class('faq')}}"><a href="{{url('adminv3/manage_faq/1')}}"><i class="fa fa-question-circle fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage FAQ</span></a></li>

                    <?php
                        if (admin_class('mailing_template') != '' || admin_class('announcements') != ""|| admin_class('sms_management') != "") {
                            $class = "active";
                            $in = 'in';
                            $style = "auto";
                        } else {
                            $class = "";
                            $in = '';
                            $style = "0 px";
                        }

                    ?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-envelope  fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Manage Templates</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('adminv3/mailing_template') }}" @if(admin_class('mailing_template')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Manage Email Template</span></a></li>

                      <li ><a href="#" @if(admin_class('partial_orders')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Announcements</span></a></li>
                      <li ><a href="#" @if(admin_class('pending_orders')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">SMS Management</span></a></li>

                     </ul>


                    </li>
                    <li class="{{admin_class('sub_admin_list')}}"><a href="{{url('adminv3/sub_admin_list')}}"><i class="fa fa-file-text fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Sub Admin</span></a></li>

                     <li class="{{admin_class('contact_query')}}"><a href="{{url('adminv3/contact_query_admin/1')}}"><i class="fa fa-phone fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage Enquiry</span></a></li>

                    <li class="{{admin_class('assets')}}"><a href="{{url('adminv3/assets/1')}}"><i class="fa fa-phone fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Assets</span></a></li>

                     <li class="{{admin_class('whitelists')}}"><a href="{{url('adminv3/whitelist')}}"><i class="fa fa-ban fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage IP Whitelists</span></a></li>

                     {{--<li class="{{admin_class('meta_content')}}"><a href="{{url('adminv3/site_meta_content')}}"><i class="fa fa-file-text fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage Meta content</span></a></li>--}}

                    {{--<li class="{{admin_class('erc20_requests')}}"><a href="{{url('adminv3/erc20_requests')}}"><i class="fa fa-file-text fa-fw">--}}
                                {{--<div class="icon-bg bg-orange"></div>--}}
                            {{--</i><span class="menu-title">Manage ERC20 Requests</span></a></li>--}}


                            <?php
                        if (admin_class('user_referral') != '' || admin_class('view_referral_settings') != "") {
                            $class = "active";
                            $in = 'in';
                            $style = "auto";
                        } else {
                            $class = "";
                            $in = '';
                            $style = "0 px";
                        }

                    ?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-envelope  fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Refferals</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('adminv3/user_referral/1') }}" @if(admin_class('user_referral')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">User Referral</span></a></li>
                     <li ><a href="{{ url('adminv3/view_referral_settings') }}" @if(admin_class('view_referral_settings')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">View Referral Settings</span></a></li>
                     <!-- <li ><a href="{{ url('adminv3/referral_extras') }}" @if(admin_class('referral_extras')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Manage Extra Referral Bonus</span></a></li>
                     <li ><a href="{{ url('adminv3/extra_earning') }}" @if(admin_class('extra_earning')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">View Extra Referral Earnings</span></a></li>
                     <li ><a href="{{ url('adminv3/reserve_balances_admin') }}" @if(admin_class('reserve_balances_admin')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Manage Reserve Balances</span></a></li> -->
                    </ul>
                    </li>

                </ul>
            </div>
        </nav>