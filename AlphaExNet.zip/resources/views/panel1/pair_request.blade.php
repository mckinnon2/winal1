@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Pair Request</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Pair Request</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                <!-- <a href="{{url('adminv3/add_pair')}}" class="btn btn-info pull-right">Add Pair</a> -->
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">


                                <div class="row">
                                    <form id="form_filters" method="get">

                                        
                                        <div class="col-md-3">
                                            <lable>Search</lable>
                                            <input type="text" id="search_id" name="search"
                                                   value="{{ app('request')->input('search') }}" class="form-control">
                                        </div>
                                        
                                        
                                        
                                        <div class="col-md-3">
                                            <button style="margin-top: 17px;" class="btn btn-default"><i
                                                        class="fa fa-search"></i></button>
                                            
                                        </div>

                                        {{csrf_field()}}
                                    </form>
                                </div>

                                <div class="table-container">

                                    <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                                           id="myTable">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>ID</th>
                                            <th>Pair Name</th>
                                            <th>Pair Type</th>
                                            <th>First Currency</th>
                                            <th>Second Currency</th>
                                            <th>Trading  On/Off</th>
                                            <th>Action</th>
                                            
                                           
                                        </tr>
                                        <tbody>
                                        @if($result)
                                            @foreach($result as $key => $val)
                                                <tr>
                                                    <td>{{$key+1}}</td>
                                                    <td>{{$val->pairId}}</td>
                                                    <td>{{$val->name}}</td>
                                                    <td>{{$val->type}}</td>
                                                    <td>{{$val->firstCurrency}}</td>
                                                    <td>{{$val->secondCurrency}}</td> 
                                                    <td>
                                                        @if($val->tradingFlag == true )
                                                            <p class="label label-success"><a href=""
                                                                                              id=""
                                                                                              style="color: white"
                                                                                              >On</a>
                                                            </p>
                                                        @else
                                                            <p class="label label-danger"><a href="" id=""
                                                                                             style="color: white"
                                                                                             >Off</a>
                                                            </p>
                                                        @endif
                                                    </td>
                                                    <td>
                                                    <a href="#" onclick="update_flag('{{$val->pairId}}','{{$val->tradingFlag}}')"
                                                            title="status"><i class="fa fa-cog"></i></a>
                                                            
                                                        </td>
                                                                                                      
                                               
                                            @endforeach
                                        @endif
                                        </tbody>
                                    </table>

                                </div>
                                <div class="row">
                                    <div class="col-lg-0">

                                    </div>
                                    <div class="col-lg-6 text-left">
                                        <div class="pagination-panel">
                                            <ul class="pagination">

                                            <li><input class="form-controlp" type="number" id="pagesearch">&nbsp;{{$pagination->lastPage}}&nbsp;<button style="margin-top: -3px;width:50px;height:41px;" class="btn btn-default" onclick="searchpage()"><i
                                                                class="fa fa-search"></i></button></li>
                                            <li><p style='color:red; display:none;'id='error_message'>Page Number should be between 0 to {{$pagination->lastPage}}</p></li>
                                            </ul>
                                        
                                        </div>
                                    </div>
                                        <div class="col-lg-6">

                                        </div>
                                        <div class="col-lg-6 text-right">
                                        <div class="pagination-panel">
                                        @include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/trade_mappings')])

                                        </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



@endsection

@section('script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
         $(document).ready(function(){
            $('#myTable').DataTable({
                "searching": false,
                "paging":   false,
                "ordering": true,
                "info":     false,
                // "lengthChange": false,
                // "pageLength" : 25
            });
        });
        function searchpage(){
            var input = document.getElementById("pagesearch").value;
            var x = document.getElementById("error_message");
            var url1 = window.location.search;
            if(input>=1 && input<={{$pagination->lastPage}}){
                window.location.href = "/adminv3/trade_mappings/"+input+url1;
                x.style.display = "none";
            }
            else{
                x.style.display = "block";
            }
            
        }
    </script>
<script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script type="text/javascript">

        // function user_verified(user_id) {
        //     $.get("{{url('ajax/user_verification')}}/" + user_id, function (data) {
        //         if (data == 1) {
        //             document.location.reload();
        //         }
        //     });
        // }

        // function auto_withdrawal(user_id) {
        //     $.get("{{url('ajax/auto_withdrawal')}}/" + user_id, function (data) {
        //         if (data == 1) {
        //             document.location.reload();
        //         }
        //     });
        // }
        
        function update_flag(pairId,tradingFlag)
        {
           
            $.ajax({
                url:'{{url('adminv3/trading_status/')}}',
                method:'post',
                data:{'pair_id':pairId, 'tradingFlag':tradingFlag},
               
            }).done(function(data){
                location.reload();
            });
        }
    </script>

    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <!-- <script src="{{URL::asset('datepicker/jquery-1.12.4.js')}}"></script> -->
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    
@endsection
