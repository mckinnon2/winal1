@extends("panel1.layout.admin_new_layout")
@section("content")

        <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                <div class="page-header pull-left">
                    <div class="page-title">Sub-Admin</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

                    <li class="active">Sub-Admin</li>
                </ol>
                <div class="clearfix"></div>
            </div>


            <div class="col-md-12 clearfix">
                @include('panel1.alert')
              <!-- <button class="btn btn-danger pull-right" id="confirm" data-toggle="modal" data-target="#myModal">Update FAQ?</button> -->
            </div>

            <div class="page-content">
                <div class="row">
                    <div class="col-md-12">




                        <div id="tableactionTabContent" class="tab-content">
                        <a href="{{url('adminv3/sub_admin')}}" class="btn btn-info pull-right">Add Sub-Admin</a>
                             <div id="table-table-tab" class="tab-pane fade in active">
                                <div class="row">
                                    <div class="col-lg-12">

                                        <div class="table-container">

                                            <table class="table table-hover table-striped table-bordered table-advanced tablesorter" id="myTable">
                                                <thead>
                                               <tr>
                                                <th>#</th>
                                                <th>Role Name</th>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Email</th>
                                                <th>Updated at</th>
                                               </tr>
                                                <tbody>
                                                
                                                @if($result)
                                                @foreach($result as $key => $val)
                                                        <tr>
                                                            <td>{{$key+1}}</td>
                                                            <td>{{$val->name}}</td>
                                                            <td>{{$val->firstName}}</td>
                                                            <td>{{$val->lastName}}</td>
                                                            <td>{{$val->email}}</td>
                                                            <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                                        </tr>
                                                @endforeach
                                                @endif
                                                </tbody>
                                                </thead></table>

                                        </div>



                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                                    <div class="col-lg-6">

                                    </div>
                                    {{--<div class="col-lg-6 text-right">--}}
                                    {{--<div class="pagination-panel">--}}
                                        {{--@include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/trade_orders')])--}}

                                            {{--</div>--}}
                                                {{--</div>--}}
                        </div>

                    </div>
                </div>
            </div>

            
        </div>
@endsection

@section('script')
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
            $('#myTable').DataTable({
                "searching": false,
                "paging":   false,
                "ordering": true,
                "info":     false,
                "lengthChange": false,
                "pageLength" : 25
            });
        });
</script>




@endsection
