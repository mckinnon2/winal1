@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Dashboard</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><a href="#" onclick="update_stats()"> <i class="fa fa-refresh"></i>&nbsp;&nbsp; Refresh
                    Balance</a> &nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>
            <li class="hidden"><a href="#">Dashboard</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
            <li class="active">Dashboard</li>
        </ol>
        <div class="clearfix"></div>
    </div>
    <div class="page-content">
        <div id="tab-general">
            @include('panel1.alert')
            <div id="sum_box" class="row mbl">
                <div class="col-sm-6 col-md-3">
                    <div class="panel profit db mbm" onclick="window.location.href='{{url('adminv3/user_list/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-group"></i></p><h4 class="value">

                                @if($currencies['dashboard'])
                                    <span data-counter="" data-start="10" data-end="50" data-step="1" data-duration="0"> 
                                    {{$currencies['dashboard']->result->userCount}}
                                                </span></h4>
                            @endif


                            <p class="description">Registered Users</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel income db mbm" onclick="window.location.href='{{url('adminv3/trade_orders/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-exchange"></i></p><h4>
                                @if($currencies['dashboard'])
                                    <span>
                                    {{$currencies['dashboard']->result->totalTrade}}
                                                </span></h4>
                            @endif

                            <p class="description">Total Transactions</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel task db mbm" onclick="window.location.href='{{url('adminv3/admin_kyc_users/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-signal"></i></p><h4 class="value">
                                <span>{{number_format(dashbard_totalbtcprofit(),4,'.','')}}</span><span><i
                                            class="fa fa-btc"></i></span></h4>

                            <p class="description">Profit</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel visit db mbm"
                         onclick="window.location.href='{{url('adminv3/admin_kyc_users/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-group"></i></p><h4 class="value">
                                @if($currencies['dashboard'])
                                    <span>
                                    {{$currencies['dashboard']->result->kycTotal}}
                                                </span></h4>
                            @endif

                            <p class="description">KYC verification</p>


                        </div>
                    </div>
                </div>


            </div>
            <div>
                <h2>&nbsp;&nbsp;Admin Balance:</h2>
                <br>
            </div>
            <div class="table-container" style="overflow-x:auto;">


                <table class="table table-hover table-bordered table-advanced tablesorter"
                       id="myTable">
                    <thead>
                    <tr>
                        <th style="background-color:white;"></th>
                        <th colspan="7" style="text-align:center!important;background-color:white;">Admin</th>
                        <th colspan="4" style="text-align:center!important;background-color:white;">Users</th>
                        <th colspan="0" style="text-align:center!important;background-color:white;">Difference</th>
                    </tr>
                    <tr>
                        <th>Currency</th>
                        <th>AlphaEx</th>
                        <th>AlphaEx Auto</th>
                        <th>BitFinex</th>
                        <th>Indodax</th>
                        <th>Liquid</th>
                        <th>Reserve</th>
                        <th>Total</th>
                        <th>Users</th>
                        <th>In Trade</th>
                        <th>Profit</th>
                        <th>Total</th>
                        <th>Difference</th>

                    </tr>
                    </thead>
                    <tbody>
                    <tr id="xdc_div">
                        <td onclick="window.open('https://explorer.xinfin.network/addr/xdc2642835a88a0b307ba6b52b7b23876210a03812c','newtab');">
                            M-XDC
                        </td>
                        <td id="xdc_bal">0</td>
                        <td id="xdc_auto_bal">0</td>
                        <td id="xdc_bit">0</td>
                        <td id="xdc_indo">0</td>
                        <td id="xdc_lqd">0</td>
                        <td id="xdc_reserve">0</td>
                        <td id="xdc_tot">0</td>
                        <td id="user_m_xdc">0</td>
                        <td id="intrade_m_xdc">0</td>
                        <td id="profit_m_xdc">0</td>
                        <td id="total_m_xdc">0</td>
                        <td id="diff_m_xdc">0</td>

                    </tr>
                    <tr id="m_xdc_div"
                    >
                        <td onclick="window.open('http://xinfin.info/account/0xb2b5b54b736e59b2a60aaf3bcc8109397562f769','newtab');">
                            XDC
                        </td>
                        <td id="m_xdc_bal">731362343.53</td>
                        <td id="m_xdc_auto_bal">0</td>
                        <td id="m_xdc_bit">0</td>
                        <td id="m_xdc_indo">0</td>
                        <td id="m_xdc_lqd">0</td>
                        <td id="m_xdc_reserve">0</td>
                        <td id="m_xdc_tot">731362343.53</td>
                        <td id="user_xdc">0</td>
                        <td id="intrade_xdc">0</td>
                        <td id="profit_xdc">0</td>
                        <td id="total_xdc">0</td>
                        <td id="diff_xdc">0</td>

                    </tr>
                    <tr id="xdce_div"
                    >
                        <td onclick="window.open('https://etherscan.io/token/0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                            XDCE
                        </td>
                        <td id="xdce_bal">0</td>
                        <td id="xdce_auto_bal">0</td>
                        <td id="xdce_bit">0</td>
                        <td id="xdce_indo">0</td>
                        <td id="xdce_lqd">0</td>
                        <td id="xdce_reserve">0</td>
                        <td id="xdce_tot">0</td>
                        <td id="user_xdce">0</td>
                        <td id="intrade_xdce">0</td>
                        <td id="profit_xdce">0</td>
                        <td id="total_xdce">0</td>
                        <td id="diff_xdce">0</td>

                    </tr>
                    <tr id="eth_div"
                    >
                        <td onclick="window.open('https://etherscan.io/address/0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                            ETH
                        </td>
                        <td id="eth_bal">0</td>
                        <td id="eth_auto_bal">0</td>
                        <td id="eth_bit">0</td>
                        <td id="eth_indo">0</td>
                        <td id="eth_lqd">0</td>
                        <td id="eth_reserve">0</td>
                        <td id="eth_tot">0</td>
                        <td id="user_eth">0</td>
                        <td id="intrade_eth">0</td>
                        <td id="profit_eth">0</td>
                        <td id="total_eth">0</td>
                        <td id="diff_eth">0</td>
                    </tr>
                    <tr id="btc_div"
                    >
                        <td onclick="window.open('https://www.blockchain.com/btc/address/3M4n1daBJZ34n5g6eBYmoCZAbJPSXDM5LG','newtab');">
                            BTC
                        </td>
                        <td id="btc_bal">0</td>
                        <td id="btc_auto_bal">0</td>
                        <td id="btc_bit">0</td>
                        <td id="btc_indo">0</td>
                        <td id="btc_lqd">0</td>
                        <td id="btc_reserve">0</td>
                        <td id="btc_tot">0</td>
                        <td id="user_btc">0</td>
                        <td id="intrade_btc">0</td>
                        <td id="profit_btc">0</td>
                        <td id="total_btc">0</td>
                        <td id="diff_btc">0</td>
                    </tr>
                    <tr id="bchabc_div"
                    >
                        <td onclick="window.open('https://explorer.bitcoin.com/bch/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">
                            BCHABC
                        </td>
                        <td id="bchabc_bal">0</td>
                        <td id="bchabc_auto_bal">0</td>
                        <td id="bchabc_bit">0</td>
                        <td id="bchabc_indo">0</td>
                        <td id="bchabc_lqd">0</td>
                        <td id="bchabc_reserve">0</td>
                        <td id="bchabc_tot">0</td>
                        <td id="user_bchabc">0</td>
                        <td id="intrade_bchabc">0</td>
                        <td id="profit_bchabc">0</td>
                        <td id="total_bchabc">0</td>
                        <td id="diff_bchabc">0</td>
                    </tr>
                    <tr id="bchsv_div"
                    >
                        <td onclick="window.open('https://bsvexplorer.info/#/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">
                            BCHSV
                        </td>
                        <td id="bchsv_bal">0</td>
                        <td id="bchsv_auto_bal">0</td>
                        <td id="bchsv_bit">0</td>
                        <td id="bchsv_indo">0</td>
                        <td id="bchsv_lqd">0</td>
                        <td id="bchsv_reserve">0</td>
                        <td id="bchsv_tot">0</td>
                        <td id="user_bchsv">0</td>
                        <td id="intrade_bchsv">0</td>
                        <td id="profit_bchsv">0</td>
                        <td id="total_bchsv">0</td>
                        <td id="diff_bchsv">0</td>
                    </tr>
                    <tr id="xrp_div"
                    >
                        <td onclick="window.open('https://bithomp.com/explorer/r3i9zk9WGNWKsp8qoPyuxDNapJm8qqK3Bj','newtab');">
                            XRP
                        </td>
                        <td id="xrp_bal">0</td>
                        <td id="xrp_auto_bal">0</td>
                        <td id="xrp_bit">0</td>
                        <td id="xrp_indo">0</td>
                        <td id="xrp_lqd">0</td>
                        <td id="xrp_reserve">0</td>
                        <td id="xrp_tot">0</td>
                        <td id="user_xrp">0</td>
                        <td id="intrade_xrp">0</td>
                        <td id="profit_xrp">0</td>
                        <td id="total_xrp">0</td>
                        <td id="diff_xrp">0</td>
                    </tr>
                    <tr id="usdt_div"
                    >
                        <td onclick="window.open('https://www.omniexplorer.info/address/13btDig1JPAbnmbUnDsBwZJXybnuheCixG','newtab');">
                            USDT
                        </td>
                        <td id="usdt_bal">0</td>
                        <td id="usdt_auto_bal">0</td>
                        <td id="usdt_bit">0</td>
                        <td id="usdt_indo">0</td>
                        <td id="usdt_lqd">0</td>
                        <td id="usdt_reserve">0</td>
                        <td id="usdt_tot">0</td>
                        <td id="user_usdt">0</td>
                        <td id="intrade_usdt">0</td>
                        <td id="profit_usdt">0</td>
                        <td id="total_usdt">0</td>
                        <td id="diff_usdt">0</td>
                    </tr>
                    <tr id="usdc_div"
                    >
                        <td onclick="window.open('https://etherscan.io/token/0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                            USDC
                        </td>
                        <td id="usdc_bal">0</td>
                        <td id="usdc_auto_bal">0</td>
                        <td id="usdc_bit">0</td>
                        <td id="usdc_indo">0</td>
                        <td id="usdc_lqd">0</td>
                        <td id="usdc_reserve">0</td>
                        <td id="usdc_tot">0</td>
                        <td id="user_usdc">0</td>
                        <td id="intrade_usdc">0</td>
                        <td id="profit_usdc">0</td>
                        <td id="total_usdc">0</td>
                        <td id="diff_usdc">0</td>
                    </tr>


                </table>
            </div>
            <div class="table-container" style="overflow-x:auto;">

                <div>
                    <h2>&nbsp;&nbsp;Latest 25 Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                       id="myTable">
                    <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Email</th>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Recieved Total</th>
                        <th>Type</th>
                        <th>Pair</th>
                        <th>Status</th>
                        <th>Updated time</th>

                    </tr>
                    <tbody>
                    @if($currencies['dashboard'])
                        @foreach($currencies['dashboard']->result->latest25 as $trades =>$trade)

                            <tr>
                                <td width="20%">{{$trade->orderId}}</td>
                                <td>{{$trade->email}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$trade->filledQty),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f', $trade->price), '0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f', $trade->fee), '0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$trade->total),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$trade->receivedTotal),'0'),'.')}}</td>
                                <td>{{$trade->type}}</td>
                                <td>{{$trade->pairName}}</td>
                                {{--<td>{{$trade->status}}</td>--}}
                                @if($trade->status == "completed")
                                    <td>CMPLT</td>
                                @elseif($trade->status == "cancelled")
                                    <td>CXL</td>
                                @elseif($trade->status == "partially")
                                    <td>PRTL</td>
                                @elseif($trade->status == 'active')
                                    <td>PNDG</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($trade->updatedAt))}}</td>
                            </tr>

                        @endforeach
                    @endif
                    </tbody>
                    </thead>
                </table>
            </div>
        </div>
    </div>
@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    {{--@include('panel1.layout.dashboard_script')--}}
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">

        //raj's code

        $(document).ready(function () {
            $('#myTable').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false
            });

            $('#xdc_bal').text('Loading');
            $('#m_xdc_bal').text('Loading');
            $('#xdce_bal').text('Loading');
            $('#eth_bal').text('Loading');
            $('#btc_bal').text('Loading');
            $('#bchabc_bal').text('Loading');
            $('#bchsv_bal').text('Loading');
            $('#usdc_bal').text('Loading');
            $('#usdt_bal').text('Loading');
            $('#xrp_bal').text('Loading');

            update_user_balance();
            update_admin_balance();
            update_admin_status();

            setInterval(function () {
                update_user_balance();
                update_admin_balance();
                update_admin_status();
            }, 300000);

        });

        function update_stats() {
            update_user_balance();
            update_admin_balance();
            update_admin_status();
        }

        function update_user_balance() {
                    @foreach($currencies_new as $currency)
            var curr = '{{$currency->currency_symbol}}';
            $.ajax({
                url: '/ajax/user_bal',
                method: 'get',
                data: {'curr': curr},
                success: function (data) {
                    data = JSON.parse(data);
                    var curr_bal = data.bal;
                    var intrade_curr_bal = data.intrade_curr_bal;
                    var profit = data.profit;
                    var curr_total = parseFloat(parseFloat(curr_bal) + parseFloat(intrade_curr_bal) + parseFloat(profit)).toFixed(4);
                    var curr = data.currency.toLowerCase();

                    $('#user_' + curr).text(curr_bal);
                    $('#intrade_' + curr).text(intrade_curr_bal);
                    $('#profit_' + curr).text(profit);
                    $('#total_' + curr).text(curr_total);
                }
            });
            @endforeach
            $.ajax({
                url: '/ajax/user_bal',
                method: 'get',
                data: {'curr': 'M-XDC'},
                success: function (data) {
                    data = JSON.parse(data);
                    var curr_bal = data.bal;
                    var intrade_curr_bal = data.intrade_curr_bal;
                    var profit = data.profit;
                    var curr_total = parseFloat(parseFloat(curr_bal) + parseFloat(intrade_curr_bal) + parseFloat(profit)).toFixed(4);

                    $('#user_m_xdc').text(curr_bal);
                    $('#intrade_m_xdc').text(intrade_curr_bal);
                    $('#profit_m_xdc').text(profit);
                    $('#total_m_xdc').text(curr_total);
                }
            });
        }

        function update_admin_balance() {
                    @foreach($currencies_new as $currency)
            var curr = '{{$currency->currency_symbol}}';
            $('#' + curr.toLowerCase() + '_bal').text('Refreshing');
            $.ajax({
                url: '/ajax/admin_bal',
                method: 'get',
                data: {'curr': curr},
                success: function (data) {
                    data = JSON.parse(data);
                    var bal = data.bal;
                    var auto_bal = data.auto_bal;
                    var reserve = data.reserve;
                    var bitfinex = data.bitfinex;
                    var indodax = data.indodax;
                    var liquid = data.liquid;
                    var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(4);
                    curr = data.currency;
                    $('#' + curr.toLowerCase() + '_bal').text(bal);
                    $('#' + curr.toLowerCase() + '_auto_bal').text(auto_bal);
                    $('#' + curr.toLowerCase() + '_bit').text(bitfinex);
                    $('#' + curr.toLowerCase() + '_indo').text(indodax);
                    $('#' + curr.toLowerCase() + '_lqd').text(liquid);
                    $('#' + curr.toLowerCase() + '_reserve').text(reserve);
                    $('#' + curr.toLowerCase() + '_tot').text(tot);
                }
            });
            @endforeach
            $('#m_xdc_bal').text('Refreshing');
            $.ajax({
                url: '/ajax/admin_bal',
                method: 'get',
                data: {'curr': 'M-XDC'},
                success: function (data) {
                    data = JSON.parse(data);
                    var bal = data.bal;
                    var auto_bal = data.auto_bal;
                    var reserve = data.reserve;
                    var bitfinex = data.bitfinex;
                    var indodax = data.indodax;
                    var liquid = data.liquid;
                    var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(4);
                    $('#m_xdc_bal').text(bal);
                    $('#m_xdc_auto_bal').text(auto_bal);
                    $('#m_xdc_bit').text(bitfinex);
                    $('#m_xdc_indo').text(indodax);
                    $('#m_xdc_lqd').text(liquid);
                    $('#m_xdc_reserve').text(reserve);
                    $('#m_xdc_tot').text(tot);
                }
            });
        }

        function update_admin_status() {
                    @foreach($currencies_new as $currency)
            var curr = '{{$currency->currency_symbol}}';
            $.ajax({
                url: '/ajax/admin_status',
                method: 'get',
                data: {'curr': curr},
                success: function (data) {
                    data = JSON.parse(data);
                    var status = data.status;
                    var diff = data.diff;
                    curr = data.currency;
                    $('#' + 'diff_' + curr.toLowerCase()).text(diff);
                    if (status == '1') {
                        $('#' + curr.toLowerCase() + '_div').css('background-color', '#90EE90');
                    }
                    else {
                        $('#' + curr.toLowerCase() + '_div').css('background-color', '#ff9999');
                    }
                }
            });
            @endforeach
            $.ajax({
                url: '/ajax/admin_status',
                method: 'get',
                data: {'curr': 'M-XDC'},
                success: function (data) {
                    data = JSON.parse(data);
                    var status = data.status;
                    var diff = data.diff;
                    $('#diff_m_xdc').text(diff);
                    if (status == '1') {
                        $('#m_xdc_div').css('background-color', '#90EE90');
                    } else {
                        $('#m_xdc_div').css('background-color', '#ff9999');
                    }
                }
            });
        }


        //mansi's code

        // $(document).ready(function () {
        //     $('#myTable').DataTable({
        //         "searching": false,
        //         "paging": false,
        //         "ordering": false,
        //         "info": false
        //     });
        //
        //     // update_user_balances();
        //     // update_admin_balances();
        //     // update_admin_status();
        //     // update_differences();
        //
        // });

        {{--function update_user_balances() {--}}
        {{--@if($currencies['balance'])--}}
        {{--@foreach($currencies['balance']->result as $dash )--}}

        {{--var currry = '{{$dash->currency}}';--}}
        {{--if (currry == "BTC") {--}}
        {{--var curr = parseFloat({{$dash->userBalance}}).toFixed(4);--}}
        {{--var intrade_curr_bal = parseFloat({{$dash->inOrder}}).toFixed(4);--}}
        {{--var profit = parseFloat({{$dash->profit}}).toFixed(4);--}}
        {{--var curr_totall = parseFloat({{$dash->total}}).toFixed(4);--}}
        {{--// console.log(">>>",curr,currry);--}}
        {{--var curr_bal = curr;--}}
        {{--var intrade_curr_bal = intrade_curr_bal;--}}
        {{--var curr_total = parseFloat(parseFloat(curr_totall) + parseFloat(profit)).toFixed(4);--}}


        {{--$('#user_' + currry.toLowerCase()).text(curr_bal);--}}
        {{--$('#intrade_' + currry.toLowerCase()).text(intrade_curr_bal);--}}
        {{--$('#profit_' + currry.toLowerCase()).text(profit);--}}
        {{--$('#total_' + currry.toLowerCase()).text(curr_total);--}}
        {{--}--}}
        {{--else {--}}
        {{--var curr = parseFloat({{$dash->userBalance}}).toFixed(2);--}}
        {{--var intrade_curr_bal = parseFloat({{$dash->inOrder}}).toFixed(2);--}}
        {{--var profit = parseFloat({{$dash->profit}}).toFixed(2);--}}
        {{--var curr_totall = parseFloat({{$dash->total}}).toFixed(2);--}}
        {{--// console.log(">>>",curr,currry);--}}
        {{--var curr_bal = curr;--}}
        {{--var intrade_curr_bal = intrade_curr_bal;--}}
        {{--var curr_total = parseFloat(parseFloat(curr_totall) + parseFloat(profit)).toFixed(2);--}}


        {{--$('#user_' + currry.toLowerCase()).text(curr_bal);--}}
        {{--$('#intrade_' + currry.toLowerCase()).text(intrade_curr_bal);--}}
        {{--$('#profit_' + currry.toLowerCase()).text(profit);--}}
        {{--$('#total_' + currry.toLowerCase()).text(curr_total);--}}
        {{--if (currry == 'XDC') {--}}
        {{--// console.log("M-XDC",curr_bal);--}}
        {{--$('#user_m_xdc').text(curr_bal);--}}
        {{--$('#intrade_m_xdc').text(intrade_curr_bal);--}}
        {{--$('#profit_m_xdc').text(profit);--}}
        {{--$('#total_m_xdc').text(curr_total);--}}
        {{--}--}}
        {{--}--}}

        {{--@endforeach--}}
        {{--@endif--}}

        {{--}--}}

        {{--function update_admin_balances() {--}}
        {{--@foreach($currencies['balance']->result as $currency)--}}
        {{--var curr = '{{$currency->currency}}';--}}
        {{--if (curr == "BTC") {--}}
        {{--var bal = parseFloat({{$currency->normal}}).toFixed(4);--}}
        {{--var auto_bal = parseFloat({{$currency->auto}}).toFixed(4);--}}
        {{--var reserve = parseFloat({{$currency->reserve}}).toFixed(4);--}}
        {{--var bitfinex = parseFloat({{$currency->bitfinex}}).toFixed(4);--}}
        {{--var indodax = parseFloat({{$currency->indodax}}).toFixed(4);--}}
        {{--var liquid = parseFloat({{$currency->liquid}}).toFixed(4);--}}
        {{--// var reserve = data.reserve;--}}
        {{--// var bitfinex = data.bitfinex;--}}
        {{--// var indodax = data.indodax;--}}
        {{--// var liquid = data.liquid;--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(4);--}}

        {{--$('#' + curr.toLowerCase() + '_bal').text(bal);--}}
        {{--$('#' + curr.toLowerCase() + '_auto_bal').text(auto_bal);--}}
        {{--$('#' + curr.toLowerCase() + '_bit').text(bitfinex);--}}
        {{--$('#' + curr.toLowerCase() + '_indo').text(indodax);--}}
        {{--$('#' + curr.toLowerCase() + '_lqd').text(liquid);--}}
        {{--$('#' + curr.toLowerCase() + '_reserve').text(reserve);--}}
        {{--$('#' + curr.toLowerCase() + '_tot').text(tot);--}}

        {{--}--}}
        {{--else {--}}
        {{--var bal = parseFloat({{$currency->normal}}).toFixed(2);--}}
        {{--var auto_bal = parseFloat({{$currency->auto}}).toFixed(2);--}}
        {{--var reserve = parseFloat({{$currency->reserve}}).toFixed(2);--}}
        {{--var bitfinex = parseFloat({{$currency->bitfinex}}).toFixed(2);--}}
        {{--var indodax = parseFloat({{$currency->indodax}}).toFixed(2);--}}
        {{--var liquid = parseFloat({{$currency->liquid}}).toFixed(2);--}}
        {{--// var reserve = data.reserve;--}}
        {{--// var bitfinex = data.bitfinex;--}}
        {{--// var indodax = data.indodax;--}}
        {{--// var liquid = data.liquid;--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(2);--}}

        {{--$('#' + curr.toLowerCase() + '_bal').text(bal);--}}
        {{--$('#' + curr.toLowerCase() + '_auto_bal').text(auto_bal);--}}
        {{--$('#' + curr.toLowerCase() + '_bit').text(bitfinex);--}}
        {{--$('#' + curr.toLowerCase() + '_indo').text(indodax);--}}
        {{--$('#' + curr.toLowerCase() + '_lqd').text(liquid);--}}
        {{--$('#' + curr.toLowerCase() + '_reserve').text(reserve);--}}
        {{--$('#' + curr.toLowerCase() + '_tot').text(tot);--}}
        {{--}--}}

        {{--@endforeach--}}

        {{--}--}}

        {{--function update_differences() {--}}
        {{--// console.log("$currencies");--}}
        {{--@foreach($currencies['balance']->result as $currency)--}}
        {{--var curr = '{{$currency->currency}}';--}}
        {{--if (curr == "BTC") {--}}
        {{--var bal = parseFloat({{$currency->normal}}).toFixed(4);--}}
        {{--var auto_bal = parseFloat({{$currency->auto}}).toFixed(4);--}}
        {{--var reserve = parseFloat({{$currency->reserve}}).toFixed(4);--}}
        {{--var bitfinex = parseFloat({{$currency->bitfinex}}).toFixed(4);--}}
        {{--var indodax = parseFloat({{$currency->indodax}}).toFixed(4);--}}
        {{--var liquid = parseFloat({{$currency->liquid}}).toFixed(4);--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(4);--}}
        {{--var user_tot = parseFloat(parseFloat({{$currency->total}}) + parseFloat({{$currency->profit}})).toFixed(4)--}}
        {{--var diff = parseFloat(parseFloat(tot) - parseFloat(user_tot)).toFixed(4);--}}
        {{--$('#' + 'diff_' + curr.toLowerCase()).text(diff);--}}
        {{--}--}}
        {{--else {--}}
        {{--if (curr == "XDC" || curr == "XDCE") {--}}
        {{--var tot = parseFloat(parseFloat({{$tot_xdc}}) + parseFloat({{$tot_xdce}})).toFixed(2);--}}
        {{--var admin_tot = parseFloat(parseFloat({{$admin_tot_xdc}}) + parseFloat({{$admin_tot_xdce}}) + parseFloat(731362343.53)).toFixed(2)--}}
        {{--var diff = parseFloat(parseFloat(admin_tot) - parseFloat(tot)).toFixed(2);--}}
        {{--$('#' + 'diff_' + curr.toLowerCase()).text(diff);--}}
        {{--// $('#' + 'diff_xdc').text(diff);--}}
        {{--$('#' + 'diff_m_xdc').text(diff);--}}
        {{--// console.log("DDDD",curr,{{$tot_xdc}},{{$tot_xdce}},{{$admin_tot_xdc}},{{$admin_tot_xdce}},diff);--}}

        {{--}--}}
        {{--else {--}}
        {{--var bal = parseFloat({{$currency->normal}}).toFixed(2);--}}
        {{--var auto_bal = parseFloat({{$currency->auto}}).toFixed(2);--}}
        {{--var reserve = parseFloat({{$currency->reserve}}).toFixed(2);--}}
        {{--var bitfinex = parseFloat({{$currency->bitfinex}}).toFixed(2);--}}
        {{--var indodax = parseFloat({{$currency->indodax}}).toFixed(2);--}}
        {{--var liquid = parseFloat({{$currency->liquid}}).toFixed(2);--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(2);--}}
        {{--var user_tot = parseFloat(parseFloat({{$currency->total}}) + parseFloat({{$currency->profit}})).toFixed(4)--}}
        {{--var diff = parseFloat(parseFloat(tot) - parseFloat(user_tot)).toFixed(2);--}}
        {{--$('#' + 'diff_' + curr.toLowerCase()).text(diff);--}}
        {{--}--}}

        {{--}--}}
        {{--@endforeach--}}


        {{--}--}}

        {{--function update_user_balance() {--}}
        {{--$.ajax({--}}
        {{--url: '{{url('adminv3/dashboard')}}',--}}
        {{--method: 'get',--}}
        {{--data: {},--}}
        {{--success: function (data) {--}}
        {{--const _data = data.currencies['balance'].result;--}}
        {{--Object.keys(_data).map((index, key) => {--}}
        {{--var dash = _data[index];--}}
        {{--var currry = dash.currency;--}}
        {{--if (currry == "BTC") {--}}
        {{--var curr = parseFloat(dash.userBalance).toFixed(4);--}}
        {{--var intrade_curr_bal = parseFloat(dash.inOrder).toFixed(4);--}}
        {{--var profit = parseFloat(dash.profit).toFixed(4);--}}
        {{--var curr_totall = parseFloat(dash.total).toFixed(4);--}}
        {{--// console.log(">>>",curr,currry);--}}
        {{--var curr_bal = curr;--}}
        {{--var intrade_curr_bal = intrade_curr_bal;--}}
        {{--var curr_total = parseFloat(parseFloat(curr_totall) + parseFloat(profit)).toFixed(4);--}}


        {{--$('#user_' + currry.toLowerCase()).text(curr_bal);--}}
        {{--$('#intrade_' + currry.toLowerCase()).text(intrade_curr_bal);--}}
        {{--$('#profit_' + currry.toLowerCase()).text(profit);--}}
        {{--$('#total_' + currry.toLowerCase()).text(curr_total);--}}
        {{--}--}}
        {{--else {--}}
        {{--var curr = parseFloat(dash.userBalance).toFixed(2);--}}
        {{--var intrade_curr_bal = parseFloat(dash.inOrder).toFixed(2);--}}
        {{--var profit = parseFloat(dash.profit).toFixed(2);--}}
        {{--var curr_totall = parseFloat(dash.total).toFixed(2);--}}
        {{--// console.log(">>>",curr,currry);--}}
        {{--var curr_bal = curr;--}}
        {{--var intrade_curr_bal = intrade_curr_bal;--}}
        {{--var curr_total = parseFloat(parseFloat(curr_totall) + parseFloat(profit)).toFixed(2);--}}


        {{--$('#user_' + currry.toLowerCase()).text(curr_bal);--}}
        {{--$('#intrade_' + currry.toLowerCase()).text(intrade_curr_bal);--}}
        {{--$('#profit_' + currry.toLowerCase()).text(profit);--}}
        {{--$('#total_' + currry.toLowerCase()).text(curr_total);--}}
        {{--if (currry == 'XDC') {--}}
        {{--// console.log("M-XDC",curr_bal);--}}
        {{--$('#user_m_xdc').text(curr_bal);--}}
        {{--$('#intrade_m_xdc').text(intrade_curr_bal);--}}
        {{--$('#profit_m_xdc').text(profit);--}}
        {{--$('#total_m_xdc').text(curr_total);--}}
        {{--}--}}
        {{--}--}}
        {{--});--}}

        {{--}--}}
        {{--});--}}

        {{--}--}}

        {{--function update_admin_balance() {--}}
        {{--$.ajax({--}}
        {{--url: '{{url('adminv3/dashboard')}}',--}}
        {{--method: 'get',--}}
        {{--data: {},--}}
        {{--success: function (data) {--}}
        {{--const _data = data.currencies['balance'].result;--}}
        {{--Object.keys(_data).map((index, key) => {--}}
        {{--var dash = _data[index];--}}
        {{--var curr = dash.currency;--}}
        {{--if (curr == "BTC") {--}}
        {{--var bal = parseFloat(dash.normal).toFixed(4);--}}
        {{--var auto_bal = parseFloat(dash.auto).toFixed(4);--}}
        {{--var reserve = parseFloat(dash.reserve).toFixed(4);--}}
        {{--var bitfinex = parseFloat(dash.bitfinex).toFixed(4);--}}
        {{--var indodax = parseFloat(dash.indodax).toFixed(4);--}}
        {{--var liquid = parseFloat(dash.liquid).toFixed(4);--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(4);--}}

        {{--$('#' + curr.toLowerCase() + '_bal').text(bal);--}}
        {{--$('#' + curr.toLowerCase() + '_auto_bal').text(auto_bal);--}}
        {{--$('#' + curr.toLowerCase() + '_bit').text(bitfinex);--}}
        {{--$('#' + curr.toLowerCase() + '_indo').text(indodax);--}}
        {{--$('#' + curr.toLowerCase() + '_lqd').text(liquid);--}}
        {{--$('#' + curr.toLowerCase() + '_reserve').text(reserve);--}}
        {{--$('#' + curr.toLowerCase() + '_tot').text(tot);--}}
        {{--}--}}
        {{--else {--}}
        {{--// $('#' + curr.toLowerCase() + '_bal').text('Refreshing');--}}
        {{--var bal = parseFloat(dash.normal).toFixed(2);--}}
        {{--var auto_bal = parseFloat(dash.auto).toFixed(2);--}}
        {{--var reserve = parseFloat(dash.reserve).toFixed(2);--}}
        {{--var bitfinex = parseFloat(dash.bitfinex).toFixed(2);--}}
        {{--var indodax = parseFloat(dash.indodax).toFixed(2);--}}
        {{--var liquid = parseFloat(dash.liquid).toFixed(2);--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(2);--}}

        {{--$('#' + curr.toLowerCase() + '_bal').text(bal);--}}
        {{--$('#' + curr.toLowerCase() + '_auto_bal').text(auto_bal);--}}
        {{--$('#' + curr.toLowerCase() + '_bit').text(bitfinex);--}}
        {{--$('#' + curr.toLowerCase() + '_indo').text(indodax);--}}
        {{--$('#' + curr.toLowerCase() + '_lqd').text(liquid);--}}
        {{--$('#' + curr.toLowerCase() + '_reserve').text(reserve);--}}
        {{--$('#' + curr.toLowerCase() + '_tot').text(tot);--}}
        {{--}--}}
        {{--});--}}
        {{--}--}}
        {{--});--}}

        {{--}--}}

        {{--function update_difference() {--}}
        {{--//    console.log("$currencies");--}}
        {{--$.ajax({--}}
        {{--url: '{{url('adminv3/dashboard')}}',--}}
        {{--method: 'get',--}}
        {{--data: {},--}}
        {{--success: function (data) {--}}
        {{--const _data = data.currencies['balance'].result;--}}
        {{--Object.keys(_data).map((index, key) => {--}}
        {{--var dash = _data[index];--}}
        {{--var curr = dash.currency;--}}
        {{--// console.log(">>>",curr);--}}
        {{--if (curr == "BTC") {--}}
        {{--var bal = parseFloat(dash.normal).toFixed(4);--}}
        {{--var auto_bal = parseFloat(dash.auto).toFixed(4);--}}
        {{--var reserve = parseFloat(dash.reserve).toFixed(4);--}}
        {{--var bitfinex = parseFloat(dash.bitfinex).toFixed(4);--}}
        {{--var indodax = parseFloat(dash.indodax).toFixed(4);--}}
        {{--var liquid = parseFloat(dash.liquid).toFixed(4);--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(4);--}}
        {{--var user_tot = parseFloat(parseFloat(dash.total) + parseFloat(dash.profit)).toFixed(4)--}}
        {{--var diff = parseFloat(parseFloat(tot) - parseFloat(user_tot)).toFixed(4);--}}
        {{--// console.log(">>>",diff);--}}
        {{--$('#' + 'diff_' + curr.toLowerCase()).text(diff);--}}
        {{--}--}}
        {{--else {--}}
        {{--if (curr == "XDC" || curr == "XDCE") {--}}
        {{--var tot = parseFloat(parseFloat(data.tot_xdc) + parseFloat(data.tot_xdce)).toFixed(2);--}}
        {{--var admin_tot = parseFloat(parseFloat(data.admin_tot_xdc) + parseFloat(data.admin_tot_xdce) + parseFloat(731362343.53)).toFixed(2)--}}
        {{--var diff = parseFloat(parseFloat(admin_tot) - parseFloat(tot)).toFixed(2);--}}
        {{--$('#' + 'diff_' + curr.toLowerCase()).text(diff);--}}
        {{--// $('#' + 'diff_xdc').text(diff);--}}
        {{--$('#' + 'diff_m_xdc').text(diff);--}}
        {{--// console.log("DDDD",curr,{{$tot_xdc}},{{$tot_xdce}},{{$admin_tot_xdc}},{{$admin_tot_xdce}},diff);--}}

        {{--}--}}
        {{--else {--}}
        {{--var bal = parseFloat(dash.normal).toFixed(2);--}}
        {{--var auto_bal = parseFloat(dash.auto).toFixed(2);--}}
        {{--var reserve = parseFloat(dash.reserve).toFixed(2);--}}
        {{--var bitfinex = parseFloat(dash.bitfinex).toFixed(2);--}}
        {{--var indodax = parseFloat(dash.indodax).toFixed(2);--}}
        {{--var liquid = parseFloat(dash.liquid).toFixed(2);--}}
        {{--// console.log("????",bitfinex,indodax,reserve);--}}
        {{--var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(auto_bal)).toFixed(2);--}}
        {{--var user_tot = parseFloat(parseFloat(dash.total) + parseFloat(dash.profit)).toFixed(4)--}}
        {{--var diff = parseFloat(parseFloat(tot) - parseFloat(user_tot)).toFixed(2);--}}
        {{--$('#' + 'diff_' + curr.toLowerCase()).text(diff);--}}
        {{--}--}}

        {{--}--}}
        {{--});--}}

        {{--}--}}
        {{--});--}}

        {{--}--}}

        {{--function update_admin_status() {--}}
        {{--var user_tot_cal = parseFloat({{$tot_xdc}}) + parseFloat({{$tot_xdce}});--}}
        {{--var admin_tot_cal = parseFloat({{$admin_tot_xdc}}) + parseFloat({{$admin_tot_xdce}}) + parseFloat(731362343.53);--}}
        {{--@foreach($currencies['balance']->result as $currency)--}}
        {{--var curr = '{{$currency->currency}}';--}}
        {{--var total = '{{$currency->total}}';--}}
        {{--var profit = '{{$currency->profit}}';--}}
        {{--var bal = '{{$currency->normal}}';--}}
        {{--var auto = '{{$currency->auto}}';--}}
        {{--var reserve = '{{$currency->reserve}}';--}}
        {{--var bitfinex = '{{$currency->bitfinex}}';--}}
        {{--var indodax = '{{$currency->indodax}}';--}}
        {{--var liquid = '{{$currency->liquid}}';--}}
        {{--var tot_xdc = '';--}}
        {{--var tot_xdce = '';--}}
        {{--if (curr == "XDC" || curr == "XDCE") {--}}
        {{--// console.log(">>>>",user_tot_cal,admin_tot_cal);--}}
        {{--$.ajax({--}}
        {{--url: '/ajax/admin_status_new',--}}
        {{--method: 'get',--}}
        {{--data: {'curr': curr, 'user_total': user_tot_cal, 'admin_total': admin_tot_cal},--}}
        {{--success: function (data) {--}}
        {{--data = JSON.parse(data);--}}
        {{--var status = data.status;--}}
        {{--curr = data.currency;--}}
        {{--// console.log(">>>>1.2",data.currency,data);--}}
        {{--if (status == '1') {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#90EE90');--}}
        {{--}--}}
        {{--else {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#ff9999');--}}
        {{--}--}}
        {{--}--}}
        {{--});--}}
        {{--$.ajax({--}}
        {{--url: '/ajax/admin_status_new',--}}
        {{--method: 'get',--}}
        {{--data: {'curr': "M-XDC", 'user_total': user_tot_cal, 'admin_total': admin_tot_cal},--}}
        {{--success: function (data) {--}}
        {{--data = JSON.parse(data);--}}
        {{--var status = data.status;--}}
        {{--curr = data.currency;--}}
        {{--// console.log(">>>>1.2",data.currency,data);--}}
        {{--if (status == '1') {--}}
        {{--$('#' + 'm_xdc' + '_div').css('background-color', '#90EE90');--}}
        {{--}--}}
        {{--else {--}}
        {{--$('#' + "m_xdc" + '_div').css('background-color', '#ff9999');--}}
        {{--}--}}
        {{--}--}}
        {{--});--}}
        {{--}--}}
        {{--else {--}}
        {{--// console.log(">>>>1",total);--}}

        {{--var admin_total = parseFloat(parseFloat(bal) + parseFloat(auto) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(reserve))--}}
        {{--var user_total = parseFloat(total) + parseFloat(profit);--}}
        {{--$.ajax({--}}
        {{--url: '/ajax/admin_status_new',--}}
        {{--method: 'get',--}}
        {{--data: {'curr': curr, 'user_total': user_total, 'admin_total': admin_total},--}}
        {{--success: function (data) {--}}
        {{--data = JSON.parse(data);--}}
        {{--// console.log(">>>>3",data.currency,data);--}}
        {{--var status = data.status;--}}
        {{--curr = data.currency;--}}
        {{--if (status == '1') {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#90EE90');--}}
        {{--}--}}
        {{--else {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#ff9999');--}}
        {{--}--}}
        {{--}--}}
        {{--});--}}
        {{--}--}}
        {{--@endforeach--}}

        {{--}--}}

        {{--function update_admin_status_new() {--}}
        {{--$.ajax({--}}
        {{--url: '{{url('adminv3/dashboard')}}',--}}
        {{--method: 'get',--}}
        {{--data: {},--}}
        {{--success: function (data) {--}}
        {{--const _data = data.currencies['balance'].result;--}}
        {{--Object.keys(_data).map((index, key) => {--}}
        {{--var dash = _data[index];--}}
        {{--var user_tot_cal = parseFloat(data.tot_xdc) + parseFloat(data.tot_xdce);--}}
        {{--var admin_tot_cal = parseFloat(data.admin_tot_xdc) + parseFloat(data.admin_tot_xdce) + parseFloat(731362343.53);--}}

        {{--var curr = dash.currency;--}}
        {{--var total = dash.total;--}}
        {{--var profit = dash.profit;--}}
        {{--var bal = dash.normal;--}}
        {{--var auto = dash.auto;--}}
        {{--var reserve = dash.reserve;--}}
        {{--var bitfinex = dash.bitfinex;--}}
        {{--var indodax = dash.indodax;--}}
        {{--var liquid = dash.liquid;--}}
        {{--var tot_xdc = '';--}}
        {{--var tot_xdce = '';--}}
        {{--if (curr == "XDC" || curr == "XDCE") {--}}
        {{--// console.log(">>>>",user_tot_cal,admin_tot_cal);--}}
        {{--$.ajax({--}}
        {{--url: '/ajax/admin_status_new',--}}
        {{--method: 'get',--}}
        {{--data: {'curr': curr, 'user_total': user_tot_cal, 'admin_total': admin_tot_cal},--}}
        {{--success: function (data) {--}}
        {{--data = JSON.parse(data);--}}
        {{--var status = data.status;--}}
        {{--curr = data.currency;--}}
        {{--// console.log(">>>>1.2",data.currency,data);--}}
        {{--if (status == '1') {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#90EE90');--}}
        {{--}--}}
        {{--else {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#ff9999');--}}
        {{--}--}}
        {{--}--}}
        {{--});--}}
        {{--$.ajax({--}}
        {{--url: '/ajax/admin_status_new',--}}
        {{--method: 'get',--}}
        {{--data: {'curr': "M-XDC", 'user_total': user_tot_cal, 'admin_total': admin_tot_cal},--}}
        {{--success: function (data) {--}}
        {{--data = JSON.parse(data);--}}
        {{--var status = data.status;--}}
        {{--curr = data.currency;--}}
        {{--// console.log(">>>>1.2",data.currency,data);--}}
        {{--if (status == '1') {--}}
        {{--$('#' + 'm_xdc' + '_div').css('background-color', '#90EE90');--}}
        {{--}--}}
        {{--else {--}}
        {{--$('#' + "m_xdc" + '_div').css('background-color', '#ff9999');--}}
        {{--}--}}
        {{--}--}}
        {{--});--}}
        {{--}--}}
        {{--else {--}}
        {{--// console.log(">>>>1",total);--}}

        {{--var admin_total = parseFloat(parseFloat(bal) + parseFloat(auto) + parseFloat(bitfinex) + parseFloat(indodax) + parseFloat(liquid) + parseFloat(reserve));--}}
        {{--var user_total = parseFloat(total) + parseFloat(profit);--}}
        {{--$.ajax({--}}
        {{--url: '/ajax/admin_status_new',--}}
        {{--method: 'get',--}}
        {{--data: {'curr': curr, 'user_total': user_total, 'admin_total': admin_total},--}}
        {{--success: function (data) {--}}
        {{--data = JSON.parse(data);--}}
        {{--// console.log(">>>>3",data.currency,data);--}}
        {{--var status = data.status;--}}
        {{--curr = data.currency;--}}
        {{--if (status == '1') {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#90EE90');--}}
        {{--}--}}
        {{--else {--}}
        {{--$('#' + curr.toLowerCase() + '_div').css('background-color', '#ff9999');--}}
        {{--}--}}
        {{--}--}}
        {{--});--}}
        {{--}--}}
        {{--});--}}

        {{--}--}}
        {{--});--}}

        {{--}--}}

        {{--function update_stats() {--}}

        {{--$('#xdc_bal').text('Refreshing');--}}
        {{--// $('#m_xdc_bal').text('Loading');--}}
        {{--$('#xdce_bal').text('Refreshing');--}}
        {{--$('#eth_bal').text('Refreshing');--}}
        {{--$('#btc_bal').text('Refreshing');--}}
        {{--$('#bchabc_bal').text('Refreshing');--}}
        {{--$('#bchsv_bal').text('Refreshing');--}}
        {{--$('#usdc_bal').text('Refreshing');--}}
        {{--$('#usdt_bal').text('Refreshing');--}}
        {{--$('#xrp_bal').text('Refreshing');--}}

        {{--update_user_balance();--}}
        {{--update_admin_balance();--}}
        {{--update_admin_status_new();--}}
        {{--update_difference();--}}

        {{--setInterval(function () {--}}
        {{--update_user_balance();--}}
        {{--update_admin_balance();--}}
        {{--update_admin_status_new();--}}
        {{--update_difference();--}}
        {{--}, 300000);--}}
        {{--}--}}

    </script>
@endsection