@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">KYC Status</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

            <li class="active">KYC</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <div class="row">
                                    <form id="form_filters" method="get">
                                    <div class="col-md-3">
                                            <lable>Start date</lable>
                                            <input type="text" id="startDate" name="startDate"
                                                   value="{{ app('request')->input('startDate') }}" class="form-control">
                                        </div>
                                        <div class="col-md-3">
                                            <lable>End date</lable>
                                            <input type="text" id="endDate" name="endDate"
                                                   value="{{ app('request')->input('endDate') }}" class="form-control">
                                        </div>
                                    <div class="col-md-2">
                                            <lable>Search</lable>
                                            <input type="text" id="search" name="search"
                                                   value="{{ app('request')->input('search') }}" class="form-control">
                                        </div>
                                        <div class="col-md-2">
                                            <lable>Status</lable>
                                            <select class="form-control" name="status">
                                                <option value="">All</option>
                                                <option value="Pending"
                                                        @if(app('request')->input('status')=='Pending') selected @endif>
                                                    Pending
                                                </option>
                                                <option value="Approved"
                                                        @if(app('request')->input('status')=='Approved') selected @endif>
                                                    Approved
                                                </option>
                                                <option value="Submitted"
                                                        @if(app('request')->input('status')=='Submitted') selected @endif>
                                                    Submitted
                                                </option>
                                                <option value="Rejected"
                                                        @if(app('request')->input('status')=='Rejected') selected @endif>
                                                    Rejected
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                        <button style="margin-top: 17px;" class="btn btn-default" onclick="{{url('adminv3/admin_kyc_users/'.$page)}}"><i
                                                        class="fa fa-search"></i></button>
                                                        </div>
                                        {{csrf_field()}}
                                    </form>
                                </div>

                                <div class="table-container">

                                    <table class="table table-hover table-striped table-bordered table-advanced tablesorter" id="myTable">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>User ID</th>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>KYC Status</th>

                                            <th>Date time</th>

                                            <th>Action</th>


                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if($result)
                                            @foreach($result as $key=>$val)
                                                <tr>
                                                    <td>{{$key+1}}</td>
                                                    <td>{{$val->userId}}</td>
                                                    <td>{{$val->firstName}} {{$val->lastName}}</td>
                                                    <td>
                                                    <p>{{$val->email}}</p>
                                                    
                                                    </td>
                                                    <td>
                                                        @if($val->status=="Pending")
                                                            <p class="label label-warning">Pending</p>
                                                        @elseif($val->status=="Approved")
                                                            <p class="label label-success">Approved</p>
                                                        @elseif($val->status=="Rejected")
                                                            <p class="label label-danger">Rejected</p>
                                                        @else
                                                            <p class="label label-warning">Submitted</p>
                                                        @endif
                                                    </td>
                                                    <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                                    <td>
                                                        <a href="{{url('adminv3/admin_view_kyc/'.$val->uniqueId)}}" title="view"><i class="fa fa-eye"></i></a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                        </tbody>
                                    </table>

                                </div>

                                <div class="row">
                                <div class="col-lg-0">

                                    </div>
                                    <div class="col-lg-6 text-left">
                                        <div class="pagination-panel">
                                            <ul class="pagination">

                                            <li><input class="form-controlp" type="number" id="pagesearch">&nbsp;{{$pagination->lastPage}}&nbsp;<button style="margin-top: -3px;width:50px;height:41px;" class="btn btn-default" onclick="searchpage()"><i
                                                                class="fa fa-search"></i></button></li>
                                            <li><p style='color:red; display:none;'id='error_message'>Page Number should be between 0 to {{$pagination->lastPage}}</p></li>
                                            </ul>
                                        
                                        </div>
                                    </div>
                                    <div class="col-lg-6">

                                    </div>
                                    <div class="col-lg-6 text-right">
                                    <div class="pagination-panel">
                                    @include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/admin_kyc_users')])

                                    </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



@endsection

@section('script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
    function searchpage(){
    var input = document.getElementById("pagesearch").value;
    var x = document.getElementById("error_message");
    var url1 = window.location.search;
    if(input>=1 && input<={{$pagination->lastPage}}){
        window.location.href = "/adminv3/admin_kyc_users/"+input+url1;
        x.style.display = "none";
    }
    else{
        x.style.display = "block";
    }
    
}
        $(document).ready(function(){
            $('#myTable').DataTable({
                "paging":   false,
                "ordering": true,
                "info":     false,
                "searching" : false
                // "lengthChange": false,
                // "pageLength" : 25
            });
        });

    </script>

    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    <script>
        $(function () {
            $("#startDate,#endDate").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd',
                
            });
        });
    </script>
@endsection