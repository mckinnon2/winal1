@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Referral Settings</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Referral Settings</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal" id="form">
                                    <h3>Referral Settings: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">


                                            <div class="row">


                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="mail" class="col-md-2 control-label"><strong>Currency ID:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">{{$result->currencyId }}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>
                                                                Referral Amount:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">
                                                                {{$result->referralAmount}}
                                                            </p></div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>
                                                                Referred Amount:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->referredAmount}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>
                                                                Status:</strong></label>

                                                                <div class="col-md-10"><p class="form-control-static">
                                                                @if($result->status==true)
                                                                    Active
                                                                @else
                                                                    Deactive
                                                                @endif
                                                            </p></div>
                                                    </div>
                                                </div>
                                                <br>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Created
                                                                date:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{strftime("%Y-%m-%d %H:%M:%S",strtotime($result->createdAt))}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <!-- <button class="btn btn-green btn-block" id="update" onClick="window.location='{{url('adminv3/edit_referral_settings/'.$result->currencyId)}}';">Update Settings</button> -->
                                                <button class="btn btn-green pull-right" id="delete"
                                                            data-toggle="modal" data-target="#updtsett">Update
                                                        Settings
                                                    </button>
                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="modal fade" id="updtsett" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
         data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <form id="profile-update" action="{{url('/adminv3/edit_referral_settings/'.$result->currencyId)}}" method="post"
                          enctype="multipart/form-data">
                        <h3>Refferal Setting: </h3>
                        {{csrf_field()}}
                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Currency ID:</label>
                                    <input 
                                           id="currency_id" name="currency_id"
                                           type="text" class="form-control"
                                           value="{{$result->currencyId}}" readonly=""
                                    >
                                    <div class="error_gap">
                                        <label id="email-error" for="currency_id" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Referral Amount</label>
                                    <input type="text" name="referral_amount"
                                           class="form-control" id = "referral_amount"
                                           value="{{ $result->referralAmount }}"
                                           >
                                    <div class="error_gap">
                                        <label id="first_name-error" for="referral_amount" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>

                            </div>


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Referred Amount</label>
                                    <input type="text" name="referred_amount"
                                           class="form-control" id ="referred_amount"
                                           value="{{ $result->referredAmount }}"
                                           >
                                    <div class="error_gap">
                                        <label id="last_name-error" for="referred_amount" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>

                            </div>

                           
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Status</label>
                                    <select class="form-control" id ="status"name="status" >
                                                   <option value="1">Activate</option>
                                                    <option value="0">Deactivate</option>
                                                </select>
                                    <div class="error_gap">
                                        <label id="address-error" for="description" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>
                            </div>
                            
                           
                        </div>
                        <hr/>
                        <div class="form-group">
                            <button type="submit"
                                    class="btn btn-green">
                                Save Changes
                            </button>
                            <button
                                    class="btn btn-danger " data-dismiss='modal'>
                                Cancel Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    


@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>

        $("#form").submit(function (){
            event.preventDefault();
        });
        function showDiv() {
   document.getElementById('updateSettings').style.display = "block";
   document.getElementById('form').style.display = "none";
}
       
    </script>

@endsection


