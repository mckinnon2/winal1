@extends("panel1.layout.admin_new_layout")
@section("content")
<div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                <div class="page-header pull-left">
                    <div class="page-title">My Profile</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                    <li class="hidden"><a href="#">Profile</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                    <li class="active">Profile</li>
                </ol>
                <div class="clearfix"></div>
            </div>


            <div class="page-content">
  <div class="row">
                    <div class="col-md-12">

                     @include('panel1.alert')

                        <div class="row mtl">

                            <div class="col-md-12">

                                <div id="generalTabContent" class="tab-content">
                                    <div id="tab-edit" class="tab-pane fade in active">
                                        <form action="{{url('adminv3/admin_profile')}}" method="post" class="form-horizontal">
                                        <h3>Account Setting</h3>
                                        {{ csrf_field() }}
                                            <div class="form-group"><label class="col-sm-3 control-label">Email *</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                 <div class="col-xs-9"><input type="email" placeholder="email@yourcompany.com" class="form-control" name="email" value="" /></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group"><label class="col-sm-3 control-label">Username *</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" placeholder="username" name="firstName" value="" class="form-control"/></div>
                                                    </div>
                                                </div>
                                            </div>


                                             <div class="form-group"><label class="col-sm-3 control-label">Phone</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" placeholder="9876543210" name="" value="" class="form-control" disabled="disabled" /></div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="form-group"><label class="col-sm-3 control-label">Country</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" placeholder="India" name="admin_country" value="" class="form-control"/></div>
                                                    </div>
                                                </div>
                                            </div>


                                            <hr/>

                                            <h3>Change password</h3>

                                            <div class="form-group"><label class="col-sm-3 control-label">Current Password</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-4"><input type="password" placeholder="Current Password" name="oldPassword" class="form-control" /></div>
                                                    </div>
                                                </div>
                                            </div>

                                             <div class="form-group"><label class="col-sm-3 control-label">New Password</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-4"><input type="password" placeholder="New Password" name="newPassword" class="form-control"/></div>
                                                    </div>
                                                </div>
                                            </div>

                                             <div class="form-group"><label class="col-sm-3 control-label">Confirm New Password</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-4"><input type="password" placeholder="Confirm New Password" name="confirmPassword" class="form-control"/></div>
                                                    </div>
                                                </div>
                                            </div>


                                            <hr/>
                                            <button type="submit" class="btn btn-green btn-block">Update</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



@endsection