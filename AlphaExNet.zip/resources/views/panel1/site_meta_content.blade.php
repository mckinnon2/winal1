@extends("panel1.layout.admin_new_layout")
@section("content")
<div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                <div class="page-header pull-left">
                    <div class="page-title">Meta Contents</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

                    <li class="active">Meta contents</li>
                </ol>
                <div class="clearfix"></div>
            </div>


            <div class="page-content">
  <div class="row">
                    <div class="col-md-12">

                 @include('panel.alert')

                        <div id="tableactionTabContent" class="tab-content">
                             <div id="table-table-tab" class="tab-pane fade in active">
                                <div class="row">
                                    <div class="col-lg-12">

                                        <div class="table-container">

                                            <table class="table table-hover table-striped table-bordered table-advanced tablesorter" id="myTable">
                                                <thead>
                                               <tr>
                                            <th>#</th>
                                            <th>Page</th>
                                            <th>Title</th>
                                            <th>Keywords</th>
                                            <th>Datetime</th>
                                            <th>Actions</th>



                                        </tr>
                                                <tbody>
                                                @if($result)
                                                @foreach($result as $key=>$val)
                                               <tr>
                                               <td>{{$key+1}}</td>
                                               <td>{{$val->heading}}</td>
                                               <td>{{$val->title}}</td>
                                               <td>{{$val->meta_keywords}}</td>
                                               <td>{{$val->updated_at}}</td>

                                               <td>
                                         <a href="{{url('adminv3/update_site_meta/'.$val->id)}}" title="Edit"><i class="fa fa-pencil"></i></a>
                                               </td>
                                               </tr>
                                               @endforeach
                                               @endif
                                                </tbody>
                                                </thead></table>

                                        </div>







                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>



@endsection

@section('script')
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
    $('#myTable').DataTable();
});
</script>
@endsection