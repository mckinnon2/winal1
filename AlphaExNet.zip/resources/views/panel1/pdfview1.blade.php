<html>
<head>
    <title>User list - PDF</title>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/jquery-ui-1.10.4.custom/css/ui-lightness/jquery-ui-1.10.4.custom.min.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/font-awesome/css/font-awesome.min.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/bootstrap/css/bootstrap.min.css') }}">
    <!--LOADING STYLESHEET FOR PAGE-->

<!-- <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/calendar/zabuto_calendar.min.css') }}"> -->
    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/animate.css/animate.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/jquery-pace/pace.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/iCheck/skins/all.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/jquery-news-ticker/jquery.news-ticker.css') }}">
    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/css/themes/style3/orange-blue.css') }}" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/css/style-responsive.css') }}">
    <link href="{{ URL::asset('control/css/patternLock.css') }}"  rel="stylesheet" type="text/css" />
    <link type="text/css" rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css">
    <style>
        body
        {
            background-color: white;
        }
    </style>
</head>
<body onload="window.print()">
<div class="container">


    <div class="page-content">
        <div class="row mbl">
            {{--user details--}}
            <div class="col-md-12">
                <div class="row">
                @foreach($result->userDetails as $res)
                    <h2><strong>Name: &nbsp;{{$res->firstName}}</strong><br></h2>
                    <label class="col-md-6"><strong>User Id:&nbsp;</strong>{{$res->uniqueId}}</label>
                    <label class="col-md-6"><strong>Email Id:&nbsp;</strong>{{$res->email}}</label>
                @endforeach
                </div>
            </div>
            {{--User Profile--}}
            <div class="col-md-12">
                <div class="row">
                    <h2><strong>Account Balances:</strong><br></h2>
                </div>
                <div class="row">
                @foreach($result->userBalanceDetails as $res)
                    <div class="col-md-4">
                        <label><strong>{{$res->symbol}}:</strong>&nbsp;{{$res->balance}}</label>
                    </div>
                @endforeach
                    
                </div>


                <div class="row">
                    <h2><strong>Explorer Deposits:</strong><br></h2>
                </div>
                <div class="row">
                @foreach($result->userDepositDetails as $res)
                    <div class="col-md-4">
                        <label><strong>{{$res->currency}}:</strong>&nbsp;{{$res->amount}}</label>
                    </div>

                    @endforeach   
                </div>

                <div class="row">
                    <h2><strong>Completed Withdrawals:</strong><br></h2>
                </div>
                <div class="row">
                    @foreach($result->userWithdrawDetails as $res)
                        <div class="col-md-4">
                            <label><strong>{{$res->currency}}:</strong>&nbsp;{{$res->amount}}</label>
                        </div>
                    @endforeach 
                    
                </div>
                <div class="row">
                    <h2><strong>Trading Balances:</strong><br></h2>
                </div>
                
                <div class="table-container">
           
            <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                   id="Tradebal">
                <thead>
                <tr>
                    <th>Updated time</th>
                    <th>Order ID</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Fee</th>
                    
                    @foreach($result->userBalanceDetails as $res)
                        <th>{{$res->symbol}}</th>
                    @endforeach
                    <th>Status</th>
                    


                </tr>
                <tbody>
                @if($trade)
                        @foreach($trade as $res)
                            <tr>
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res['updatedAt']))}}</td>
                                <td>{{$res['order_id']}}</td>
                                <td>{{$res['type']}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res['price']),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res['fee']),'0'),'.')}}</td>
                                @if($res['order_id'])
                                @foreach($res['balance'] as $key)
                                <td>{{rtrim(rtrim(sprintf('%.10f',$key['value']),'0'),'.')}}</td>
                                @endforeach
                            
                                @endif
                                    @if($res['status'] == "completed" || $res['status'] == "Completed")
                                    <td>CMPLT</td>
                                @elseif($res['status'] == "cancelled" || $res['status'] == "Cancelled")
                                    <td>CXL</td>
                                @elseif($res['status'] == "partially")
                                    <td>PRTL</td>
                                @elseif($res['status'] == "Pending")
                                    <td>PNDG</td>
                                @elseif($res['status'] == "Processing")
                                    <td>PROCESS</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                   
                                
                                
                            </tr>
                        @endforeach
                    @endif   
                </tbody>
                </thead>

            </table>

        </div>
            </div>

        </div>


        <div>
            <h2>Total Trade Supply:</h2>
            <br>
            <div class="row">
                <div class="col-md-4">
                @foreach($result->userBuyTradeDetails as $res)
                                <div class="col-md-6">
                                    <label><strong>Buyed {{$res->currency}}:</strong></label>
                                </div>

                                <div class="col-md-6">
                                    <label>{{$res->amount}}</label>
                                </div>
                @endforeach
                </div>
                <div class="col-md-4">
                                @foreach($result->userSellTradeDetails as $res)
                                <div class="col-md-6">
                                    <label><strong>Sell {{$res->currency}}:</strong></label>
                                </div>

                                <div class="col-md-6">
                                    <label>{{$res->amount}}</label>
                                </div>
                                @endforeach
                            </div>
                            
                            <div class="col-md-4">
                                @foreach($result->userIntradeTradeDetails as $res)
                                <div class="col-md-6">
                                    <label><strong>InTrade {{$res->currency}}:</strong></label>
                                </div>

                                <div class="col-md-6">
                                    <label>{{$res->amount}}</label>
                                </div>
                                @endforeach
                            </div>
                

            </div>
        </div>
        {{--user buy Trade of that particular currency--}}
        <div class="table-container">
            <div>
                <h2>&nbsp;&nbsp;Buy Trades:</h2>
                <br>
            </div>
            <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                   id="myBuyTrade">
                <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Amount</th>
                    <th>Price</th>
                    <th>Fee</th>
                    <th>Total</th>
                    <th>Type</th>
                    <th>First Currency</th>
                    <th>Second Currency</th>
                    <th>Status</th>
                    <th>Updated time</th>


                </tr>
                <tbody>
                    @if($result->userTradeDetails->buyTrades)
                        @foreach($result->userTradeDetails->buyTrades as $res)
                            <tr>
                                <td>{{$res->orderId}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->originalQty),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->price),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res->fee),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->updatedTotal),'0'),'.')}}</td>
                                <td>{{$res->type}}</td>
                                <td>{{$res->firstCurrency}}</td>
                                <td>{{$res->secondCurrency}}</td>
                                @if($res->status == "completed")
                                    <td>CMPLT</td>
                                @elseif($res->status == "cancelled")
                                    <td>CXL</td>
                                @elseif($res->status == "partially")
                                    <td>PRTL</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res->updatedAt))}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </thead>

            </table>

        </div>

        {{--user buy Trade of that particular currency--}}
        <div class="table-container">
            <div>
                <h2>&nbsp;&nbsp;Sell Trades:</h2>
                <br>
            </div>
            <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                   id="mySellTrade">
                <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Amount</th>
                    <th>Price</th>
                    <th>Fee</th>
                    <th>Total</th>
                    <th>Type</th>
                    <th>First Currency</th>
                    <th>Second Currency</th>
                    <th>Status</th>
                    <th>Updated time</th>


                </tr>
                <tbody>
                    @if($result->userTradeDetails->sellTrades)
                        @foreach($result->userTradeDetails->sellTrades as $res)
                            <tr>
                            <td>{{$res->orderId}}</td>
                            <td>{{rtrim(rtrim(sprintf('%.10f',$res->originalQty),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->price),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res->fee),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->updatedTotal),'0'),'.')}}</td>
                                <td>{{$res->type}}</td>
                                <td>{{$res->firstCurrency}}</td>
                                <td>{{$res->secondCurrency}}</td>
                                @if($res->status == "completed")
                                    <td>CMPLT</td>
                                @elseif($res->status == "cancelled")
                                    <td>CXL</td>
                                @elseif($res->status == "partially")
                                    <td>PRTL</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res->updatedAt))}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </thead>

            </table>

        </div>
        <div class="table-container">
            <div>
                <h2>&nbsp; Pending Trades:</h2>
                <br>
            </div>
            <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                   id="myPendingTrade">
                <thead>
                <tr>
                    <th>Order ID>
                    <th>Amount</th>
                    <th>Price</th>
                    <th>Fee</th>
                    <th>Total</th>
                    <th>Type</th>
                    <th>First Currency</th>
                    <th>Second Currency</th>
                    <th>Status</th>
                    <th>Updated time</th>


                </tr>
                <tbody>
                    @if($result->userTradeDetails->inTrades)
                        @foreach($result->userTradeDetails->inTrades as $res)
                            <tr>
                            <td>{{$res->orderId}}</td>
                            <td>{{rtrim(rtrim(sprintf('%.10f',$res->originalQty),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->price),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res->fee),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->updatedTotal),'0'),'.')}}</td>
                                <td>{{$res->type}}</td>
                                <td>{{$res->firstCurrency}}</td>
                                <td>{{$res->secondCurrency}}</td>
                                @if($res->status == "completed")
                                    <td>CMPLT</td>
                                @elseif($res->status == "cancelled")
                                    <td>CXL</td>
                                @elseif($res->status == "partially")
                                    <td>PRTL</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res->updatedAt))}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </thead>

            </table>

        </div>

        {{--ico buy Trade of that particular currency--}}
        <!-- <div class="table-container">
            <div>
                <h2>&nbsp;&nbsp;ICO Trades:</h2>
                <br>
            </div>
            <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                   id="myICO">
                <thead>
                <tr>
                    <th>Amount</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Type</th>
                    <th>First Currency</th>
                    <th>Second Currency</th>
                    <th>Status</th>
                    <th>Updated time</th>


                </tr>
                
                </thead>
            </table>

        </div> -->

        {{--user Deposit Trade of that particular currency--}}
        <div class="table-container">
            <div>
                <h2>&nbsp;&nbsp;Deposits:</h2>
                <br>
            </div>
            <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                   id="mySellTrade">
                <thead>
                <tr>
                        <th>#</th>
                        <th>Transaction ID</th>
                        <th>Type</th>
                        <th>Currency</th>
                        <th>Amount</th>
                        <th>Datetime</th>
                        <th>Status</th>
                        <th>From Address</th>


                    </tr>
                    <tbody>
                    @if($result->userTransactionsDetails->deposits)
                        @foreach($result->userTransactionsDetails->deposits as $key=>$val)
                            <tr>
                            <td>{{$key+1}}</td>
                                <td>{{$val->transactionId}}</td>
                                <td>{{$val->transactionType}}</td>
                                <td>{{$val->currencyName}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$val->amount),'0'),'.')}}</td>
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                @if($val->status == "Completed")
                                    <td>CMPLT</td>
                                @elseif($val->status == "Cancelled")
                                    <td>CXL</td>
                                @elseif($val->status == "Pending")
                                    <td>PNDG</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{$val->fromAddress}}</td>
                                
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </thead>

            </table>

        </div>

        {{--user Withdrawal Trade of that particular currency--}}
        <div class="table-container">
            <div>
                <h2>&nbsp;&nbsp;Withdrawal:</h2>
                <br>
            </div>
            <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                   id="mySellTrade">
                <thead>
                <tr>
                        <th>#</th>
                        <th>Transaction ID</th>
                        <th>Type</th>
                        <th>Currency</th>
                        <th>Amount</th>
                        <th>Datetime</th>
                        <th>Status</th>


                    </tr>
                    <tbody>
                    @if($result->userTransactionsDetails->withdrawals)
                        @foreach($result->userTransactionsDetails->withdrawals as $key=>$val)
                            <tr>
                            <td>{{$key+1}}</td>
                                <td>{{$val->transactionId}}</td>
                                <td>{{$val->transactionType}}</td>
                                <td>{{$val->currencyName}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$val->amount),'0'),'.')}}</td>
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                @if($val->status == "Completed")
                                    <td>CMPLT</td>
                                @elseif($val->status == "Cancelled")
                                    <td>CXL</td>
                                @elseif($val->status == "Pending")
                                    <td>PNDG</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </thead>

            </table>

        </div>


    </div>

</div>

{{--scripts--}}

<script src="{{ URL::asset('control/js/jquery-1.10.2.min.js') }}"></script>
<script src="{{ URL::asset('control/js/jquery-migrate-1.2.1.min.js') }}"></script>
<script src="{{ URL::asset('control/js/jquery-ui.js') }}"></script>
<!--loading bootstrap js-->
<script src="{{ URL::asset('control/vendors/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('control/vendors/bootstrap-hover-dropdown/bootstrap-hover-dropdown.js') }}"></script>

<script src="{{ URL::asset('control/js/respond.min.js') }}"></script>
<script src="{{ URL::asset('control/vendors/metisMenu/jquery.metisMenu.js') }}"></script>
<script src="{{ URL::asset('control/vendors/slimScroll/jquery.slimscroll.js') }}"></script>
<script src="{{ URL::asset('control/vendors/jquery-cookie/jquery.cookie.js') }}"></script>
<script src="{{ URL::asset('control/vendors/iCheck/icheck.min.js') }}"></script>
<script src="{{ URL::asset('control/vendors/iCheck/custom.min.js') }}"></script>
<script src="{{ URL::asset('control/vendors/jquery-news-ticker/jquery.news-ticker.js') }}"></script>
<script src="{{ URL::asset('control/js/jquery.menu.js') }}"></script>
<script src="{{ URL::asset('control/vendors/jquery-pace/pace.min.js') }}"></script>
<script src="{{ URL::asset('control/vendors/holder/holder.js') }}"></script>
<script src="{{ URL::asset('control/vendors/responsive-tabs/responsive-tabs.js') }}"></script>

<script src="{{ URL::asset('control/js/main.js') }}"></script>

<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
<script src="//cdn.datatables.net/plug-ins/1.10.11/sorting/date-eu.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#myBuyTrade').DataTable({
            "searching": false,
            "paging": false,
            // "ordering": false,
            "info": false,
            "order": [[ 0, "desc" ]], //or asc 
            "columnDefs" : [{"targets":[0], "type":"date"}]
            
        });
        $('#Tradebal').DataTable({
            "searching": false,
            "paging": false,
            "ordering": true,
            "info": false,
            "order": [[ 0, "desc" ]], //or asc 
            "columnDefs" : [{"targets":[0], "type":"date"}]
        });

        $('#mySellTrade').DataTable({
            "searching": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "order": [[ 0, "desc" ]], //or asc 
            "columnDefs" : [{"targets":[0], "type":"date"}]
        });
    });
    
</script>


<link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
<script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
<script>
    $(function () {

        $("#max,#min").datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'yy-mm-dd',
            onSelect: function (selectedDate) {
                if (this.id == 'min') {
                    var dateMin = $('#min').datepicker("getDate");
                    var rMin = new Date(dateMin.getFullYear(), dateMin.getMonth(), dateMin.getDate() + 1);
                    $('#max').datepicker("option", "minDate", rMin);
                }

            }


        });


    });
</script>


</body>

</html>