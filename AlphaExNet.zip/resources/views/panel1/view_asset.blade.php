@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Asset</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Asset</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal"  method="post" action="{{url('adminv3/view_asset/'.$uniqueId)}}">
                                {{ csrf_field() }}
                                    <h3>Asset Details: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">


                                            <div class="row">


                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="mail" class="col-md-2 control-label"><strong>Asset Type:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">{{$result->assetType }}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>Token
                                                                Name:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">
                                                                {{$result->tokenName}} 
                                                            </p></div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>Contract Address:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->contractAddress}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Token Symbol:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->tokenSymbol}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Token Decimals:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->tokenDecimals}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Requested By:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->requestedBy}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Logo URL:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->logoURL}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Email:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->emailAddress}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Status:</strong></label>

                                                        <div class="col-md-10"><p id="check_status" class="form-control-static">
                                                                @if($result->status=="approval_request")
                                                                    Approval Request 
                                                                @elseif($result->status=="pending")
                                                                    Pending
                                                                @else
                                                                    Rejected
                                                                @endif
                                                            </p></div>
                                                    </div>
                                                </div>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Updated At:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{strftime("%Y-%m-%d %H:%M:%S",strtotime($result->updatedAt))}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Over All Status:</strong></label>

                                                        <div class="col-md-6"><p class="form-control-static">
                                                        <select class="form-control" id ="status"name="status" onchange="kycscr(this.value)">
                                                            <option value="pending" @if($result->status=="pending")selected @endif>Pending</option>
                                                            <option value="approval_request" @if($result->status=="approval_request")selected @endif >Approval Request</option>
                                                            <option value="rejected" @if($result->status=="rejected")selected @endif>Reject</option>
                                                        </select>
                                                        </p></div>
                                                    </div>
                                                </div>
                                                <div id="asset_reason" name="asset_reason" style="display: none;">
                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Reason:</strong></label>

                                                            <div class="col-md-6"><p class="form-control-static">
                                                        <textarea class="form-control" id= "description"name="description"></textarea>
                                                            </p></div>
                                                        </div>
                                                </div>
                                                </div>

                                                <button id="reason_submit" type="submit" class="btn btn-green btn-block">Update</button>

                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="clearfix"></div>
    


@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>
function kycscr(id)
    {
        if(id=="rejected")
        {
            $("#asset_reason").show();
            
        }
        else
        {
             $("#asset_reason").hide();
             
        }
    }

    $(document).ready(function(){
            var status = $('#check_status').text().trim();
            console.log("status>>",status);
            if(status == "Pending"){
                $("#reason_submit").attr("disabled", false);
            }
            else if(status == "Reject"){
                $("#reason_submit").attr("disabled", true);
            }
            else{
                $("#reason_submit").attr("disabled", true);
            }
            
    });
        $("#form").submit(function (){
            event.preventDefault();
        });

        
    </script>

@endsection


