@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Transaction details</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Transaction details</li>
        </ol>
        <div class="clearfix"></div>
    </div>

    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal"
                                      action="" method="post">
                                    <h3>Request Details: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">

                                            <div class="row">

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Transaction
                                                                ID:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$transactionDetail->transactionId}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Currency
                                                                Name:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$transactionDetail->currencyName}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Type:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$transactionDetail->transactionType}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Unique
                                                                ID:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$transactionDetail->uniqueId}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>User
                                                                Email:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$transactionDetail->email}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>
                                                                Status
                                                                :</strong></label>

                                                        @if($transactionDetail->status == 'Completed')
                                                            <div class="col-md-10"><p
                                                                        class="label label-success">CMPLT</p>
                                                            </div>
                                                        @elseif($transactionDetail->status == 'Pending')
                                                        
                                                            <div class="col-md-10"><p
                                                                        class="label label-warning">PNDG</p>
                                                            </div>
                                                        @elseif($transactionDetail->status == 'Cancelled')
                                                            <div class="col-md-10"><p
                                                                        class="label label-danger">CXL</p>
                                                            </div>
                                                        @else
                                                            <div class="col-md-10"><p
                                                                        class="label label-warning">RP</p>
                                                            </div>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Amount:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static" id="amount">{{rtrim(rtrim(sprintf('%.10f',$transactionDetail->amount),'0'),'.')}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Fee:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{rtrim(rtrim(sprintf('%.10f',$transactionDetail->fee),'0'),'.')}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Transfer
                                                                Amount:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{rtrim(rtrim(sprintf('%.10f',$transactionDetail->transferAmount),'0'),'.')}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>To
                                                                Address:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$transactionDetail->toAddress}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                @if($transactionDetail->status == 'Processing' || $transactionDetail->status == 'Pending' || $transactionDetail->status == 'Cancelled')
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  target="_blank"><p
                                                                        class="form-control-static">N.A</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                @else
                                                    @if($transactionDetail->currencyName == "XDCE")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://etherscan.io/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static" id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "XDC")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://explorer.xinfin.network/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "ETH")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label" ><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                
                                                                    <a class="col-md-10"  href="https://etherscan.io/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid" ><p
                                                                            class="form-control-static" id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                    </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "BTC")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://www.blockchain.com/btc/tx/{{$transactionDetail->walletTxId}}" target="_blank" id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "XRP")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://bithomp.com/explorer/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "USDT")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://www.omniexplorer.info/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "BCHABC")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://explorer.bitcoin.com/bch/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "BCHSV")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://bsvexplorer.info/#/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "USDC")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://etherscan.io/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    @elseif($transactionDetail->currencyName == "BCH")
                                                        <div class="col-md-12">
                                                            <div class="form-group"><label for="inputLastName"
                                                                                        class="col-md-2 control-label"><strong>Transaction 
                                                                                            Hash:</strong></label>

                                                                <a class="col-md-10"  href="https://explorer.bitcoin.com/bch/tx/{{$transactionDetail->walletTxId}}" target="_blank"id="wtxid"><p
                                                                        class="form-control-static"id="txid">{{$transactionDetail->walletTxId}}</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    
                                                    @endif
                                                @endif
                                                @if($transactionDetail->currencyName == "XRP")
                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Destination
                                                                    Tag:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static">{{$transactionDetail->destinationTag}}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Updated
                                                                Date:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{strftime("%Y-%m-%d %H:%M:%S",strtotime($transactionDetail->updatedAt))}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                @if($transactionDetail->status == "Pending")
                                                    <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="inputLastName"
                                                                    class="col-md-2 control-label"><strong></strong></label>
                                                                <a href="{{url('adminv3/confirm_withdraw_transactions/'.$transactionDetail->uniqueId)}}" class="btn btn-success">Confirm</a>
                                                                <a href="{{url('adminv3/cancel_withdraw_transactions/'.$transactionDetail->uniqueId)}}" class="btn btn-primary">Cancel</a>
                                                            </div>
                                                    </div>
                                                @endif
                        
                                                <!-- <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Transaction
                                                                Details:</strong></label>

                                                        <div class="col-md-10"><a
                                                                    class="form-control-static" target="_blank"
                                                                    href="">click
                                                                here</a>
                                                        </div>
                                                    </div>
                                                </div> -->

                                                

                                                    <!-- <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Reason
                                                                    for manual withdrawal:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"></p>
                                                            </div>
                                                        </div>
                                                    </div> -->

                                                    {{csrf_field()}}
                                                    <input type="hidden" name="txdid"
                                                           value="">
                                                    <input type="hidden" name="currency"
                                                           value="">

                                                    {{--for otp--}}
                                                    {{--<div class="col-md-12">--}}
                                                    {{--<div class="form-group input-group"><label for="inputLastName" class="col-md-2 control-label"><strong>OTP:</strong></label>--}}

                                                    {{--<div class="col-md-10">--}}
                                                    {{--<input type="text" class="form-control" name="otp_code" required />--}}
                                                    {{--<span class="input-group-addon" id="trans_otp">--}}
                                                    {{--<a href="#" onclick="generate_otp();" class="btn btn-info btn-sm">Generate OTP</a>--}}
                                                    {{--</span>--}}
                                                    {{--</div>--}}
                                                    {{--</div>--}}
                                                    {{--</div>--}}
<!-- 
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="inputLastName"
                                                                   class="col-md-2 control-label"><strong></strong></label>
                                                            

                                                                <input type="submit" class="btn btn-success"
                                                                       name="subbuton" value="Completed">
                                                                <input type="submit" class="btn btn-success"
                                                                       name="subbuton"
                                                                       value="Confirm" onclick="XDCEsubmit()">
                                                            
                                                                <input type="submit" class="btn btn-success"
                                                                       name="subbuton"
                                                                       value="Confirm">
                                                           
                                                            <input type="submit" class="btn btn-primary" name="subbuton"
                                                                   value="Cancel">
                                                        </div>
                                                    </div>

                                              

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Reason
                                                                    for manual withdrawal:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"></p>
                                                            </div>
                                                        </div>
                                                    </div> -->
<!-- 
                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Txd
                                                                    ID:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Completion
                                                                    Type :</strong></label>
                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"></p>
                                                            </div>
                                                        </div>
                                                    </div> -->

                                                

                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

@endsection

@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        var watxid = document.getElementById("txid").innerText;
        var split = watxid.split(":");
        document.getElementById("txid").innerText = split[0];
        
        if("{{$transactionDetail->currencyName}}" == "ETH" || "{{$transactionDetail->currencyName}}" == "XDCE" || "{{$transactionDetail->currencyName}}" == "USDC"){
            document.getElementById("wtxid").href = "https://etherscan.io/tx/" + split[0]
        }
        else if("{{$transactionDetail->currencyName}}" == "BTC"){
            document.getElementById("wtxid").href = "https://www.blockchain.com/btc/tx/" + split[0]
        }
        else if("{{$transactionDetail->currencyName}}" == "XDC"){
            document.getElementById("wtxid").href = "https://explorer.xinfin.network/tx/" + split[0]
        }
        else if("{{$transactionDetail->currencyName}}" == "XRP"){
            document.getElementById("wtxid").href = "https://bithomp.com/explorer/" + split[0]
        }
        else if("{{$transactionDetail->currencyName}}" == "USDT"){
            document.getElementById("wtxid").href = "https://www.omniexplorer.info/tx/" + split[0]
        }
        
        else if("{{$transactionDetail->currencyName}}" == "BCHABC" || "{{$transactionDetail->currencyName}}" == "BCH"){
            document.getElementById("wtxid").href = "https://explorer.bitcoin.com/bch/tx/" + split[0]
        }
        else if("{{$transactionDetail->currencyName}}" == "BCHSV"){
            document.getElementById("wtxid").href = "https://bsvexplorer.info/#/tx/" + split[0]
        }
        
        
        
        
    });
    </script>
  
@endsection
