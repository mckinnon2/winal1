@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">User Trade Transaction Details</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>
        </ol>
        <div class="clearfix"></div>
    </div>
    @foreach($result->userDetails as $res)
        <div style="float: right"><a
                    href="{{url('adminv3/user_transactions_detail/'.$res->uniqueId.'?type=PDF&user_id='.$res->uniqueId)}}"
                    target="_blank" style="cursor:pointer;">Download</a></div>
    @endforeach
    <div class="page-content">
        <div class="row mbl">
            {{--user details--}}

            {{--User Profile--}}
            <div class="col-sm-6 col-md-4">
                <div class="panel db mbm" style="cursor: pointer;">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center"><i class="fa fa-user fa-3"></i></div>
                                <div style="text-align: center"><p>
                                    @foreach($result->userDetails as $res)
                                        <h2>{{$res->firstName}}</h2></p>
                                        <p class="description "><strong>{{$res->email}}</strong></p></div>

                                @endforeach
                            </div>
                        </div>

                        <div class="row">
                            @foreach($result->userBalanceDetails as $res)
                                <div class="col-md-8">
                                    <label><strong>{{$res->symbol}}</strong></label>
                                </div>
                                <div class="col-md-4">
                                    <label>{{rtrim(rtrim(sprintf('%.10f',$res->balance),'0'),'.')}}</label>
                                </div>
                            @endforeach

                        </div>

                    </div>
                </div>
            </div>

            {{--Explorer Deposit--}}
            <div class="col-sm-6 col-md-4">
                <div class="panel db mbm" style="cursor: pointer;">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center"><i class="fa fa-exchange fa-6x"></i></div>
                                <div style="text-align: center"><p>
                                    <h2>Explorer Deposit</h2></p>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            @foreach($result->userDepositDetails as $res)
                                <div class="col-md-4">
                                    <label><strong>{{$res->currencyName}}</strong></label>
                                </div>
                                <div class="col-md-8">
                                    <label>{{rtrim(rtrim(sprintf('%.10f',$res->amount),'0'),'.')}}</label>
                                </div>
                            @endforeach
                        </div>

                    </div>
                </div>
            </div>

            {{--User Profile--}}
            <div class="col-sm-6 col-md-4">
                <div class="panel db mbm" style="cursor: pointer;">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center"><i class="fa fa-exchange fa-6x"></i></div>
                                <div style="text-align: center"><p>
                                    <h2>Withdrawals</h2></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            @foreach($result->userWithdrawDetails as $res)
                                <div class="col-md-4">
                                    <label><strong>{{$res->currencyName}}</strong></label>
                                </div>
                                <div class="col-md-8">
                                    <label>{{rtrim(rtrim(sprintf('%.10f',$res->amount),'0'),'.')}}</label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div>
            <h2>Total Trade Supply:</h2>
            <br>
            <div class="row">
                <div class="col-md-6">
                    @foreach($result->userBuyTradeDetails as $res)
                        <div class="col-md-8">
                            <label><strong>Buyed {{$res->currency}}:</strong></label>
                        </div>

                        <div class="col-md-4">
                            <label>{{rtrim(rtrim(sprintf('%.10f',$res->amount),'0'),'.')}}</label>
                        </div>
                    @endforeach
                </div>

                <div class="col-md-6">
                    @foreach($result->userSellTradeDetails as $res)
                        <div class="col-md-8">
                            <label><strong>Sell {{$res->currency}}:</strong></label>
                        </div>

                        <div class="col-md-4">
                            <label>{{rtrim(rtrim(sprintf('%.10f',$res->amount),'0'),'.')}}</label>
                        </div>
                    @endforeach
                </div>
                <div class="col-md-6">
                    @foreach($result->userIntradeTradeDetails as $res)
                        <div class="col-md-8">
                            <label><strong>Sell {{$res->currency}}:</strong></label>
                        </div>

                        <div class="col-md-4">
                            <label>{{rtrim(rtrim(sprintf('%.10f',$res->amount),'0'),'.')}}</label>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <form class="form-horizontal">
            <h3>User Addresses: </h3>
            @foreach($result->userBalanceDetails as $res)
                <div class="col-md-12">
                    <div class="form-group"><label for="inputLastName"
                                                   class="col-md-2 control-label"><strong> {{$res->symbol}}
                                :</strong></label>

                        <div class="col-md-10"><p class="form-control-static">
                                {{$res->currencyAddress}}
                            </p></div>
                    </div>
                </div>
            @endforeach


        </form>
        <div>
            <h3>Order Details:</h3>
        </div>
        <div class="tab-content ">
            <div class="table-container tab-pane fade in active">

                <table class="table table-hover table-striped table-advanced tablesorter table-wrapper-scroll-y my-custom-scrollbar"
                       id="Tradebal">
                    <thead>
                    <tr>
                        <th>Updated time</th>
                        <th>Order ID</th>
                        <th>Type</th>
                        <th>Price</th>
                        <th>Fee</th>

                        @foreach($result->userBalanceDetails as $res)
                            <th>{{$res->symbol}}</th>
                        @endforeach
                        <th>Status</th>


                    </tr>
                    <tbody>
                    @if($trade)
                        @foreach($trade as $res)
                        @if($res['status'] == "completed" || $res['status'] == "Completed")
                        @if($res['type'] == "buy" || $res['type'] == "sell" ||  $res['type'] == "Deposit" ||  $res['type'] == "Withdraw")
                            <tr>
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res['updatedAt']))}}</td>
                                <td>{{$res['order_id']}}</td>
                                <td>{{$res['type']}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res['price']),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res['fee']),'0'),'.')}}</td>
                                @if($res['order_id'])
                                    @foreach($res['balance'] as $key)
                                        <td>{{rtrim(rtrim(sprintf('%.10f',$key['value']),'0'),'.')}}</td>
                                    @endforeach

                                @endif
                                @if($res['status'] == "completed" || $res['status'] == "Completed")
                                    <td>CMPLT</td>
                                
                                @endif


                            </tr>
                            @endif
                        @endif
                        @endforeach
                    @endif
                    
                    
                    </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th colspan="0" style="text-align:right">Total:</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                    
                    
                    
                    </tfoot>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th colspan="0" style="text-align:right">Balance:@foreach($result->userBalanceDetails as $res)
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->balance),'0'),'.')}}</td>
                            @endforeach
                            </th>
                        
                        
                    </tr>
                    
                    
                    </tfoot>
                    </thead>

                </table>

            </div>
        </div>
        <div>
            <h3>Type of Order:</h3>
        </div>
        <div class="row">

            <div class="col-md-3">

                <select class="form-control" name="order" id="order">

                    <option value="buy_order">
                        Buy Order
                    </option>
                    <option value="sell_order">
                        Sell Order
                    </option>
                    <option value="pending_order">
                        Pending Order
                    </option>

                </select>
            </div>

        </div>
        <br>

        <div class="tab-content">

            {{--user buy Trade of that particular currency--}}
            <div id="buy_trades" class="table-container tab-pane fade in active">
                <div>
                    <h2>&nbsp;&nbsp;Buy Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped table-advanced tablesorter"
                       id="myBuyTrade">
                    <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>
                    </tr>
                    </thead>
                    <tbody>
                    @if($result->userTradeDetails->buyTrades)
                        @foreach($result->userTradeDetails->buyTrades as $res)
                            <tr>
                                <td>{{$res->orderId}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->originalQty),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->price),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res->fee),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->updatedTotal),'0'),'.')}}</td>
                                <td>{{$res->type}}</td>
                                <td>{{$res->firstCurrency}}</td>
                                <td>{{$res->secondCurrency}}</td>
                                @if($res->status == "completed")
                                    <td>CMPLT</td>
                                @elseif($res->status == "cancelled")
                                    <td>CXL</td>
                                @elseif($res->status == "partially")
                                    <td>PRTL</td>
                                @elseif($res->status == 'active')
                                    <td>PNDG</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res->updatedAt))}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>

                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>
            {{--user buy Trade of that particular currency--}}
            <div id="sell_trades" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;Sell Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="mySellTrade">
                    <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>


                    </tr>

                    </thead>
                    <tbody>
                    @if($result->userTradeDetails->sellTrades)
                        @foreach($result->userTradeDetails->sellTrades as $res)
                            <tr>
                                <td>{{$res->orderId}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->originalQty),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->price),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res->fee),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->updatedTotal),'0'),'.')}}</td>
                                <td>{{$res->type}}</td>
                                <td>{{$res->firstCurrency}}</td>
                                <td>{{$res->secondCurrency}}</td>
                                @if($res->status == "completed")
                                    <td>CMPLT</td>
                                @elseif($res->status == "cancelled")
                                    <td>CXL</td>
                                @elseif($res->status == "partially")
                                    <td>PRTL</td>
                                @elseif($res->status == 'active')
                                    <td>PNDG</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res->updatedAt))}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>

            {{--user penidng trades--}}
            <div id="pending_trades" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp; Pending Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="myPendingTrade">
                    <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>


                    </tr>

                    </thead>
                    <tbody>
                    @if($result->userTradeDetails->inTrades)
                        @foreach($result->userTradeDetails->inTrades as $res)
                            <tr>
                                <td>{{$res->orderId}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->originalQty),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->price),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.4f',$res->fee),'0'),'.')}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$res->updatedTotal),'0'),'.')}}</td>
                                <td>{{$res->type}}</td>
                                <td>{{$res->firstCurrency}}</td>
                                <td>{{$res->secondCurrency}}</td>
                                @if($res->status == "completed")
                                    <td>CMPLT</td>
                                @elseif($res->status == "cancelled")
                                    <td>CXL</td>
                                @elseif($res->status == "partially")
                                    <td>PRTL</td>
                                @elseif($res->status == "active")
                                    <td>PNDG</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($res->updatedAt))}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>

            {{--ico buy Trade of that particular currency--}}
            <div id="ico_trades" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;ICO Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="myICO">
                    <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>


                    </tr>

                    </thead>
                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>
        </div>

        <div>
            <h3>Type of Transaction:</h3>
        </div>
        <div class="row">

            <div class="col-md-3">

                <select class="form-control" name="transaction" id="transaction">

                    <option value="deposit_transaction">
                        Deposit
                    </option>
                    <option value="withdraw_transaction">
                        Withdrawal
                    </option>
                    <option value="referral">
                        Referral
                    </option>

                </select>
            </div>

        </div>
        <br>

        <div class="tab-content">

            {{--user Deposit Trade of that particular currency--}}
            <div id="deposit_transaction" class="table-container tab-pane fade in active"style="overflow-y: auto;">
                <div>
                    <h2>&nbsp;&nbsp;Deposits:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="Deposits" >
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Transaction ID</th>
                        <th>Type</th>
                        <th>Currency</th>
                        <th>Amount</th>
                        <th>Datetime</th>
                        <th>Status</th>
                        <th>From Address</th>


                    </tr>

                    </thead>
                    <tbody>
                    @if($result->userTransactionsDetails->deposits)
                        @foreach($result->userTransactionsDetails->deposits as $key=>$val)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$val->transactionId}}</td>
                                <td>{{$val->transactionType}}</td>
                                <td>{{$val->currencyName}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$val->amount),'0'),'.')}}</td>
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                @if($val->status == "Completed")
                                    <td>CMPLT</td>
                                @elseif($val->status == "Cancelled")
                                    <td>CXL</td>
                                @elseif($val->status == "Pending")
                                    <td>PNDG</td>
                                @else
                                    <td>PRTL-CXL</td>
                                @endif
                                <td>{{$val->fromAddress}}</td>

                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="4" style="text-align:right"></th>
                        <th></th>

                    </tr>
                    </tfoot>
                </table>

            </div>

            {{--user Withdrawal Trade of that particular currency--}}
            <div id="withdraw_transaction" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;Withdrawal:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="Withdrawals">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Transaction ID</th>
                        <th>Type</th>
                        <th>Currency</th>
                        <th>Amount</th>
                        <th>Datetime</th>
                        <th>Status</th>


                    </tr>

                    </thead>
                    <tbody>
                    @if($result->userTransactionsDetails->withdrawals)
                        @foreach($result->userTransactionsDetails->withdrawals as $key=>$val)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$val->transactionId}}</td>
                                <td>{{$val->transactionType}}</td>
                                <td>{{$val->currencyName}}</td>
                                <td>{{rtrim(rtrim(sprintf('%.10f',$val->amount),'0'),'.')}}</td>
                                <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                @if($val->status == "Completed")
                                    <td>CMPLT</td>
                                @elseif($val->status == "Cancelled")
                                    <td>CXL</td>
                                @elseif($val->status == "Pending")
                                    <td>PNDG</td>
                                @else
                                    <td>RP</td>
                                @endif


                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="4" style="text-align:right"></th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>

            {{--user Referral Earning --}}
            <div id="referral" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;Referral:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter" id="referral_earning">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Referred User ID</th>
                        <th>Referred Name</th>
                        <th>Currency</th>
                        <th>Bonus</th>
                        <th>Datetime</th>
                        <th>Status</th>


                    </tr>
                    </thead>

                    <tfoot>
                    <tr>
                        <th colspan="5" style="text-align:right"></th>
                        <th></th>
                        <th> Total Bonus :</th>

                    </tr>
                    </tfoot>

                </table>

            </div>

        </div>


    </div>



@endsection

@section('script')
    <!-- <script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script> -->
    <!-- <script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script> -->
    <!-- <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script> -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.20/api/sum().js"></script>
    <script type="text/javascript">

        $(document).ready(function () {
            $('#Tradebal').DataTable({
                "searching": false,
                "paging": false,
                // "ordering": false,
                "info": false,
                "dom": 'Bfrtip',
                "buttons": [
                    'excelHtml5',
                    'csvHtml5'
                ],
                "order": [[0, "desc"]], //or asc
                "columnDefs": [{"targets": [0], "type": "date"}],
                "footerCallback": function (tfoot, data, start, end, display) {
                    var api = this.api(), data;
                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;

                    };
                    columns = [5, 6, 7, 8, 9, 10, 11, 12, 13];
                    for (var j = 0; j < columns.length; j++) {
                        $('tfoot th').eq(columns[j]).html(api.column(columns[j], {filter: 'applied'}).data().sum().toFixed(8) + '<br>');
                    }
                    columns = [5, 6, 7, 8, 9, 10, 11, 12, 13];
                    for (var j = 0; j < columns.length; j++) {
                        $('tfoot th').eq(columns[j]).html(api.column(columns[j], {filter: 'applied'}).data().sum().toFixed(8) + '<br>');
                    }

                }
            });
            $('#myBuyTrade').DataTable({
                "searching": false,
                "paging": false,
                // "ordering": false,
                "info": false,
                "order": [[9, "desc"]], //or asc
                "columnDefs": [{"targets": [9], "type": "date"}],
                "footerCallback": function (tfoot, data, start, end, display) {
                    var api = this.api(), data;
                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;

                    };

                    // Total over all pages
                    amount = api
                        .column(1)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    total = api
                        .column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                            ;
                        });


                    // Update footer
                    // Update footer
                    $(api.column(0).footer()).html(
                        'Amount: ' + amount
                    );


                    $(api.column(3).footer()).html(
                        'Total: ' + total
                    );
                }
            });

            $('#mySellTrade').DataTable({
                "searching": false,
                "paging": false,
                // "ordering": false,
                "info": false,
                "order": [[9, "desc"]], //or asc
                "columnDefs": [{"targets": [9], "type": "date"}],
                "footerCallback": function (tfoot, data, start, end, display) {
                    var api = this.api(), data;
                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;

                    };

                    // Total over all pages
                    amount = api
                        .column(1)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    total = api
                        .column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                            ;
                        });


                    // Update footer
                    // Update footer
                    $(api.column(0).footer()).html(
                        'Amount: ' + amount
                    );


                    $(api.column(3).footer()).html(
                        'Total: ' + total
                    );
                }
            });
            $('#myPendingTrade').DataTable({
                "searching": false,
                "paging": false,
                // "ordering": false,
                "info": false,
                "order": [[9, "desc"]], //or asc
                "columnDefs": [{"targets": [9], "type": "date"}],
                "footerCallback": function (tfoot, data, start, end, display) {
                    var api = this.api(), data;
                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;

                    };

                    // Total over all pages
                    amount = api
                        .column(1)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    total = api
                        .column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                            ;
                        });


                    // Update footer
                    // Update footer
                    $(api.column(0).footer()).html(
                        'Amount: ' + amount
                    );


                    $(api.column(3).footer()).html(
                        'Total: ' + total
                    );
                }
            });

            $('#Deposits').DataTable({
                "searching": false,
                "paging": false,
                // "ordering": false,
                "info": false,
                "order": [[5, "desc"]], //or asc
                "columnDefs": [{"targets": [5], "type": "date"}],
                "footerCallback": function (row, data, start, end, display) {
                    var api = this.api(), data;

                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;
                    };


                    amount = api
                        .column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    // Update footer
                    // Update footer
                    $(api.column(4).footer()).html(
                        'Amount: ' + amount
                    );

                }
            });

            $('#Withdrawals').DataTable({
                "searching": false,
                "paging": false,
                // "ordering": false,
                "info": false,
                "order": [[5, "desc"]], //or asc
                "columnDefs": [{"targets": [5], "type": "date"}],
                "footerCallback": function (row, data, start, end, display) {
                    var api = this.api(), data;

                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;
                    };

                    amount = api
                        .column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    // Update footer
                    // Update footer
                    $(api.column(4).footer()).html(
                        'Amount: ' + amount
                    );

                }
            });

            // $('#referral_earning').DataTable({
            //     "searching": false,
            //     "paging": false,
            //     "ordering": false,
            //     "info": false,
            //     "footerCallback": function ( row, data, start, end, display ) {
            //         var api = this.api(), data;
            //
            //         // Remove the formatting to get integer data for summation
            //         var intVal = function ( i ) {
            //             return typeof i === 'string' ?
            //                 i*1 :
            //                 typeof i === 'number' ?
            //                     i : 0;
            //         };
            //
            //         amount = api.column(4)
            //             .data()
            //             .reduce(function (a,b) {
            //                 return intVal(a)+intVal(b);
            //             });
            //
            //         // Update footer
            //         // Update footer
            //         $(api.column(4).footer()).html(
            //             'Total Bonus: '+ amount
            //         );
            //
            //     }
            // });

        });
    </script>


    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    <script>
        $(function () {

            $("#max,#min").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd',
                onSelect: function (selectedDate) {
                    if (this.id == 'min') {
                        var dateMin = $('#min').datepicker("getDate");
                        var rMin = new Date(dateMin.getFullYear(), dateMin.getMonth(), dateMin.getDate() + 1);
                        $('#max').datepicker("option", "minDate", rMin);
                    }

                }


            });


        });
    </script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js">
    </script>
    <script src="{{ URL::asset('control/vendors/metisMenu/jquery.metisMenu.js') }}"></script>
    <script src="{{ URL::asset('control/vendors/slimScroll/jquery.slimscroll.js') }}"></script>
    <script src="{{ URL::asset('control/js/main.js') }}"></script>

    <script>

        $('#order').on('change', function () {
            if (this.value == 'buy_order') {
                $("#buy_trades").show();
                $("#sell_trades").hide();
                $("#pending_trades").hide();
            }
            else if (this.value == 'sell_order') {
                $("#sell_trades").show();
                $("#buy_trades").hide();
                $("#pending_trades").hide();
            }
            else if (this.value == 'pending_order') {
                $("#sell_trades").hide();
                $("#buy_trades").hide();
                $("#pending_trades").show();

            }
        });

        $('#transaction').on('change', function () {
            if (this.value == 'deposit_transaction') {
                $("#deposit_transaction").show();
                $("#withdraw_transaction").hide();
                $("#referral").hide();
            }
            else if (this.value == 'withdraw_transaction') {
                $("#withdraw_transaction").show();
                $("#deposit_transaction").hide();
                $("#referral").hide();
            }
            else if (this.value == 'referral') {
                $("#withdraw_transaction").hide();
                $("#deposit_transaction").hide();
                $("#referral").show();

            }
        });


    </script>


@endsection
