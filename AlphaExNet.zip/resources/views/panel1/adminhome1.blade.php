@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Dashboard</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><a href="#" onclick="update_stats()"> <i class="fa fa-refresh"></i>&nbsp;&nbsp; Refresh
                    Balance</a> &nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/home')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>
            <li class="hidden"><a href="#">Dashboard</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
            <li class="active">Dashboard</li>
        </ol>
        <div class="clearfix"></div>
    </div>
    <div class="page-content">
        <div id="tab-general">
        @include('panel1.alert')
            <div id="sum_box" class="row mbl">
                <div class="col-sm-6 col-md-3">
                    <div class="panel profit db mbm" onclick="window.location.href='{{url('adminv3/user_list/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-group"></i></p><h4 class="value">
                                
                        
                                    <span data-counter="" data-start="10" data-end="50" data-step="1" data-duration="0"> 
                                    
                                                </span></h4>
                                            
                                
                        
                            <p class="description">Registered Users</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel income db mbm" onclick="window.location.href='{{url('adminv3/trade_orders/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-exchange"></i></p><h4>
                        
                                    <span > 
                                    
                                                </span></h4>
                         

                            <p class="description">Total Transactions</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel task db mbm" onclick="window.location.href='{{url('adminv3/admin_kyc_users/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-signal"></i></p><h4 class="value">
                                <span></span><span><i
                                            class="fa fa-btc"></i></span></h4>

                            <p class="description">Profit</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel visit db mbm" onclick="window.location.href='{{url('adminv3/admin_kyc_users/1')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-group"></i></p><h4 class="value">
                        
                                    <span > 
                                    
                                                </span></h4>
                        

                            <p class="description">KYC verification</p>


                        </div>
                    </div>
                </div>
                

            </div>
            <div>
                <h2>&nbsp;&nbsp;Admin Balance:</h2>
                <br>
            </div>
            <div class="table-container"style="overflow-x:auto;">

                
                <table class="table table-hover table-bordered table-advanced tablesorter"
                       id="myTable">
                    <thead>
                    <tr>
                        <th style="background-color:white;"></th>
                        <th colspan="7" style="text-align:center!important;background-color:white;">Admin</th>
                        <th colspan="3" style="text-align:center!important;background-color:white;">Users</th>
                    </tr>
                    <tr>
                        <th>Currency</th>
                        <th>AlphaEx</th>
                        <th>AlphaEx Auto</th>
                        <th>BitFinex</th>
                        <th>Indodax</th>
                        <th>Liquid</th>
                        <th>Reserve</th>
                        <th>Total</th>
                        <th>Users</th>
                        <th>In Trade</th>
                        <th>Total</th>

                    </tr>
                    </thead>
                    <tbody>
                    <tr id="m_xdc_div">
                        <td onclick="window.open('https://explorer.xinfin.network/addr/xdc2642835a88a0b307ba6b52b7b23876210a03812c','newtab');">Mainnet-XDC</td>
                        <td id="m_xdc_bal">0</td>
                        <td id="m_xdc_auto_bal">0</td>
                        <td id="m_xdc_bit">0</td>
                        <td id="m_xdc_indo">0</td>
                        <td id="m_xdc_lqd">0</td>
                        <td id="m_xdc_reserve">0</td>
                        <td id="m_xdc_tot">0</td>
                        <td id="user_m_xdc">0</td>
                        <td id="intrade_m_xdc">0</td>
                        <td id="total_m_xdc">0</td>

                    </tr>
                    <tr id="xdc_div"
                        >
                        <td onclick="window.open('http://xinfin.info/account/0xb2b5b54b736e59b2a60aaf3bcc8109397562f769','newtab');">XDC</td>
                        <td id="xdc_bal">0</td>
                        <td id="xdc_auto_bal">0</td>
                        <td id="xdc_bit">0</td>
                        <td id="xdc_indo">0</td>
                        <td id="xdc_lqd">0</td>
                        <td id="xdc_reserve">0</td>
                        <td id="xdc_tot">0</td>
                        <td id="user_xdc">0</td>
                        <td id="intrade_xdc">0</td>
                        <td id="total_xdc">0</td>

                    </tr>
                    <tr id="xdce_div"
                        >
                        <td onclick="window.open('https://etherscan.io/token/0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">XDCE</td>
                        <td id="xdce_bal">0</td>
                        <td id="xdce_auto_bal">0</td>
                        <td id="xdce_bit">0</td>
                        <td id="xdce_indo">0</td>
                        <td id="xdce_lqd">0</td>
                        <td id="xdce_reserve">0</td>
                        <td id="xdce_tot">0</td>
                        <td id="user_xdce">0</td>
                        <td id="intrade_xdce">0</td>
                        <td id="total_xdce">0</td>

                    </tr>
                    <tr id="eth_div"
                        >
                        <td onclick="window.open('https://etherscan.io/address/0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">ETH</td>
                        <td id="eth_bal">0</td>
                        <td id="eth_auto_bal">0</td>
                        <td id="eth_bit">0</td>
                        <td id="eth_indo">0</td>
                        <td id="eth_lqd">0</td>
                        <td id="eth_reserve">0</td>
                        <td id="eth_tot">0</td>
                        <td id="user_eth">0</td>
                        <td id="intrade_eth">0</td>
                        <td id="total_eth">0</td>

                    </tr>
                    <tr id="btc_div"
                        >
                        <td onclick="window.open('https://www.blockchain.com/btc/address/3M4n1daBJZ34n5g6eBYmoCZAbJPSXDM5LG','newtab');">BTC</td>
                        <td id="btc_bal">0</td>
                        <td id="btc_auto_bal">0</td>
                        <td id="btc_bit">0</td>
                        <td id="btc_indo">0</td>
                        <td id="btc_lqd">0</td>
                        <td id="btc_reserve">0</td>
                        <td id="btc_tot">0</td>
                        <td id="user_btc">0</td>
                        <td id="intrade_btc">0</td>
                        <td id="total_btc">0</td>

                    </tr>
                    <tr id="bchabc_div"
                        >
                        <td onclick="window.open('https://explorer.bitcoin.com/bch/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">BCHABC</td>
                        <td id="bchabc_bal">0</td>
                        <td id="bchabc_auto_bal">0</td>
                        <td id="bchabc_bit">0</td>
                        <td id="bchabc_indo">0</td>
                        <td id="bchabc_lqd">0</td>
                        <td id="bchabc_reserve">0</td>
                        <td id="bchabc_tot">0</td>
                        <td id="user_bchabc">0</td>
                        <td id="intrade_bchabc">0</td>
                        <td id="total_bchabc">0</td>

                    </tr>
                    <tr id="bchsv_div"
                        >
                        <td onclick="window.open('https://bsvexplorer.info/#/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">BCHSV</td>
                        <td id="bchsv_bal">0</td>
                        <td id="bchsv_auto_bal">0</td>
                        <td id="bchsv_bit">0</td>
                        <td id="bchsv_indo">0</td>
                        <td id="bchsv_lqd">0</td>
                        <td id="bchsv_reserve">0</td>
                        <td id="bchsv_tot">0</td>
                        <td id="user_bchsv">0</td>
                        <td id="intrade_bchsv">0</td>
                        <td id="total_bchsv">0</td>

                    </tr>
                    <tr id="xrp_div"
                        >
                        <td onclick="window.open('https://bithomp.com/explorer/r3i9zk9WGNWKsp8qoPyuxDNapJm8qqK3Bj','newtab');">XRP</td>
                        <td id="xrp_bal">0</td>
                        <td id="xrp_auto_bal">0</td>
                        <td id="xrp_bit">0</td>
                        <td id="xrp_indo">0</td>
                        <td id="xrp_lqd">0</td>
                        <td id="xrp_reserve">0</td>
                        <td id="xrp_tot">0</td>
                        <td id="user_xrp">0</td>
                        <td id="intrade_xrp">0</td>
                        <td id="total_xrp">0</td>

                    </tr>
                    <tr id="usdt_div"
                        >
                        <td onclick="window.open('https://www.omniexplorer.info/address/13btDig1JPAbnmbUnDsBwZJXybnuheCixG','newtab');">USDT</td>
                        <td id="usdt_bal">0</td>
                        <td id="usdt_auto_bal">0</td>
                        <td id="usdt_bit">0</td>
                        <td id="usdt_indo">0</td>
                        <td id="usdt_lqd">0</td>
                        <td id="usdt_reserve">0</td>
                        <td id="usdt_tot">0</td>
                        <td id="user_usdt">0</td>
                        <td id="intrade_usdt">0</td>
                        <td id="total_usdt">0</td>

                    </tr>
                    <tr id="usdc_div"
                        >
                        <td onclick="window.open('https://etherscan.io/token/0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">USDC</td>
                        <td id="usdc_bal">0</td>
                        <td id="usdc_auto_bal">0</td>
                        <td id="usdc_bit">0</td>
                        <td id="usdc_indo">0</td>
                        <td id="usdc_lqd">0</td>
                        <td id="usdc_reserve">0</td>
                        <td id="usdc_tot">0</td>
                        <td id="user_usdc">0</td>
                        <td id="intrade_usdc">0</td>
                        <td id="total_usdc">0</td>

                    </tr>


                </table>
            </div>
            <div class="table-container">

                <div>
                    <h2>&nbsp;&nbsp;Latest 25 Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                       id="myTable">
                    <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Email</th>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Recieved Total</th>
                        <th>Type</th>
                        <th>Pair</th>
                        <th>Status</th>
                        <th>Updated time</th>

                    </tr>
                    <tbody>
                   
                    </tbody>
                    </thead>
                </table>
            </div>
        </div>
    </div>
@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    {{--@include('panel1.layout.dashboard_script')--}}
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#myTable').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false
            });

            $('#xdc_bal').text('Loading');
            $('#m_xdc_bal').text('Loading');
            $('#xdce_bal').text('Loading');
            $('#eth_bal').text('Loading');
            $('#btc_bal').text('Loading');
            $('#bchabc_bal').text('Loading');
            $('#bchsv_bal').text('Loading');
            $('#usdc_bal').text('Loading');
            $('#usdt_bal').text('Loading');
            $('#xrp_bal').text('Loading');

            update_user_balance();
            update_admin_balance();
            update_admin_status();
            
            setInterval(function () {
                update_user_balance();
                update_admin_balance();
                update_admin_status();
            }, 300000);

        });
        
        function update_user_balance() {
                    
                    
        }

        function update_admin_balance() {
               
            
        }

        function update_admin_status() {    
            
        }

        function update_stats() {
            update_user_balance();
            update_admin_balance();
            update_admin_status();
            
        }

    </script>
@endsection