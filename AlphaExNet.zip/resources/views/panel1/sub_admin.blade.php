@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Sub Admin</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Sub Admin</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                

                                <form action="{{url('adminv3/sub_admin')}}" method="post" class="form-horizontal" id="updateSettings">
                                    <h3>Sub Admin Form</h3>
                                    {{ csrf_field() }}
                                    
                                                    <div class="form-group">
                                                        <label for="text" class="col-sm-3 control-label">Role Name:</label>

                                                        <div class="col-sm-9 controls">
                                                            <div class="row">
                                                                <div class="col-xs-6 input-group">
                                                                    <select class="form-control" id ="name"name="name" >
                                                                        @foreach($result as $res)
                                                                        <option value="{{$res->name}}">{{$res->name}}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                
                                    <div class="form-group"><label class="col-sm-3 control-label">First Name: </label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-6 input-group">

                                                    <input type="text" name="firstName" class="form-control" id="firstName"  />
                                                    
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group"><label class="col-sm-3 control-label">Last Name: </label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-6 input-group">

                                                    <input type="text"  name="lastName" class="form-control" id="lastName"  />
                                                    
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group"><label class="col-sm-3 control-label">Email: </label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-6 input-group">
                                                <input type="text"  name="email" class="form-control" id="email"  />
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-sm-3 control-label">Password: </label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-6 input-group">
                                                <input type="text"  name="password" class="form-control" id="password"  />
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <hr/>
                                    <button type="submit" class="btn btn-green btn-block">Submit</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    


@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>

        $("#form").submit(function (){
            event.preventDefault();
        });
        function showDiv() {
   document.getElementById('updateSettings').style.display = "block";
   document.getElementById('form').style.display = "none";
}
       
    </script>

@endsection


