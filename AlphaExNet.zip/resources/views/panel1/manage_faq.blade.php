@extends("panel1.layout.admin_new_layout")
@section("content")

<div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                <div class="page-header pull-left">
                    <div class="page-title">FAQ</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

                    <li class="active">FAQ</li>
                </ol>
                <div class="clearfix"></div>
            </div>


            <div class="col-md-12 clearfix">
                @include('panel1.alert')
              <button class="btn btn-danger pull-right" id="confirm" data-toggle="modal" data-target="#myModal">Update FAQ?</button>
          </div>

            <div class="page-content">
  <div class="row">
                    <div class="col-md-12">




                        <div id="tableactionTabContent" class="tab-content">
                        <a href="{{url('adminv3/add_faqs')}}" class="btn btn-info pull-right">Add FAQ</a>
                             <div id="table-table-tab" class="tab-pane fade in active">
                                <div class="row">
                                    <div class="col-lg-12">

                                        <div class="table-container">

                                            <table class="table table-hover table-striped table-bordered table-advanced tablesorter" id="myTable">
                                                <thead>
                                               <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Category</th>
                                                <th>Question</th>
                                                <th>Answer</th>
                                                <th>Updated at</th>
                                                <th>Action</th>
                                               </tr>
                                                <tbody>
                                                
                                                @if($result)
                                                @foreach($result as $key => $val)
                                                        <tr>
                                                            <td>{{$key+1}}</td>
                                                            <td>{{$val->name}}</td>
                                                            <td>{{$val->category}}</td>
                                                            <td>{{$val->title}}</td>
                                                            <td>{{$val->description}}</td>
                                                            <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                                            <td>
                                                                <a href="{{url('adminv3/view_faq/'.$val->uniqueId)}}"
                                                                title="view"><i class="fa fa-eye"></i></a>
                                                                
                                                                
                                                            </td>
                                                        </tr>
                                                @endforeach
                                                @endif
                                                </tbody>
                                                </thead></table>

                                        </div>

                                        <div class="row">
                                        <div class="col-lg-0">

                                        </div>
                                        <div class="col-lg-6 text-left">
                                            <div class="pagination-panel">
                                                <ul class="pagination">

                                                <li><input class="form-controlp" type="number" id="pagesearch">&nbsp;{{$pagination->lastPage}}&nbsp;<button style="margin-top: -3px;width:50px;height:41px;" class="btn btn-default" onclick="searchpage()"><i
                                                                    class="fa fa-search"></i></button></li>
                                                <li><p style='color:red; display:none;'id='error_message'>Page Number should be between 0 to {{$pagination->lastPage}}</p></li>
                                                </ul>
                                            
                                            </div>
                                        </div>
                                    <div class="col-lg-6">

                                    </div>
                                    <div class="col-lg-6 text-right">
                                    <div class="pagination-panel">
                                    @include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/manage_faq')])

                                    </div>
                                    </div>
                                </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="modal fade" id="myModal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            Update FAQ?
                        </div>
                        <div class="modal-body">
                            Are you sure you want to update the FAQs?
                        </div>

              <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                        <button id="confirmed" class="btn btn-success success" onclick="confirmation()">Yes</button>
                    </div>
                </div>
            </div>
            </div>



@endsection

@section('script')
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>


<script type="text/javascript">
    $(document).ready(function(){
    $('#myTable').DataTable({
        "searching": true,
        "paging":   false,
        "ordering": true,
        "info":     false,
    });
});
function searchpage(){
    var input = document.getElementById("pagesearch").value;
    var x = document.getElementById("error_message");
    var url = window.location.hostname;
    if(input>=1 && input<='{{$pagination->lastPage}}'){
        window.location.href = "/adminv3/manage_faq/"+input;
        x.style.display = "none";
    }
    else{
        x.style.display = "block";
    }
    
}

function confirmation()
{
    window.location.href="{{URL::to('/adminv3/confirmation')}}";
}

</script>



@endsection
