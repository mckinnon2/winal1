@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Trading Fee</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

            <li class="active">Fee</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div class="row mtl">

                    <div class="col-md-12">

                        <div id="generalTabContent" class="tab-content">

                            <div id="tab-edit" class="tab-pane fade in active">
                                <form action="{{url('adminv3/set_trading_fee')}}" method="post" class="form-horizontal">
                                    <h3>Trading Fee </h3>
                                    {{ csrf_field() }}

                                    <div class="col-md-12">
                                    <div class="form-group"><label for="inputLastName" class="col-md-3 control-label">Currency Name</label>

                                        <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-8"><p class="form-control-static">
                                                        <select class="form-control" id ="name" onchange="dropDownSet()"name="name" >
                                                            @foreach ($result as $res)
                                                                <option value="{{ $res->name }}" > 
                                                                {{ $res->name }} 
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>                  
                                  @foreach ($result as $res)
                                  @if($res->name == "Ripple")
                                    <div class="form-group"><label class="col-sm-3 control-label" style="display:none;"> Currency ID</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="uniqueId" id="uniqueId" value="{{ $res->uniqueId }}"  style="display:none;"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-sm-3 control-label"> Buy Fees</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="buy_fee" id="buyFee" value="{{ $res->buyFee }}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group"><label class="col-sm-3 control-label"> Sell Fees</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="sell_fee" id="sellFee" value="{{ $res->sellFee }}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-sm-3 control-label"> Minimum Scale</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="min_scale" id="minScale" value="{{ $res->minScale }}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-sm-3 control-label"> Maximum Scale</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="max_scale" id="maxScale" value="{{ $res->maxScale }}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-sm-3 control-label"> Deposit Fees</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="deposit_fee" id="depositFee" value="{{ $res->depositFee }}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-sm-3 control-label">Withdrawal Normal Fees</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="withdrawal_normal_fee" id="withdrawalNormalFee" value="{{ $res->withdrawalNormalFee }}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-sm-3 control-label"> Withdrawal Fast Fees</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="withdrawal_fast_fee" id="withdrawalFastFee" value="{{$res->withdrawalFastFee}}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                      
                                    <div class="form-group"><label class="col-sm-3 control-label" >UpdatedAt</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="updatedt" id="updatedAt" value="{{$res->updatedAt}}" disabled />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   @endif 
                                 @endforeach
                                    <hr/>
                                    <button type="submit" class="btn btn-green btn-block">Update</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $("#buyFee").keydown(function (evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode
            if (charCode > 31 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 106) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                return false;
            return true;
        });

        $("#sellFee").keydown(function (evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode
            if (charCode > 31 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 106) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                return false;
            return true;
        });

    function dropDownSet(){
        var dropdown = document.getElementById("name");
        var selection = dropdown.value;
        
        var data = {!! json_encode($result) !!};
        $.each(data, function(k,v) {
            // console.log(v.name, selection)
            if(v.name==selection){
                // console.log(v.name==selection)
                 uniqueId.value=v.uniqueId;
                 minScale.value=v.minScale;
                 maxScale.value=v.maxScale;
                 buyFee.value=v.buyFee;
                 uniqueId.value=v.uniqueId;
                 sellFee.value=v.sellFee;
                 depositFee.value=v.depositFee;
                 withdrawalNormalFee.value=v.withdrawalNormalFee;
                 withdrawalFastFee.value=v.withdrawalFastFee;
                 updatedAt.value=v.updatedAt;
                 
            }
        })
    }
    </script>
@endsection