@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Partnership</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Partnership</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal"  method="post" action="{{url('adminv3/view_partnership/'.$uniqueId)}}">
                                {{ csrf_field() }}
                                    <h3>Partnership Details: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">


                                            <div class="row">


                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="mail" class="col-md-2 control-label"><strong>Name:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">{{$result->name }}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>
                                                                Email:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">
                                                                {{$result->email}} 
                                                            </p></div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>Partnership Type:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->type}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                class="col-md-2 control-label"><strong>Partnership Options:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->options}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Details:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->description}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Status:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">@if($result->status==1)
                                                                    Pending
                                                                @else
                                                                    Viewed
                                                                @endif</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                               
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Updated At:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{strftime("%Y-%m-%d %H:%M:%S",strtotime($result->updatedAt))}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                </div>

                                                <!-- <button id="reason_submit" type="submit" class="btn btn-green btn-block">Update</button> -->

                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="clearfix"></div>
    


@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>


    
        $("#form").submit(function (){
            event.preventDefault();
        });

        
    </script>

@endsection


