@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Referral Extra</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

            <li class="active">Referral Extra</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div class="row mtl">

                    <div class="col-md-12">

                        <div id="generalTabContent" class="tab-content">
                            @if($view=='add')
                                <div id="tab-edit" class="tab-pane fade in active">
                                    <form action="{{url('adminv3/add_referral_bonus')}}" method="post" class="form-horizontal">
                                        <h3>Add New Referral</h3>
                                        {{ csrf_field() }}

                                        <div class="form-group"><label class="col-sm-3 control-label">Users </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9"><input type="text" value="{{old('users')}}" name="users" class="form-control"  /></div>
                                                </div>
                                            </div>
                                        </div>




                                        <div class="form-group"><label class="col-sm-3 control-label">Bonus </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9">
                                                        <input class="form-control" name="bonus" id="content" value="{{old('bonus')}}" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <hr/>
                                        <button type="submit" class="btn btn-green btn-block">Add</button>
                                    </form>
                                </div>
                            @endif

                            @if($view=='edit')
                                <div id="tab-edit" class="tab-pane fade in active">
                                    <form action="{{url('adminv3/update_referral_bonus/'.$id)}}" method="post" class="form-horizontal">
                                        <h3>Update Referral Extra</h3>
                                        {{ csrf_field() }}

                                        <div class="form-group"><label class="col-sm-3 control-label">Users </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9"><input type="text" value="{{$result->users}}" name="users" class="form-control"  /></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-sm-3 control-label">Bonus </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9">
                                                        <input class="form-control" name="bonus" id="content" value="{{$result->bonus}}"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <hr/>
                                        <button type="submit" class="btn btn-green btn-block">Update</button>
                                    </form>
                                </div>
                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



@endsection

@section('script')
@endsection