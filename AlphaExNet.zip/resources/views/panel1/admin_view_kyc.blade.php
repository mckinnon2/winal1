@extends("panel1.layout.admin_new_layout")
@section("content")
<div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                <div class="page-header pull-left">
                    <div class="page-title">User KYC Details</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

                    <li class="active">KYC Details</li>
                </ol>
                <div class="clearfix"></div>
            </div>


            <div class="page-content">
  <div class="row">
                    <div class="col-md-12">

                 @include('panel1.alert')

                        <div id="tableactionTabContent" class="tab-content">
                             <div id="table-table-tab" class="tab-pane fade in active">
                                <div class="row">
                                    <div class="col-lg-12">

                                     <form class="form-horizontal" method="post" action="{{url('adminv3/admin_view_kyc/'.$uniqueId)}}" >
                                    {{ csrf_field() }}
                                         <h3>KYC Details: </h3>
                                      <div class="panel-body pan">
                                      <div class="form-body pal">


                              <div class="row">

                               <div class="col-md-12">
                                <div class="form-group"><label for="inputFirstName" class="col-md-2 control-label"><strong>User ID:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">{{ $result->userId }}</p></div>
                                </div>
                            </div>  <br>



                            <div class="col-md-12">
                                <div class="form-group"><label for="inputFirstName" class="col-md-2 control-label"><strong>First Name:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">{{$result->firstName}}</p></div>
                                </div>
                            </div> <br>



                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Last Name:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">{{$result->lastName}}</p></div>
                                </div>
                            </div> <br>
                            
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Gender:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">
                                        @if($result->gender == 1)
                                            Female
                                        @else
                                            Male
                                        @endif
                                    </p></div>
                                </div>
                            </div> <br>
                            
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Date Of Birth:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">{{$result->dob}}</p></div>
                                </div>
</div> <br>
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Country:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">{{$result->countryName}}</p></div>
                                </div>
                            </div> <br>
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Document Type:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">{{$result->docTypeName}}</p></div>
                                </div>
                            </div> <br>
                            
                                <div class="col-md-12">
                                    <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Document No:</strong></label>

                                        <div class="col-md-10"><p class="form-control-static">{{$result->docUniqueNo}}</p></div>
                                    </div>
                                </div> <br>
                            

                             <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Updated date:</strong></label>

                                    <div class="col-md-10"><p class="form-control-static">{{strftime("%Y-%m-%d %H:%M:%S",strtotime($result->updatedAt))}}</p></div>
                                </div>
                            </div><br>



                             <h3>KYC Status: </h3>
                           <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>KYC status:</strong></label>

                                    <div class="col-md-10 form-control-static">
                                        @if($result->status=="Pending")
                                            <p class="label label-warning">Pending</p>
                                        @elseif($result->status=="Approved")
                                            <p class="label label-success">Approved</p>
                                        @elseif($result->status=="Rejected")
                                            <p class="label label-danger">Rejected</p>
                                        @else
                                        <p class="label label-warning">Submitted</p>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            @if(strpos(json_encode($result), 'image') !== false)
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Image:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                      <img src="{{$result->image}}" style="width: 150px;height: 100px;" id="proof1" data-zoom-image="/src.php?name={{$result->image}}">
                                    </p>
                                    </div>
                                    <div class="col-md-4">
                                    
                                    </div>
                                </div>
                            </div>
                            @else
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Image:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                      <img src="" style="width: 150px;height: 100px;" id="proof1" data-zoom-image="">
                                    </p>
                                    </div>
                                    <div class="col-md-4">
                                    
                                    </div>
                                </div>
                            </div>
                            @endif
                            @if(strpos(json_encode($result), 'image_2') !== false)
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Image:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                      <img src="{{$result->image_2}}" style="width: 150px;height: 100px;" id="proof1" data-zoom-image="/src.php?name={{$result->image}}">
                                    </p>
                                    </div>
                                    <div class="col-md-4">
                                    
                                    </div>
                                </div>
                            </div>
                            @else
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Image:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                      <img src="" style="width: 150px;height: 100px;" id="proof1" data-zoom-image="">
                                    </p>
                                    </div>
                                    <div class="col-md-4">
                                    
                                    </div>
                                </div>
                            </div>
                            @endif
                            @if(strpos(json_encode($result), 'image_3') !== false)
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Image:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                      <img src="{{$result->image_3}}" style="width: 150px;height: 100px;" id="proof1" data-zoom-image="/src.php?name={{$result->image}}">
                                    </p>
                                    </div>
                                    <div class="col-md-4">
                                    
                                    </div>
                                </div>
                            </div>
                            @else
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Image:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                      <img src="" style="width: 150px;height: 100px;" id="proof1" data-zoom-image="">
                                    </p>
                                    </div>
                                    <div class="col-md-4">
                                    
                                    </div>
                                </div>
                            </div>
                           @endif
                            <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Over All Status:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                    <select class="form-control" id ="verify_status"name="verify_status" onchange="kycscr(this.value)">
                                        <option value="Pending" @if($result->status=="Pending")selected @endif>Pending</option>
                                        <option value="Approved" @if($result->status=="Approved")selected @endif >Approve</option>
                                        <option value="Rejected" @if($result->status=="Rejected")selected @endif>Reject</option>
                                        <option value="Submitted" @if($result->status=="Submitted")selected @endif>Submitted</option>
                                    </select>
                                    </p></div>
                                </div>
                            </div>

                            <div id="kyc_reason" style="display: none;">
                             <div class="col-md-12">
                                <div class="form-group"><label for="inputLastName" class="col-md-2 control-label"><strong>Reason:</strong></label>

                                    <div class="col-md-6"><p class="form-control-static">
                                   <textarea class="form-control" id= "description"name="description"></textarea>
                                    </p></div>
                                </div>
                            </div>

                            </div>

                        <small>Note: If you have approve please select proof checkbox</small>

                        </div>
                    </div>
                     </div>
                      <hr/>
                        <button type="submit" class="btn btn-green btn-block">Update</button>

                      </form>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

@endsection

@section('script')
<script type="text/javascript">
    // $("#proof1").elevateZoom();
    // $("#proof2").elevateZoom();
    // $("#proof3").elevateZoom();

    function kycscr(id)
    {
        if(id=="Rejected")
        {
            $("#kyc_reason").show();
        }
        else
        {
             $("#kyc_reason").hide();
        }
    }
</script>
@endsection

