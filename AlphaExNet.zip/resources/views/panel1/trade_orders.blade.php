@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title"> Trade Transactions</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active"> Trade Transactions</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">


                                <div class="row">
                                    <form id="form_filters" method="get">
                                    <div class="col-md-3">
                                            <lable>Start date</lable>
                                            <input type="text" id="startDate" name="startDate"
                                                   value="{{ app('request')->input('startDate') }}" class="form-control">
                                        </div>
                                        <div class="col-md-3">
                                            <lable>End date</lable>
                                            <input type="text" id="endDate" name="endDate"
                                                   value="{{ app('request')->input('endDate') }}" class="form-control">
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <lable>Search</lable>
                                            <input type="text" id="search" name="search"
                                                   value="{{ app('request')->input('search') }}" class="form-control">
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <lable>Pair</lable>
                                            <select class="form-control" name="pair" id='pair' >
                                                <option value=" ">All</option>
                                                @if($currency)
                                                    @foreach($currency->result as $key=>$val)
                                                <option value="{{$val->name}}"
                                                        @if(app('request')->input('pair')==$val->name) selected @endif>
                                                        {{$val->name}}
                                                </option>
                                                @endforeach
                                                @endif

                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <lable>Status</lable>
                                            <select class="form-control" name="status" id='status' >
                                                <option value=" ">All</option>
                                                <option value="completed"
                                                        @if(app('request')->input('status')=='completed') selected @endif>
                                                        Completed
                                                </option>
                                                <option value="active"
                                                        @if(app('request')->input('status')=='active') selected @endif>
                                                        Active
                                                </option>
                                                <option value="cancelled"
                                                        @if(app('request')->input('status')=='cancelled') selected @endif>
                                                        Cancelled
                                                </option>
                                                <option value="partially"
                                                        @if(app('request')->input('status')=='partially') selected @endif>
                                                        Partially
                                                </option>
                                                <option value="partially cancelled"
                                                        @if(app('request')->input('status')=='partially') selected @endif>
                                                        Partially Cancelled
                                                </option>

                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <lable>Type</lable>
                                            <select class="form-control" name="type" id='type' >
                                                <option value=" ">All</option>
                                                <option value="buy"
                                                        @if(app('request')->input('type')=='buy') selected @endif>
                                                        Buy
                                                </option>
                                                <option value="sell"
                                                        @if(app('request')->input('type')=='sell') selected @endif>
                                                        Sell
                                                </option>
                                               

                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                        <button style="margin-top: 17px;" class="btn btn-default" onclick="{{url('adminv3/trade_orders/'.$page)}}"><i
                                                        class="fa fa-search"></i></button>
                                                        </div>

                                        {{csrf_field()}}
                                    </form>
                                </div>

                                
                                <div class="table-container"style="overflow-x:auto;">

                                    <table class="table table-hover table-striped table-bordered table-advanced tablesorter scrollit"
                                           id="myTable">
                                        <thead>
                                        <tr>
                                            <!-- <th>#</th> -->
                                            <th>ID</th>
                                            <th>Order ID</th>
                                            <th>Email</th>
                                            <th>Pair</th>
                                            <th>Amount</th>
                                            <th>Price</th>
                                            <th>Fee</th>
                                            <th>Total</th>
                                            <th>Recieved Total</th>
                                            <th>Type</th>
                                            <th>Status</th>
                                            <th>Updated at</th>
                                            
                                            
                                            
                                            

                                        </tr>
                                        <tbody>
                                        @if($result)
                                            @foreach($result as $key => $val)
                                            
                                                <tr>
                                                    <td>{{$key+1}}</td>
                                                    <td>{{$val->orderId}}</td> 
                                                    <td>{{$val->email}}</td> 
                                                    <td>{{$val->name}}</td>
                                                    <td>{{rtrim(rtrim(sprintf('%.10f',$val->originalQty),'0'),'.')}}</td>                                               
                                                    <td>{{rtrim(rtrim(sprintf('%.10f', $val->price), '0'),'.')}}</td>
                                                    <td>{{rtrim(rtrim(sprintf('%.4f', $val->fee),'0'),'.')}}</td>
                                                    <td>{{rtrim(rtrim(sprintf('%.10f',$val->total),'0'),'.')}}</td>
                                                    <td>{{rtrim(rtrim(sprintf('%.10f',$val->receivedTotal),'0'),'.')}}</td>
                                                    <td>{{$val->type}}</td>
                                                    
                                                    @if($val->status == "completed")
                                                        <td>CMPLT</td>
                                                    @elseif($val->status == "cancelled")
                                                        <td>CXL</td>
                                                    @elseif($val->status == "partially")
                                                        <td>PRTL</td>
                                                    @elseif($val->status == "active")
                                                        <td>PNDG</td>
                                                    @else
                                                        <td>PRTL-CXL</td>
                                                    @endif
                                                    
                                                    <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                                    
                                                    
                                                   
                                                
                                            @endforeach
                                        @endif
                                        </tbody>
                                    </table>

                                </div>
                                <div class="row">
                                <div class="col-lg-0">

                                    </div>
                                    <div class="col-lg-6 text-left">
                                        <div class="pagination-panel">
                                            <ul class="pagination">
                    
                                            <li><input class="form-controlp" type="number" id="pagesearch">&nbsp;{{$pagination->lastPage}}&nbsp;<button style="margin-top: -3px;width:50px;height:41px;" class="btn btn-default" onclick="searchpage()"><i
                                                                class="fa fa-search"></i></button></li>
                                            <li><p style='color:red; display:none;'id='error_message'>Page Number should be between 0 to {{$pagination->lastPage}}</p></li>
                                            </ul>
                                        
                                        </div>
                                    </div>
                                    <div class="col-lg-6">

                                    </div>
                                    <div class="col-lg-6 text-right">
                                    <div class="pagination-panel">
                                    
                                    @include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/trade_orders')])

                                    </div>
                                    </div>
                                </div>


                            
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



@endsection

@section('script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#myTable').DataTable({
                "searching": false,
                "paging":   false,
                "ordering": true,
                "info":     false,
                // "lengthChange": false,
                // "pageLength" : 25
            });
        });

        $(function () {
            $("#startDate,#endDate").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd',
                
            });
        });
function searchpage(){
    var input = document.getElementById("pagesearch").value;
    var x = document.getElementById("error_message");
    var url1 = window.location.search;
    if(input>=1 && input<={{$pagination->lastPage}}){
        window.location.href = "/adminv3/trade_orders/"+input+url1;
        x.style.display = "none";
    }
    else{
        x.style.display = "block";
    }
    
}
        

        function hideRow(type) {
            $.each(type, function(k,v) {
                v.style.display = 'none';
            });
        }

        function showRow(type) {
            $.each(type, function(k,v) {
                v.style.display = '';
            });
        }
    </script>

    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <!-- <script src="{{URL::asset('datepicker/jquery-1.12.4.js')}}"></script> -->
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    
@endsection
