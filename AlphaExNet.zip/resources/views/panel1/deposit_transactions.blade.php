@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Deposit Transactions</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Deposit Transactions</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">


                                <div class="row">
                                    <form id="form_filters" method="get">
                                    <div class="col-md-3">
                                            <lable>Start date</lable>
                                            <input type="text" id="startDate" name="startDate"
                                                   value="{{ app('request')->input('startDate') }}" class="form-control">
                                        </div>
                                        <div class="col-md-3">
                                            <lable>End date</lable>
                                            <input type="text" id="endDate" name="endDate"
                                                   value="{{ app('request')->input('endDate') }}" class="form-control">
                                        </div>
                                        
                                        <div class="col-md-2">
                                            <lable>Search</lable>
                                            <input type="text" id="search_id" name="search"
                                                   value="{{ app('request')->input('search') }}" class="form-control">
                                        </div>
                                        
                                        <div class="col-md-2">
                                            <lable>Currency</lable>
                                            <select class="form-control" name="currencyName" id='currencyName' >
                                                <option value=" ">All</option>
                                                @if(strpos(json_encode($currency), 'data') !== false) 
                                                    @if($currency)
                                                        @foreach($currency->data as $key=>$val)
                                                    <option value="{{$val->symbol}}"
                                                            @if(app('request')->input('currencyName')==$val->symbol) selected @endif>
                                                            {{$val->symbol}}
                                                    </option>
                                                    @endforeach
                                                    @endif
                                                @endif

                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                        <button style="margin-top: 17px;" class="btn btn-default" onclick="{{url('adminv3/deposit_transactions/'.$page)}}"><i
                                                        class="fa fa-search"></i></button>
                                                        </div>
                                        {{csrf_field()}}
                                    </form>
                                </div>


                                <div class="table-container">

                                    <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                                           id="myTable">
                                        <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Transaction ID</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Amount</th>
                                            <th>Currency Name</th>
                                            <!-- <th>Transaction Type</th> -->
                                            <!-- <th>Fee</th> -->
                                            <!-- <th>Fee Percent</th> -->
                                            <!-- <th>Transfer Amount</th> -->
                                            <!-- <th>Description</th> -->
                                            <!-- <th>From Address</th> -->
                                            <!-- <th>To Address</th> -->
                                            <!-- <th>Wallet Transaction ID</th> -->
                                            <!-- <th>Payment Type</th> -->
                                            <th>Status</th>
                                            <th>Updated Date</th>


                                        </tr>
                                        <tbody>
                                        @if(strpos(json_encode($result),'transactionId') !== false) 
                                            @if($result)
                                                @foreach($result as $key=>$val)
                                                    
                                                        <tr>
                                                            <td>{{$key+1}}</td>
                                                            <td>{{$val->transactionId}}</td>
                                                            <td><a class="form-control-static" target="_blank"
                                                                href="{{url('adminv3/user_transactions_detail/'.$val->userId)}}">
                                                                @if($val->lastName == "null")
                                                                    {{$val->firstName}} </a></td>
                                                                @else
                                                                {{$val->firstName}} {{$val->lastName}}</a></td>
                                                                @endif
                                                            <td>{{$val->email}}</td>
                                                            <td>{{rtrim(rtrim(sprintf('%.10f',$val->amount),'0'),'.')}}</td>
                                                            <td>{{$val->currencyName}}</td>
                                                            <!-- <td>{{$val->transactionType}}</td> -->
                                                            <!-- <td>{{$val->fee}}</td> -->
                                                            
                                                            <!-- <td>{{$val->feePercent}}</td>
                                                            <td>{{$val->transferAmount}}</td>
                                                            <td>{{$val->description}}</td>
                                                            <td>{{$val->fromAddress}}</td>
                                                            <td>{{$val->toAddress}}</td>
                                                            <td>{{$val->walletTxId}}</td>
                                                            <td>{{$val->paymentType}}</td> -->
                                                            @if($val->status == "Completed")
                                                                <td>CMPLT</td>
                                                            @elseif($val->status == "Cancelled")
                                                                <td>CXL</td>
                                                            @elseif($val->status == "Pending")
                                                                <td>PNDG</td>
                                                            @endif
                                                            <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                                        </tr>
                                                    
                                                @endforeach
                                            @endif
                                        @endif
                                        </tbody>
                                        </thead>

                                    </table>

                                </div>
                                <div class="row">
                                <div class="col-lg-0">

                                </div>
                                <div class="col-lg-6 text-left">
                                    <div class="pagination-panel">
                                        <ul class="pagination">

                                        <li><input class="form-controlp" type="number" id="pagesearch">&nbsp;{{$pagination->lastPage}}&nbsp;<button style="margin-top: -3px;width:50px;height:41px;" class="btn btn-default" onclick="searchpage()"><i
                                                            class="fa fa-search"></i></button></li>
                                        <li><p style='color:red; display:none;'id='error_message'>Page Number should be between 0 to {{$pagination->lastPage}}</p></li>
                                        </ul>
                                    
                                    </div>
                                </div>
                                    <div class="col-lg-6">

                                    </div>
                                    <div class="col-lg-6 text-right">
                                    <div class="pagination-panel">
                                    @include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/deposit_transactions')])

                                    </div>
                                    </div>
                                </div>
                                

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



@endsection

@section('script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    
    <script type="text/javascript">
           $(document).ready(function(){
            $('#myTable').DataTable({
                "searching": false,
                "paging":   false,
                "ordering": true,
                "info":     false,
               
            });
        });
        function searchpage(){
            var input = document.getElementById("pagesearch").value;
            var x = document.getElementById("error_message");
            var url1 = window.location.search;
            if(input>=1 && input<={{$pagination->lastPage}}){
                window.location.href = "/adminv3/deposit_transactions/"+input+url1;
                x.style.display = "none";
            }
            else{
                x.style.display = "block";
            }
    
        }
        </script>
       


    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    <script>
        $(function () {
            $("#startDate,#endDate").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd',
                
            });
        });
    </script>

@endsection