@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Referral Bonus</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

            <li class="active">Referral Bonus</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                             <div id="table-table-tab" class="tab-pane fade in active">
                                <div class="row">
                                    <div class="col-lg-12">
                                    <div class="row">
                                    <form id="form_filters" method="get">

                                        
                                        <div class="col-md-3">
                                            <lable>Search</lable>
                                            <input type="text" id="search" name="search"
                                                   value="{{ app('request')->input('search') }}" class="form-control">
                                        </div>
                                        
                                        
                                        <div class="col-md-3">
                                            <button style="margin-top: 17px;" class="btn btn-default"><i
                                                        class="fa fa-search"></i></button>
                                                   
                                        </div>

                                        {{csrf_field()}}
                                    </form>
                                </div>
                                        <div class="table-container">

                                            <table class="table table-hover table-striped table-bordered table-advanced tablesorter" id="myTable">
                                                <thead>
                                               <tr>
                                            <th>#</th>
                                            <th>Referral User</th>
                                            <th>Referred User</th>
                                            <th>Referral Amount</th>
                                            <th>Referred Amount</th>
                                            <th>Updated Time</th>                                        

                                        </tr>
                                                <tbody>
                                               
                                        @foreach($result as $key=>$val)
                                        <tr>
                                            <td>{{$key+1}}</td>
                                            <td>{{$val->referralUser}}</td>
                                            <td>{{$val->referredlUser}}</td>
                                            <td>{{$val->referralAmount}}</td>
                                            <td>{{$val->referredAmount}}</td>
                                            <td>{{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}</td>
                                                                                   
                                        </tr>
                                        @endforeach
                                      
                                                </tbody>
                                                </thead></table>

                                        </div>
                                        <div class="col-lg-6 text-left">
                                        <div class="pagination-panel">
                                            <ul class="pagination">

                                            <li><input class="form-controlp" type="number" id="pagesearch">&nbsp;{{$pagination->lastPage}}&nbsp;<button style="margin-top: -3px;width:50px;height:41px;" class="btn btn-default" onclick="searchpage()"><i
                                                                class="fa fa-search"></i></button></li>
                                            <li><p style='color:red; display:none;'id='error_message'>Page Number should be between 0 to {{$pagination->lastPage}}</p></li>
                                            </ul>
                                        
                                        </div>
                                    </div>
                                        <div class="col-lg-6">

                                        </div>
                                        <div class="col-lg-6 text-right">
                                        <div class="pagination-panel">
                                        @include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/user_referral')])

                                        </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#myTable').DataTable({
                "searching": false,
                "paging":   false,
                "ordering": true,
                "info":     false,
                // "lengthChange": false,
                // "pageLength" : 25
            });
        });
    </script>
@endsection