@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Users</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Users</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal" id="form">
                                    <h3>User Details: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">


                                            <div class="row">

                                            
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="mail" class="col-md-2 control-label"><strong>Email:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">{{$result->email }}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>User
                                                                Name:</strong></label>
                                                                @if($result->lastName != "null")
                                                                <div class="col-md-10"><p class="form-control-static">
                                                                        {{$result->firstName}} {{$result->lastName}}
                                                                    </p></div>
                                                                    @else
                                                                    <div class="col-md-10"><p class="form-control-static">
                                                                        {{$result->firstName}} 
                                                                    </p></div>
                                                                    @endif
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>First
                                                                Name:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->firstName}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>

                                            @if($result->lastName != "null")
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Last
                                                                Name:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->lastName}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>
                                            @endif
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Created
                                                                date:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{strftime("%Y-%m-%d %H:%M:%S",strtotime($result->createdAt))}}</p>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Status:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">
                                                                @if($result->accountStatus=="Active")
                                                                    Active
                                                                @else
                                                                    Deactive
                                                                @endif
                                                            </p></div>
                                                    </div>
                                                </div>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Image:</strong></label>

                                                        <div class="col-md-10">
                                                            <img src="{{URL::asset('uploads/users/profileimg')}}/noimage.png"
                                                                 style="width: 150px;height: 150px;"/>
                                                        </div>
                                                    </div>
                                                </div>
                                               
                                                </div>

                                               
                                                    <button class="btn btn-danger pull-right" id="delete" data-toggle="modal" data-target="#myModal">Delete Account</button>
                                                
                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="clearfix"></div>
    <div class="modal fade" id="myModal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
            <form class="form-horizontal" action="{{url('adminv3/view_user/'.$uniqueId)}}" method="post"  enctype="multipart/form-data">
                <div class="modal-header" style="color: red;">
                    <h4><strong>Delete Account!</strong></h4>
                    {{csrf_field()}}
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this Account?
                    <br>
                    <br>
                    <strong><p style="color: red;">Note : Account once deleted can't be recovered. So please be sure about deleting the account.</p></strong>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                    <button class="btn btn-success success" >Yes</button>
                </div>
            </form>
            </div>
        </div>
    </div>


@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>

        $("#form").submit(function (){
            event.preventDefault();
        });

        function confirmation()
        {
            var user_id = '{{$uniqueId}}';
            // user_id = btoa(user_id);
            console.log(user_id);
            
        }
    </script>

@endsection


