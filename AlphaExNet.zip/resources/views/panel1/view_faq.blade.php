@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">FAQ</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">FAQ</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal" id='form'>
                                {{ csrf_field() }}
                                    <h3>FAQ Details: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">


                                            <div class="row">


                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="mail" class="col-md-2 control-label"><strong>Name:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">{{$result->name }}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>
                                                                Category:</strong></label>

                                                        <div class="col-md-10"><p class="form-control-static">
                                                                {{$result->category}} 
                                                            </p></div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputFirstName"
                                                                                   class="col-md-2 control-label"><strong>Question:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->title}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                class="col-md-2 control-label"><strong>Answer:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->description}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>

                                                
                                                
                                                               
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Updated At:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->updatedAt}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                </div>

                                                <button class="btn btn-green pull-right" id="delete"
                                                            data-toggle="modal" data-target="#updtfaq">Update
                                                        FAQ
                                                    </button>
                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="modal fade" id="updtfaq" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
         data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <form id="profile-update" action="{{url('/adminv3/view_faq/'.$uniqueId)}}" method="post"
                          enctype="multipart/form-data">
                        <h3>FAQ Details: </h3>
                        {{csrf_field()}}
                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Category</label>
                                    <input 
                                           id="category" name="category"
                                           type="text" class="form-control"
                                           value="{{ $result->category }}"
                                    >
                                    <div class="error_gap">
                                        <label id="email-error" for="category" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" name="name"
                                           class="form-control"
                                           value="{{ $result->name}}"
                                           >
                                    <div class="error_gap">
                                        <label id="first_name-error" for="name" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>

                            </div>


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Question</label>
                                    <input type="text" name="title"
                                           class="form-control"
                                           value="{{ $result->title }}"
                                           >
                                    <div class="error_gap">
                                        <label id="last_name-error" for="title" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>

                            </div>

                           
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Answer</label>
                                    <input type="text" name="description"
                                           class="form-control"
                                           value="{{ $result->description }}"
                                           >
                                    <div class="error_gap">
                                        <label id="address-error" for="description" generated="true"
                                               style="display: none;" class="error"></label>
                                    </div>
                                </div>
                            </div>
                            
                           
                        </div>
                        <hr/>
                        <div class="form-group">
                            <button type="submit"
                                    class="btn btn-green">
                                Save Changes
                            </button>
                            <button
                                    class="btn btn-danger " data-dismiss='modal'>
                                Cancel Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>
    


@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>


    
        $("#form").submit(function (){
            event.preventDefault();
        });

        
    </script>

@endsection


