@extends("panel1.layout.admin_new_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Users</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('adminv3/adminhome')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Users</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel1.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">


                                <div class="row">
                                    <form id="form_filters" method="get">
                                    <div class="col-md-3">
                                            <lable>Start date</lable>
                                            <input type="text" id="startDate" name="startDate"
                                                   value="{{ app('request')->input('startDate') }}" class="form-control">
                                        </div>
                                        <div class="col-md-3">
                                            <lable>End date</lable>
                                            <input type="text" id="endDate" name="endDate"
                                                   value="{{ app('request')->input('endDate') }}" class="form-control">
                                        </div>
                                        
                                        
                                        <div class="col-md-2">
                                            <lable>Search</lable>
                                            <input type="text" id="search" name="search"
                                                   value="{{ app('request')->input('search') }}" class="form-control">
                                        </div>
                                        <div class="col-md-2">
                                            <label>KYC Status</label>
                                            <select class="form-control" name="documentStatus" id="documentStatus">
                                                <option value="">All</option>
                                                <option value="Approved"
                                                        @if(app('request')->input('documentStatus')=='Approved') selected @endif>
                                                        Approved
                                                </option>
                                                <option value="Pending"
                                                        @if(app('request')->input('documentStatus')=='Pending') selected @endif>
                                                    Pending
                                                </option>
                                                <option value="Rejected"
                                                        @if(app('request')->input('documentStatus')=='Rejected') selected @endif>
                                                        Rejected
                                                </option>
                                                <option value="Submitted"
                                                        @if(app('request')->input('documentStatus')=='Submitted') selected @endif>
                                                        Submitted
                                                </option>
                                            </select>
                                        </div>
                                        
                                        
                                        <div class="col-md-2">
                                        <button style="margin-top: 17px;" class="btn btn-default" onclick="{{url('adminv3/user_list/'.$page)}}"><i
                                                        class="fa fa-search"></i></button>
                                                        </div>

                                        {{csrf_field()}}
                                    </form>
                                </div>

                                <div class="table-container">

                                    <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                                           id="myTable">
                                        <thead>
                                        <tr>
                                            <th>#Id</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Country</th>
                                            <th>Verification</th>
                                            <th>KYC Status</th>
                                            <th>Status</th>
                                            <th>Updated date</th>
                                            <th>Action</th>
                                            <!-- <th> A/W</th> -->

                                        </tr>
                                        <tbody>
                                        @if($result)
                                            @foreach($result as $key => $val)
                                                
                                                    <tr>
                                                        <td>{{$key+1}}</td>
                                                        <td>
                                                            <a class="form-control-static" target="_blank"
                                                            href="{{url('adminv3/user_transactions_detail/'.$val->uniqueId)}}">
                                                                @if($val->lastName == "null")
                                                                    {{$val->firstName}}
                                                                @else
                                                                {{$val->firstName}} {{$val->lastName}}
                                                                @endif 
                                                                </a>

                                                             
                                                        </td>
                                                        <td>{{$val->email}}</td>
                                                        <td>@if($val->country==NULL)
                                                        <p>-</p>
                                                        @else
                                                            {{$val->country}}
                                                        @endif
                                                        </td>
                                                        <td>
                                                        @if($val->userVerified === true) 
                                                                <p class="label label-success">Verified</a>
                                                                </p>
                                                        
                                                        @elseif($val->userVerified === false)
                                                            <p class="label label-danger">Unverified</a>
                                                            </p>
                                                        @elseif($val->userVerified === null)
                                                            <p class="label label-warning">Null</a>
                                                            <!-- <pre>{!!json_encode($val->userVerified)!!}</pre> -->
                                                            </p>
                                                        @endif
                                                            
                                                        </td>
                                                    
                                                        <td>
                                                            @if($val->documentStatus=="Approved")
                                                                <p class="label label-success">Approved</p>
                                                            @elseif($val->documentStatus=="Pending")
                                                                <p class="label label-warning">Pending</p>
                                                            @elseif($val->documentStatus=="Submitted")
                                                                <p class="label label-warning">Submitted</p>
                                                            @elseif($val->documentStatus== null)
                                                                <p class="label label-warning">Pending</p>
                                                            @else
                                                                <p class="label label-danger">Rejected</p>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            @if($val->accountStatus == "Active") 
                                                                <p class="label label-success">Active</a>
                                                                </p>
                                                            @elseif($val->accountStatus == "Blocked")
                                                            <p class="label label-danger">Blocked</a>
                                                                </p>
                                                                @else
                                                                <p class="label label-danger">Deactive</a>
                                                                </p>
                                                            @endif
                                                        </td>
                                                        <td>
                                                        {{strftime("%Y-%m-%d %H:%M:%S",strtotime($val->updatedAt))}}
                                                        
                                                        </td>
                                                        <td>
                                                            <a href="#" onclick="update_status('{{$val->uniqueId}}','{{$val->userVerified}}')"
                                                            title="status"><i class="fa fa-cog"></i></a>
                                                            <a href="{{url('adminv3/view_user/'.$val->uniqueId)}}"
                                                            title="view"><i class="fa fa-eye"></i></a>
                                                            <a href="#" onclick="update_account('{{$val->uniqueId}}','{{$val->accountStatus}}')"
                                                            title="account_status"><i class="fa fa-ban"></i></a>
                                                        </td>
                                                        
                                                    </tr>
                                                
                                            @endforeach
                                        @endif
                                        </tbody>
                                    </table>

                                </div>
                                <div class="row">
                                    <div class="col-lg-0">

                                    </div>
                                    <div class="col-lg-6 text-left">
                                        <div class="pagination-panel">
                                            <ul class="pagination">

                                            <li><input class="form-controlp" type="number" id="pagesearch">&nbsp;{{$pagination->lastPage}}&nbsp;<button style="margin-top: -3px;width:50px;height:41px;" class="btn btn-default" onclick="searchpage()"><i
                                                                class="fa fa-search"></i></button></li>
                                            <li><p style='color:red; display:none;'id='error_message'>Page Number should be between 0 to {{$pagination->lastPage}}</p></li>
                                            </ul>
                                        
                                        </div>
                                    </div>
                                    <div class="col-lg-6">

                                    </div>
                                    <div class="col-lg-6 text-right">
                                    <div class="pagination-panel">
                                    @include('panel1.pagination', ['paginator' => $pagination,'url' => url('/adminv3/user_list')])

                                    </div>
                                    </div>
                                </div>
                                


                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



@endsection

@section('script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
    
        $(document).ready(function(){
            $('#myTable').DataTable({
                "searching": false,
                "paging":   false,
                "ordering": true,
                "info":     false
            });
        });
    </script>

<script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script type="text/javascript">

        // function user_verified(user_id) {
        //     $.get("{{url('ajax/user_verification')}}/" + user_id, function (data) {
        //         if (data == 1) {
        //             document.location.reload();
        //         }
        //     });
        // }

        // function auto_withdrawal(user_id) {
        //     $.get("{{url('ajax/auto_withdrawal')}}/" + user_id, function (data) {
        //         if (data == 1) {
        //             document.location.reload();
        //         }
        //     });
        // }
       
        function update_status(uniqueId,userVerified)
        {
           
            $.ajax({
                url:'{{url('adminv3/status_user/')}}',
                method:'post',
                data:{'uniqueId':uniqueId, 'userVerified':userVerified},
               
            }).done(function(data){
                location.reload();
            });
        }
        function update_account(uniqueId,accountStatus)
        {
           
            $.ajax({
                url:'{{url('adminv3/account_status/')}}',
                method:'post',
                data:{'uniqueId':uniqueId, 'accountStatus':accountStatus},
               
            }).done(function(data){
                location.reload();
            });
        }
        function searchpage(){
            var input = document.getElementById("pagesearch").value;
            var x = document.getElementById("error_message");
            var url1 = window.location.search;
            if(input>=1 && input<={{$pagination->lastPage}}){
                window.location.href = "/adminv3/user_list/"+input+url1;
                x.style.display = "none";
            }
            else{
                x.style.display = "block";
            }
    
        }
        $(function () {
            $("#startDate,#endDate").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd',
                
            });
        });

    </script>

    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <!-- <script src="{{URL::asset('datepicker/jquery-1.12.4.js')}}"></script> -->
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    
@endsection
