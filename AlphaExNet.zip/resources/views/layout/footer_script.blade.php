<div class="scroll-top page-scroll visible-xs visible-sm"> <a class="btn btn-primary" href="#page-top"> <i class="fa fa-chevron-up"></i> </a> </div>
<!-- jQuery -->
<script src="{{URL::asset('front')}}/assets/js/jquery-1.12.4.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="{{URL::asset('front')}}/assets/js/bootstrap.min.js"></script>
<!-- Plugin JavaScript -->
<script src="{{URL::asset('front')}}/assets/js/jquery.easing.min.js"></script>
<script src="{{URL::asset('front')}}/assets/js/classie.js"></script>
<script src="{{URL::asset('front')}}/assets/js/cbpAnimatedHeader.js"></script>
<!-- Custom Theme JavaScript -->
<script src="{{URL::asset('front')}}/assets/js/main.js"></script>

<script src="{{URL::asset('front')}}/assets/js/bootstrap-select.min.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function()
	{
		setTimeout(function()
		{
			$(".alert").fadeOut(3000);
		},2000);
	});
</script>