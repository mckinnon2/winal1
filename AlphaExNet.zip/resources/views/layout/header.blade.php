<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="{{get_meta_keywords()}}">
<meta name="description" content="{{get_meta_description()}}">
<meta name="author" content="indsoft">
<meta name="csrf-token" content="{{ csrf_token() }}">

<title>{{get_meta_title()}}</title>


    <link rel="apple-touch-icon" sizes="57x57" href="{{URL::asset('front')}}/assets/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="{{URL::asset('front')}}/assets/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="{{URL::asset('front')}}/assets/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="{{URL::asset('front')}}/assets/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="{{URL::asset('front')}}/assets/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="{{URL::asset('front')}}/assets/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="{{URL::asset('front')}}/assets/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="{{URL::asset('front')}}/assets/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="{{URL::asset('front')}}/assets/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="{{URL::asset('front')}}/assets/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="{{URL::asset('front')}}/assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="{{URL::asset('front')}}/assets/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="{{URL::asset('front')}}/assets/favicon/favicon-16x16.png">

<!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
<link href="{{URL::asset('front')}}/assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="{{URL::asset('front')}}/assets/css/main.css" rel="stylesheet">
<link href="{{URL::asset('front')}}/assets/css/responsive.css" rel="stylesheet">
<!-- Custom Fonts -->
<link href="{{URL::asset('front')}}/assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
<link href="{{URL::asset('front')}}/assets/datatables/dataTables.bootstrap.min.css" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link href="{{URL::asset('front')}}/assets/css/bootstrap-select.min.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="https://code.highcharts.com/css/highcharts.css">
<style>
.highcharts-color-1 {
  fill: grey;
  stroke: grey;
   opacity: 0.5 ;
}
</style>

<style type="text/css">
	.error
	{
		color: red;
	}
</style>
</head>
