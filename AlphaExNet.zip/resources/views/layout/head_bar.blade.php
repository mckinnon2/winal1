<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header page-scroll">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
       @if(Session::has('alphauserid'))
      <a class="navbar-brand" href="{{url('/dashboard')}}"><img src="{{URL::asset('uploads/logo')}}/{{get_config('site_logo')}}" height="75px" style="margin-top:-25px;"> </a>
      @else
      <a class="navbar-brand" href="{{url('/')}}"><img src="{{URL::asset('uploads/logo')}}/{{get_config('site_logo')}}" height="75px" style="margin-top:-25px;"> </a>
      @endif
       </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
      @if(Session::has('alphauserid'))
   <!--    <li class="{{front_class('profile')}}"><a href="{{url('profile')}}">MY profile</a></li> -->
    <li class="{{front_class('dashboard')}}"><a href="{{url('dashboard')}}">Dashboard</a></li>
       <!--  <li class="{{front_class('exchange')}}"><a href="{{url('exchange')}}">Exchange</a></li> -->
       <li class="{{front_class('ico')}}"><a href="{{url('ico')}}">ICO</a></li>
        <li class="{{front_class('trade')}}"><a href="{{url('trade')}}">Trade</a></li>
      <li class="{{front_class('wallet')}}"><a href="{{url('wallet')}}">Wallet</a></li>
      <li class="{{front_class('trade_history')}}"><a href="{{url('trade_history')}}">Order Book</a></li>
      <li><a href="{{url('logout')}}">Log Out</a></li>
      @else
       <li class="{{front_class('')}}"><a href="{{url('/')}}">Home</a></li>
        <li class="{{front_class('login')}}"><a href="{{url('/login')}}">Sign In</a></li>
        <li class="{{front_class('register')}}"><a href="{{url('/register')}}">Create Account</a></li>
        <li class="{{front_class('contact_us')}}"><a href="{{url('/contact_us')}}">Support</a></li>
        @endif
      </ul>
    </div>
    <!-- /.navbar-collapse -->
  </div>
  <!-- /.container-fluid -->
</nav>