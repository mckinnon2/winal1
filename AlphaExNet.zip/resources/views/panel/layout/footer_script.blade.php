<script src="{{ URL::asset('control/js/jquery-1.10.2.min.js') }}"></script>
<script src="{{ URL::asset('control/js/jquery-migrate-1.2.1.min.js') }}"></script>
<script src="{{ URL::asset('control/js/jquery-ui.js') }}"></script>
<!--loading bootstrap js-->
<script src="{{ URL::asset('control/vendors/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('control/vendors/bootstrap-hover-dropdown/bootstrap-hover-dropdown.js') }}"></script>

<script src="{{ URL::asset('control/js/respond.min.js') }}"></script>
<script src="{{ URL::asset('control/vendors/metisMenu/jquery.metisMenu.js') }}"></script>
<script src="{{ URL::asset('control/vendors/slimScroll/jquery.slimscroll.js') }}"></script>
<script src="{{ URL::asset('control/vendors/jquery-cookie/jquery.cookie.js') }}"></script>
{{--<script src="{{ URL::asset('control/vendors/iCheck/icheck.min.js') }}"></script>--}}
{{--<script src="{{ URL::asset('control/vendors/iCheck/custom.min.js') }}"></script>--}}
<script src="{{ URL::asset('control/vendors/jquery-news-ticker/jquery.news-ticker.js') }}"></script>
<script src="{{ URL::asset('control/js/jquery.menu.js') }}"></script>
{{--<script src="{{ URL::asset('control/vendors/jquery-pace/pace.min.js') }}"></script>--}}
<script src="{{ URL::asset('control/vendors/holder/holder.js') }}"></script>
<script src="{{ URL::asset('control/vendors/responsive-tabs/responsive-tabs.js') }}"></script>

<script src="{{ URL::asset('control/js/main.js') }}"></script>

