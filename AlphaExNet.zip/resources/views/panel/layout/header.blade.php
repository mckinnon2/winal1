<head><title>Admin | Alphaex</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="{{ URL::asset('control/images/icons/favicon.ico') }}">
    <link rel="apple-touch-icon" href="{{ URL::asset('control/images/icons/favicon.png') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/jquery-ui-1.10.4.custom/css/ui-lightness/jquery-ui-1.10.4.custom.min.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/font-awesome/css/font-awesome.min.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/bootstrap/css/bootstrap.min.css') }}">
    <!--LOADING STYLESHEET FOR PAGE-->

    <!-- <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/calendar/zabuto_calendar.min.css') }}"> -->
    <!--Loading style vendors-->
    {{--<link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/animate.css/animate.css') }}">--}}
    {{--<link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/jquery-pace/pace.css') }}">--}}
    {{--<link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/iCheck/skins/all.css') }}">--}}
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/vendors/jquery-news-ticker/jquery.news-ticker.css') }}">
    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/css/themes/style3/orange-blue.css') }}" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="{{ URL::asset('control/css/style-responsive.css') }}">
     <link href="{{ URL::asset('control/css/patternLock.css') }}"  rel="stylesheet" type="text/css" />

    <link type="text/css" rel="stylesheet" href="{{URL::asset('control/vendors/dataTables.bootstrap.min.css')}}">
    {{--<link type="text/css" rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">--}}
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css">
</head>