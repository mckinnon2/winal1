 <nav id="sidebar" role="navigation" data-step="2" data-intro="Template has &lt;b&gt;many navigation styles&lt;/b&gt;" data-position="right" class="navbar-default navbar-static-side">
            <div class="sidebar-collapse menu-scroll">
                <ul id="side-menu" class="nav">
                    <li class="user-panel">
                        <div class="thumb"><img src="https://cdn4.iconfinder.com/data/icons/general24/png/128/administrator.png" alt="" class="img-circle"/></div>
                        <div class="info"><p>{{get_adminprofile('XDC_username')}}</p>
                            <ul class="list-inline list-unstyled">
                                <li><a href="{{url('prashaasak/profile')}}" data-hover="tooltip" title="Profile"><i class="fa fa-user"></i></a></li>

                                <li><a href="{{url('prashaasak/site_settings')}}" data-hover="tooltip" title="Setting" ><i class="fa fa-cog"></i></a></li>
                                <li><a href="{{url('prashaasak/logout')}}" data-hover="tooltip" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </li>

                    <li class="{{admin_class('home').admin_class('')}}"><a href="{{url('prashaasak/home')}}"><i class="fa fa-tachometer fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Dashboard</span></a></li>


                    <?php
if (admin_class('users') != '' || admin_class('userbalance') != "" || admin_class('openingbalance') != "" || admin_class('closingbalance') != "" || admin_class('kyc_users') != "") {
	$class = "active";
	$in = 'in';
	$style = "auto";
} else {
	$class = "";
	$in = '';
	$style = "0 px";
}

?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-user fa-fw"><div class="icon-bg bg-pink"></div>
                            </i><span class="menu-title">Manage Users</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                            <li ><a href="{{ url('prashaasak/users') }}" @if(admin_class('users')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">User List</span></a></li>
                            <li ><a href="{{ url('prashaasak/non_email_verified') }}" @if(admin_class('userbalance')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">UnVerified Email</span></a></li>
                            <li ><a href="{{ url('prashaasak/userbalance') }}" @if(admin_class('userbalance')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">User Balance</span></a></li>
                            <li ><a href="{{ url('prashaasak/users_opening_balance') }}" @if(admin_class('openingbalance')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Opening Balance</span></a></li>
                            <li ><a href="{{ url('prashaasak/users_closing_balance') }}" @if(admin_class('closingbalance')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Closing Balance</span></a></li>

                            <li ><a href="{{ url('prashaasak/kyc_users') }}" @if(admin_class('kyc_users')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">KYC verfication</span></a></li>
                            <li ><a href="{{ url('prashaasak/users_balance_validation?currency=XDC') }}" @if(admin_class('kyc_users')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Balance Verification</span></a></li>

                        </ul>


                    </li>


                      <?php
if (admin_class('transactions') != ''|| admin_class('pending_history') != "" || admin_class('trade_history') != "" || admin_class('deposit_history') != "" || admin_class('withdraw_history') != "" || admin_class('updated_history') != "" || admin_class('swap_history') !=""|| admin_class('ico_history')!= "") {
	$class = "active";
	$in = 'in';
	$style = "auto";
} else {
	$class = "";
	$in = '';
	$style = "0 px";
}

?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-exchange fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Transactions</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                    <!--  <li ><a href="{{ url('prashaasak/transactions') }}" @if(admin_class('transactions')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Exchange Transactions</span></a></li> -->

                        <li ><a href="{{ url('prashaasak/trade_history') }}" @if(admin_class('trade_history')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Trade Transactions</span></a></li>

                        <li ><a href="{{ url('prashaasak/pending_history') }}" @if(admin_class('pending_history')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Pending Transactions</span></a></li>

                        <li ><a href="{{ url('prashaasak/deposit_history') }}" @if(admin_class('deposit_history')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Deposit Transactions</span></a></li>

                        <li ><a href="{{ url('prashaasak/updated_history') }}" @if(admin_class('updated_history')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Updated Transactions</span></a></li>

                        <li ><a href="{{ url('prashaasak/withdraw_history') }}" @if(admin_class('withdraw_history')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Send Transactions (Cryptocurrency)</span></a></li>

                        <li ><a href="{{ url('prashaasak/swap_history') }}" @if(admin_class('swap_history')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Swap Transaction</span></a></li>

                        <li ><a href="{{ url('prashaasak/ico_history') }}" @if(admin_class('ico_history')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">ICO Transaction</span></a></li>

                        <li ><a href="{{ url('prashaasak/trade_mapping') }}" @if(admin_class('trade_mapping')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Trade Mapping</span></a></li>

                     </ul>


                    </li>


                     <li class="{{admin_class('profit')}}"><a href="{{url('prashaasak/profit')}}"><i class="fa fa-signal fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Admin Profit</span></a></li>



                    <?php
if (admin_class('market_price') != '' || admin_class('allprice') != "") {
	$class = "active";
	$in = 'in';
	$style = "auto";
} else {
	$class = "";
	$in = '';
	$style = "0 px";
}

?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-money fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Market Price</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('prashaasak/market_price') }}" @if(admin_class('market_price')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">Market Price - XDC</span></a></li>

                      <li ><a href="{{ url('prashaasak/allprice') }}" @if(admin_class('allprice')!='')style='color:#dc6767' @endif ><i class="fa fa-align-left"></i><span class="submenu-title">All Prices</span></a></li>



                     </ul>


                    </li>


                     <?php
if (admin_class('trading_fee') != '') {
	$class = "active";
	$in = 'in';
	$style = "auto";
} else {
	$class = "";
	$in = '';
	$style = "0 px";
}

?>

                    <li class="<?php echo $class; ?>"><a href="#"><i class="fa fa-usd fa-fw"><div class="icon-bg bg-pink"></div>
                    </i><span class="menu-title">Trading Fee</span><span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level collapse <?php echo $in; ?>" style="height: <?php echo $style; ?>;">
                     <li ><a href="{{ url('prashaasak/trading_fee/XDC-BTC') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-BTC</span></a></li>

                         <li ><a href="{{ url('prashaasak/trading_fee/XDC-BCHABC') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-BCHABC</span></a></li>

                         <li ><a href="{{ url('prashaasak/trading_fee/XDC-BCHSV') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-BCHSV</span></a></li>

                     <li ><a href="{{ url('prashaasak/trading_fee/XDC-ETH') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-ETH</span></a></li>

                     <li ><a href="{{ url('prashaasak/trading_fee/XDC-XRP') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-XRP</span></a></li>

                     <li ><a href="{{ url('prashaasak/trading_fee/XDC-XDCE') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-XDCE</span></a></li>

                         <li ><a href="{{ url('prashaasak/trading_fee/XDC-ET') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-ET</span></a></li>

                         <li ><a href="{{ url('prashaasak/trading_fee/XDC-USDT') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-USDT</span></a></li>

                         <li ><a href="{{ url('prashaasak/trading_fee/XDC-USDC') }}"  ><i class="fa fa-align-left"></i><span class="submenu-title">Fee XDC-USDC</span></a></li>

                     </ul>

                    </li>

                    <li class="{{admin_class('fee_config')}}"><a href="{{url('prashaasak/fee_config')}}"><i class="fa fa-money fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Fees / Limit Settings</span></a></li>

                    <li class="{{admin_class('cms')}}"><a href="{{url('prashaasak/cms')}}"><i class="fa fa-file-text fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage CMS</span></a></li>


                       <li class="{{admin_class('user_activity')}}"><a href="{{url('prashaasak/user_activity')}}"><i class="fa fa-user fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">User Activity</span></a></li>


                    <li class="{{admin_class('faq')}}"><a href="{{url('prashaasak/faq')}}"><i class="fa fa-question-circle fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage FAQ</span></a></li>

                     <li class="{{admin_class('mail_template')}}"><a href="{{url('prashaasak/mail_template')}}"><i class="fa fa-envelope fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage Email Template</span></a></li>


                     <li class="{{admin_class('contact_query')}}"><a href="{{url('prashaasak/contact_query')}}"><i class="fa fa-phone fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage Enquiry</span></a></li>

                     <li class="{{admin_class('whitelists')}}"><a href="{{url('prashaasak/whitelists')}}"><i class="fa fa-ban fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage IP Whitelists</span></a></li>

                     <li class="{{admin_class('meta_content')}}"><a href="{{url('prashaasak/meta_content')}}"><i class="fa fa-file-text fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Manage Meta content</span></a></li>

                    {{--<li class="{{admin_class('erc20_requests')}}"><a href="{{url('prashaasak/erc20_requests')}}"><i class="fa fa-file-text fa-fw">--}}
                                {{--<div class="icon-bg bg-orange"></div>--}}
                            {{--</i><span class="menu-title">Manage ERC20 Requests</span></a></li>--}}

                    <li class="{{admin_class('referral')}}"><a href="{{url('prashaasak/referral')}}"><i class="fa fa-group ">
                                <div class="icon-bg bg-orange"></div>
                            </i><span class="menu-title">Manage Referral Bonus</span></a></li>

                    <li class="{{admin_class('referral')}}"><a href="{{url('prashaasak/view_referral_earnings')}}"><i class="fa fa-group ">
                                <div class="icon-bg bg-orange"></div>
                            </i><span class="menu-title">View Referral Earnings</span></a></li>

                    <li class="{{admin_class('referral')}}"><a href="{{url('prashaasak/referral_extra')}}"><i class="fa fa-group ">
                                <div class="icon-bg bg-orange"></div>
                            </i><span class="menu-title">Manage Extra Referral Bonus</span></a></li>

                    <li class="{{admin_class('referral')}}"><a href="{{url('prashaasak/extra_earnings')}}"><i class="fa fa-group ">
                                <div class="icon-bg bg-orange"></div>
                            </i><span class="menu-title">View Extra Referral Earnings</span></a></li>

                    <li class="{{admin_class('reserve_balances')}}"><a href="{{url('prashaasak/reserve_balances')}}"><i class="fa fa-group ">
                                <div class="icon-bg bg-orange"></div>
                            </i><span class="menu-title">Manage Reserve Balances</span></a></li>

                </ul>
            </div>
        </nav>