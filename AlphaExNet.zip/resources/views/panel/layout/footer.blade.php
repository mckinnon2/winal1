<div id="footer">
                <div class="copyright">{{date('Y')}} © {{get_config('site_name')}}</div>
            </div>