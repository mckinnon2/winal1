@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Dashboard</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><a href="#" onclick="update_stats()"> <i class="fa fa-refresh"></i>&nbsp;&nbsp; Refresh
                    Balance</a> &nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>
            <li class="hidden"><a href="#">Dashboard</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
            <li class="active">Dashboard</li>
        </ol>
        <div class="clearfix"></div>
    </div>
    <!--END TITLE & BREADCRUMB PAGE--><!--BEGIN CONTENT-->
    <div class="page-content">
        <div id="tab-general">
            <div id="sum_box" class="row mbl">
                <div class="col-sm-6 col-md-3">
                    <div class="panel profit db mbm" onclick="window.location.href='{{url('prashaasak/users')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-group"></i></p><h4 class="value">
                                <span data-counter="" data-start="10" data-end="50" data-step="1"
                                      data-duration="0">{{dashboard_usercount()}}</span></h4>

                            <p class="description">Registered Users</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel income db mbm" onclick="window.location.href='{{url('prashaasak/trade_history')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-exchange"></i></p><h4>
                                <span>{{dashboard_totaltrans()}}</span></h4>

                            <p class="description">Total Transactions</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel task db mbm" onclick="window.location.href='{{url('prashaasak/profit')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-signal"></i></p><h4 class="value">
                                <span>{{number_format(dashbard_totalbtcprofit(),4,'.','')}}</span><span><i
                                            class="fa fa-btc"></i></span></h4>

                            <p class="description">Profit</p>


                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="panel visit db mbm" onclick="window.location.href='{{url('prashaasak/kyc_users')}}'"
                         style="cursor: pointer;">
                        <div class="panel-body"><p class="icon"><i class="icon fa fa-group"></i></p><h4 class="value">
                                <span>{{dashbard_totalkyc()}}</span></h4>

                            <p class="description">KYC verification</p>


                        </div>
                    </div>
                </div>
                {{--<div class="col-sm-6 col-md-3">--}}
                {{--<div class="panel visit db mbm" onclick="window.location.href='{{url('prashaasak/ico_listing')}}'" style="cursor: pointer;">--}}
                {{--<div class="panel-body"><p class="icon"><i class="icon fa fa-group"></i></p><h4 class="value"><span>{{dashboard_ico_listing_count()}}</span></h4>--}}

                {{--<p class="description">ICO verification</p>--}}


                {{--</div>--}}
                {{--</div>--}}
                {{--</div>--}}
                <div class="clearfix"></div>
            {{--admin xdc balance--}}
            <!-- <div class="col-sm-6 col-md-4">
                    <div class="panel db mbm" style="cursor: pointer;" id="xdc_div">
                        <div class="panel-body"
                             onclick="window.open('http://xinfin.info/account/0xb2b5b54b736e59b2a60aaf3bcc8109397562f769','newtab');">
                            <div class="row">
                                <div class="col-md-12">
                                    <div style="text-align: center"><i class="fa font50"><img
                                                    src="{{URL::asset('front')}}/assets/icons/XDC.png" class="stat-icon"
                                                    style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="xdc_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin XDC Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('XDC')}}</label>--}}
                    <label id="user_xdc">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('XDC')}}</label>--}}
                    <label id="intrade_xdc">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('XDC')+get_total_intradebalance('XDC')}}</label>--}}
                    <label id="total_xdc">0</label>
                </div>

            </div>


        </div>
    </div>
</div>

{{--admin mainnet-xdc balance--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="m_xdc_div">
                            <div class="panel-body"
                                 onclick="window.open('https://explorer.xinfin.network/addr/xdc2642835a88a0b307ba6b52b7b23876210a03812c','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/XDC.png" class="stat-icon"
                                                    style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="m_xdc_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin Mainnet-XDC Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('XDC')}}</label>--}}
                    <label id="user_m_xdc">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('XDC')}}</label>--}}
                    <label id="intrade_m_xdc">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('XDC')+get_total_intradebalance('XDC')}}</label>--}}
                    <label id="total_m_xdc">0</label>
                </div>

            </div>


        </div>
    </div>
</div>

{{--admin xdce balance--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="xdce_div">
                            <div class="panel-body"
                                 onclick="window.open('https://etherscan.io/token/0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/XDCE.png"
                                                    class="stat-icon" style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="xdce_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin XDCE Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('XDCE')}}</label>--}}
                    <label id="user_xdce">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
                    <label>0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('XDCE')}}</label>--}}
                    <label id="total_xdce">0</label>
                </div>

            </div>


        </div>
    </div>
</div>

{{--BTC Admin--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="btc_div">
                            <div class="panel-body"
                                 onclick="window.open('https://www.blockchain.com/btc/address/3M4n1daBJZ34n5g6eBYmoCZAbJPSXDM5LG','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/BTC.png" class="stat-icon"
                                                    style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="btc_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin BTC Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('BTC')}}</label>--}}
                    <label id="user_btc">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('BTC')}}</label>--}}
                    <label id="intrade_btc">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('BTC')+get_total_intradebalance('BTC')}}</label>--}}
                    <label id="total_btc">0</label>
                </div>

            </div>


        </div>
    </div>
</div>

{{--BCH Admin--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="bchabc_div">
                            <div class="panel-body"
                                 onclick="window.open('https://explorer.bitcoin.com/bch/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/BCHABC.png"
                                                    class="stat-icon" style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="bchabc_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin BCHABC Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('BCHABC')}}</label>--}}
                    <label id="user_bchabc">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('BCHABC')}}</label>--}}
                    <label id="intrade_bchabc">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('BCHABC')+get_total_intradebalance('BCHABC')}}</label>--}}
                    <label id="total_bchabc">0</label>
                </div>

            </div>
        </div>
    </div>
</div>

{{--BCHSV Admin--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="bchsv_div">
                            <div class="panel-body"
                                 onclick="window.open('https://bsvexplorer.info/#/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/BCHSV.png"
                                                    class="stat-icon" style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="bchsv_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin BCHSV Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('BCHSV')}}</label>--}}
                    <label id="user_bchsv">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('BCHSV')}}</label>--}}
                    <label id="intrade_bchsv">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('BCHSV')+get_total_intradebalance('BCHSV')}}</label>--}}
                    <label id="total_bchsv">0</label>
                </div>

            </div>
        </div>
    </div>
</div>

{{--ETH Admin--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="eth_div">
                            <div class="panel-body"
                                 onclick="window.open('https://etherscan.io/address/0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/ETH.png" class="stat-icon"
                                                    style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="eth_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin ETH Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('ETH')}}</label>--}}
                    <label id="user_eth">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('ETH')}}</label>--}}
                    <label id="intrade_eth">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('ETH')+get_total_intradebalance('ETH')}}</label>--}}
                    <label id="total_eth">0</label>
                </div>

            </div>


        </div>
    </div>
</div>

{{--XRP admin--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="xrp_div">
                            <div class="panel-body"
                                 onclick="window.open('https://bithomp.com/explorer/r3i9zk9WGNWKsp8qoPyuxDNapJm8qqK3Bj','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/XRP.png" class="stat-icon"
                                                    style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="xrp_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin XRP Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('XRP')}}</label>--}}
                    <label id="user_xrp">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('XRP')}}</label>--}}
                    <label id="intrade_xrp">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('XRP')+get_total_intradebalance('XRP')}}</label>--}}
                    <label id="total_xrp">0</label>
                </div>
            </div>
        </div>
    </div>
</div> -->

            {{--admin et balance--}}
            {{--<div class="col-sm-6 col-md-4">--}}
            {{--<div class="panel db mbm" style="cursor: pointer;">--}}
            {{--<div class="panel-body" onclick="window.open('http://testexplorer.energyecochain.com/account/0xa775b30d6be7ead0a55e64a6224bd083dac321a2','newtab');">--}}
            {{--<div class="row">--}}
            {{--<div class="col-md-12">--}}
            {{--<div style="text-align: center"><i class="fa font50"><img src="{{URL::asset('front')}}/assets/icons/ET.png" class="stat-icon" style="width: 50px;height: 50px;"></i></div>--}}
            {{--<div style="text-align: center"><p><h2>{{$et_bal}}</h2></p>--}}
            {{--<p class="description "><strong>Admin ET Balance</strong></p></div>--}}
            {{--</div>--}}
            {{--</div>--}}

            {{--<div class="row">--}}
            {{--<div class="col-md-4">--}}
            {{--<label><strong>Users:</strong></label>--}}
            {{--</div>--}}
            {{--<div class="col-md-8">--}}
            {{--<label>{{$user_et}}</label>--}}
            {{--</div>--}}

            {{--<div class="col-md-4">--}}
            {{--<label><strong>In Trade:</strong></label>--}}
            {{--</div>--}}
            {{--<div class="col-md-8">--}}
            {{--<label>{{$trade_et}}</label>--}}
            {{--</div>--}}


            {{--<div class="col-md-4">--}}
            {{--<label><strong>Total:</strong></label>--}}
            {{--</div>--}}
            {{--<div class="col-md-8">--}}
            {{--<label>{{$user_et+$trade_et}}</label>--}}
            {{--</div>--}}

            {{--</div>--}}



            {{--</div>--}}
            {{--</div>--}}
            {{--</div>--}}

            <!-- {{--admin usdt balance--}}
                    <div class="col-sm-6 col-md-4">
                        <div class="panel db mbm" style="cursor: pointer;" id="usdt_div">
                            <div class="panel-body"
                                 onclick="window.open('https://www.omniexplorer.info/address/13btDig1JPAbnmbUnDsBwZJXybnuheCixG','newtab');">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div style="text-align: center"><i class="fa font50"><img
                                                        src="{{URL::asset('front')}}/assets/icons/USDT.png"
                                                    class="stat-icon" style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="usdt_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin USDT Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('USDT')}}</label>--}}
                    <label id="user_usdt">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
                    {{--<label>{{get_total_intradebalance('USDT')}}</label>--}}
                    <label id="intrade_usdt">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
                    {{--<label>{{get_total_userbalance('USDT')+get_total_intradebalance('USDT')}}</label>--}}
                    <label id="total_usdt">0</label>
                </div>

            </div>


        </div>
    </div>
</div> -->

            {{--admin usdc balance--}}
            <!-- <div class="col-sm-6 col-md-4">
                    <div class="panel db mbm" style="cursor: pointer;" id="usdc_div">
                        <div class="panel-body"
                             onclick="window.open('https://etherscan.io/token/0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                            <div class="row">
                                <div class="col-md-12">
                                    <div style="text-align: center"><i class="fa font50"><img
                                                    src="{{URL::asset('front')}}/assets/icons/USDC.png"
                                                    class="stat-icon" style="width: 50px;height: 50px;"></i></div>
                                    <div style="text-align: center"><p>
                                        <h2><span id="usdc_bal">0</span></h2></p>
                                        <p class="description "><strong>Admin USDC Balance</strong></p></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Users:</strong></label>
                                </div>
                                <div class="col-md-8">
                                    {{--<label>{{get_total_userbalance('USDC')}}</label>--}}
                    <label id="user_usdc">0</label>
                </div>

                <div class="col-md-4">
                    <label><strong>In Trade:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_intradebalance('USDC')}}</label>--}}
                    <label id="intrade_usdc">0</label>
                </div>


                <div class="col-md-4">
                    <label><strong>Total:</strong></label>
                </div>
                <div class="col-md-8">
{{--<label>{{get_total_userbalance('USDC')+get_total_intradebalance('USDC')}}</label>--}}
                    <label id="total_usdc">0</label>
                </div>

            </div>


        </div>
    </div>
</div> -->


            </div>
            <div class="table-container">

                <div>
                    <h2>&nbsp;&nbsp;Admin Balance:</h2>
                    <br>
                </div>
                <table class="table table-hover table-bordered table-advanced tablesorter"
                       id="myTable">
                    <thead>
                    <tr>
                        <th style="background-color:white;"></th>
                        <th colspan="5" style="text-align:center!important;background-color:white;">Admin</th>
                        <th colspan="3" style="text-align:center!important;background-color:white;">Users</th>
                    </tr>
                    <tr>
                        <th>Currency</th>
                        <th>AlphaEx</th>
                        <th>BitFinex</th>
                        <th>Liquid</th>
                        <th>Reserve</th>
                        <th>Total</th>
                        <th>Users</th>
                        <th>In Trade</th>
                        <th>Total</th>

                    </tr>
                    </thead>
                    <tbody>
                    <tr id="m_xdc_div"
                        onclick="window.open('https://explorer.xinfin.network/addr/xdc2642835a88a0b307ba6b52b7b23876210a03812c','newtab');">
                        <td>Mainnet-XDC</td>
                        <td id="m_xdc_bal">0</td>
                        <td id="m_xdc_bit">0</td>
                        <td id="m_xdc_lqd">0</td>
                        <td id="m_xdc_reserve">0</td>
                        <td id="m_xdc_tot">0</td>
                        <td id="user_m_xdc">0</td>
                        <td id="intrade_m_xdc">0</td>
                        <td id="total_m_xdc">0</td>

                    </tr>
                    <tr id="xdc_div"
                        onclick="window.open('http://xinfin.info/account/0xb2b5b54b736e59b2a60aaf3bcc8109397562f769','newtab');">
                        <td>XDC</td>
                        <td id="xdc_bal">0</td>
                        <td id="xdc_bit">0</td>
                        <td id="xdc_lqd">0</td>
                        <td id="xdc_reserve">0</td>
                        <td id="xdc_tot">0</td>
                        <td id="user_xdc">0</td>
                        <td id="intrade_xdc">0</td>
                        <td id="total_xdc">0</td>

                    </tr>
                    <tr id="xdce_div"
                        onclick="window.open('https://etherscan.io/token/0x41ab1b6fcbb2fa9dced81acbdec13ea6315f2bf2?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                        <td>XDCE</td>
                        <td id="xdce_bal">0</td>
                        <td id="xdce_bit">0</td>
                        <td id="xdce_lqd">0</td>
                        <td id="xdce_reserve">0</td>
                        <td id="xdce_tot">0</td>
                        <td id="user_xdce">0</td>
                        <td id="intrade_xdce">0</td>
                        <td id="total_xdce">0</td>

                    </tr>
                    <tr id="eth_div"
                        onclick="window.open('https://etherscan.io/address/0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                        <td>ETH</td>
                        <td id="eth_bal">0</td>
                        <td id="eth_bit">0</td>
                        <td id="eth_lqd">0</td>
                        <td id="eth_reserve">0</td>
                        <td id="eth_tot">0</td>
                        <td id="user_eth">0</td>
                        <td id="intrade_eth">0</td>
                        <td id="total_eth">0</td>

                    </tr>
                    <tr id="btc_div"
                        onclick="window.open('https://www.blockchain.com/btc/address/3M4n1daBJZ34n5g6eBYmoCZAbJPSXDM5LG','newtab');">
                        <td>BTC</td>
                        <td id="btc_bal">0</td>
                        <td id="btc_bit">0</td>
                        <td id="btc_lqd">0</td>
                        <td id="btc_reserve">0</td>
                        <td id="btc_tot">0</td>
                        <td id="user_btc">0</td>
                        <td id="intrade_btc">0</td>
                        <td id="total_btc">0</td>

                    </tr>
                    <tr id="bchabc_div"
                        onclick="window.open('https://explorer.bitcoin.com/bch/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">
                        <td>BCHABC</td>
                        <td id="bchabc_bal">0</td>
                        <td id="bchabc_bit">0</td>
                        <td id="bchabc_lqd">0</td>
                        <td id="bchabc_reserve">0</td>
                        <td id="bchabc_tot">0</td>
                        <td id="user_bchabc">0</td>
                        <td id="intrade_bchabc">0</td>
                        <td id="total_bchabc">0</td>

                    </tr>
                    <tr id="bchsv_div"
                        onclick="window.open('https://bsvexplorer.info/#/address/bitcoincash:qrat6a4jscp7qqfuqquvrjnwha66uk7sfq2hs3cjut','newtab');">
                        <td>BCHSV</td>
                        <td id="bchsv_bal">0</td>
                        <td id="bchsv_bit">0</td>
                        <td id="bchsv_lqd">0</td>
                        <td id="bchsv_reserve">0</td>
                        <td id="bchsv_tot">0</td>
                        <td id="user_bchsv">0</td>
                        <td id="intrade_bchsv">0</td>
                        <td id="total_bchsv">0</td>

                    </tr>
                    <tr id="xrp_div"
                        onclick="window.open('https://bithomp.com/explorer/r3i9zk9WGNWKsp8qoPyuxDNapJm8qqK3Bj','newtab');">
                        <td>XRP</td>
                        <td id="xrp_bal">0</td>
                        <td id="xrp_bit">0</td>
                        <td id="xrp_lqd">0</td>
                        <td id="xrp_reserve">0</td>
                        <td id="xrp_tot">0</td>
                        <td id="user_xrp">0</td>
                        <td id="intrade_xrp">0</td>
                        <td id="total_xrp">0</td>

                    </tr>
                    <tr id="usdt_div"
                        onclick="window.open('https://www.omniexplorer.info/address/13btDig1JPAbnmbUnDsBwZJXybnuheCixG','newtab');">
                        <td>USDT</td>
                        <td id="usdt_bal">0</td>
                        <td id="usdt_bit">0</td>
                        <td id="usdt_lqd">0</td>
                        <td id="usdt_reserve">0</td>
                        <td id="usdt_tot">0</td>
                        <td id="user_usdt">0</td>
                        <td id="intrade_usdt">0</td>
                        <td id="total_usdt">0</td>

                    </tr>
                    <tr id="usdc_div"
                        onclick="window.open('https://etherscan.io/token/0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48?a=0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7','newtab');">
                        <td>USDC</td>
                        <td id="usdc_bal">0</td>
                        <td id="usdc_bit">0</td>
                        <td id="usdc_lqd">0</td>
                        <td id="usdc_reserve">0</td>
                        <td id="usdc_tot">0</td>
                        <td id="user_usdc">0</td>
                        <td id="intrade_usdc">0</td>
                        <td id="total_usdc">0</td>

                    </tr>


                </table>
            </div>
            <div class="table-container">

                <div>
                    <h2>&nbsp;&nbsp;Latest 25 Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped table-bordered table-advanced tablesorter"
                       id="myTable">
                    <thead>
                    <tr>

                        <th>User ID</th>
                        <th>Username</th>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>

                    </tr>
                    <tbody>
                    @if($trade_25)
                        @foreach($trade_25 as $key=>$val)
                            <tr>

                                <td>{{$val->user_id}}</td>
                                <td>{{get_user_details($val->user_id,'enjoyer_name')}}</td>
                                @if($val->type=='active'||$val->type=='partially')
                                    <td>{{number_format($val->updated_qty,'0','.','')}}</td>
                                @else
                                    <td>{{number_format($val->original_qty,'0','.','')}}</td>
                                @endif
                                <td>{{number_format($val->price,'8','.','')}}</td>
                                <td>{{number_format($val->fee,'9','.','')}}</td>
                                @if($val->status=='active'||$val->status=='cancelled')
                                    <td>{{number_format($val->total,'8','.','')}}</td>
                                @else
                                    <td>{{number_format($val->updated_total,'8','.','')}}</td>
                                @endif
                                <td>{{$val->type}}</td>
                                <td>{{$val->firstCurrency}}</td>
                                <td>{{$val->secondCurrency}}</td>
                                <td>{{$val->status}}</td>
                                <td>{{$val->updated_at}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    </thead>
                </table>
            </div>
        </div>
    </div>
@endsection
@section('script')

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    {{--@include('panel.layout.dashboard_script')--}}
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#myTable').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false
            });

            $('#xdc_bal').text('Loading');
            $('#m_xdc_bal').text('Loading');
            $('#xdce_bal').text('Loading');
            $('#eth_bal').text('Loading');
            $('#btc_bal').text('Loading');
            $('#bchabc_bal').text('Loading');
            $('#bchsv_bal').text('Loading');
            $('#usdc_bal').text('Loading');
            $('#usdt_bal').text('Loading');
            $('#xrp_bal').text('Loading');

            update_user_balance();
            update_admin_balance();
            update_admin_status();

            setInterval(function () {
                update_user_balance();
                update_admin_balance();
                update_admin_status();
            }, 300000);

        });

        function update_user_balance() {
                    @foreach($currencies as $currency)
            var curr = '{{$currency->currency_symbol}}';
            $.ajax({
                url: '/ajax/user_bal',
                method: 'get',
                data: {'curr': curr},
                success: function (data) {
                    data = JSON.parse(data);
                    var curr_bal = data.bal;
                    var intrade_curr_bal = data.intrade_curr_bal;
                    var curr_total = parseFloat(parseFloat(curr_bal) + parseFloat(intrade_curr_bal)).toFixed(4);
                    var curr = data.currency.toLowerCase();

                    $('#user_' + curr).text(curr_bal);
                    $('#intrade_' + curr).text(intrade_curr_bal);
                    $('#total_' + curr).text(curr_total);
                }
            });
            @endforeach
            $.ajax({
                url: '/ajax/user_bal',
                method: 'get',
                data: {'curr': 'M-XDC'},
                success: function (data) {
                    data = JSON.parse(data);
                    var curr_bal = data.bal;
                    var intrade_curr_bal = data.intrade_curr_bal;
                    var curr_total = parseFloat(parseFloat(curr_bal) + parseFloat(intrade_curr_bal)).toFixed(4);

                    $('#user_m_xdc').text(curr_bal);
                    $('#intrade_m_xdc').text(intrade_curr_bal);
                    $('#total_m_xdc').text(curr_total);
                }
            });
        }

        function update_admin_balance() {
                    @foreach($currencies as $currency)
            var curr = '{{$currency->currency_symbol}}';
            $('#' + curr.toLowerCase() + '_bal').text('Refreshing');
            $.ajax({
                url: '/ajax/admin_bal',
                method: 'get',
                data: {'curr': curr},
                success: function (data) {
                    
                    data = JSON.parse(data);
                    var bal = data.bal;
                    var reserve = data.reserve;
                    var bitfinex = data.bitfinex;
                    var liquid = data.liquid;
                    var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(liquid)).toFixed(4);
                    curr = data.currency;
                    $('#' + curr.toLowerCase() + '_bal').text(bal);
                    $('#' + curr.toLowerCase() + '_bit').text(bitfinex);
                    $('#' + curr.toLowerCase() + '_lqd').text(liquid);
                    $('#' + curr.toLowerCase() + '_reserve').text(reserve);
                    $('#' + curr.toLowerCase() + '_tot').text(tot);
                }
            });
            @endforeach
            $('#m_xdc_bal').text('Refreshing');
            $.ajax({
                url: '/ajax/admin_bal',
                method: 'get',
                data: {'curr': 'M-XDC'},
                success: function (data) {
                    data = JSON.parse(data);
                    var bal = data.bal;
                    var reserve = data.reserve;
                    var bitfinex = data.bitfinex;
                    var liquid = data.liquid;
                    var tot = parseFloat(parseFloat(bal) + parseFloat(reserve) + parseFloat(bitfinex) + parseFloat(liquid)).toFixed(4);
                    $('#m_xdc_bal').text(bal);
                    $('#m_xdc_bit').text(bitfinex);
                    $('#m_xdc_lqd').text(liquid);
                    $('#m_xdc_reserve').text(reserve);
                    $('#m_xdc_tot').text(tot);
                }
            });
        }

        function update_admin_status() {
                    @foreach($currencies as $currency)
            var curr = '{{$currency->currency_symbol}}';
            $.ajax({
                url: '/ajax/admin_status',
                method: 'get',
                data: {'curr': curr},
                success: function (data) {
                    data = JSON.parse(data);
                    var status = data.status;
                    curr = data.currency;
                    if (status == '1') {
                        $('#' + curr.toLowerCase() + '_div').css('background-color', '');
                    }
                    else {
                        $('#' + curr.toLowerCase() + '_div').css('background-color', '#ff9999');
                    }
                }
            });
            @endforeach
            $.ajax({
                url: '/ajax/admin_status',
                method: 'get',
                data: {'curr': 'M-XDC'},
                success: function (data) {
                    data = JSON.parse(data);
                    var status = data.status;
                    if (status == '1') {
                        $('#m_xdc_div').css('background-color', '');
                    } else {
                        $('#m_xdc_div').css('background-color', '#ff9999');
                    }
                }
            });
        }

        function update_stats() {
            update_user_balance();
            update_admin_balance();
            update_admin_status();
        }

    </script>
@endsection