@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Transaction details</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Find Transfer</li>
        </ol>
        <div class="clearfix"></div>
    </div>

    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal"
                                      action="{{url('prashaasak/confirm_transfer/'.$result->id)}}" method="post">
                                    <h3>Request Details: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">

                                            <div class="row">

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Transaction
                                                                ID:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->transaction_id}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Currency
                                                                Name:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->currency_name}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Type:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->type}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>User
                                                                ID:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->user_id}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>User
                                                                Email:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{get_usermail($result->user_id)}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>User
                                                                Verified
                                                                :</strong></label>

                                                        @if(get_user_verified($result->user_id)== 'Unverified')
                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"><a href=""
                                                                                                       id="user_verified"
                                                                                                       style="color: red"
                                                                                                       onclick="user_verified()">{{get_user_verified($result->user_id)}}</a>
                                                                </p>
                                                            </div>
                                                        @else
                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"><a href=""
                                                                                                       id="user_verified"
                                                                                                       style="color: green"
                                                                                                       onclick="user_verified()">{{get_user_verified($result->user_id)}}</a>
                                                                </p>
                                                            </div>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Auto
                                                                Withdrawal
                                                                :</strong></label>

                                                        @if(get_auto_withdrawal($result->user_id)== 'Off')
                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"><a href=""
                                                                                                       id="auto_withdrawal"
                                                                                                       style="color: red"
                                                                                                       onclick="auto_withdrawal()">{{get_auto_withdrawal($result->user_id)}}</a>
                                                                </p>
                                                            </div>
                                                        @else
                                                            <div class="col-md-10"><p
                                                                        class="form-control-static"><a href=""
                                                                                                       id="auto_withdrawal"
                                                                                                       style="color: green"
                                                                                                       onclick="auto_withdrawal()">{{get_auto_withdrawal($result->user_id)}}</a>
                                                                </p>
                                                            </div>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>KYC
                                                                Status
                                                                :</strong></label>

                                                        @if(get_user_details($result->user_id,'document_status')=='1')
                                                            <div class="col-md-10"><p
                                                                        class="label label-success">Verified</p>
                                                            </div>
                                                        @elseif(get_user_details($result->user_id,'document_status')=='3')
                                                            <div class="col-md-10"><p
                                                                        class="label label-info">Submitted</p>
                                                            </div>
                                                        @elseif(get_user_details($result->user_id,'document_status')=='2')
                                                            <div class="col-md-10"><p
                                                                        class="label label-danger">Rejected</p>
                                                            </div>
                                                        @else
                                                            <div class="col-md-10"><p
                                                                        class="label label-warning">Pending</p>
                                                            </div>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Amount:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->amount}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Fee:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->fee}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Transfer
                                                                Amount:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->paid_amount}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>To
                                                                Address:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->crypto_address}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                @if($result->currency_name=='XRP')
                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Destination
                                                                    Tag:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static">{{$result->xrp_desttag}}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Request
                                                                Date:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->created_at}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Status:</strong></label>

                                                        <div class="col-md-10"><p
                                                                    class="form-control-static">{{$result->status}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-2 control-label"><strong>Transaction
                                                                Details:</strong></label>

                                                        <div class="col-md-10"><a
                                                                    class="form-control-static" target="_blank"
                                                                    href="{{url('prashaasak/user_transaction_details?user_id='.$result->user_id)}}">click
                                                                here</a>
                                                        </div>
                                                    </div>
                                                </div>

                                                @if($result->status=='Pending' || $result->status=='Processing')

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Reason
                                                                    for manual withdrawal:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static">{{$result->description}}</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    {{csrf_field()}}
                                                    <input type="hidden" name="txdid"
                                                           value="{{$result->transaction_id}}">
                                                    <input type="hidden" name="currency"
                                                           value="{{$result->currency_name}}">

                                                    {{--for otp--}}
                                                    {{--<div class="col-md-12">--}}
                                                    {{--<div class="form-group input-group"><label for="inputLastName" class="col-md-2 control-label"><strong>OTP:</strong></label>--}}

                                                    {{--<div class="col-md-10">--}}
                                                    {{--<input type="text" class="form-control" name="otp_code" required />--}}
                                                    {{--<span class="input-group-addon" id="trans_otp">--}}
                                                    {{--<a href="#" onclick="generate_otp();" class="btn btn-info btn-sm">Generate OTP</a>--}}
                                                    {{--</span>--}}
                                                    {{--</div>--}}
                                                    {{--</div>--}}
                                                    {{--</div>--}}

                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="inputLastName"
                                                                   class="col-md-2 control-label"><strong></strong></label>
                                                            @if($result->currency_name=='XDCE')

                                                                <input type="submit" class="btn btn-success"
                                                                       name="subbuton" value="Completed">
                                                                <input type="submit" class="btn btn-success"
                                                                       name="subbuton"
                                                                       value="Confirm" onclick="XDCEsubmit()">
                                                            @else
                                                                <input type="submit" class="btn btn-success"
                                                                       name="subbuton"
                                                                       value="Confirm">
                                                            @endif
                                                            <input type="submit" class="btn btn-primary" name="subbuton"
                                                                   value="Cancel">
                                                        </div>
                                                    </div>

                                                @else

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Reason
                                                                    for manual withdrawal:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static">{{$result->description}}</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Txd
                                                                    ID:</strong></label>

                                                            <div class="col-md-10"><p
                                                                        class="form-control-static">{{$result->wallet_txid}}</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-2 control-label"><strong>Completion
                                                                    Type :</strong></label>
                                                            <div class="col-md-10"><p
                                                                        class="form-control-static">{{$result->completed_type}}</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                @endif

                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

@endsection

@section('script')
    <script type="text/javascript">
        function generate_otp() {
            $.ajax({
                type: 'post',
                url: '{{url("prashaasak/generate_otp")}}',
                data: 'key={{time()}}&_token={{ csrf_token() }}',
                success: function (data) {
                    $("#trans_otp").html('<a href="#" class="btn btn-info btn-sm">Sent</a>');
                }
            });
        }

        function user_verified() {
            $.get("{{url('ajax/user_verification')}}/{{$result->user_id}}", function (data) {
                if (data == 1) {
                    document.location.reload();
                }
            });
        }

        function auto_withdrawal() {
            $.get("{{url('ajax/auto_withdrawal')}}/{{$result->user_id}}", function (data) {
                if (data == 1) {
                    document.location.reload();
                }
            });
        }

    </script>
    <script type="text/javascript">
        function XDCEsubmit() {
            window.open('https://etherscan.io/address/0xe1db13e1db3ddbefe1e0e171dc38db94e62206d7#tokentxns', "_blank");
            $('form').submit();
        }
    </script>
@endsection
