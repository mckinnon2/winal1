@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">XinFin Bond Request Details</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">XinFin Bond Request Details</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div id="tableactionTabContent" class="tab-content">
                    <div id="table-table-tab" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-lg-12">

                                <form class="form-horizontal"
                                      action="{{url('prashaasak/confirm_xinfin_request/'.$result->id)}}" method="post"
                                      id="confirm_request">
                                    {{csrf_field()}}
                                    <h3>Request Details: </h3>
                                    <div class="panel-body pan">
                                        <div class="form-body pal">

                                            <div class="row">

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>
                                                                ID:</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->id}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>
                                                                Bond Name :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->bond_name}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>
                                                                Issuer Name :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->issuer_name}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Bond
                                                                Contract
                                                                Address :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->bond_contract_address}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Bond
                                                                Symbol :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->bond_symbol}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Bond
                                                                Token
                                                                Decimals :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->bond_decimals}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Coupon
                                                                (%) :</strong></label>
                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->coupon}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Maturity
                                                                Date :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->maturity_date}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Payment
                                                                Frequency :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->payment_frequency}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Next
                                                                Interest Payment Date :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->interest_date}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Listing
                                                                Date :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->listing_date}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Listing
                                                                Price :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->listing_price}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Email
                                                                Id :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->email}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Requested
                                                                By :</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->requested_by}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Request
                                                                Date:</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->created_at}}</p>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-md-12">
                                                    <div class="form-group"><label for="inputLastName"
                                                                                   class="col-md-3 control-label"><strong>Status:</strong></label>

                                                        <div class="col-md-9"><p
                                                                    class="form-control-static">{{$result->status}}</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                @if($result->status=='Pending')
                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-3 control-label"><strong>Reason(if
                                                                    rejected) :</strong></label>

                                                            <div class="col-md-9"><p
                                                                        class="form-control-static"><textarea
                                                                            name="reason" id="reason"
                                                                            class="form-control"
                                                                            placeholder="Reason for rejection"></textarea>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-3 control-label"><strong>Deposit
                                                                    Fees(if accepted) :</strong></label>

                                                            <div class="col-md-9"><p
                                                                        class="form-control-static"><input
                                                                            name="deposit_fees" id="deposit_fees"
                                                                            class="form-control"
                                                                            onkeypress='return event.charCode == 46 || event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"'
                                                                            placeholder="Deposit Fees"></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group"><label for="inputLastName"
                                                                                       class="col-md-3 control-label"><strong>Withdrawal
                                                                    Fees(if accepted) :</strong></label>

                                                            <div class="col-md-9"><p
                                                                        class="form-control-static"><input
                                                                            name="withdrawal_fees" id="withdrawal_fees"
                                                                            class="form-control"
                                                                            onkeypress='return event.charCode == 46 || event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"'
                                                                            placeholder="Withdrawal Fees"></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="inputLastName"
                                                                   class="col-md-3 control-label"><strong></strong></label>
                                                            <input type="submit" class="btn btn-success" name="subbuton"
                                                                   value="Accept">
                                                            <input type="submit" class="btn btn-primary" name="subbuton"
                                                                   value="Reject">
                                                        </div>
                                                    </div>
                                                @endif

                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



@endsection

@section('script')

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>

    <script type="text/javascript">
        $('#confirm_request').validate({
            rules:
                {
                    deposit_fees: {number: true,},
                    withdrawal_fees: {number: true,},
                },
            messages:
                {
                    deposit_fees: {number: 'Enter valid fees format'},
                    withdrawal_fees: {number: 'Enter valid fees format'},
                },
        });
    </script>
@endsection
