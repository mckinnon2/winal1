@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">New Request</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">FAQ</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div class="row mtl">

                    <div class="col-md-12">

                        <div id="generalTabContent" class="tab-content">

                            <div id="tab-edit" class="tab-pane fade in active">
                                <form action="{{url('/add_xinfin_request')}}" method="post" id="add_xinfin">
                                    {{--<div class="col-sm-12"><p class="text-center">Coming Soon</p></div>--}}

                                    {{ csrf_field() }}

                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="bond_name">Bond Name</label>
                                                <input type="text" value="{{old('bond_name')}}" name="bond_name"
                                                       id="bond_name" class="form-control" placeholder="Bond Name"/>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="issuer_name">Issuer Name</label>
                                                <input type="text" value="{{old('issuer_name')}}" name="issuer_name"
                                                       id="issuer_name" class="form-control" placeholder="Issuer Name"/>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="contract_address">Bond Contract Address</label>
                                                <input type="text" value="{{old('bond_contract_address')}}"
                                                       name="bond_contract_address" id="bond_contract_address"
                                                       class="form-control"
                                                       placeholder="Contract Address"/>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="bond_symbol">Bond Short Name/Symbol </label>
                                                <input type="text" value="{{old('bond_symbol')}}"
                                                       style="text-transform: uppercase;" name="bond_symbol"
                                                       id="bond_symbol" class="form-control"
                                                       placeholder="Bond Short Name/Symbol"/>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="coupon">Coupon (%) </label>
                                                <input type="text" value="{{old('coupon')}}" name="coupon" id="coupon"
                                                       onkeypress='return event.charCode==46 || event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"'
                                                       class="form-control" placeholder="Coupon (%)"/>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="maturity_date">Maturity Date </label>

                                                <div class="input-group date">
                                                    <span class="input-group-addon"><i
                                                                class="fa fa-calendar"></i></span><input
                                                            id="maturity_date" name="maturity_date" type="text"
                                                            onkeydown="return false;"
                                                            class="form-control" value="{{ old('maturity_date') }}"
                                                            placeholder="Maturity Date">
                                                </div>
                                                <label for="maturity_date" generated="true" style="display: none;"
                                                       class="error"></label>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="payment_frequency">Payment Frequency</label>
                                                <select name="payment_frequency" id="payment_frequency"
                                                        class="form-control">
                                                    <option value="">Select Options</option>
                                                    <option value="daily">Daily</option>
                                                    <option value="weekly">Weekly</option>
                                                    <option value="biweekly">Biweekly</option>
                                                    <option value="monthly">Monthly</option>
                                                    <option value="quarterly">Quarterly</option>
                                                    <option value="yearly">Yearly</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="interest_date">Next Interest Payment Date </label>

                                                <div class="input-group date">
                                                    <span class="input-group-addon"><i
                                                                class="fa fa-calendar"></i></span><input
                                                            id="interest_date" name="interest_date" type="text"
                                                            onkeydown="return false;"
                                                            class="form-control" value="{{ old('interest_date') }}"
                                                            placeholder="Interest Payment Date">
                                                </div>
                                                <label for="interest_date" generated="true" style="display: none;"
                                                       class="error"></label>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="listing_date">Listing Date </label>

                                                <div class="input-group date">
                                                    <span class="input-group-addon"><i
                                                                class="fa fa-calendar"></i></span><input
                                                            id="listing_date" name="listing_date" type="text"
                                                            onkeydown="return false;" class="form-control"
                                                            value="{{old('listing_date')}}" placeholder="Listing Date">
                                                </div>
                                                <label for="listing_date" generated="true" style="display: none;"
                                                       class="error"></label>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="listing_price">Listing Price </label>
                                                <input type="text" value="{{old('listing_price')}}" name="listing_price"
                                                       onkeypress='return event.charCode==46 || event.charCode >= 48 && event.charCode <= 57 || event.key === "Backspace"'
                                                       id="lisitng_price" class="form-control"
                                                       placeholder="Listing Price"/>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="email">Email</label>
                                                <input type="text" value="{{old('email_id')}}" id="email_id"
                                                       class="form-control"
                                                       placeholder="Enter Email" name="email_id">
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="requested_by">Requested By </label>
                                                <input type="text" value="{{old('requested_by')}}" name="requested_by"
                                                       id="requested_by" class="form-control"
                                                       placeholder="Requested By"/>
                                            </div>
                                        </div>

                                        <hr/>

                                        <div class="col-sm-12">
                                            <div class="form-group text-right">
                                                <button type="submit" class="btn yellow-btn min-width-btn">Create
                                                    Request
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    {{--<script src="{{URL::asset('front')}}/assets/js/bootstrap-datepicker.js"></script>--}}

    <script type="text/javascript">

        $("#add_xinfin").validate({
            rules:
                {
                    bond_name: {required: true},
                    issuer_name: {required: true},
                    bond_contract_address: {required: true, alphanumer: true},
                    bond_symbol: {required: true},
                    coupon: {required: true, number: true},
                    maturity_date: {required: true},
                    interest_date: {required: true},
                    payment_frequency: {required: true},
                    listing_date: {required: true},
                    listing_price: {required: true, number: true},
                    requested_by: {required: true},
                    email_id: {required: true, email: true},
                },
            messages:
                {
                    bond_name: {required: 'Bond name is required'},
                    issuer_name: {required: 'Issuer name is required'},
                    bond_contract_address: {required: 'Bond Contract Address is required'},
                    bond_symbol: {required: 'Bond short name/symbol is required'},
                    coupon: {required: 'Coupon (%) is required', number: 'Enter valid number format'},
                    maturity_date: {required: 'Maturity date is required'},
                    interest_date: {required: 'Interest date is required'},
                    listing_date: {required: 'Listing date is required'},
                    listing_price: {required: 'Listing price is required', number: 'Enter valid number format'},
                    payment_frequency: {required: 'Payment frequency is required'},
                    requested_by: {required: 'Requested by is required'},
                    email_id: {required: 'Email id is required', email: 'Enter valid email id'},
                },
        });

        jQuery.validator.addMethod("alphanumer", function (value, element) {
            return this.optional(element) || /^([a-zA-Z0-9 _-]+)$/.test(value);
        }, 'Does not allow any grammatical connotation, like " : ./');

        $(document).ready(function () {

            $(function () {
                $("#maturity_date,#interest_date,#listing_date").datepicker({
                    todayBtn: "linked",
                    keyboardNavigation: false,
                    forceParse: false,
                    calendarWeeks: true,
                    autoclose: true,
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'dd/mm/yy',
                });
            });
        });

    </script>

@endsection