@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">User Trade Transaction Details</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            {{--<li class="active">Verification Status  &nbsp;</li>--}}
            {{--@if($flag == 1)--}}
            {{--<li><i class="fa fa-angle-right"></i>&nbsp;&nbsp;<i class="fa fa-circle" style="color: green"--}}
            {{--aria-hidden="true"></i> &nbsp;</li>--}}
            {{--@else--}}
            {{--<li><i class="fa fa-angle-right"></i>&nbsp;&nbsp;<i class="fa fa-circle" style="color: red"--}}
            {{--aria-hidden="true"></i> &nbsp;</li>--}}
            {{--@endif--}}
        </ol>
        <div class="clearfix"></div>
    </div>

    <div style="float: right"><a href="{{url('prashaasak/user_transaction_details?&type=PDF&user_id='.$id)}}"
                                 target="_blank" style="cursor:pointer;">Download</a></div>
    <div class="page-content">
        <div class="row mbl">
            {{--user details--}}

            {{--User Profile--}}
            <div class="col-sm-6 col-md-4">
                <div class="panel db mbm" style="cursor: pointer;">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center"><i class="fa fa-user fa-3"></i></div>
                                <div style="text-align: center"><p>
                                    <h2>{{get_user_details($bal->user_id,'enjoyer_name')}}</h2></p>
                                    <p class="description "><strong>{{ get_usermail($bal->user_id) }}</strong></p></div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <label><strong>BTC:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->BTC}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>ETH:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->ETH}}</label>
                            </div>


                            <div class="col-md-4">
                                <label><strong>XRP:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->XRP}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>XDC:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->XDC}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>XDCE:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->XDCE}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>BCHABC:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->BCHABC}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>BCHSV:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->BCHSV}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>USDT:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->USDT}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>USDC:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$bal->USDC}}</label>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            {{--Explorer Deposit--}}
            <div class="col-sm-6 col-md-4">
                <div class="panel db mbm" style="cursor: pointer;">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center"><i class="fa fa-exchange fa-6x"></i></div>
                                <div style="text-align: center"><p>
                                    <h2>Explorer Deposit</h2></p>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <label><strong>BTC:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['BTC']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>ETH:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['ETH']}}</label>
                            </div>


                            <div class="col-md-4">
                                <label><strong>XRP:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['XRP']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>XDC:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['XDC']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>XDCE:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['XDCE']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>ICO XDCE:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$ico['XDCE']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>BCH:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['BCH']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>BCHSV:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['BCHSV']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>USDT:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['USDT']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>USDC:</strong></label>
                            </div>
                            <div class="col-md-8">
                                <label>{{$explorer['USDC']}}</label>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            {{--User Profile--}}
            <div class="col-sm-6 col-md-4">
                <div class="panel db mbm" style="cursor: pointer;">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center"><i class="fa fa-exchange fa-6x"></i></div>
                                <div style="text-align: center"><p>
                                    <h2>Withdrawals</h2></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-4">
                                <label><strong>BTC:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['BTC']}}</label>
                            </div>


                            <div class="col-md-4">
                                <label><strong>ETH:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['ETH']}}</label>
                            </div>


                            <div class="col-md-4">
                                <label><strong>XRP:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['XRP']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>XDC:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['XDC']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>XDCE:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['XDCE']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>BCH:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['BCH']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>BCHSV:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['BCHSV']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>USDT:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['USDT']}}</label>
                            </div>

                            <div class="col-md-4">
                                <label><strong>USDC:</strong></label>
                            </div>

                            <div class="col-md-8">
                                <label>{{$withdraw['USDC']}}</label>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div>
            <h2>Total Trade Supply:</h2>
            <br>
            <div class="row">
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed XDC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['XDC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell XDC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Sell_total['XDC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade XDC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['XDC']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed XDCE:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['XDCE']+$ico['XDCE']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell XDCE:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Sell_total['XDCE']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade XDCE:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['XDCE']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed XRP:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['XRP']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell XRP:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Sell_total['XRP']+$ico['XRP']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade XRP:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['XRP']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed ETH:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['ETH']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell ETH:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Sell_total['ETH']+$ico['ETH']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade ETH:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['ETH']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed BTC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['BTC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell BTC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Sell_total['BTC']+$ico['BTC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade BTC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['BTC']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed BCH:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['BCH']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell BCH:</strong></label>
                    </div>
                    <div class="col-md-6">
                        <label>{{$Sell_total['BCH']+$ico['BCH']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade BCH:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['BCH']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed BCHABC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['BCHABC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell BCHABC:</strong></label>
                    </div>
                    <div class="col-md-6">
                        <label>{{$Sell_total['BCHABC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade BCHABC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['BCHABC']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed BCHSV:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['BCHSV']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell BCHSV:</strong></label>
                    </div>
                    <div class="col-md-6">
                        <label>{{$Sell_total['BCHSV']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade BCHSV:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['BCHSV']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed USDT:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['USDT']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell USDT:</strong></label>
                    </div>
                    <div class="col-md-6">
                        <label>{{$Sell_total['USDT']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade USDT:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['USDT']}}</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Buyed USDC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Buy_total['USDC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Sell USDC:</strong></label>
                    </div>
                    <div class="col-md-6">
                        <label>{{$Sell_total['USDC']}}</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-6">
                        <label><strong>Intrade USDC:</strong></label>
                    </div>

                    <div class="col-md-6">
                        <label>{{$Intrade_total['USDC']}}</label>
                    </div>
                </div>


            </div>
        </div>

        <form class="form-horizontal">
            <h3>User Addresses: </h3>
            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>BTC:</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->BTC_addr}}<br>
                            {{--<a href="{{url('ajax/btc_deposit_process_user/'.$user->BTC_addr)}}" style="color: red;">--}}
                            {{--Click here--}}
                            {{--</a>to manually deposit <strong>BTC</strong>.--}}
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>BCHABC:</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->BCHABC_addr}}
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>BCHSV:</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->BCHSV_addr}}
                        </p></div>
                </div>
            </div>


            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>ETH:</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->ETH_addr}}<br>
                            <a href="{{url('cron/eth_deposit_process_user/'.$user->ETH_addr)}}" style="color: red;">
                                Click here
                            </a>to manually deposit <strong>ETH</strong>.
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>XRP
                            :</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->XRP_addr}}
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>XRP Destination Tag
                            :</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->xrp_desttag}}
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>XDC
                            :</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->XDC_addr}}<br>
                            <a href="{{url('ajax/XDCdeposit/'.$id)}}" style="color: red;">
                                Click here
                            </a>to manually deposit <strong>XDC</strong>.
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>XDCE
                            :</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->XDCE_addr}}<br>
                            <a href="{{url('cron/xdce_deposit_process_user/'.$user->XDCE_addr)}}" style="color: red;">
                                Click here
                            </a>to manually deposit <strong>XDCE</strong>.
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>USDT:</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->USDT_addr}}
                        </p></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group"><label for="inputLastName"
                                               class="col-md-2 control-label"><strong>USDC:</strong></label>

                    <div class="col-md-10"><p class="form-control-static">
                            {{$user->USDC_addr}}
                        </p></div>
                </div>
            </div>

        </form>


        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#buy_trades">Buy Trades</a></li>
            <li><a data-toggle="tab" href="#sell_trades">Sell Trades</a></li>
            <li><a data-toggle="tab" href="#pending_trades">Pending Trades</a></li>
            <li><a data-toggle="tab" href="#ico_trades">ICO Trades</a></li>
        </ul>

        <div class="tab-content">

            {{--user buy Trade of that particular currency--}}
            <div id="buy_trades" class="table-container tab-pane fade in active">
                <div>
                    <h2>&nbsp;&nbsp;Buy Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped table-advanced tablesorter"
                       id="myBuyTrade">
                    <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>
                    </tr>
                    </thead>

                    <tbody>
                    @if($buy_trade)
                        @foreach($buy_trade as $key=>$val)
                            <tr>
                                <td>{{$val->original_qty}}</td>
                                <td>{{$val->price}}</td>
                                <td>{{$val->fee}}</td>
                                <td>{{$val->updated_total}}</td>
                                <td>{{$val->type}}</td>
                                <td>{{$val->firstCurrency}}</td>
                                <td>{{$val->secondCurrency}}</td>
                                <td>{{$val->status}}</td>
                                <td>{{$val->updated_at}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>

            {{--user buy Trade of that particular currency--}}
            <div id="sell_trades" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;Sell Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="mySellTrade">
                    <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>


                    </tr>
                    <tbody>
                    @if($sell_trade)
                        @foreach($sell_trade as $key=>$val)
                            <tr>
                                <td>{{$val->original_qty}}</td>
                                <td>{{$val->price}}</td>
                                <td>{{$val->fee}}</td>
                                <td>{{$val->updated_total}}</td>
                                <td>{{$val->type}}</td>
                                <td>{{$val->firstCurrency}}</td>
                                <td>{{$val->secondCurrency}}</td>
                                <td>{{$val->status}}</td>
                                <td>{{$val->updated_at}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    </thead>
                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>

            {{--user penidng trades--}}
            <div id="pending_trades" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp; Pending Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="myPendingTrade">
                    <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Fee</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>


                    </tr>
                    <tbody>
                    @if($pending_trade)
                        @foreach($pending_trade as $key=>$val)
                            <tr>
                                <td>{{$val->updated_qty}}</td>
                                <td>{{$val->price}}</td>
                                <td>{{$val->fee}}</td>
                                <td>{{$val->total}}</td>
                                <td>{{$val->type}}</td>
                                <td>{{$val->firstCurrency}}</td>
                                <td>{{$val->secondCurrency}}</td>
                                <td>{{$val->status}}</td>
                                <td>{{$val->updated_at}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    </thead>
                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>

            {{--ico buy Trade of that particular currency--}}
            <div id="ico_trades" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;ICO Trades:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="myICO">
                    <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Type</th>
                        <th>First Currency</th>
                        <th>Second Currency</th>
                        <th>Status</th>
                        <th>Updated time</th>


                    </tr>
                    <tbody>
                    @if($ico_trade)
                        @foreach($ico_trade as $key=>$val)
                            <tr>
                                <td>{{$val->Amount}}</td>
                                <td>{{$val->Price}}</td>
                                <td>{{$val->Total}}</td>
                                <td>{{$val->Type}}</td>
                                <td>{{$val->FirstCurrency}}</td>
                                <td>{{$val->SecondCurrency}}</td>
                                <td>{{$val->Status}}</td>
                                <td>{{$val->updated_at}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    </thead>
                    <tfoot>
                    <tr>
                        <th colspan="0" style="text-align:right">Amount:</th>
                        <th colspan="3" style="text-align:right">Total:</th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>
        </div>

        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#deposits">Deposits</a></li>
            <li><a data-toggle="tab" href="#withdrawals">Withdrawals</a></li>
            <li><a data-toggle="tab" href="#referral">Referral Earning</a></li>
        </ul>

        <div class="tab-content">

            {{--user Deposit Trade of that particular currency--}}
            <div id="deposits" class="table-container tab-pane fade in active">
                <div>
                    <h2>&nbsp;&nbsp;Deposits:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="Deposits">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Transaction ID</th>
                        <th>Type</th>
                        <th>Currency</th>
                        <th>Amount</th>
                        <th>Datetime</th>
                        <th>Status</th>
                        <th>From Email(XDC)</th>


                    </tr>
                    <tbody>
                    @if($Deposit)
                        @foreach($Deposit as $key=>$val)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$val->transaction_id}}</td>
                                <td>{{$val->type}}</td>
                                <td>{{$val->currency_name}}</td>
                                <td>{{$val->amount}}</td>
                                <td>{{$val->updated_at}}</td>
                                <td>{{$val->status}}</td>
                                <td>{{$val->description}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    </thead>
                    <tfoot>
                    <tr>
                        <th colspan="5" style="text-align:right"></th>
                        <th></th>

                    </tr>
                    </tfoot>
                </table>

            </div>

            {{--user Withdrawal Trade of that particular currency--}}
            <div id="withdrawals" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;Withdrawal:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter"
                       id="Withdrawals">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Transaction ID</th>
                        <th>Type</th>
                        <th>Currency</th>
                        <th>Amount</th>
                        <th>Datetime</th>
                        <th>Status</th>


                    </tr>
                    <tbody>
                    @if($Withdrawal)
                        @foreach($Withdrawal as $key=>$val)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$val->transaction_id}}</td>
                                <td>{{$val->type}}</td>
                                <td>{{$val->currency_name}}</td>
                                <td>{{$val->amount}}</td>
                                <td>{{$val->updated_at}}</td>
                                <td>{{$val->status}}</td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                    </thead>
                    <tfoot>
                    <tr>
                        <th colspan="5" style="text-align:right"></th>
                        <th></th>

                    </tr>
                    </tfoot>

                </table>

            </div>

            {{--user Referral Earning --}}
            <div id="referral" class="table-container tab-pane fade in">
                <div>
                    <h2>&nbsp;&nbsp;Referral:</h2>
                    <br>
                </div>
                <table class="table table-hover table-striped  table-advanced tablesorter" id="referral_earning">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Referred User ID</th>
                        <th>Referred Name</th>
                        <th>Currency</th>
                        <th>Bonus</th>
                        <th>Datetime</th>
                        <th>Status</th>


                    </tr>
                    </thead>
                    <tbody>

                    @if($referred)
                        @foreach($referred as $key=>$val)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$val->referrer_id}}</td>
                                <td>{{$val->referrer_name}}</td>
                                <td>{{$val->currency}}</td>
                                <td>{{$val->referred_bonus}}</td>
                                <td>{{$val->updated_at}}</td>
                                <td>
                                    @if($val->referred_status == 1)
                                        Bonus added.
                                    @elseif($val->referred_status == 0)
                                        Referred First Trade Pending.
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    @endif

                    @if($referrer)
                        @foreach($referrer as $key=>$val)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$val->referred_id}}</td>
                                <td>{{$val->referred_name}}</td>
                                <td>{{$val->currency}}</td>
                                <td>{{$val->referrer_bonus}}</td>
                                <td>{{$val->updated_at}}</td>
                                <td>
                                    @if($val->referrer_status == 1 && $val->referred_status == 1)
                                        Bonus added.
                                    @elseif($val->referred_status == 0)
                                        Referred First Trade Pending.
                                    @elseif($val->referrer_status == 0)
                                        Referrer First Trade Pending.
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    @endif

                    @if($referred_users)
                        @foreach($referred_users as $key=>$val)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td></td>
                                <td>Referred {{$val->referred_users}} users</td>
                                <td>{{$val->currency}}</td>
                                <td>{{$val->bonus}}</td>
                                <td>{{$val->updated_at}}</td>
                                <td>
                                    @if($val->status == 1)
                                        Bonus added.
                                    @else
                                        Bonus pending.
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    @endif

                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="5" style="text-align:right"></th>
                        <th></th>
                        <th> Total Bonus : {{$referral_bonus}}</th>

                    </tr>
                    </tfoot>

                </table>

            </div>

        </div>


    </div>
@endsection

@section('script')
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#myBuyTrade').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,

                "footerCallback": function (row, data, start, end, display) {
                    var api = this.api(), data;

                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;
                    };

                    // Total over all pages
                    total = api
                        .column(3)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                            ;
                        });

                    amount = api.column(0)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    // Update footer
                    // Update footer
                    $(api.column(0).footer()).html(
                        'Amount: ' + amount
                    );


                    $(api.column(3).footer()).html(
                        'Total: ' + total
                    );
                }
            });

            $('#mySellTrade').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,
                "footerCallback": function (row, data, start, end, display) {
                    var api = this.api(), data;

                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;
                    };

                    // Total over all pages
                    total = api
                        .column(3)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                            ;
                        });

                    amount = api.column(0)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    // Update footer
                    // Update footer
                    $(api.column(0).footer()).html(
                        'Amount: ' + amount
                    );


                    $(api.column(3).footer()).html(
                        'Total: ' + total
                    );
                }
            });

            $('#Deposits').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,
                "footerCallback": function (row, data, start, end, display) {
                    var api = this.api(), data;

                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;
                    };


                    amount = api.column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    // Update footer
                    // Update footer
                    $(api.column(4).footer()).html(
                        'Amount: ' + amount
                    );

                }
            });

            $('#Withdrawals').DataTable({
                "searching": false,
                "paging": false,
                "ordering": false,
                "info": false,
                "footerCallback": function (row, data, start, end, display) {
                    var api = this.api(), data;

                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i * 1 :
                            typeof i === 'number' ?
                                i : 0;
                    };

                    amount = api.column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        });

                    // Update footer
                    // Update footer
                    $(api.column(4).footer()).html(
                        'Amount: ' + amount
                    );

                }
            });

            // $('#referral_earning').DataTable({
            //     "searching": false,
            //     "paging": false,
            //     "ordering": false,
            //     "info": false,
            //     "footerCallback": function ( row, data, start, end, display ) {
            //         var api = this.api(), data;
            //
            //         // Remove the formatting to get integer data for summation
            //         var intVal = function ( i ) {
            //             return typeof i === 'string' ?
            //                 i*1 :
            //                 typeof i === 'number' ?
            //                     i : 0;
            //         };
            //
            //         amount = api.column(4)
            //             .data()
            //             .reduce(function (a,b) {
            //                 return intVal(a)+intVal(b);
            //             });
            //
            //         // Update footer
            //         // Update footer
            //         $(api.column(4).footer()).html(
            //             'Total Bonus: '+ amount
            //         );
            //
            //     }
            // });

        });
    </script>


    <link rel="stylesheet" href="{{URL::asset('datepicker/jquery-ui.css')}}">
    <script src="{{URL::asset('datepicker/jquery-ui.js')}}"></script>
    <script>
        $(function () {

            $("#max,#min").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd',
                onSelect: function (selectedDate) {
                    if (this.id == 'min') {
                        var dateMin = $('#min').datepicker("getDate");
                        var rMin = new Date(dateMin.getFullYear(), dateMin.getMonth(), dateMin.getDate() + 1);
                        $('#max').datepicker("option", "minDate", rMin);
                    }

                }


            });


        });
    </script>
    <script>
        function pdf() {

        }
    </script>

@endsection
