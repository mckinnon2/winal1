@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">New Request</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

            <li class="active">FAQ</li>
        </ol>
        <div class="clearfix"></div>
    </div>


    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div class="row mtl">

                    <div class="col-md-12">

                        <div id="generalTabContent" class="tab-content">

                                <div id="tab-edit" class="tab-pane fade in active">
                                    <form action="{{url('prashaasak/add_erc20_request')}}" method="post" class="form-horizontal" id="new_request">
                                        <h3>Add ERC20 Request</h3>
                                        {{ csrf_field() }}

                                        <div class="form-group"><label class="col-sm-3 control-label">Token Name </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9"><input type="text" value="{{old('name')}}" name="name" id="name" class="form-control"  /></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-sm-3 control-label">Contract Address </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9"><input type="text" value="{{old('contract_address')}}" name="contract_address" id="contract_address" class="form-control"  /></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-sm-3 control-label">Token Symbol </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9"><input type="text" value="{{old('symbol')}}" style="text-transform: uppercase;" name="symbol" id="symbol" class="form-control"  /></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-sm-3 control-label">Token Decimals </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9"><input type="text" value="{{old('token_decimals')}}" name="token_decimals" id="token_decimals" class="form-control"  /></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-sm-3 control-label">Requested By </label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-9"><input type="text" value="{{old('requested_by')}}" name="requested_by" id="requested_by" class="form-control"  /></div>
                                                </div>
                                            </div>
                                        </div>

                                        <hr/>
                                        <button type="submit" class="btn btn-green btn-block">Submit Request</button>
                                    </form>
                                </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

    <script type="text/javascript">

        $('#new_request').validate({
            rules:
                {
                    name: {required:true, },
                    contract_address: {required:true, alphanumer:true},
                    symbol : { required : true },
                    token_decimals : { required : true, regex : '^[0-9]+$'},
                    requested_by : { required : true}
                },
            messages:
                {
                    name:{required:'Token name is required'},
                    contract_address:{required:'Contract Address is required'},
                    symbol:{required:'Token Symbol is required'},
                    token_decimals:{required:'Token Decimals is required',regex:'Only numbers allowed'},
                    requested_by:{required:'Requested by is required'}
                },
        });

        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Number Not valid."
        );

        jQuery.validator.addMethod("alphanumer", function(value, element) {
            return this.optional(element) || /^([a-zA-Z0-9 _-]+)$/.test(value);
        }, 'Only alphabets and numbers allowed');

        $(document).ready(function(){
            $("#symbol").keyup(function(){
                $('#symbol').val($(this).val().toUpperCase());
            });
        });

        </script>
@endsection