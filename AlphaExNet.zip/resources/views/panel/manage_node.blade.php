@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Manage Node</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>

            <li class="active">Manage Node</li>
        </ol>
        <div class="clearfix"></div>
    </div>



    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div class="row mtl">

                    <div class="col-md-12">

                        <div id="generalTabContent" class="tab-content">

                            <div id="tab-edit" class="tab-pane fade in active">
                                <form action="{{url('prashaasak/manage_node/'.$currency)}}" method="post" class="form-horizontal">
                                    <h3>Manage Node ({{$currency}})</h3>
                                    {{ csrf_field() }}

                                    <div class="form-group"><label class="col-sm-3 control-label">{{$currency}} User Name</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  readonly="readonly" class="form-control"  name="uname" id="uname" value="{{$uname}}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group"><label class="col-sm-3 control-label">{{$currency}} Password</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"   readonly="readonly" class="form-control"  name="password" id="password" value="{{$password}}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group"><label class="col-sm-3 control-label">{{$currency}} Host</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"   class="form-control"  name="host" id="host" value="{{$host}}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group"><label class="col-sm-3 control-label">{{$currency}} Port</label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <input type="text"  class="form-control"  name="port" id="port" value="{{$port}}"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <hr/>
                                    <button type="submit" class="btn btn-green btn-block">Update</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
