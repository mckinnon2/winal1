@extends("panel.layout.admin_layout")
@section("content")
    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
        <div class="page-header pull-left">
            <div class="page-title">Reserve Balances</div>
        </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
            <li><i class="fa fa-home"></i>&nbsp;<a href="{{url('prashaasak/home')}}">Home</a>&nbsp;&nbsp;<i
                        class="fa fa-angle-right"></i>&nbsp;&nbsp;
            </li>

            <li class="active">Reserve Balances</li>
        </ol>
        <div class="clearfix"></div>
    </div>

    <div class="page-content">
        <div class="row">
            <div class="col-md-12">

                @include('panel.alert')

                <div class="row mtl">

                    <div class="col-md-12">

                        <div id="generalTabContent" class="tab-content">

                            <div id="tab-edit" class="tab-pane fade in active">
                                <form action="{{url('prashaasak/reserve_balances')}}" method="post"
                                      class="form-horizontal">
                                    <h3>Reserve Balances</h3>
                                    {{ csrf_field() }}

                                    @foreach($currencies as $currency)
                                        <div class="form-group"><label
                                                    class="col-sm-3 control-label">{{$currency->currency_symbol}} <i
                                                        class="fa fa-random"></i></label>

                                            <div class="col-sm-9 controls">
                                                <div class="row">
                                                    <div class="col-xs-6 input-group">

                                                        <input type="text"
                                                               value="{{get_reserve_balance($currency->currency_symbol)}}"
                                                               name="{{$currency->currency_symbol}}"
                                                               class="form-control"
                                                               id="{{$currency->currency_symbol}}"/>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    @endforeach

                                    <div class="form-group"><label
                                                class="col-sm-3 control-label">M-XDC <i
                                                    class="fa fa-random"></i></label>

                                        <div class="col-sm-9 controls">
                                            <div class="row">
                                                <div class="col-xs-6 input-group">

                                                    <input type="text"
                                                           value="{{get_reserve_balance('M-XDC')}}"
                                                           name="M-XDC"
                                                           class="form-control"
                                                           id="M-XDC"/>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <hr/>
                                    <button type="submit" class="btn btn-green btn-block">Update</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>

        @foreach($currencies as $currency)
        $("#{{$currency->currency_symbol}}").keydown(function (evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode
            if (charCode > 31 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 106) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                return false;
            return true;
        });
        @endforeach
        $("#M-XDC").keydown(function (evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode
            if (charCode > 31 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 106) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                return false;
            return true;
        });
    </script>
@endsection