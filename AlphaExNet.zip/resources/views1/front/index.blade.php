@extends('front.layout.front')

@section('content')

 <!-- header -->
    <header class="cover">
        <div class="container">
            <div class="row  align-items-center" style="display: flex; flex-wrap: wrap;">
                <div class="col-md-8 mb40">
                    <h2 class="text-left text-orange font44 fontNormal">Welcome to Alphaex</h2>
                    <p class="text-left font24 fontNormal">AlphaEX is an ambitious, awesome, advanced crypto currency exchange. We aim to provide instant and simplified purchasing experience for customers looking to acquire crypto assets.</p>
                    <br>
                    <div class="row">
                        <div class="col-xs-12 mb40">
                            <div class="col-md-8 col-sm-offset-2">
                                <p class="text-center text-green font28">Last Price of XDC</p>
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
                            <div class="contact-info-holder">
                                <div class="sideline"></div>
                                <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/BTC.png" alt="">
                                    <p class="text-center"style="color: white">XDC/BTC</p>
                                    <p class="text-center" style="color: white">{{$BTC}}</p>
                                </div>
                            </div>
                        </div>
                        <!--end item-->

                        <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
                            <div class="contact-info-holder active">
                                <div class="sideline"></div>
                                <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/ETH.png" alt=""></div>
                                <p class="text-center"style="color: white">XDC/ETH</p>
                                <p class="text-center" style="color: white">{{$ETH}}</p>
                            </div>
                        </div>
                        <!--end item-->


                        <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
                            <div class="contact-info-holder">
                                <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/XRP.png" alt=""></div>
                                <p class="text-center"style="color: white">XDC/XRP</p>
                                <p class="text-center" style="color: white">{{$XRP}}</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
                            <div class="contact-info-holder">
                                <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/dollar.png" alt=""></div>
                                <p class="text-center"style="color: white">XDC/US$</p>
                                <p class="text-center" style="color: white">{{number_format($USD,6, '.', ',')}}*</p>
                            </div>
                        </div>
                        <!--end item-->
                        <div class="clearfix"></div>
                        <div class="">
                            <br>
                            <p>*Note:Estimated US$ price is based on ETH/XDC trade</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">

                    <h3 class="form-signin-heading">Login</h3>
                    <div class="loginBox">
                      @include('panel.alert')
                    <form action="{{url('/login')}}" method="POST" id="login_form">
                     {{ csrf_field() }}

                            <div class="form-group">
                                <input type="text" class="form-control input-md" name="login_mail" placeholder="Email id">
                            </div>


                             <div class="form-group">
                                <input type="password" class="form-control input-md" name="password" placeholder="Password">
                            </div>
                            <div class="form-group text-left">
                            <span id="capimg" style="margin-bottom: 20px; display: inline-block;">{!! captcha_img() !!}
                            </span>
                            <a href="javascript:;" onclick="change_captcha()" class="m_tl">
                            <i class="fa fa-refresh fa-3x"></i></a>

                                <input type="text" class="form-control input-md" name="captcha" placeholder="Captcha code">
                            </div>

                            <div class="button-checkbox text-left">
                                <label> <input type="checkbox" name="remember_me" id="remember_me" checked="checked" value="yes"> Remember me</label>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary pull-left" name="ec_login"><i class="fa fa-sign-in"></i> &nbsp; Login</button>
                                <span class="pull-left log_tx text-left" style="margin-left:20px;">
                  Don't have an Account? <a href="{{url('register')}}">Create Now!</a><br/>Forgot your Password? <a href="{{url('forgotpass')}}">Reset</a>
                  </span>
                           </div>
                    </form>
                    </div>
                </div>

            </div>
        </div>
    </header>
    <!-- / header -->
 <!-- How to Start -->
    <section class="sec-white sec-tpadding-2">
    <div class="container">
      <div class="row align-items-center" style="display: flex; flex-wrap: wrap;">
        <div class="col-md-6 mb40">
          <h2 class="text-left text-orange font44 fontNormal">How to Start?</h2>
          <p class="text-left font24 fontNormal">Its very simple</p>
          <p class="text-left font20">Register, Verify Your Email, Mobile Number and Start Trading.</p>
            <!--<div class="mt40"><img src="assets/imgs/steps.png" class="img-responsive"></div>-->
        </div>
        <!--end item-->

        <div class="col-md-6"> <img src="{{URL::asset('front')}}/assets/imgs/alphaex_screen.png" alt="" class="img-responsive"> </div>
        <!--end item-->
      </div>
    </div>
  </section>
    <!-- / How to Start -->
    <div class="clearfix"></div>


  <section class="parallax-section1">
    <div class="section-overlay bg-opacity-9">
      <div class="container sec-tpadding-2 sec-bpadding-2">
        <div class="row">
      <div class="col-xs-12 mb40">
      <div class="col-md-8 col-sm-offset-2">
        <p class="text-center text-green font28">With blockchain technology continuing to innovate, alphaex supports established and emerging Digital currencies like Bitcoin-BTC, Ethereum-ETH, Ripple-XRP, Xinfin XDC at this moment.</p>
      </div>
      </div>

      <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
        <div class="contact-info-holder">
          <div class="sideline"></div>
          <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/BTC.png" alt=""></div>
        </div>
      </div>
      <!--end item-->

      <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
        <div class="contact-info-holder active">
          <div class="sideline"></div>
          <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/ETH.png" alt=""></div>
        </div>
      </div>
      <!--end item-->

      <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
        <div class="contact-info-holder">
          <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/XRP.png" alt=""></div>
        </div>
      </div>
      <!--end item-->

      <div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">
        <div class="contact-info-holder">
          <div class="iconbox-xmedium round white"><img src="{{URL::asset('front')}}/assets/icons/XDC.png" alt=""></div>
        </div>
      </div>
      <!--end item-->
      <div class="clearfix"></div>
    </div>
      </div>
    </div>
  </section>
  <div class="clearfix"></div>
 <!--Start of Zendesk Chat Script-->
 <script type="text/javascript">
     window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
         d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
     _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
         $.src="https://v2.zopim.com/?5ITMJ6sGQRObFmQft2Foia6vuJIJXs6b";z.t=+new Date;$.
             type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
 </script>
 <!--End of Zendesk Chat Script-->

 <!-- Modal HTML -->
 {{--<div id="myModal" class="modal">--}}
     {{--<div class="modal-dialog">--}}
         {{--<div class="modal-content">--}}
             {{--<div class="modal-header">--}}
                 {{--<div class="modal-title">XDCE ICO</div>--}}
             {{--</div>--}}
             {{--<div class="modal-body">--}}
                 {{--<div class="text-center"><a href="{{url('/ico')}}"><img src="{{URL::asset('front')}}/assets/imgs/ico-banner.jpg" class="img-responsive"></a></div>--}}
                 {{--<div class="text-center" style="margin-top:-12%;"><a href="{{url('/ico')}}" target="_blank"><button type="button" class="btn btn-rounded">Join ICO Now</button></a></div>--}}
             {{--</div>--}}
             {{--<div class="modal-footer">--}}
                 {{--<div class="col-sm-12 text-right">--}}
                     {{--<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>--}}
                 {{--</div>--}}
             {{--</div>--}}
         {{--</div>--}}
     {{--</div>--}}
 {{--</div>--}}

@endsection

@section('xscript')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    {{--<script type="text/javascript">--}}
        {{--$(window).on('load',function(){--}}



            {{--$("#myModal").modal({--}}
                {{--show: true,--}}
                {{--backdrop: 'true'--}}
            {{--});--}}
        {{--});--}}
        {{--$(document).keydown(function(e) {--}}
            {{--if (e.keyCode == 27) {--}}
                {{--$("#myModal").modal('hide');--}}

            {{--}--}}
        {{--});--}}
    {{--</script>--}}
<script>
function change_captcha()
{
    $("#capimg").html('Loading....');
    $.post('{{url("ajax/refresh_capcha")}}',function(data,result)
    {
       $("#capimg").html(data);
    });
}


</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

<script type="text/javascript">
    $("#login_form").validate({
        rules:
        {
            login_mail:{required:true,email:true,},
            password:{required:true,},
            captcha:{required:true,},
        },
        messages:
        {
            login_mail:{required:'Email is required',email:'Enter valid email address',},
            password:{required:'Password is required',},
            captcha:{required:'Captha is required',},
        },
    });
</script>


@endsection
