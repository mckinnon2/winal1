@extends('front.layout.front')

@section('css')
    <link rel="stylesheet" href="{{URL::asset('front')}}/build/css/countrySelect.css">
@endsection

@section('content')

    <!-- Profile, Edit Profile & Change Password -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <!-- left navigation -->
            @include('front.sidebar')
            <!-- / left navigation -->

                <!--  right panel - profile, edit profile & change password data -->
                <div class="col-md-9">
                    @include('front.alert')
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="panel-body noPadd">
                                <ul class="nav nav-tabs profile-tabs">
                                    <li class="active"><a data-toggle="tab" href="#aboutme" aria-expanded="false">Profile</a></li>
                                    <li><a data-toggle="tab" href="#edit-profile" aria-expanded="true">Edit Profile</a></li>
                                    <li><a data-toggle="tab" href="#projects" aria-expanded="false">Change Password</a></li>
                                    <!--  <li><a data-toggle="tab" href="#kycdocuments" aria-expanded="false">KYC</a></li> -->
                                </ul>

                                <div class="tab-content m-0">

                                    <!-- Profile -->
                                    <div id="aboutme" class="tab-pane active">
                                        <div class="profile-desk">

                                            <h4>Personal Information</h4>

                                            <div class="table-responsive noBorder mb40">
                                                <table class="table">
                                                    <tbody>
                                                    <tr>
                                                        <td>User Name</td>
                                                        <td>{{$result->enjoyer_name}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Email Id</td>
                                                        <td>{{get_usermail($result->id)}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>First Name</td>
                                                        <td>{{$result->first_name}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Last Name</td>
                                                        <td>{{$result->last_name}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Contact Number</td>
                                                        <td class="ng-binding">
                                                            ({{$result->mob_isd}}) {{owndecrypt($result->mobile_no)}}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Country</td>
                                                        <td>{{get_country_name($result->country)}}</td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <h4>Status</h4>

                                            <div class="table-responsive noBorder">
                                                <table class="table">
                                                    <tbody>
                                                    <tr>
                                                        <td>&bull; Email Status</td>
                                                        <td>
                                                            @if($result->verify_status==1)
                                                                <span class="label label-success">Verified</span>
                                                            @else
                                                                <span class="label label-danger">Un-verified</span>
                                                            @endif
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>&bull; Mobile Status</td>
                                                        <td>
                                                            @if($result->mobile_status==1)
                                                                <span class="label label-success">Verified</span>
                                                            @else
                                                                <span class="label label-danger">Un-verified</span>
                                                            @endif
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>&bull; TFA Status</td>
                                                        <td>
                                                            @if($result->tfa_status=='enable')
                                                                <span class="label label-success">Enabled</span>
                                                            @else
                                                                <span class="label label-danger">Disabled</span>
                                                            @endif
                                                        </td>
                                                    </tr>

                                                    </tbody>
                                                </table>
                                            </div>

                                        <!--  <h4>KYC Documents</h4>

                                            <div class="table-responsive noBorder">
                                                <table class="table">
                                                    <tbody>
                                                        <tr>
                                                            <td>&bull; Pan card</td>
                                                            <td>
                                                @if(get_document_status($result->id,'proof1_status')==1)
                                            <span class="label label-success">Verified</span>
@elseif(get_document_status($result->id,'proof1_status')==2)
                                            <span class="label label-danger">Rejected</span>
@elseif(get_document_status($result->id,'proof1_status')=='0')
                                            <span class="label label-warning">Pending</span>
@else
                                            <span class="label label-danger">Not-Verified</span>
@endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&bull; Adhar card</td>
                                                            <td>
                                                     @if(get_document_status($result->id,'proof2_status')==1)
                                            <span class="label label-success">Verified</span>
@elseif(get_document_status($result->id,'proof2_status')==2)
                                            <span class="label label-danger">Rejected</span>
@elseif(get_document_status($result->id,'proof2_status')=='0')
                                            <span class="label label-warning">Pending</span>
@else
                                            <span class="label label-danger">Not-Verified</span>
@endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&bull; Address proof</td>
                                                            <td>
                                                            @if(get_document_status($result->id,'proof3_status')==1)
                                            <span class="label label-success">Verified</span>
@elseif(get_document_status($result->id,'proof3_status')==2)
                                            <span class="label label-danger">Rejected</span>
@elseif(get_document_status($result->id,'proof3_status')=='0')
                                            <span class="label label-warning">Pending</span>
@else
                                            <span class="label label-danger">Not-Verified</span>
@endif
                                                </td>
                                            </tr>


                                            <tr>
                                                <td>&bull; Over All status</td>
                                                            <td>
                                                            @if($result->document_status==1)
                                            <span class="label label-success">Verified</span>
@elseif($result->document_status==2)
                                            <span class="label label-danger">Rejected</span>
@else
                                            <span class="label label-warning">Not-Verified</span>
@endif
                                                </td>
                                            </tr>

@if(get_document_status($result->id,'reason'))
                                            <tr>
                                             <td>&bull; Reason</td>
                                                            <td>
                                                            {{get_document_status($result->id,'reason')}}
                                                    </td>
                                                </tr>
@endif

                                                </tbody>
                                            </table>
                                        </div> -->

                                        </div>
                                    </div>
                                    <!-- / Profile -->

                                    <!-- Edit Profile -->
                                    <div id="edit-profile" class="tab-pane">
                                        <div class="user-profile-content">
                                            <form role="form" id="profile_update" action="{{url('profile')}}" method="post">
                                                {{csrf_field()}}
                                                <div class="form-group">
                                                    <input type="text" class="form-control input-lg" name="username" placeholder="User Name" value="{{$result->enjoyer_name}}">
                                                </div>
                                                <input type="hidden" id="ptostatus" name="ptostatus">
                                                <div class="form-group">
                                                    <input type="email" class="form-control input-lg" id="Email" disabled="disabled" value="{{get_usermail($result->id)}}">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input-lg" name="first_name" placeholder="first Name" value="{{$result->first_name}}">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input-lg" name="last_name" placeholder="Last Name" value="{{$result->last_name}}">
                                                </div>
                                                <div class="col-xs-12">
                                                    <div class="form-group input-group">
                                                        <span class="input-group-addon"><strong id="country_selector" class="input-lg"></strong></span>
                                                        <input type="hidden" name="isdcode" id="isdcode" value="0" data-id="{{strtolower($countrycode->iso)}}">
                                                        <input type="number" class="form-control input-lg" name="telephone" placeholder="Phone number" id="telephone" value="{{owndecrypt($result->mobile_no)}}">
                                                        {{--@if($result->mobile_status!=1)--}}
                                                            {{--<span class="input-group-addon" id="susotp">--}}
                                                          {{--<a href="#modal-otp" id="otp_but" class="btn btn-info btn-sm" onclick="sendotp()">Send OTP</a>--}}
                                                        {{--</span>--}}
                                                        {{--@endif--}}
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <textarea class="form-control input-lg" name="address" placeholder="Address">{{$result->address}}</textarea>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input-lg" name="state" placeholder="State" value="{{$result->state}}">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input-lg" name="city" placeholder="City" value="{{$result->city}}">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input-lg" value="{{get_country_name($result->country)}}" disabled="disabled">
                                                </div>

                                                <button class="btn btn-primary" type="submit" onclick="savenumber()">Save</button>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- / Edit Profile -->

                                    <!-- Change Password -->
                                    <div id="projects" class="tab-pane">
                                        <div class="user-profile-content">
                                            <form id="change_pass" action="{{url('/change_password')}}" method="post" role="form">
                                                {{csrf_field()}}
                                                <div class="form-group">
                                                    <input type="password" class="form-control input-lg" name="old_password" placeholder="Current Password">
                                                </div>
                                                <div class="form-group">
                                                    <input type="password" class="form-control input-lg" id="new_pass" name="password" placeholder="New Password">
                                                </div>
                                                <div class="form-group">
                                                    <input type="password" class="form-control input-lg" name="password_confirmation" placeholder="Re-type New Password">
                                                </div>

                                                <button class="btn btn-primary" type="submit">Save</button>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- / Change Password -->


                                    <!-- KYC document -->
                                    <div id="kycdocuments" class="tab-pane">
                                        <div class="user-profile-content">
                                            <form action="{{url('document_submission')}}" method="post" id="kycform" enctype= "multipart/form-data" >
                                                {{csrf_field()}}
                                                <div class="form-group">
                                                    <label class="label-control font16">PAN Card :</label>
                                                    @if(get_document_status($result->id,'proof1_status')!=1)
                                                        <input type="file"  name="proof1">
                                                    @endif
                                                    @if(get_document_status($result->id,'proof1'))

                                                        <img src="{{getDataURI(public_path('/uploads/users/documents/').get_document_status($result->id,'proof1'))}}" style="width: 100px;height: 75px;" />

                                                    @endif
                                                </div>

                                                <div class="form-group">
                                                    <label class="label-control font16">Adhaar Card : </label>
                                                    @if(get_document_status($result->id,'proof2_status')!=1)
                                                        <input type="file"  name="proof2">
                                                    @endif
                                                    @if(get_document_status($result->id,'proof2'))

                                                        <img src="{{getDataURI(public_path('/uploads/users/documents/').get_document_status($result->id,'proof2'))}}" style="width: 100px;height: 75px;" />
                                                    @endif
                                                </div>

                                                <div class="form-group">
                                                    <label class="label-control font16">Address Proof : </label>
                                                    @if(get_document_status($result->id,'proof3_status')!=1)
                                                        <input type="file"  name="proof3">
                                                    @endif
                                                    @if(get_document_status($result->id,'proof3'))

                                                        <img src="{{getDataURI(public_path('/uploads/users/documents/').get_document_status($result->id,'proof3'))}}" style="width: 100px;height: 75px;" />
                                                    @endif
                                                </div>
                                                @if($result->document_status !='1')

                                                    <input type="submit" class="btn btn-primary" value="Update">
                                                @endif
                                            </form>
                                        </div>
                                    </div>
                                    <!-- / kyc documents -->


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / right panel - profile, edit profile & change password data -->
            </div>
        </div>
    </section>
    <!-- / Profile, Edit Profile & Change Password -->


    <!-- Small modal -->
    <div id="modal-otp" tabindex="-1" role="dialog" aria-labelledby="modal-login-label" aria-hidden="true"
         class="modal fade" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 id="modal-login-label" class="modal-title">Mobile Number Verification </h4></div>
                <div id="otp_message"></div>
                <div class="modal-body">
                    <div class="form">
                        <form class="form-horizontal" id="otp_form" method="post" action="#">
                            {{csrf_field()}}
                            <div class="form-group"><label class="control-label col-md-3">Enter Verification
                                    code</label>

                                <div class="col-md-9"><input id="verify_code" class="form-control" name="verify_code"
                                                             type="text">
                                    <br>
                                    <div id="countdown">
                                        <span style="float:left">Resend Link:&nbsp;</span>
                                        <div id="minutes" style="float:left;color: red">00</div>
                                        <div style="float:left">:</div>
                                        <div id="seconds" style="float:left;color: red">00</div>
                                    </div>
                                    <div id="aftercount" style="display:none">Support Link:&nbsp;<a href="{{url('/contact_us')}}" style="color: lightblue">click Here</a></div>
                                    <div id="aftercount_msg" style="display:none">*If you do not recieve OTP within 15 minutes please contact support by clicking the above link </div>

                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-9 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary reg_btn" onclick="verify_otp()">Submit</button>&nbsp;&nbsp;
                                    <button type="button" class="btn btn-danger reg_btn"  data-dismiss="modal">Cancel</button>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <label><strong>Note:</strong> &nbsp;Withdrawal cannot be done until mobile number is verified.<br>&nbsp;</label>
                            </div>


                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

@endsection

@section('xscript')

    <script>
        function linkactivate()
        {
            try
            {
                var sTime = new Date().getTime();
                var countDown = 30;

                function UpdateTime() {
                    var cTime = new Date().getTime();
                    var diff = cTime - sTime;
                    var seconds = countDown - Math.floor(diff / 1000);
                    if (seconds >= 0) {
                        var minutes = Math.floor(seconds / 60);
                        seconds -= minutes * 60;
                        $("#minutes").text(minutes < 10 ? "0" + minutes : minutes);
                        $("#seconds").text(seconds < 10 ? "0" + seconds : seconds);
                    } else {
                        $("#countdown").hide();
                        $("#aftercount").show();
                        $('#aftercount_msg').show();
                        clearInterval(counter);
                    }
                }
                UpdateTime();
                var counter = setInterval(UpdateTime, 500);

            }
            catch(e)
            {
                console.log(e);
            }
        }

    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

    <script type="text/javascript">
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
  </script>

    <script>


        $("#change_pass").validate({
            rules:
                {
                    old_password:{required:true,remote:{url:"{{url('ajax/checkoldpass')}}",type:'post',data:{'_token':"{{ csrf_token() }}"}}},
                    password:{required:true,minlength:6},
                    password_confirmation:{required:true,equalTo:'#new_pass',},
                },
            messages:
                {
                    old_password:{required:'Old Password is required',remote:'Old password is wrong',},
                    password:{required:'Password is required',minlength:'minimum 6 characters is required'},
                    password_confirmation:{required:'Confirm password is required',equalTo:'password does not match',},

                },
        });
    </script>

    <script src="{{URL::asset('front')}}/build/js/countrySelect.js"></script>
    <script>
        function set_country() {
            var code = $('#isdcode ').attr('data-id');
            $("#country_selector").countrySelect("selectCountry", code);
        }
        $("#country_selector").countrySelect({
            preferredCountries: ['jp', 'in', 'gb', 'us']
        });

    </script>

    <script>
        $(document).ready(function(){
            set_country();
            $(window).load(function(){
                if({{$flag}}==1)
                {
                    sendotp();
                }
            })
        });
    </script>

    <script type="text/javascript">
        $("#profile_update").validate({
            rules:
                {
                    username:{required:true,},
                    first_name:{required:true,},
                    last_name:{required:true,},
                    telephone:{required:true,number:true,},
                    address:{required:true,},
                    state:{required:true,},
                    city:{required:true,},
                },
            messages:
                {
                    username:{required:'Username is required',},
                    first_name:{required:'First name is required',},
                    last_name:{required:'Last name is required',},
                    telephone:{required:'Mobile number is required',number:'Enter valid mobile number',},
                    address:{required:'Address is required',},
                    state:{required:'State is required',},
                    city:{required:'City is required',},
                },

        });
    </script>

    <script>
        function verify_otp()
        {
            var code=$('#verify_code').val();
            var mobile=$('#telephone').val();
            var user_id={{$result->id}};
            $.ajax({
                url:'{{url("ajax/verify_otp")}}',
                method:'post',
                data:{'verify_code':code, 'mobile':mobile, 'user_id':user_id},
                success : function(data)
                {
                    location.reload();
                }
            });
        }
    </script>

    <script>
        $("#telephone").keydown(function (evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode
            if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                return false;
            return true;
        });

        function change_mobile(str)
        {
            $("#upt_mob").html('<a id="otp_but" class="btn btn-info btn-sm" onclick="sendotp()">Send OTP</a>');
        }

        function sendotp()
        {
            var countryData = $("#country_selector").countrySelect("getSelectedCountryData");
            var isd = countryData.isd;
            $("#isdcode").val(isd);
            var isdcode = $("#isdcode").val();
            var mobile=$("#telephone").val();
            var email=$('#Email').val();
            var user_id = {{$result->id}};
            $.ajax({
              url:'{{url("ajax/checkphone")}}',
              method:'post',
              data:{'mobile_no':mobile,'user_id':user_id},
              success:function(data)
              {
                console.log(data);
                obj = JSON.parse(data);
                if(obj.message=='1')
                {
                  window.location.href = "{{url("/profile")}}";
                }
                else {
                  $.ajax({
                      url:'{{url("ajax/registerotp")}}',
                      method:'post',
                      data:{'isdcode':isdcode,'phone':mobile,'reg_email':email, 'type': 'Update'},
                      success:function(output)
                      {
                          obj = JSON.parse(output);
                          if(obj.status=='1')
                          {
                              $("#modal-otp").modal({
                                  backdrop: 'static',
                                  keyboard: false
                              });
                              linkactivate();
                          }
                          else
                          {
                              $("#otp_msg").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+obj.sms+'</div>')
                          }
                      }
                  });

                }
              }
            });
        }
    </script>

    <script>
        function savenumber()
        {
            var countryData = $("#country_selector").countrySelect("getSelectedCountryData");
            var isd = countryData.isd;
            $("#isdcode").val(isd);
            var isdcode = $("#isdcode").val();
        }
    </script>

    <script type="text/javascript">
        $("#otp_form").validate(
            {
                rules:
                    {
                        verify_code:{required:true,number:true,},
                    },
                messages:
                    {
                        verify_code:{required:'Verification code is required',number:'Digit only allowed',},
                    },
                submitHandler: function(form)
                {
                    var otpser=$("#otp_form").serialize();
                    var mob=$('#telephone').val();

                    $.ajax({
                        type:'post',
                        url:'{{url("ajax/verify_otp")}}',
                        data:otpser+'&mobile='+mob,
                        success:function(data)
                        {

                            otpobj = JSON.parse(data);
                            if(otpobj.status=='1')
                            {
                                $("#telephone").attr('readonly','readonly');
                                $("#otp_but").html('verified');
                                $("#modal-otp").modal('hide');
                                $("#ptostatus").val(otpobj.key);
                                $("#otp_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+otpobj.message+'</div>');
                            }
                            else
                            {
                                $("#otp_but").html('Failed');
                                $("#ptostatus").val(otpobj.key);
                                $("#otp_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+otpobj.message+'</div>');
                            }
                        }
                    })
                }
            });
    </script>

    <script type="text/javascript">
        $("#kycform").validate(
            {
                rules:
                    {
                        proof1:{required:true,},
                        proof2:{required:true,},
                        proof3:{required:true,},
                    },
                messages:
                    {
                        proof1:{required:'Pan Card is required',},
                        proof2:{required:'Adhaar Card is required',},
                        proof3:{required:'Address proof is required',},
                    }
            });
    </script>


@endsection
