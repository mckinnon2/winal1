
@extends('front.layout.front')
@section('content')

 <!-- Wallet datatable -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <div class="panel panel-default noBorder">
                        <div class="panel-body">


                            <div class="table-responsive">
                                <table class="table table-striped table-bordered tableBorder" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th>Currency</th>
                                            <th>Balance</th>
                                            <th>Deposit</th>
                                            <th>Withdrawal</th>
                                            <th>History</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>XDC</td>
                                            <td>{{get_userbalance($userid,'XDC')}}</td>
                                            <td><a href="{{url('deposit/XDC')}}" class="btn-add-delete"><i class="fa fa-plus"></i></a></td>
                                            <td><a href="{{url('transfercrypto/xdc')}}" class="btn-add-delete"><i class="fa fa-minus"></i></a></td>
                                            <td><a href="{{url('wallet_history/XDC')}}" class="btn-add-delete"><i class="fa fa-a"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td>BTC</td>
                                            <td>{{get_userbalance($userid,'BTC')}}</td>
                                            <td><a href="{{url('deposit/BTC')}}" class="btn-add-delete"><i class="fa fa-plus"></i></a></td>
                                            <td><a href="{{url('transfercrypto/btc')}}" class="btn-add-delete"><i class="fa fa-minus"></i></a></td>
                                            <td><a href="{{url('wallet_history/BTC')}}" class="btn-add-delete"><i class="fa fa-a"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td>ETH</td>
                                            <td>{{get_userbalance($userid,'ETH')}}</td>
                                            <td><a href="{{url('deposit/ETH')}}" class="btn-add-delete"><i class="fa fa-plus"></i></a></td>
                                            <td><a href="{{url('transfercrypto/eth')}}" class="btn-add-delete"><i class="fa fa-minus"></i></a></td>
                                            <td><a href="{{url('wallet_history/ETH')}}" class="btn-add-delete"><i class="fa fa-a"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td>XRP</td>
                                            <td>{{get_userbalance($userid,'XRP')}}</td>
                                            <td><a href="{{url('deposit/XRP')}}" class="btn-add-delete"><i class="fa fa-plus"></i></a></td>
                                            <td><a href="{{url('transfercrypto/xrp')}}" class="btn-add-delete"><i class="fa fa-minus"></i></a></td>
                                            <td><a href="{{url('wallet_history/XRP')}}" class="btn-add-delete"><i class="fa fa-a"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td>XDCE</td>
                                            <td>{{get_userbalance($userid,'XDCE')}}</td>
                                            <td><a href="{{url('deposit/XDCE')}}" class="btn-add-delete"><i class="fa fa-plus"></i></a></td>
                                            <td><a href="{{url('transfercrypto/xdce')}}" class="btn-add-delete"><i class="fa fa-minus"></i></a></td>
                                            <td><a href="{{url('wallet_history/XDCE')}}" class="btn-add-delete"><i class="fa fa-a"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td>BCH</td>
                                            <td>{{get_userbalance($userid,'BCH')}}</td>
                                            <td><a href="{{url('deposit/BCH')}}" class="btn-add-delete"><i class="fa fa-plus"></i></a></td>
                                            <td><a href="{{url('transfercrypto/bch')}}" class="btn-add-delete"><i class="fa fa-minus"></i></a></td>
                                            <td><a href="{{url('wallet_history/BCH')}}" class="btn-add-delete"><i class="fa fa-a"></i></a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <p><strong>Warning *</strong> On security aspect, We advice to transfer BTC/ETH/XRP/XDC/XDCE/BCH balance to your Cold/Hot wallet as soon as Trade takes place</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- / Wallet datatable -->

@endsection

@section('xscript')
<script>
    $(document).ready(function() {
    var sum = 0;
    $('.price').each(function() {
        var price = $(this);
        sum += parseFloat(price.html());
    });

    $('#total_usd').html("US $ "+sum.toFixed(2));
});
</script>
@endsection

