@extends('front.layout.front')
@section('content')

    <!-- trade home data and datatables -->
    <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">


                <div class="col-sm-12">
                    @include('front.alert')
                    <div class="page-header page-header-panel">
                        <div class="col-md-4">
                            <h3>Trading Pair</h3>

                        </div>
                        <div class="col-md-5">
                            <p><strong>Buy Rate :</strong> <span>{{sprintf('%.8f',$buy_rate)}}</span>
                                <strong>Sell Rate :</strong> <span>{{sprintf('%.8f',$sell_rate)}}</span></p>
                        </div>
                        <div class="col-md-3 text-right"><span id="book_selector">
                        <div class="tab-navigation">
                            <ul class="nav" role="tablist">
                            <li role="presentation" class="dropdown open">
                            <select id="select-box" onchange="change_trade(this.value);">
                                <option value="XDC-ETH" {{second_selected('XDC-ETH')}} >XDC / ETH</option>
                                <option value="XDC-BTC" {{second_selected('XDC-BTC')}} >XDC / BTC</option>
                                <option value="XDC-XRP" {{second_selected('XDC-XRP')}} >XDC / XRP</option>
                                 <option value="XDC-BCH" {{second_selected('XDC-BCH')}} >XDC / BCH</option>
                                 <option value="XDC-XDCE" {{second_selected('XDC-XDCE')}} >XDC / XDCE</option>

                            </select>
                            </li>
                            </ul>
                        </div>
                    </span></div>
                    </div>
                </div>


                <div id="col-sm-12">

                    <!-- XDC/BTC chart and all data and datatables -->
                    <div id="tab-1" class="tab--content">
                        <div class="col-md-8 mt10">
                            <h4>{{$pair}}</h4>

                        </div>

                        <div class="col-md-8 mb40">
                            <div id="container" style="height: 400px; min-width: 310px">
                                <img src="{{URL::asset("front")}}/assets/imgs/chartloading.gif" style="display: block; height:10%; width:10%; margin-top:180px; margin-left:auto; margin-right:auto;">
                            </div>

                        </div>

                        <!-- buy sell box data -->
                        <div class="col-md-4">
                            <input type="hidden" name="what_cur" id="what_cur" value="{{$second_currency}}">
                            <div class="panel panel-buy qb-selector">
                                <div class="panel-heading">
                                    @if($pair == 'XDC-XDCE')
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li class="active"><a href="#swap_XDCE" role="tab" onclick="swapAmount('xdce')" data-toggle="tab"
                                                >Swap XDCE</a></li>
                                            <li><a href="#swap_XDC" onclick="swapAmount('xdc')" role="tab" data-toggle="tab" >Swap XDC
                                                </a></li>
                                        </ul>
                                    @else
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li class="active" id="buy_tab"><a href="#buy" role="tab" data-toggle="tab"
                                                                               class="tab-buy">Buy Order</a></li>
                                            <li id="sell_tab"><a href="#sell" role="tab" data-toggle="tab" class="tab-sell">Sell
                                                    Order</a></li>
                                        </ul>
                                    @endif

                                </div>
                                <div class="panel-body">
                                    <div class="tab-content">
                                        <div id="load_message" class="text-center">
                                        </div>
                                        <div class="input-group">
                                            <select class="form-control" id="order_list"
                                                    onchange="trading_uiform(this.value)">
                                                <!--  <option value="1">Instant Order</option> -->
                                                <option value="2">Limit Order</option>
                                                <!-- <option value="3">Stop Order</option> -->
                                            </select>
                                        </div>

                                        @if($pair == 'XDC-XDCE')
                                            {{--swap xdce tab--}}
                                            <div class="tab-pane active" id="swap_XDCE">
                                                <p class="text-center">Balance
                                                    : {{$second_cur_balance}} {{$second_currency}}</p>
                                                <form class="tradeinput form-horizontal"
                                                      action="{{url('/swap')}}" onsubmit="return validateSwapXDC('xdce')">
                                                    <div>
                                                        {{csrf_field()}}
                                                        <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i
                                                                    class="fa"><img
                                                                        src="{{URL::asset('front')}}/assets/icons/{{$second_currency}}.png"
                                                                        width="16px" height="16px"></i></span>
                                                            <input class="form-control block_non_numbers"
                                                                   id="swap_amount_xdce"
                                                                   onkeypress='return event.charCode >= 48 && event.charCode <= 57'
                                                                   name="swap_amount"
                                                                   onkeyup="swapAmount('xdce')"
                                                                   placeholder="enter amount to be swapped"
                                                                   required="required">

                                                            <input type="hidden" name="currency" value="{{$second_currency}}">
                                                        </div>
                                                        <label style="color: red;display: none" id="error_xdce">*Enter Amount greater than 1000</label>


                                                    </div>
                                                    <div class="qb-button">
                                                        <button type="submit"
                                                                class="btn btn-green btn-action" id="btn-buy">Swap XDCE
                                                        </button>

                                                    </div>
                                                </form>
                                            </div>


                                            {{--swap xdc tab--}}
                                            <div class="tab-pane " id="swap_XDC">
                                                <p class="text-center">Balance
                                                    : {{$first_cur_balance}} {{$first_currency}}</p>
                                                <form class="tradeinput form-horizontal"
                                                      action="{{url('/swap')}}" id="swap_xdc_form" onsubmit="return validateSwapXDC('xdc')">
                                                    <div>
                                                        {{csrf_field()}}
                                                        <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i
                                                                    class="fa"><img
                                                                        src="{{URL::asset('front')}}/assets/icons/{{$first_currency}}.png"
                                                                        width="16px" height="16px"></i></span>
                                                            <input class="form-control block_non_numbers"
                                                                   name="swap_amount"
                                                                   onkeypress='return event.charCode >= 48 && event.charCode <= 57'
                                                                   id="swap_amount_xdc"
                                                                   onkeyup="swapAmount('xdc')"
                                                                   placeholder="enter amount to be swapped"
                                                                   required="required"
                                                            >
                                                            <input type="hidden" name="currency" value="{{$first_currency}}">
                                                        </div>
                                                        <label style="color: red;display: none" id="error_xdc">*Enter Amount greater than 1000</label>


                                                    </div>
                                                    <div class="qb-button">
                                                        <button type="submit"
                                                                class="btn btn-green btn-action" id="btn-buy">Swap XDC
                                                        </button>

                                                    </div>
                                                </form>
                                            </div>

                                        @else
                                            {{--buy tab--}}
                                            <div class="tab-pane active" id="buy">
                                                <p class="text-center">Balance
                                                    : {{$second_cur_balance}} {{$second_currency}}</p>
                                                <form class="tradeinput form-horizontal" data-tradedirection="buy"
                                                      role="form" autocomplete="off" id="buy_ins_form"
                                                      action="javascript:;">
                                                    <div>
                                                        {{csrf_field()}}
                                                        <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i
                                                                    class="fa"><img
                                                                        src="{{URL::asset('front')}}/assets/icons/{{$first_currency}}.png"
                                                                        width="16px" height="16px"></i></span>
                                                            <input class="form-control block_non_numbers"
                                                                   id="buy_ins_{{$first_currency}}"
                                                                   name="buy_ins_{{$first_currency}}"
                                                                   onkeyup="instant_order('buy');"
                                                                   @if($pair == 'XDC-XDCE')onchange="swapValue()" @endif
                                                                   placeholder="{{$first_currency}}" title="Amount spend"
                                                                   value="0">

                                                            <input type="hidden" id="buy_fee_amount" name="buy_fee_amount"
                                                                   value="0">
                                                            <input type="hidden" id="buy_price_amount"
                                                                   name="buy_price_amount" value="0">
                                                        </div>


                                                    </div>
                                                    <div class="qb-button">
                                                        <button type="button"
                                                                onclick="trade_popup_ins('buy','buy_ins_form')"
                                                                class="btn btn-green btn-action" id="btn-buy">Buy
                                                        </button>

                                                    </div>
                                                </form>
                                            </div>
                                            <div class="tab-pane" id="sell">
                                                <p class="text-center">Balance
                                                    : {{$first_cur_balance}} {{$first_currency}}</p>
                                                <form class="tradeinput form-horizontal" data-tradedirection="sell"
                                                      role="form" autocomplete="off" id="sell_ins_form"
                                                      action="javascript:;">
                                                    <div>
                                                        {{csrf_field()}}
                                                        <div class="input-group">
                                                        <span class="input-group-addon" style="padding-right:10px;"><i
                                                                    class="fa"><img
                                                                        src="{{URL::asset('front')}}/assets/icons/{{$first_currency}}.png"
                                                                        width="16px" height="16px"></i></span>
                                                            <input class="form-control block_non_numbers"
                                                                   id="sell_ins_{{$first_currency}}"
                                                                   name="sell_ins_{{$first_currency}}"
                                                                   onkeyup="instant_order('sell');"
                                                                   placeholder="{{$first_currency}}" title="Amount spend"
                                                                   value="0">
                                                            <input type="hidden" name="sell_fee_amount" id="sell_fee_amount"
                                                                   value="0">
                                                            <input type="hidden" id="sell_price_amount"
                                                                   name="sell_price_amount" value="0">
                                                        </div>

                                                    </div>
                                                    <div class="qb-button">
                                                        <button type="button" class="btn btn-warning btn-action"
                                                                id="btn-sell"
                                                                onclick="trade_popup_ins('sell','sell_ins_form')">Sell
                                                        </button>

                                                    </div>
                                                </form>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="panel-error"></div>
                                <div class="panel-footer">
                                    @if($pair =='XDC-XDCE')
                                        <div class="row">
                                            <input type="hidden" id="trade_frm_id" value="">
                                            <div class="col-xs-6">
                                                <div>Fee ({{$second_currency}}):</div>
                                                <span id="trade_fee">0 %</span>
                                            </div>
                                            <div class="col-xs-6">
                                                <div> Total :</div>
                                                <span id="swapTotal">0</span>
                                            </div>
                                        </div>
                                    @else
                                        <div class="row">
                                            <input type="hidden" id="trade_frm_id" value="">
                                            <div class="col-xs-6">
                                                <div>Fee ({{$second_currency}}):</div>
                                                <span id="trade_fee">{{$trading_fee}} %</span>
                                            </div>
                                            <div class="col-xs-6">
                                                <div> Total ({{$second_currency}}) :</div>
                                                <span id="total_{{$second_currency}}">0</span>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <!-- / buy sell box data -->


                    </div>
                    <!-- / XDC/BTC chart and all data and datatables -->


                </div>

                @if($pair == 'XDC-XDCE')
                    <div class="col-md-12 mb40">
                        <div class="head">
                            <div class="name font20">Your Trade Orders</div>
                        </div>

                        <div class="table-responsive">
                            <table id="active_orders" class="table table-striped table-bordered tableBorder" cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <th class="text-center">Type</th>
                                    <th class="text-center">Date &amp; Time</th>
                                    <th class="text-center">{{$first_currency}}</th>
                                    <th class="text-center">{{$second_currency}}</th>
                                    <th class="text-center">Price ({{$second_currency}})</th>
                                    <th class="text-center">Fee</th>
                                    <th class="text-center">Sum({{$second_currency}})</th>
                                    <th class="text-center">Status</th>

                                </tr>
                                </thead>
                                <tbody>
                                @if(isset($active_orders[0]))
                                    @foreach($active_orders as $active_ord)
                                        <tr>
                                            <td class="text-center">{{$active_ord->Type}}</td>
                                            <td class="text-center">{{$active_ord->created_at}}</td>
                                            <td class="text-center price">{{$active_ord->Amount}}</td>
                                            <td class="text-center price">{{sprintf('%.8f',$active_ord->Price)}}</td>
                                            <td class="text-center price">{{($active_ord->Price * $active_ord->Amount)}}</td>
                                            <td class="text-center price">{{$active_ord->Fee}}</td>
                                            <td class="text-center price">{{$active_ord->Total}}</td>
                                            @if($active_ord->status=='active')
                                                <td class="text-center">Pending</td>
                                            @else
                                                <td class="text-center">{{$active_ord->status}}</td>
                                            @endif
                                        </tr>
                                    @endforeach
                                @else
                                    <td class="text-center" colspan="9">
                                        No Record Found
                                    </td>
                                @endif
                                </tbody>
                            </table>

                        </div>
                    </div>
                @else
                    <div class="col-md-12 mt80">
                        <div class="col-md-6 mb40">

                            <div class="head">
                                <div class="name">Sell Orders</div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-striped table-bordered tableBorder" id="buy_ord_tbl">
                                    <thead>
                                    <tr>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">{{$first_currency}}</th>
                                        <th class="text-center">SUM ({{$second_currency}})</th>
                                    </tr>
                                    </thead>
                                    <tbody id="buy_ord_tbl_data">
                                    @if(isset($buy_order_list[0]))
                                        @foreach($buy_order_list as $buy_list)
                                            <tr onclick="buy_click_value('{{sprintf('%.8f',$buy_list->Price)}}','{{$buy_list->Amount}}')">
                                                <td class="text-center price">{{sprintf('%.8f',$buy_list->Price)}}</td>
                                                <td class="text-center price">{{$buy_list->Amount}}</td>
                                                <td class="text-center price">{{sprintf('%f',($buy_list->Amount * $buy_list->Price))}}</td>
                                            </tr>
                                        @endforeach

                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-md-6 mb40">

                            <div class="head">
                                <div class="name">Buy Orders</div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-striped table-bordered tableBorder" id="sell_ord_tbl">
                                    <thead>
                                    <tr>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">{{$first_currency}}</th>
                                        <th class="text-center">SUM ({{$second_currency}})</th>
                                    </tr>
                                    </thead>
                                    <tbody id="sell_ord_tbl_data">
                                    @if(isset($sell_order_list[0]))
                                        @foreach($sell_order_list as $sell_list)
                                            <tr onclick="sell_click_value('{{sprintf('%.8f',$sell_list->Price)}}','{{$sell_list->Amount}}')">
                                                <td class="text-center price">{{sprintf('%.8f',$sell_list->Price)}}</td>
                                                <td class="text-center price">{{$sell_list->Amount}}</td>
                                                <td class="text-center price">{{sprintf('%f',($sell_list->Amount * $sell_list->Price))}}</td>
                                            </tr>
                                        @endforeach

                                    @endif

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>


                    <!-- Trade history -->

                    <div class="col-md-12 mb40">
                        <div class="head">
                            <div class="name font20">Recent 5 Trade</div>
                        </div>

                        <div class="table-responsive">
                            <table id="active_orders" class="table table-striped table-bordered tableBorder" cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <!-- <th class="text-center">Type</th> -->
                                    <th class="text-center">Date &amp; Time</th>
                                    <th class="text-center">{{$first_currency}}</th>
                                    <th class="text-center">Price({{$second_currency}})</th>
                                <!--  <th class="text-center">Total ({{$second_currency}})</th> -->
                                <!--  <th class="text-center">Fee</th>
                                            <th class="text-center">Sum ({{$second_currency}})</th> -->

                                </tr>
                                </thead>
                                <tbody>
                                @if(isset($trade_history[0]))
                                    @foreach($trade_history as $tradehis)
                                        <tr>
                                        <!-- <td class="text-center">{{$tradehis->Type}}</td> -->
                                            <td class="text-center price">{{$tradehis->updated_at}}</td>
                                            <td class="text-center price">{{$tradehis->Amount}}</td>

                                            @if($tradehis->Type=='Buy')
                                                <td class="text-center price">{{sprintf('%.8f',$tradehis->opt_price ? $tradehis->opt_price : $tradehis->Price)}}</td>
                                            @else
                                                <td class="text-center price">{{sprintf('%.8f',$tradehis->opt_price ? $tradehis->opt_price : $tradehis->Price)}}</td>
                                        @endif

                                        <!--  <td class="text-center price">{{sprintf('%.8f',($tradehis->Price * $tradehis->Amount))}}</td> -->
                                        <!--  <td class="text-center price">{{$tradehis->Fee}}</td>
                                             <td class="text-center price">{{$tradehis->Total}}</td> -->


                                        </tr>
                                    @endforeach
                                @else
                                    <td class="text-center" colspan="7">
                                        No Record Found
                                    </td>
                                @endif
                                </tbody>
                            </table>

                        </div>
                    </div>

                    <!-- Active orders -->

                    <div class="col-md-12 mb40">
                        <div class="head col-md-12">
                            <div class="name font20 col-md-9">Your Pending Order</div>
                            <div class="col-md-3">
                                <button class="btn-danger pull-right" id="cancel_button" style="margin-top:35px; display:none;" data-toggle="modal" data-target="#cancel_multiple">Cancel Trades</button>
                                <button class="btn-info pull-right" id="checknone" style="margin-top:35px; margin-right:5px; display:none;" onclick="check_none()">None</button>
                                <button class="btn-info pull-right" id="checkall" style="margin-top:35px; margin-right:5px; display:none;" onclick="check_all()">All</button>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table id="active_orders" class="table table-striped table-bordered tableBorder" cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Type</th>
                                    <th class="text-center">Date &amp; Time</th>
                                    <th class="text-center">{{$first_currency}}</th>
                                    <th class="text-center">{{$second_currency}}</th>
                                    <th class="text-center">Price ({{$second_currency}})</th>
                                    <th class="text-center">Fee</th>
                                    <th class="text-center">Sum({{$second_currency}})</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                @if(isset($active_orders[0]))
                                    @foreach($active_orders as $key=>$active_ord)
                                        <tr>
                                            <td class="text-center">{{$key+1}}</td>
                                            <td class="text-center">{{$active_ord->Type}}</td>
                                            <td class="text-center">{{$active_ord->created_at}}</td>
                                            <td class="text-center price">{{$active_ord->Amount}}</td>
                                            <td class="text-center price">{{sprintf('%.8f',$active_ord->Price)}}</td>
                                            <td class="text-center price">{{($active_ord->Price * $active_ord->Amount)}}</td>
                                            <td class="text-center price">{{$active_ord->Fee}}</td>
                                            <td class="text-center price">{{$active_ord->Total}}</td>
                                            @if($active_ord->status=='active')
                                                <td class="text-center">Pending</td>
                                            @else
                                                <td class="text-center">{{$active_ord->status}}</td>
                                            @endif
                                            <td class="text-center">
                                                <button class="btn btn-danger btn-xs" id="cancelsingle" value="{{base64_encode($active_ord->id)}}" data-toggle="modal" data-target="#cancel_single">&times;</button>
                                                &nbsp;&nbsp;<input type='checkbox' name='checked[]' style="margin-top: 15px;" id="checkbox{{$key}}" value="{{$active_ord->id}}" onclick="check_selected()">
                                            </td>

                                        </tr>
                                    @endforeach
                                @else
                                    <td class="text-center" colspan="9">
                                        No Record Found
                                    </td>
                                @endif
                                </tbody>
                            </table>

                        </div>
                    </div>
            @endif

            <!-- stop orders -->

            <!-- <div class="col-md-12 mb40">
                            <div class="head">
                                <div class="name font20">Stop Orders</div>
                            </div>

                            <div class="table-responsive">
                                <table id="active_orders" class="table table-striped table-bordered tableBorder" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Type</th>
                                            <th class="text-center">Date &amp; Time</th>
                                            <th class="text-center">{{$first_currency}}</th>
                                            <th class="text-center">{{$second_currency}}</th>
                                            <th class="text-center">Price ({{$second_currency}})</th>
                                            <th class="text-center">Fee</th>
                                            <th class="text-center">Sum({{$second_currency}})</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @if(isset($stop_orders[0]))
                @foreach($stop_orders as $stop_ord)
                    <tr>
                         <td class="text-center">{{$stop_ord->Type}}</td>
                                             <td class="text-center">{{$stop_ord->created_at}}</td>
                                             <td class="text-center price">{{$stop_ord->Amount}}</td>
                                             <td class="text-center price">{{sprintf('%f',$stop_ord->Price)}}</td>
                                             <td class="text-center price">{{($stop_ord->Price * $stop_ord->Amount)}}</td>
                                             <td class="text-center price">{{$stop_ord->Fee}}</td>
                                             <td class="text-center price">{{$stop_ord->Total}}</td>
                                             <td class="text-center">{{$stop_ord->status}}</td>
                                             <td class="text-center">
                                                 <a href="{{url('trade/stop_cancel_order')}}/{{base64_encode($stop_ord->id)}}" class="btn btn-danger btn-xs" onclick="return confirm('Are sure to cancel the stop order')">&times;</a>
                                             </td>

                                        </tr>
                                        @endforeach
            @else
                <td class="text-center" colspan="9">
                No Record Found
                </td>
@endif
                    </tbody>
                </table>

            </div>
        </div> -->


            </div>
        </div>
    </section>
    <!-- / trade home data and datatables -->



    <!-- Modal -->
    <div id="myModaltrade" class="modal fade pop1" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Trade details</h4>
                </div>
                <div class="modal-body">
                    <div class="table-responsive pop_table1">
                        <table class="table">
                            <tbody>
                            <tr>
                                <td class="fs_sep"><label class="control-label"> Type </label></td>
                                <td class="sec_fd text-uppercase" id="modal_ord_type"></td>
                            </tr>
                            <tr>
                                <td class="fs_sep"><label class="control-label"> {{$first_currency}} </label></td>
                                <td class="sec_fd" id="modal_first_curr"></td>
                            </tr>
                            <tr>
                                <td class="fs_sep"><label class="control-label"> {{$second_currency}} </label></td>
                                <td class="sec_fd" id="modal_second_curr"></td>
                            </tr>
                            <tr>
                                <td class="fs_sep"><label class="control-label"> Price ( {{$second_currency}} ) </label>
                                </td>
                                <td class="sec_fd" id="sum_first_second"></td>
                            </tr>
                            <tr>
                                <td class="fs_sep"><label class="control-label"> Fee ( {{$second_currency}} ) </label>
                                </td>
                                <td class="sec_fd" id="modal_fee_amt"></td>
                            </tr>
                            <tr>
                                <td class="fs_sep"><label class="control-label"> Sum ( {{$second_currency}} ) </label>
                                </td>
                                <td class="sec_fd" id="modal_price_amt"></td>
                            </tr>
                            <tr>
                                <td class="fs_sep"><label class="control-label" style="font-weight: bold;"> Est.$
                                        /{{$first_currency}} </label></td>
                                <td class="sec_fd" style="font-weight: bold;" id="modal_est_usd_price"></td>
                            </tr>
                            <tr>
                                <td class="fs_sep"><label class="control-label"> Date &amp; time </label></td>
                                <td class="sec_fd"> {{date('Y-m-d H:i:s')}} </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="form-group">
                        <button type="button" onclick="trade_modal_submit()" id="modal_btn_sub"
                                class="btn btn-primary center-block">
                            Place Order
                        </button>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="modal fade" id="cancel_single" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Cancel Trade
                </div>
                <div class="modal-body">
                    Are you sure you want to cancel the trade?
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                    <button id="confirmed" class="btn btn-success success" onclick="cancel_single()">Yes</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cancel_multiple" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Cancel Trade
                </div>
                <div class="modal-body">
                    Are you sure you want to cancel the selected trades?
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                    <button id="confirmed" class="btn btn-success success" onclick="cancel_multiple()">Yes</button>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('xscript')




    <script type="text/javascript">
        function validateSwapXDC(currency)
        {
            var amount = document.getElementById('swap_amount_'+currency).value;
            if(amount >= 1000)
            {
                document.getElementById('error_'+currency).style.display = 'none';
                return true;
            }
            else
            {
                document.getElementById('error_'+currency).style.display = 'block';
                return false;
            }
        }
    </script>
    <script src="https://code.highcharts.com/stock/highstock.js"></script>
    <script src="https://code.highcharts.com/stock/modules/exporting.js"></script>

    <script type="text/javascript">
        $(window).load(function() {
            $('#loader').show();
            $.getJSON('{{url("trade/trade_chart")}}/{{$pair}}', function (data) {

                var sellprice = [],
                    volume = [],
                    dataLength = data.length,
                    // set the allowed units for data grouping
                    groupingUnits = [[
                        'week',                         // unit name
                        [1]                             // allowed multiples
                    ], [
                        'month',
                        [1, 2, 3, 4, 6]
                    ]],
                    i = 0;
                for (i; i < dataLength; i += 1) {
                    sellprice.push([
                        data[i][0], // the date
                        data[i][1], // open
                        data[i][2], // high
                        data[i][3], // low
                        data[i][4] // close
                    ]);

                    volume.push([
                        data[i][0], // the date
                        data[i][5] // the volume
                    ]);
                }

                // create the chart
                Highcharts.stockChart('container',
                    {
                        rangeSelector:
                            {
                                selected: 3,
                                inputEnabled: false
                            },
                        chart: {
                            zoomType: 'x'
                        },
                        title: {
                            text: '{{$pair}}'
                        },
                        navigator: {
                            enabled: false
                        },
                        yAxis: [{
                            title: {
                                text: 'Price'
                            },
                            resize: {
                                enabled: true
                            }
                        }, {
                            className: 'highcharts-color-1',
                            opposite: false,
                            title: {
                                text: 'Volume'
                            }
                        }],
                        series: [
                            {
                                type: 'candlestick',
                                name: 'Alphaex Sell Price',
                                data: sellprice,
                                dataGrouping: {
                                    units: groupingUnits
                                }
                            },
                            {
                                type: 'column',
                                name: 'Volume',
                                data: volume,
                                yAxis: 1,
                                dataGrouping:
                                    {
                                        units: groupingUnits
                                    }
                            }]
                    });
                $('#loader').hide();
            });
        })
    </script>




    <script type="text/javascript">
        function trading_uiform(id) {

            if (id == 1) {
                $.get("{{url('ajax/get_instant_buy_form')}}/{{$pair}}", function (data) {
                    $("#buy").html(data);
                    $(document).trigger('buyinstval');
                    $(document).trigger('instordersrc');
                });
                $.get("{{url('ajax/get_instant_sell_form')}}/{{$pair}}", function (data) {
                    $("#sell").html(data);
                    $(document).trigger('sellinstval');
                    $(document).trigger('instordersrc');

                });


            }
            else if (id == 2) {
                $.get("{{url('ajax/get_limit_buy_form')}}/{{$pair}}", function (data) {
                    $("#buy").html(data);
                    $(document).trigger('buylimitval');
                    $(document).trigger('instordersrc');
                });
                $.get("{{url('ajax/get_limit_sell_form')}}/{{$pair}}", function (data) {
                    $("#sell").html(data);
                    $(document).trigger('selllimitval');
                    $(document).trigger('instordersrc');

                });
            }
            else {
                $.get("{{url('ajax/get_stop_buy_form')}}/{{$pair}}", function (data) {
                    $("#buy").html(data);
                    $(document).trigger('buystopval');
                    $(document).trigger('instordersrc');
                });
                $.get("{{url('ajax/get_stop_sell_form')}}/{{$pair}}", function (data) {
                    $("#sell").html(data);
                    $(document).trigger('sellstopval');
                    $(document).trigger('instordersrc');

                });
            }


        }
    </script>

    <script>
        function swapAmount(currency)
        {
            var SpanId = document.getElementById('swapTotal');
            var amount = document.getElementById('swap_amount_'+currency).value;
            SpanId.innerHTML = amount;
        }

    </script>



    <script type="text/javascript">
        $(document).on('ready instordersrc', function () {
            $("#buy_ins_{{$first_currency}}").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });
            $("#sell_ins_{{$first_currency}}").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });

            $("#buy_limit_{{$first_currency}}").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });
            $("#sell_limit_{{$first_currency}}").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });

            $("#buy_limit_price").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });
            $("#sell_limit_price").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });

            $("#buy_stop_{{$first_currency}}").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });

            $("#sell_stop_{{$first_currency}}").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });

            $("#buy_stop_price").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });

            $("#sell_stop_price").keydown(function (evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode
                if (charCode > 32 && (charCode < 46 || charCode > 57) && (charCode < 90 || charCode > 107) && (charCode < 109 || charCode > 111) && (charCode < 189 || charCode > 191))
                    return false;
                return true;
            });


        });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

    <script type="text/javascript">

        $(document).on('ready buyinstval', function () {
            $("#buy_ins_form").validate({
                rules:
                    {
                        buy_ins_{{$first_currency}}: {required: true, min: 1000, digits: true,}
                    },
                messages:
                    {
                        buy_ins_{{$first_currency}}: {
                            required: '{{$first_currency}} amount is required',
                            min: 'Minimum 1000 XDC',
                            digits: 'Decimal value not allowed'
                        }
                    },
                submitHandler: function (form) {
                    instant_order('buy');
                    var sell_rate = '{{$sell_rate}}';
                    var trade_fee = '{{$trading_fee}}';
                    var buy_rate = '{{$buy_rate}}';
                    var buyformser = $("#buy_ins_form").serialize();
                    $.ajax({
                        type: 'Post',
                        url: '{{url("trade/instant_order")}}',
                        data: buyformser + '&sell_rate=' + sell_rate + '&trade_fee=' + trade_fee + '&buy_rate=' + buy_rate + '&pair={{$pair}}&type=Buy',
                        beforeSend: function () {
                            $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                            $("#btn-buy").attr('disabled', 'disabled');
                        },
                        success: function (data) {
                            obj = JSON.parse(data);
                            if (obj.status == '0') {
                                $("#btn-buy").removeAttr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                            }
                            else if (obj.status == '1') {
                                $("#btn-buy").attr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                                pagereload();
                            }
                        }
                    });

                }
            });
        });
    </script>

    <script type="text/javascript">
        $(document).on('ready sellinstval', function () {
            $("#sell_ins_form").validate({
                rules:
                    {
                        sell_ins_{{$first_currency}}: {required: true, min: 1000, digits: true,}
                    },
                messages:
                    {
                        sell_ins_{{$first_currency}}: {
                            required: '{{$first_currency}} amount is required',
                            min: 'Minimum 1000 XDC',
                            digits: 'Decimal value not allowed'
                        }
                    },
                submitHandler: function (form) {
                    instant_order('sell');
                    var sell_rate = '{{$sell_rate}}';
                    var trade_fee = '{{$trading_fee}}';
                    var buy_rate = '{{$buy_rate}}';
                    var buyformser = $("#sell_ins_form").serialize();
                    $.ajax({
                        type: 'Post',
                        url: '{{url("trade/instant_order")}}',
                        data: buyformser + '&sell_rate=' + sell_rate + '&trade_fee=' + trade_fee + '&buy_rate=' + buy_rate + '&pair={{$pair}}&type=Sell',
                        beforeSend: function () {
                            $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                            $("#btn-sell").attr('disabled', 'disabled');
                        },
                        success: function (data) {
                            obj = JSON.parse(data);
                            if (obj.status == '0') {
                                $("#btn-sell").removeAttr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                            }
                            else if (obj.status == '1') {
                                $("#btn-sell").attr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                                pagereload();
                            }
                        }
                    });
                }
            });
        });

    </script>



    <script type="text/javascript">
        $(document).on('ready buylimitval', function () {

            $("#buy_limit_form").validate({
                rules:
                    {
                        buy_limit_{{$first_currency}}: {required: true, min: 1000, digits: true,},
                        buy_limit_price: {required: true, number: true, adecimal: true},
                    },
                messages:
                    {
                        buy_limit_{{$first_currency}}: {
                            required: '{{$first_currency}} amount is required',
                            min: 'Minimum 1000 XDC',
                            digits: 'Decimal value not allowed'
                        },
                        buy_limit_price: {
                            required: 'Enter {{$second_currency}} Price',
                            number: 'Enter valid price format',
                            adecimal: 'Please enter a correct number'
                        },
                    },
                submitHandler: function (form) {
                    limit_order('buy');
                    var sell_rate = '{{$sell_rate}}';
                    var trade_fee = '{{$trading_fee}}';
                    var buy_rate = '{{$buy_rate}}';
                    var buyformser = $("#buy_limit_form").serialize();
                    $.ajax({
                        type: 'Post',
                        url: '{{url("trade/limit_order")}}',
                        data: buyformser + '&sell_rate=' + sell_rate + '&trade_fee=' + trade_fee + '&buy_rate=' + buy_rate + '&pair={{$pair}}&type=Buy',
                        beforeSend: function () {
                            $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                            $("#btn-buy").attr('disabled', 'disabled');
                        },
                        success: function (data) {
                            obj = JSON.parse(data);
                            if (obj.status == '0') {
                                $("#btn-buy").removeAttr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                            }
                            else if (obj.status == '1') {
                                $("#btn-buy").attr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                                pagereload();
                            }
                        }
                    });

                }
            });
        });
    </script>



    <script type="text/javascript">
        $(document).on('ready selllimitval', function () {

            $("#sell_limit_form").validate({
                rules:
                    {
                        sell_limit_{{$first_currency}}: {required: true, min: 1000, digits: true,},
                        sell_limit_price: {required: true, number: true, adecimal: true},
                    },
                messages:
                    {
                        sell_limit_{{$first_currency}}: {
                            required: '{{$first_currency}} amount is required',
                            min: 'Minimum 1000 XDC',
                            digits: 'Decimal value not allowed'
                        },
                        sell_limit_price: {
                            required: 'Enter {{$second_currency}} Price',
                            number: 'Enter valid price',
                            adecimal: 'Please enter a correct number'
                        },
                    },
                submitHandler: function (form) {
                    limit_order('sell');
                    var sell_rate = '{{$sell_rate}}';
                    var trade_fee = '{{$trading_fee}}';
                    var buy_rate = '{{$buy_rate}}';
                    var buyformser = $("#sell_limit_form").serialize();
                    $.ajax({
                        type: 'Post',
                        url: '{{url("trade/limit_order")}}',
                        data: buyformser + '&sell_rate=' + sell_rate + '&trade_fee=' + trade_fee + '&buy_rate=' + buy_rate + '&pair={{$pair}}&type=Sell',
                        beforeSend: function () {
                            $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                            $("#btn-sell").attr('disabled', 'disabled');
                        },
                        success: function (data) {
                            obj = JSON.parse(data);
                            if (obj.status == '0') {
                                $("#btn-sell").removeAttr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                            }
                            else if (obj.status == '1') {
                                $("#btn-sell").attr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                                pagereload();
                            }
                        }
                    });
                }
            });
        });

    </script>




    <script type="text/javascript">
        $(document).on('ready buystopval', function () {
            $("#buy_stop_form").validate({
                rules:
                    {
                        buy_stop_{{$first_currency}}: {required: true, min: 1000, digits: true,},
                        buy_stop_price: {required: true, number: true, adecimal: true},
                    },
                messages:
                    {
                        buy_stop_{{$first_currency}}: {
                            required: '{{$first_currency}} amount is required',
                            min: 'Minimum 1000 XDC',
                            digits: 'Decimal value not allowed'
                        },
                        buy_stop_price: {
                            required: 'Enter {{$second_currency}} Price',
                            number: 'Enter valid price format',
                            adecimal: 'Please enter a correct number'
                        },
                    },
                submitHandler: function (form) {
                    stop_order('buy');
                    var sell_rate = '{{$sell_rate}}';
                    var trade_fee = '{{$trading_fee}}';
                    var buy_rate = '{{$buy_rate}}';
                    var buyformser = $("#buy_stop_form").serialize();
                    $.ajax({
                        type: 'Post',
                        url: '{{url("trade/stop_order")}}',
                        data: buyformser + '&sell_rate=' + sell_rate + '&trade_fee=' + trade_fee + '&buy_rate=' + buy_rate + '&pair={{$pair}}&type=Buy',
                        beforeSend: function () {
                            $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                            $("#btn-buy").attr('disabled', 'disabled');
                        },
                        success: function (data) {
                            obj = JSON.parse(data);
                            if (obj.status == '0') {
                                $("#btn-buy").removeAttr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                            }
                            else if (obj.status == '1') {
                                $("#btn-buy").attr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                                pagereload();
                            }
                        }
                    });

                }
            });
        });
    </script>



    <script type="text/javascript">
        $(document).on('ready sellstopval', function () {
            $("#sell_stop_form").validate({
                rules:
                    {
                        sell_stop_{{$first_currency}}: {required: true, min: 1000, digits: true,},
                        sell_stop_price: {required: true, number: true, adecimal: true},
                    },
                messages:
                    {
                        sell_stop_{{$first_currency}}: {
                            required: '{{$first_currency}} amount is required',
                            min: 'Minimum 1000 XDC',
                            digits: 'Decimal value not allowed'
                        },
                        sell_stop_price: {
                            required: 'Enter {{$second_currency}} Price',
                            number: 'Enter valid price',
                            adecimal: 'Please enter a correct number'
                        },
                    },
                submitHandler: function (form) {
                    stop_order('sell');
                    var sell_rate = '{{$sell_rate}}';
                    var trade_fee = '{{$trading_fee}}';
                    var buy_rate = '{{$buy_rate}}';
                    var buyformser = $("#sell_stop_form").serialize();
                    $.ajax({
                        type: 'Post',
                        url: '{{url("trade/stop_order")}}',
                        data: buyformser + '&sell_rate=' + sell_rate + '&trade_fee=' + trade_fee + '&buy_rate=' + buy_rate + '&pair={{$pair}}&type=Sell',
                        beforeSend: function () {
                            $("#load_message").html(' <img src="{{URL::asset("front")}}/assets/imgs/load.gif" style="height: 64px;">');
                            $("#btn-sell").attr('disabled', 'disabled');
                        },
                        success: function (data) {

                            obj = JSON.parse(data);
                            if (obj.status == '0') {
                                $("#btn-sell").removeAttr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                            }
                            else if (obj.status == '1') {
                                $("#btn-sell").attr('disabled', 'disabled');
                                $("#load_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + obj.message + '</div>');
                                pagereload();
                            }
                        }
                    });
                }
            });
        });

    </script>



    <script type="text/javascript">
        function instant_order(type) {
            var buy_rate = '{{$buy_rate}}';
            var sell_rate = '{{$sell_rate}}';
            var trade_fee = '{{$trading_fee}}';
            var buy_inst_amount = $("#buy_ins_{{$first_currency}}").val();
            var sell_inst_amount = $("#sell_ins_{{$first_currency}}").val();
            if (type == 'buy') {
                var price = parseFloat(buy_inst_amount) * parseFloat(sell_rate);
                var fee_amount = parseFloat(price) * (parseFloat(trade_fee) / 100);
                var total = parseFloat(price) + parseFloat(fee_amount);
                $("#total_{{$second_currency}}").html(total.toFixed(8));
                $("#buy_fee_amount").val(parseFloat(fee_amount).toFixed(8));
                $("#buy_price_amount").val(total.toFixed(8));
            }
            else if (type == 'sell') {
                var price = parseFloat(sell_inst_amount) * parseFloat(buy_rate);
                var fee_amount = parseFloat(price) * (parseFloat(trade_fee) / 100);
                var total = parseFloat(price) - parseFloat(fee_amount);
                $("#total_{{$second_currency}}").html(total.toFixed(8));
                $("#sell_fee_amount").val(parseFloat(fee_amount).toFixed(8));
                $("#sell_price_amount").val(total.toFixed(8));
            }
        }

        function limit_order(type) {


            var trade_fee = '{{$trading_fee}}';
            var buy_limit_amount = $("#buy_limit_{{$first_currency}}").val();
            var sell_limit_amount = $("#sell_limit_{{$first_currency}}").val();
            if (type == 'buy') {
                var sell_rate = $("#buy_limit_price").val();
                var price = parseFloat(buy_limit_amount) * parseFloat(sell_rate);
                var fee_amount = parseFloat(price) * (parseFloat(trade_fee) / 100);
                var total = parseFloat(price) + parseFloat(fee_amount);
                $("#total_{{$second_currency}}").html(total.toFixed(8));
                $("#buy_fee_amount").val(parseFloat(fee_amount).toFixed(8));
                $("#buy_price_amount").val(total.toFixed(8));
            }
            else {
                var buy_rate = $("#sell_limit_price").val();
                var price = parseFloat(sell_limit_amount) * parseFloat(buy_rate);
                var fee_amount = parseFloat(price) * (parseFloat(trade_fee) / 100);
                var total = parseFloat(price) - parseFloat(fee_amount);
                $("#total_{{$second_currency}}").html(total.toFixed(8));
                $("#sell_fee_amount").val(parseFloat(fee_amount).toFixed(8));
                $("#sell_price_amount").val(total.toFixed(8));
            }
        }

        function stop_order(type) {
            var trade_fee = '{{$trading_fee}}';
            var buy_stop_amount = $("#buy_stop_{{$first_currency}}").val();
            var sell_stop_amount = $("#sell_stop_{{$first_currency}}").val();
            if (type == 'buy') {
                var sell_rate = $("#buy_stop_price").val();
                var price = parseFloat(buy_stop_amount) * parseFloat(sell_rate);
                var fee_amount = parseFloat(price) * (parseFloat(trade_fee) / 100);
                var total = parseFloat(price) + parseFloat(fee_amount);
                $("#total_{{$second_currency}}").html(total.toFixed(8));
                $("#buy_fee_amount").val(parseFloat(fee_amount).toFixed(8));
                $("#buy_price_amount").val(total.toFixed(8));
            }
            else {
                var buy_rate = $("#sell_stop_price").val();
                var price = parseFloat(sell_stop_amount) * parseFloat(buy_rate);
                var fee_amount = parseFloat(price) * (parseFloat(trade_fee) / 100);
                var total = parseFloat(price) - parseFloat(fee_amount);
                $("#total_{{$second_currency}}").html(total.toFixed(8));
                $("#sell_fee_amount").val(parseFloat(fee_amount).toFixed(8));
                $("#sell_price_amount").val(total.toFixed(8));
            }
        }

        function pagereload() {
            window.location.reload();
        }
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            var id = $("#order_list").val();
            trading_uiform(id);

        });

        function buy_click_value(price, amt) {
            $('#order_list').val('2');
            trading_uiform('2');
            $("#sell_tab").trigger('click').removeClass('active');
            $("#buy_tab").trigger('click').addClass('active');
            $("#sell").removeClass('active');
            $("#buy").addClass('active');
            setTimeout(function () {
                $("#buy_limit_{{$first_currency}}").val(amt);
                $("#buy_limit_price").val(price);
                limit_order('buy');
            }, 1000);


        }

        function sell_click_value(price, amt) {
            $('#order_list').val('2');
            trading_uiform('2');
            $("#buy_tab").trigger('click').removeClass('active');
            $("#sell_tab").trigger('click').addClass('active');
            $("#buy").removeClass('active');
            $("#sell").addClass('active');
            setTimeout(function () {
                $("#sell_limit_{{$first_currency}}").val(amt);
                $("#sell_limit_price").val(price);
                limit_order('sell');
            }, 1000);


        }

        function change_trade(pair) {
            window.location.href = '{{url("trade")}}/' + pair;
        }
    </script>


    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>



    <script>
        $(document).on('ready sellbuytbl', function () {
            $('#sell_ord_tbl').DataTable({
                "scrollY": "250px",
                "scrollCollapse": true,
                "paging": false,
                "ordering": false,
                "info": false,
            });

            $('#buy_ord_tbl').DataTable({
                "scrollY": "250px",
                "scrollCollapse": true,
                "paging": false,
                "ordering": false,
                "info": false
            });


        });

        /*setInterval(function()
           {
               $.get("{{url('ajax/get_buy_tradeorders')}}/{{$pair}}", function(data){
            $("#buy_ord_tbl_data").html(data);
        });
        $.get("{{url('ajax/get_sell_tradeorders')}}/{{$pair}}", function(data){
            $("#sell_ord_tbl_data").html(data);

        });
        console.clear();
    },2500);*/

        function trade_popup_ins(type, frmid) {
            var frmvalid = $("#" + frmid).valid();
            var priceamt = $("#" + type + "_price_amount").val();
            var feeamt = $("#" + type + "_fee_amount").val();
            var famount = $("#" + type + "{{$first_currency}}").val();
            var buy_rate = '{{$buy_rate}}';
            var sell_rate = '{{$sell_rate}}';
            if (frmvalid == true) {
                $("#trade_frm_id").val(frmid);
                $("#myModaltrade").modal('show');
                $("#modal_ord_type").html(type);
                $("#modal_price_amt").html(priceamt);
                $("#modal_fee_amt").html(feeamt);
                $("#modal_first_curr").html(famount);
                if (type == 'buy') {
                    $("#modal_second_curr").html(sell_rate);
                    var bprice = parseFloat(sell_rate) * parseFloat(famount);
                    $("#sum_first_second").html(bprice.toFixed(8));
                }
                else {
                    var sprice = parseFloat(buy_rate) * parseFloat(famount);
                    $("#modal_second_curr").html(buy_rate);
                    $("#sum_first_second").html(sprice.toFixed(8));
                }
            }

        }

        $.validator.addMethod('adecimal', function (value, element) {
            return this.optional(element) || (value > 0);
        }, "Please enter a correct number");

    </script>
    <script src="{{URL::asset('tradejs')}}/tradepop.js"></script>

    <script>
        // $(document).bind("contextmenu", function (e) {
        //     e.preventDefault();
        // });
        document.onkeydown = function (e) {
            if (e.keyCode == 123) {
                return false;
            }
            if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
                return false;
            }
            if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
                return false;
            }
            if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
                return false;
            }

            if (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
                return false;
            }
        }
    </script>

    <script type="text/javascript">

        function cancel_single()
        {
            var id = $('#cancelsingle').val();
            window.location="{{url('trade/cancel_order')}}/"+id;
        }

        function check_all(){
            var chk_arr =  document.getElementsByName("checked[]");
            for(k=0;k< chk_arr.length;k++)
            {
                chk_arr[k].checked = true;
            }
            check_selected();
        }

        function check_none(){
            var chk_arr =  document.getElementsByName("checked[]");
            for(k=0;k< chk_arr.length;k++)
            {
                chk_arr[k].checked = false;
            }
            check_selected();
        }

        function checkany(){
            var chk_arr =  document.getElementsByName("checked[]");
            for(k=0;k< chk_arr.length;k++)
            {
                if(chk_arr[k].checked==true){
                    return true;
                }
            }
            return false;
        }

        function show(){
            document.getElementById('cancel_button').style.display="block";
            document.getElementById('checkall').style.display="block";
            document.getElementById('checknone').style.display="block";
        }

        function hide()
        {
            document.getElementById('cancel_button').style.display="none";
            document.getElementById('checkall').style.display="none";
            document.getElementById('checknone').style.display="none";
        }

        function check_selected(){
            checkany() ? show():hide();
        }

        function cancel_multiple(){
            var chk_arr=document.getElementsByName("checked[]");
            var id=new Array();
            var i=0;
            for(var k=0;k<chk_arr.length;k++)
            {
                if(chk_arr[k].checked==true)
                {
                    id[i]=chk_arr[k].value;
                    i++;
                }
            }
                window.location.href="/trade/cancel_multiple/"+encodeURIComponent(JSON.stringify(id));
        }

    </script>
@endsection
