
@extends('front.layout.front')




@section('content')

    <section>
        <br>
        <div>
            <p class="text-center">
                <br><br><br>
                ICO Services
                <br>
                Email us at support@alphaex.net to launch your own ICO now.
                <br>
            </p>
        </div>
    </section>


@endsection


