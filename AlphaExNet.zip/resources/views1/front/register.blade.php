@extends('front.layout.front')
@section('css')
    <link rel="stylesheet" href="{{URL::asset('front')}}/build/css/countrySelect.css">
    <link rel="stylesheet" href="{{URL::asset('front')}}/build/css/demo.css">
@endsection
@section('content')

    <section style="margin-top:50px; min-height:740px;">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                @if(Session::has('success'))
                    <div class="alert-static" style="display: block">
                        <span class="closebtn" onclick="this.parentElement.style.display='none'">&times;</span>
                        <p>Please verify your email address  by clicking on Account Activation Link which would be sent to your registered Email Address in 30 minutes.</p>
                    </div>
                @endif
                <div class="col-md-12">
                    <h3>Create Account</h3>
                    @if(count($errors) > 0)
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            @foreach($errors->all() as $er)
                                {{$er}}<br/>
                            @endforeach
                        </div>
                    @endif
                    @if(Session::has('error'))
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            {{ Session('error') }}</div>
                    @endif


                    <form id="register_form" action="{{url('/register')}}" method="post" accept-charset="UTF-8">
                        {{csrf_field()}}
                        <div class="row">


                            <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
                                <div class="form-group">
                                    <input type="text" class="form-control input-lg" name="first_name"
                                           placeholder="First name" value="{{old('first_name')}}" id="first_name">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
                                <div class="form-group">
                                    <input type="text" class="form-control input-lg" name="last_name"
                                           placeholder="Last name" value="{{old('last_name')}}" id="last_name">
                                </div>
                            </div>
                        </div>
                    <!--   <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
              <div class="form-group">
                <input type="text" class="form-control input-lg" name="username" placeholder="Username" value="{{old('username')}}">
                 <input type="hidden" name="ptostatus" id="ptostatus" value="0">
              </div>
            </div> -->
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
                                <div class="form-group">
                                    <input type="text" class="form-control input-lg" name="email_id"
                                           placeholder="Email address" id="email_id" value="{{old('email_id')}}">
                                </div>
                                <label id="email_id-error" class="error" for="email_id"></label>
                            </div>
                        </div>

                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
                                <div class="form-group">
                                    <input type="password" class="form-control input-lg" name="password"
                                           placeholder="Password" id="password">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
                                <div class="form-group">
                                    <input type="password" class="form-control input-lg" name="password_confirmation"
                                           placeholder="Confirm password">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
                                <div class="form-group">
                                    <select name="country_id" id="country_id" class="form-control input-lg"
                                            onchange="set_country()">
                                        <option value="">Select Country</option>
                                        @foreach($country as $val)
                                            <option value="{{$val->id}}" @if($val->id==old('country_id')) selected
                                                    @endif data-id="{{strtolower($val->iso)}}">{{$val->nicename}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12 cls_resp50">
                                <div class="form-group input-group">
                                    <span class="input-group-addon"><strong id="country_selector"
                                                                            class="input-lg"></strong></span>
                                    <input type="hidden" name="isdcode" id="isdcode" value="0">

                                    <input type="text" class="form-control input-lg" name="phone_no"
                                           placeholder="Phone number" id="phone_no" value="{{old('phone_no')}}">
                                    <span class="input-group-addon" id="susotp">
                 </span>
                                </div>
                                <p id="number_example" style="font-size: small;display: block">Enter your number without Countrycode<br> Example(15999999999)</p>
                                <p id="registerdisplay" style="display:none">Please click on Register Button Below</p>

                                <label id="phone_no-error" class="error" for="phone_no"></label>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xs-12">
                            <span>By Clicking Below, You indicate that you have read, understood and agree to our <a
                                        href="{{url('terms')}}">Terms & Condition</a> & <a href="{{url('privacy')}}">Privacy Policy</a>.</span>
                            <hr>
                        </div>
                        <div class="col-sm-12 col-xs-12 ">
                            <!-- <input type="submit" id="ec_register" class="btn btn-primary pull-left reg_btn" name="ec_register" value="Register" /> -->
                            <div id="reg_but">
                                <button type="submit" onclick="sendotp(1)" class="btn btn-primary pull-left reg_btn"
                                        name="ec_register" id="ec_register"><i class="fa fa-check"></i> &nbsp; Register
                                </button>
                            </div>

                            <span class="pull-left log_tx" style="margin-left:20px;"> Already have an Account? <a
                                        href="{{url('/login')}}">Login</a><br>
              Forgot your Password? <a href="{{url('/forgotpass')}}">Reset</a>
               </span>
                        </div>

                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </section>




@endsection
@section('xscript')


<script>
    function sendotp(choice) {
        var countryData = $("#country_selector").countrySelect("getSelectedCountryData");
        var isd = countryData.isd;
        $("#isdcode").val(isd);
        var isdcode = $("#isdcode").val();


    }
</script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>

    <script type="text/javascript">

        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Number Not valid."
        );

        $("#register_form").validate({
            rules:
                {
                    first_name: {required:true, minlength:2, regex:"^[A-Za-z]*$"},
                    last_name: {required:true, minlength:2, regex:"^[A-Za-z]*$"},
                    phone_no: { number: true,regex:"^[1-9][0-9]*$"},
                    email_id: {required: true, email: true},
                    password: {
                        required: true,
                        noSpace: true,
                        pwcheckallowedchars: true,
                        pwcheckspechars: true,
                        pwcheckuppercase: true,
                    },
                    password_confirmation: {required: true, equalTo: '#password',},

                },
            messages:
                {
                    first_name:{required:'First name is required',minlength:'First name should contain atleast two alphabets',regex:'Only alphabets allowed'},
                    last_name:{required:'Last name is required',minlength:'Last name should contain atleast two alphabets',regex:'Only alphabets allowed'},
                    phone_no: { number: 'Digit only allowed',regex:'Number not valid should not start with zero'},
                    email_id: {required: 'Email id is required', email: 'Enter valid email id'},
                    password: {required: 'Password is required',},
                    password_confirmation: {
                        required: 'Password Confirmation is required',
                        equalTo: 'Password does not match',
                    },

                }
        });
        jQuery.validator.addMethod("noSpace", function (value, element) {
            return value.indexOf(" ") < 0 && value != "";
        }, "No space please and don't leave it empty");

        jQuery.validator.addMethod("pwcheckallowedchars", function (value) {
            return /^[a-zA-Z0-9!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]+$/.test(value) // has only allowed chars letter
        }, "The password contains non-admitted characters");

        jQuery.validator.addMethod("pwcheckspechars", function (value) {
            return /[!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]/.test(value)
        }, "The password must contain at least one special character");

        jQuery.validator.addMethod("pwcheckuppercase", function (value) {
            return /[A-Z]/.test(value) // has an uppercase letter
        }, "The password must contain at least one uppercase letter");


    </script>

    <script type="text/javascript">


        function set_country() {
            var code = $('#country_id option:selected').attr('data-id');
            $("#country_selector").countrySelect("selectCountry", code);
        }
    </script>




    <script type="text/javascript">
        var user_id = '{{$user_id}}';
        $("#otp_form").validate(
            {
                rules:
                    {
                        verify_code: {required: true, number: true,},
                    },
                messages:
                    {
                        verify_code: {required: 'Verification code is required', number: 'Digit only allowed',},
                    },
                submitHandler: function (form) {
                    var otpser = $("#otp_form").serialize();
                    var mob = $('#phone_no').val();

                    $.ajax({
                        type: 'post',
                        url: '{{url("ajax/verify_otp")}}',
                        data: otpser + '&mobile=' + mob + '&user_id='+user_id,
                        success: function (data) {

                            otpobj = JSON.parse(data);
                            if (otpobj.status == '1') {
                                $("#susotp").html('<a href="#" class="btn btn-info btn-sm">Verified</a>');
                                $("#phone_no").attr('readonly', 'readonly');
                                $("#ptostatus").val(otpobj.key);
                                $("#otp_message").html('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + otpobj.message + '</div>');
                                $("#modal-otp").modal('hide');

                            }
                            else {
                                $("#otp_but").html('Failed');
                                $("#ptostatus").val('');
                                $("#otp_message").html('<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' + otpobj.message + '</div>');
                            }
                        }
                    })
                }
            });
    </script>

    <script src="{{URL::asset('front')}}/build/js/countrySelect.js"></script>
    <script>
        $("#country_selector").countrySelect({
            preferredCountries: ['jp','in', 'gb', 'us']
        });

    </script>
    <style>
        .alert-static {
            padding: 20px;
            background-color: lightskyblue;
            color: white;
        }

        .closebtn {
            margin-left: 15px;
            color: white;
            font-weight: bold;
            float: right;
            font-size: 22px;
            line-height: 20px;
            cursor: pointer;
            transition: 0.3s;
        }

        .closebtn:hover {
            color: black;
        }
    </style>


@endsection