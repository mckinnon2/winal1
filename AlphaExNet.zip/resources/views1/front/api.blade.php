@extends('front.layout.front')
@section('css')
    <link rel="stylesheet" href="{{URL::asset('front')}}/build/css/countrySelect.css">
    <link rel="stylesheet" href="{{URL::asset('front')}}/build/css/demo.css">
    <style>
        .preclass {
            white-space: pre-wrap; /* Since CSS 2.1 */
            white-space: -moz-pre-wrap; /* Mozilla, since 1999 */
            white-space: -pre-wrap; /* Opera 4-6 */
            white-space: -o-pre-wrap; /* Opera 7 */
            word-wrap: break-word; /* Internet Explorer 5.5+ */
        }
    </style>
@endsection
@section('content')
    <section id="home">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <h1>Cryptocurrencies exchange rates API</h1>
                    <p class="">
                        AlphaEx provides unique volume of cryptocurrency exchange rates data, which is delivered in
                        easy-to-integrate JSON format via simple HTTPS requests. Prices are updated every 30 seconds.
                    </p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <br>
                    <hr style="color: black;border: double">
                    <br>
                    <h2 class="text-center">XDC-BTC Ticker</h2>
                    <hr>
                    <p>
                        Returns actual volume-weighted price with respect to last executed XDC-BTC Trade, total 24h
                        volume,US$ price and the price change.
                    </p>
                    <p><strong>XDC-BTC API</strong></p>

                    <pre onclick="apicall('BTC')" onmouseover="" style="cursor: pointer;"><a><h4>https://alphaex.net/ticker/info/XDC-BTC</h4></a></pre>
                    <br>
                    <label>returns</label>
                    <pre class="col-md-12 preclass" style="color: #0f7864" id="BTC">{{$BTC}}</pre>
                </div>
                <div class="col-md-12">
                    <br>
                    <hr style="color: black;border: double">
                    <br>
                    <h2 class="text-center">XDC-ETH Ticker</h2>
                    <hr>
                    <p>
                        Returns actual volume-weighted price with respect to last executed XDC-ETH Trade, total 24h
                        volume,US$ price and the price change.
                    </p>
                    <p><strong>XDC-ETH API</strong></p>

                    <pre onclick="apicall('ETH')" onmouseover="" style="cursor: pointer;"><a><h4>https://alphaex.net/ticker/info/XDC-ETH</h4></a></pre>
                    <br>
                    <label>returns</label>
                    <pre class="col-md-12 preclass" style="color: #0f7864" id="ETH">{{$ETH}}</pre>

                </div>

                <div class="col-md-12">
                    <br>
                    <hr style="color: black;border: double">
                    <br>
                    <h2 class="text-center">XDC-XRP Ticker</h2>
                    <hr>
                    <p>
                        Returns actual volume-weighted price with respect to last executed XDC-XRP Trade, total 24h
                        volume,US$ price and the price change.
                    </p>
                    <p><strong>XDC-XRP API</strong></p>

                    <pre onclick="apicall('XRP')" onmouseover="" style="cursor: pointer;"><a><h4>https://alphaex.net/ticker/info/XDC-XRP</h4></a></pre>
                    <br>
                    <label>returns</label>
                    <pre class="col-md-12 preclass" style="color: #0f7864" id="XRP">{{$XRP}}</pre>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <br>
                        <hr style="color: black;border: double">
                        <br>
                        <h2 class="text-center">Other Resources</h2>
                        <br>
                        <br>
                        <ul>
                            <li><b><a href="http://xinfin.info/">XinFin Explorer</a></b> - XDC Explorer Site</li>
                            <li><b><a href="http://xinfin.org">XinFin</a></b> - XinFin-XDC website and White paper</li>
                            <li><b><a href="https://bitcointalk.org/index.php?topic=1989818.0">Announcement</a></b> - Xinfin-XDC Announcements site</li>
                            <li><b><a href="https://github.com/XinFinorg">Source Code</a></b> - Xinfin-XDC Source Code Link</li>
                            <li><b><a href="http://xinfin.net">Message Board</a></b> -  Xinfin-XDC Message Board Link</li>

                        </ul>
                    </div>

                    {{--<div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">--}}
                        {{--<div class="contact-info-holder">--}}
                            {{--<div class="sideline"></div>--}}
                            {{--<div class="iconbox-xmedium round white"><img--}}
                                        {{--src="{{URL::asset('front')}}/assets/icons/XDC.png" alt="">--}}
                                {{--<br>--}}
                                {{--<p class="text-center"><a href="http://xinfin.info/"><strong>XDC Explorer</strong></a></p>--}}
                                {{--<p class="text-center">The explorer for XDC tokens</p>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                    {{--<div class="col-md-3 col-sm-6 col-xs-12 text-center mb40">--}}
                        {{--<div class="contact-info-holder">--}}
                            {{--<div class="sideline"></div>--}}
                            {{--<div class="iconbox-xmedium round white"><img--}}
                                        {{--src="{{URL::asset('front')}}/assets/icons/XDC.png" alt="">--}}
                                {{--<p class="text-center">XinFin</p>--}}
                                {{--<p class="text-center">The explorer for XDC tokens</p>--}}

                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}


                </div>
            </div>
        </div>
    </section>
@endsection

@section('xscript')

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>
    <script>


        function apicall(callname) {

            console.log("called");

            var displaypre = document.getElementById(callname);
            $.getJSON("https://alphaex.net/ticker/info/XDC-" + callname, function (result) {
                var json = JSON.stringify(result);
                displaypre.innerHTML = json;


            })

        }
    </script>
@endsection
