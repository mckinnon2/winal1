
@extends('front.layout.front')
@section('content')


    <!-- login -->
    <section style="margin-top:50px; min-height:740px;">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <h3>Login</h3>
                       @include('panel.alert')
                    <form action="{{url('/login')}}" method="POST" id="login_form">
                        <!--<div class="row">-->
                        {{ csrf_field() }}
                        <div class="">
                            <hr>
                            <div class="form-group">
                                <input type="text" class="form-control input-lg" name="login_mail" placeholder="Email id">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control input-lg" name="password" placeholder="Password">
                            </div>

                            <div class="form-group">
                            <span id="capimg" style="margin-bottom: 20px; display: inline-block;">{!! captcha_img() !!}
                            </span>
                            <a href="javascript:;" onclick="change_captcha()" class="m_tl">
                            <i class="fa fa-refresh fa-3x"></i></a>

                                <input type="text" class="form-control input-lg" name="captcha" placeholder="Captcha code">
                            </div>

                            <div class="button-checkbox">
                                <label>
                                    <input type="checkbox" name="remember_me" id="remember_me" checked="checked" value="yes"> Remember me</label>
                            </div>
                            <hr>
                            <button type="submit" class="btn btn-primary pull-left" name="ec_login"><i class="fa fa-sign-in"></i> &nbsp; Login</button>
                            <span class="pull-left log_tx" style="margin-left:20px;">
								Don't have an Account? <a href="{{url('/register')}}">Create Now!</a><br/>
								Forgot your Password? <a href="{{url('/forgotpass')}}">Reset</a>
							</span>
                        </div>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </section>
    <!-- / login -->

    {{--otp verification link--}}
    <!-- Small modal -->
    <div id="modal-otp" tabindex="-1" role="dialog" aria-labelledby="modal-login-label" aria-hidden="true"
         class="modal fade" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 id="modal-login-label" class="modal-title">Mobile Number Verification </h4></div>
                <div id="otp_message"></div>
                <div class="modal-body">
                    <div class="form">
                        <form class="form-horizontal">
                            {{csrf_field()}}
                            <div class="form-group"><label class="control-label col-md-3">Enter Verification
                                    code</label>

                                <div class="col-md-9"><input id="verify_code" class="form-control" name="verify_code"
                                                             type="text">
                                    <br>
                                    <div id="countdown">
                                        <span style="float:left">Resend Link:&nbsp;</span>
                                        <div id="minutes" style="float:left;color: red">00</div>
                                        <div style="float:left">:</div>
                                        <div id="seconds" style="float:left;color: red">00</div>
                                    </div>
                                    <div id="aftercount" style="display:none">Support Link:&nbsp;<a href="{{url('/contact_us')}}" style="color: lightblue">click Here</a></div>
                                    <div id="aftercount_msg" style="display:none">*If you do not recieve OTP within 15 minutes please contact support by clicking the above link </div>

                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-9 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary reg_btn" onclick="verify_otp()">Submit</button>&nbsp;&nbsp;
                                    <button type="button" class="btn btn-danger reg_btn"  data-dismiss="modal">Cancel</button>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <label><strong>Note:</strong> &nbsp;Withdrawal cannot be done until mobile number is verified.<br>&nbsp;</label>
                            </div>


                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection

@section('xscript')
<script>
function change_captcha()
{
    $("#capimg").html('Loading....');
    $.post('{{url("ajax/refresh_capcha")}}',function(data,result)
    {
       $("#capimg").html(data);
    });
}
</script>

<script>
    try
    {
        var id = '{{$user_id}}';
        if(id != 0)
        {
            $("#modal-otp").modal({
                backdrop: 'static',
                keyboard: false
            });

            var sTime = new Date().getTime();
            var countDown = 30;

            function UpdateTime() {
                var cTime = new Date().getTime();
                var diff = cTime - sTime;
                var seconds = countDown - Math.floor(diff / 1000);
                if (seconds >= 0) {
                    var minutes = Math.floor(seconds / 60);
                    seconds -= minutes * 60;
                    $("#minutes").text(minutes < 10 ? "0" + minutes : minutes);
                    $("#seconds").text(seconds < 10 ? "0" + seconds : seconds);
                } else {
                    $("#countdown").hide();
                    $("#aftercount").show();
                    $('#aftercount_msg').show();
                    clearInterval(counter);
                }
            }
            UpdateTime();
            var counter = setInterval(UpdateTime, 500);

        }

    }
    catch(e)
    {
        console.log(e);
    }


</script>
{{--for verifying entered otp number--}}
<script>
    function verify_otp()
    {
        var code=$('#verify_code').val();
        var mobile=$('#telephone').val();
        var user_id='{{$user_id}}';
        $.ajax({
            url:'{{url("ajax/verify_otp")}}',
            method:'post',
            data:{'verify_code':code, 'mobile':mobile, 'user_id':user_id},
            success : function(data)
            {

                window.location.href = ('{{url('/login')}}');
            }
        });
    }
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.js"></script>


<script type="text/javascript">
    $("#login_form").validate(
        {
        rules:
        {
            login_mail:{required:true,email:true},
            password:{required:true},
            captcha:{required:true}
        },
        messages:
        {
            login_mail:{required:'Email is required',email:'Enter valid email address',},
            password:{required:'Password is required',},
            captcha:{required:'Captha is required',},
        }
    });
</script>
<script>
window.location.hash="#";
window.location.hash="Again-No-back-button";//again because google chrome don't insert first hash into history
window.onhashchange=function(){window.location.hash="#";}
</script>


@endsection