@extends('front.layout.front')
@section('content')


   <section class="mt60" style="min-height:740px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default noBorder">
                        <h3 class="mb20">Friendly Asked Questions</h3>
                        <div class="panel-group" id="faqAccordion">
                        @if($data)
                        @foreach($data as $val)
                            <div class="panel panel-default">
                                <div class="panel-heading accordion-toggle question-toggle collapsed" data-parent="#faqAccordion" data-target="#question{{$val->id}}" data-toggle="collapse">
                                    <h4 class="panel-title"><a class="ing" href="#">Q : {{$val->question}}</a></h4>
                                </div>
                                <div class="panel-collapse collapse" id="question{{$val->id}}" style="height: 0px;">
                                    <div class="panel-body">
                                        <h5><span class="label label-primary">Answer</span></h5>
                                        <p class="font16">
                                            {!! $val->description !!}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            @endforeach
                            @endif
                            
                        </div>
                        <!-- / panel-group-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- / faqs data -->
@endsection