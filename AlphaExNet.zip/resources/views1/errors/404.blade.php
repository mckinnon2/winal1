<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center><img src="{{URL::asset('front/assets/imgs')}}/error-404.png" /></center>
</body>
</html>