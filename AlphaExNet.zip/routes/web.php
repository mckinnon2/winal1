<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/', function () {
    return view('errors.404');
});

//admin
Route::group(['prefix' => 'sanchalak', 'middleware' => ['web', 'XSS']], function () {

    Route::get('/', 'SiteadminController@index');
    Route::post('/', 'SiteadminController@index');
    Route::get('/logout', 'SiteadminController@logout');
    Route::get('/home', 'SiteadminController@home');
    Route::get('/profile', 'SiteadminController@profile');
    Route::post('/profile', 'SiteadminController@profile');
    Route::get('/site_settings', 'SiteadminController@site_settings');
    Route::post('/site_settings', 'SiteadminController@site_settings');
    Route::get('/test', 'SiteadminController@test');
    Route::post('/checkpattern', 'SiteadminController@checkpattern');
    Route::get('/change_pattern', 'SiteadminController@change_pattern');
    Route::post('/set_pattern', 'SiteadminController@set_pattern');
    Route::get('/cms', 'SiteadminController@cms');
    Route::get('/updatecms/{id}', 'SiteadminController@updatecms');
    Route::post('/updatecms/{id}', 'SiteadminController@updatecms');
    Route::get('/users', 'SiteadminController@users');
    Route::get('/userbalance', 'SiteadminController@userbalance');
    Route::get('/users_opening_balance', 'SiteadminController@users_opening_balance');
    Route::get('/users_closing_balance', 'SiteadminController@users_closing_balance');
    Route::post('/update_user_balance', 'SiteadminController@update_userbal');
    Route::get('/faq', 'SiteadminController@faq');
    Route::get('/mail_template', 'SiteadminController@mail_template');
    Route::get('/contact_query', 'SiteadminController@contact_query');
    Route::get('/view_enquiry/{id}', 'SiteadminController@view_enquiry');
    Route::post('/view_enquiry/{id}', 'SiteadminController@view_enquiry');
    Route::get('/add_faq', 'SiteadminController@add_faq');
    Route::post('/add_faq', 'SiteadminController@add_faq');
    Route::get('/delete_faq/{id}', 'SiteadminController@delete_faq');
    Route::get('/status_faq/{id}', 'SiteadminController@status_faq');
    Route::get('/update_faq/{id}', 'SiteadminController@update_faq');
//    Route::post('/update_faq/{id}', 'SiteadminController@update_faq');
    Route::get('/update_template/{id}', 'SiteadminController@update_template');
//    Route::post('/update_template/{id}', 'SiteadminController@update_template');
    Route::get('/transactions', 'SiteadminController@transactions');
    Route::get('/profit', 'SiteadminController@profit');
    Route::get('/kyc_users', 'SiteadminController@kyc_users');
    Route::get('/ico_listing', 'SiteadminController@ico_listing');
    Route::get('/status_users/{id}', 'SiteadminController@status_users');
    Route::get('/view_users/{id}', 'SiteadminController@view_users');
    Route::get('/view_kyc/{id}', 'SiteadminController@view_kyc');
    Route::post('/view_kyc/{id}', 'SiteadminController@view_kyc');
    Route::get('/ico_view/{id}', 'SiteadminController@ico_view');
    Route::post('/ico_view/{id}', 'SiteadminController@ico_view');
    Route::get('/forgot', 'SiteadminController@forgot');
    Route::post('/forgot', 'SiteadminController@forgot');
    Route::get('/trade_history', 'SiteadminController@trade_history');
    Route::get('/swap_history', 'SiteadminController@swap_history');
    Route::get('/create_ripple_tag', 'SiteadminController@create_riple_xrp_tag');

    Route::get('/cancel_trade/{id}', 'SiteadminController@cancel_trade');
    Route::get('/delete_transaction/{id}', 'SiteadminController@delete_trans');
    Route::get('/pending_history', 'SiteadminController@pending_history');
    Route::get('/deposit_history', 'SiteadminController@deposit_history');
    Route::get('/withdraw_history', 'SiteadminController@withdraw_history');
    Route::get('/updated_history', 'SiteadminController@updated_history');
    Route::get('/market_price', 'SiteadminController@market_price');
    Route::post('/market_price', 'SiteadminController@market_price');
    Route::get('/allprice', 'SiteadminController@all_price');
    Route::get('/meta_content', 'SiteadminController@meta_content');
    Route::get('/update_meta/{id}', 'SiteadminController@update_meta');
    Route::post('/update_meta/{id}', 'SiteadminController@update_meta');
    Route::get('/trading_fee/{currency?}', 'SiteadminController@trading_fee');
    Route::post('/trading_fee/{currency?}', 'SiteadminController@trading_fee');
    Route::get('/fee_config', 'SiteadminController@fee_config');
    Route::post('/fee_config', 'SiteadminController@fee_config');
    Route::get('/user_activity', 'SiteadminController@user_activity');
    Route::get('/whitelists', 'SiteadminController@whitelists');
    Route::post('/whitelists', 'SiteadminController@whitelists');
    Route::get('/delete_whitelist/{id}', 'SiteadminController@delete_whitelist');
    Route::get('/confirm_transfer/{id}', 'SiteadminController@confirm_transfer');
    Route::post('/generate_otp', 'SiteadminController@generate_otp');
    Route::post('/confirm_transfer/{id}', 'SiteadminController@confirm_transfer');
    Route::get('/view_transactions/{trans_id}', 'SiteadminController@view_transactions');
    Route::get('/tradeadmin', 'SiteadminController@tradeadmin');
    Route::get('/total_userbalance', 'SiteadminController@getTotal_Usersbalance');
    Route::get('/testmail', 'SiteadminController@testmail');
    Route::get('/valid_balance', 'SiteadminController@validate_XDC_bal');
    Route::get('/users_balance_validation', 'SiteadminController@users_balance_validation');
    Route::get('/validate_eth_block', 'SiteadminController@validate_eth_block');
    Route::get('/trade_details/{id}', 'SiteadminController@user_XDC_Sell');
    Route::get('/explorer_xdc', 'SiteadminController@users_explorer_validation');
    Route::get('/generate_eth/{id}', 'SiteadminController@generate_eth');
    Route::get('/xrp_withdraw/{id}', 'SiteadminController@xrp_withdraw');
    Route::get('/xrp_create', 'SiteadminController@adminxrpaddress');
    Route::get('/create_email_verification/{id}', 'SiteadminController@create_email_verification');
    Route::get('/user_transaction_details', 'SiteadminController@user_transaction_details');
    Route::get('/ftp', 'SiteadminController@ftp_test');
    Route::get('/ico_history', 'SiteadminController@ico_history');
    Route::get('/cancel_pending_ico_order/{id}', 'SiteadminController@Cancel_pending_ico_order');

    Route::get('/set_trade_cancel', 'SiteadminController@set_trade_cancel');
    Route::POST('/update_ico_price', 'SiteadminController@update_ico_price');

    Route::get('/create_bch_all', 'SiteadminController@create_bch_all');
    Route::get('/confirmation', 'SiteadminController@confirm');
    Route::get('/cancel_multiple/{id}', 'SiteadminController@cancel_multiple');
    Route::get('/export_user_list', 'SiteadminController@export_user_list');
    Route::get('/export_referral_list', 'SiteadminController@export_referral_list');
    Route::get('/export_withdrawal_list/{currency}', 'SiteadminController@export_withdrawal_list');
    Route::get('/export_deposit_list/{currency}', 'SiteadminController@export_deposit_list');
//    Route::get('/manage_node/{currency?}', 'SiteadminController@manage_node');
//    Route::post('/manage_node/{currency?}', 'SiteadminController@manage_node');
    Route::get('/trade_mapping', 'SiteadminController@trade_mapping');
    Route::post('/deleteaccount', 'SiteadminController@deleteaccount');
    Route::get('/non_email_verified', 'SiteadminController@non_email_verified');
    Route::get('/create_email_verification/{id}', 'SiteadminController@create_email_verification');

    Route::get('/erc20_requests', 'SiteadminController@erc20_requests');
    Route::get('/add_erc20_request', 'SiteadminController@add_erc20_request');
    Route::post('/add_erc20_request', 'SiteadminController@add_erc20_request');
    Route::get('/view_erc20_request/{id}', 'SiteadminController@view_erc20_request');
    Route::post('/confirm_erc20_request/{id}', 'SiteadminController@confirm_erc20_request');
    Route::get('/referral', 'SiteadminController@referral');
    Route::post('/referral', 'SiteadminController@referral');
    Route::get('/view_referral_earnings', 'SiteadminController@view_referral_earnings');
    Route::post('/view_referral_earnings', 'SiteadminController@view_referral_earnings');
    Route::get('/extra_earnings', 'SiteadminController@extra_earnings');
    Route::post('/extra_earnings', 'SiteadminController@extra_earnings');

    Route::get('/referral_extra', 'SiteadminController@referral_extra');
    Route::get('/add_referral', 'SiteadminController@add_referral');
    Route::post('/add_referral', 'SiteadminController@add_referral');
    Route::get('/delete_referral/{id}', 'SiteadminController@delete_referral');
    Route::get('/status_referral/{id}', 'SiteadminController@status_referral');
    Route::get('/update_referral/{id}', 'SiteadminController@update_referral');
    Route::post('/update_referral/{id}', 'SiteadminController@update_referral');
    Route::get('/send_balance_email', 'SiteadminController@send_balance_email');
    Route::get('/reserve_balances', 'SiteadminController@reserve_balances');
    Route::post('/reserve_balances', 'SiteadminController@reserve_balances');
    Route::get('/transfer_xdce', 'SiteadminController@transfer_xdce');
    Route::get('/transfer_eth', 'SiteadminController@transfer_eth');
    Route::get('/datetime', 'SiteadminController@currentDateTime');

});

Route::group(['prefix' => 'sanchalak', 'middleware' => ['web']], function () {

    Route::post('/update_template/{id}', 'SiteadminController@update_template');
    Route::post('/update_faq/{id}', 'SiteadminController@update_faq');

});

// Ajax
Route::group(['prefix' => 'ajax', 'middleware' => ['web', 'XSS']], function () {

    Route::get('/', 'AjaxController@index');
    Route::post('/checkemail', 'AjaxController@checkemail');
    Route::post('/get_currency_address', 'AjaxController@get_currency_address');
    Route::post('/registerotp', 'AjaxController@registerotp');
    Route::post('/verify_otp', 'AjaxController@verify_otp');
    Route::post('/checkphone', 'AjaxController@checkphone');
    Route::post('/refresh_capcha', 'AjaxController@refresh_capcha');
    Route::post('/checkoldpass', 'AjaxController@checkoldpass');
    Route::post('/verifyotp', 'AjaxController@verifyotp');
    Route::post('/limit_balance', 'AjaxController@limit_balance');
    Route::post('/generate_otp', 'AjaxController@generate_otp');
    Route::post('/generate_email_otp', 'AjaxController@generate_email_otp');
    Route::post('/address_validation', 'AjaxController@address_validation');
    Route::post('/address_validation_walletjey', 'AjaxController@address_validation_walletjey');
    Route::get('/exchange_chart/{pair?}', 'AjaxController@exchange_chart');
    Route::get('/get_instant_buy_form/{pair?}', 'AjaxController@get_instant_buy_form');
    Route::get('/get_instant_sell_form/{pair?}', 'AjaxController@get_instant_sell_form');
    Route::get('/get_limit_buy_form/{pair?}', 'AjaxController@get_limit_buy_form');
    Route::get('/get_limit_sell_form/{pair?}', 'AjaxController@get_limit_sell_form');
    Route::get('/get_stop_buy_form/{pair?}', 'AjaxController@get_stop_buy_form');
    Route::get('/get_stop_sell_form/{pair?}', 'AjaxController@get_stop_sell_form');
    Route::get('/get_buy_tradeorders/{pair?}', 'AjaxController@get_buy_tradeorders');
    Route::get('/get_sell_tradeorders/{pair?}', 'AjaxController@get_sell_tradeorders');
    Route::get('/get_estimatme_usdbalance', 'AjaxController@get_estimatme_usdbalance');
    Route::get('/otp_test', 'AjaxController@otp_test');
    Route::get('/otp_call/{id}', 'AjaxController@otp_call');
    Route::post('/otpcall', 'AjaxController@otpcall');
    Route::post('/openorders', 'AjaxController@openorders');
    Route::post('/mytradehistory', 'AjaxController@mytradehistory');
    Route::get('/user_verification/{id}', 'AjaxController@user_verification');
    Route::get('/auto_withdrawal/{id}', 'AjaxController@auto_withdrawal');
    Route::get('/XDCdeposit/{id}', 'AjaxController@XDCdeposit');
    Route::get('/btc_deposit_process_user/{user_addr}', 'AjaxController@btc_deposit_process_user');
    Route::get('/geticorate', 'AjaxController@geticorate');
    Route::get('/favorites/add', 'AjaxController@add_fav');
    Route::get('/favorites/remove', 'AjaxController@remove_fav');
    Route::get('/walletid/check', 'AjaxController@remove_fav');
    Route::get('/updateprice', 'AjaxController@updateprice');
    Route::get('/updaterate', 'AjaxController@updaterate');
    Route::get('/updatebalance', 'AjaxController@updatebalance');
    Route::post('/available_market_data', 'AjaxController@available_market_data');
    Route::post('/getfee', 'AjaxController@getfee');
    Route::post('/cancel_order', 'AjaxController@cancel_order');
    Route::post('/pusher/auth', 'AjaxController@pusher_auth');
    Route::get('/buy_order_list', 'AjaxController@buy_order_list');
    Route::get('/sell_order_list', 'AjaxController@sell_order_list');
    Route::get('/trade_history_table', 'AjaxController@trade_history_table');
    Route::get('/get_trading_fee', 'AjaxController@get_trading_fee');
    Route::get('/min_withdrawal', 'AjaxController@min_withdrawal');
    Route::get('/min_trade', 'AjaxController@min_trade');
    Route::get('/referral', 'AjaxController@referral');
    Route::get('/admin_bal', 'AjaxController@admin_bal');
    Route::get('/admin_status', 'AjaxController@admin_status');
    Route::get('/admin_status_new', 'AjaxController@admin_status_new');
    Route::get('/user_bal', 'AjaxController@user_bal');
    Route::get('/btcusdc', 'AjaxController@btcusdc');
    Route::post('/ethusdt', 'AjaxController@ethusdt');
    Route::get('/admin_balances', 'AjaxController@admin_balances');
});

Route::group(['prefix' => 'adminv3', 'middleware' => ['web']], function () {
    Route::post('/update_mail_template/{id}', 'AlphaexadminController@update_mail_template');
    Route::post('/mail_template', 'AlphaexadminController@mail_template');
    Route::post('/add_faqs', 'AlphaexadminController@add_faqs');
});

Route::group(['prefix' => 'adminv3', 'middleware' => ['web', 'XSS']], function () {

    Route::get('/', 'AlphaexadminController@index');
    Route::post('/', 'AlphaexadminController@index');
    Route::get('/register', 'AlphaexadminController@register');
    Route::post('/register', 'AlphaexadminController@register');
    Route::get('/logout', 'AlphaexadminController@logout');
    Route::get('/adminhome', 'AlphaexadminController@adminhome');
    Route::get('/dashboard', 'AlphaexadminController@dashboard');
    Route::get('/adminforgot', 'AlphaexadminController@adminforgot');
    Route::post('/adminforgot', 'AlphaexadminController@adminforgot');
    Route::get('/admin_profile', 'AlphaexadminController@admin_profile');
    Route::get('/admin_site_settings', 'AlphaexadminController@admin_site_settings');
    Route::post('/admin_profile', 'AlphaexadminController@admin_profile');
    Route::post('/admin_site_settings', 'AlphaexadminController@admin_site_settings');

    Route::get('/user_list/{page}', 'AlphaexadminController@user_list');
    Route::get('/user_auto_flag/{page}', 'AlphaexadminController@user_auto_flag');
    Route::get('/view_user/{unique_id}', 'AlphaexadminController@view_user');
    Route::post('/view_user/{unique_id}', 'AlphaexadminController@view_user');
    Route::post('/status_user', 'AlphaexadminController@status_user');
    Route::post('/account_status', 'AlphaexadminController@account_status');
    Route::get('/confirmation', 'AlphaexadminController@confirm');
    Route::get('/ftp', 'AlphaexadminController@ftp_test');
    Route::get('/user_transactions_detail/{unique_id}', 'AlphaexadminController@user_transactions_detail');
    Route::get('/admin_kyc_users/{page}', 'AlphaexadminController@admin_kyc_users');
    Route::get('/admin_view_kyc/{unique_id}', 'AlphaexadminController@admin_view_kyc');
    Route::post('/admin_view_kyc/{unique_id}', 'AlphaexadminController@admin_view_kyc');
    Route::get('/user_email_verification', 'AlphaexadminController@user_email_verification');
    Route::get('/users_balance/{page}', 'AlphaexadminController@users_balance');
    Route::get('/edit_user_balance/{page}', 'AlphaexadminController@edit_user_balance');
    Route::get('/users_opening_balance', 'AlphaexadminController@users_opening_balance');
    Route::get('/users_closing_balance', 'AlphaexadminController@users_closing_balance');

    Route::get('/deposit_transactions/{page}', 'AlphaexadminController@deposit_transactions');
    Route::get('/withdraw_transactions/{page}', 'AlphaexadminController@withdraw_transactions');
    Route::get('/view_transactions/{transactionId}', 'AlphaexadminController@view_transactions');
    Route::get('/confirm_withdraw_transactions/{transactionId}', 'AlphaexadminController@confirm_withdraw_transactions');
    Route::get('/cancel_withdraw_transactions/{transactionId}', 'AlphaexadminController@cancel_withdraw_transactions');
    Route::get('/updated_transactions/{page}', 'AlphaexadminController@updated_transactions');
    Route::get('/pending_tranc_history', 'AlphaexadminController@pending_tranc_history');
    Route::get('/deposit_transaction', 'AlphaexadminController@deposit_transaction');
    Route::get('/updated_transaction', 'AlphaexadminController@updated_transaction');
    Route::get('/send_transaction', 'AlphaexadminController@send_transaction');
    Route::get('/trade_mappings/{page}', 'AlphaexadminController@trade_mappings');


    Route::get('/admin_profit', 'AlphaexadminController@admin_profit');


    Route::get('/set_trading_fee/{currency?}', 'AlphaexadminController@set_trading_fee');
    Route::post('/set_trading_fee/{currency?}', 'AlphaexadminController@set_trading_fee');


    Route::get('/otc_list/{page}', 'AlphaexadminController@otc_list');
    Route::get('/otc_status', 'AlphaexadminController@otc_status');
    Route::post('/otc_status', 'AlphaexadminController@otc_status');
    Route::get('/view_otc/{unique_id}', 'AlphaexadminController@view_otc');
    Route::get('/partnership/{page}', 'AlphaexadminController@partnership');
    Route::get('/partnership_status', 'AlphaexadminController@partnership_status');
    Route::post('/partnership_status', 'AlphaexadminController@partnership_status');
    Route::get('/view_partnership/{unique_id}', 'AlphaexadminController@view_partnership');

    Route::get('/user_activities', 'AlphaexadminController@user_activities');
    Route::get('/user_activity/{id}', 'AlphaexadminController@user_activity');
    Route::get('/subadmin_activities', 'AlphaexadminController@subadmin_activities');
    Route::get('/subadmin_activity/{id}', 'AlphaexadminController@subadmin_activity');


    Route::get('/manage_faq/{page}', 'AlphaexadminController@manage_faq');
    Route::get('/add_faqs', 'AlphaexadminController@add_faqs');
    Route::get('/delete_faqs/{id}', 'AlphaexadminController@delete_faqs');
    Route::get('/status_faqs/{id}', 'AlphaexadminController@status_faqs');
    Route::get('/view_faq/{id}', 'AlphaexadminController@view_faq');
    Route::post('/view_faq/{id}', 'AlphaexadminController@view_faq');

    Route::get('/mailing_template', 'AlphaexadminController@mailing_template');
    Route::get('/mail_template', 'AlphaexadminController@mail_template');
    Route::get('/update_mail_template/{id}', 'AlphaexadminController@update_mail_template');
    Route::get('/announcements', 'AlphaexadminController@announcements');
    Route::get('/update_announcements/{id}', 'AlphaexadminController@update_announcements');
    Route::get('/sms_management', 'AlphaexadminController@sms_management');
    Route::get('/update_sms_management/{id}', 'AlphaexadminController@update_sms_management');

    Route::get('/contact_query_admin/{page}', 'AlphaexadminController@contact_query_admin');
    Route::get('/contact_status', 'AlphaexadminController@contact_status');
    Route::post('/contact_status', 'AlphaexadminController@contact_status');
    Route::get('/view_contact/{unique_id}', 'AlphaexadminController@view_contact');

    Route::get('/whitelist', 'AlphaexadminController@whitelist');
    Route::post('/whitelist', 'AlphaexadminController@whitelist');


    Route::get('/sub_admin', 'AlphaexadminController@sub_admin');
    Route::post('/sub_admin', 'AlphaexadminController@sub_admin');
    Route::get('/sub_admin_list', 'AlphaexadminController@sub_admin_list');
    Route::post('/sub_admin_list', 'AlphaexadminController@sub_admin_list');

    Route::get('/assets/{page}', 'AlphaexadminController@assets');
    Route::post('/assets/{page}', 'AlphaexadminController@assets');
    Route::get('/view_asset/{unique_id}', 'AlphaexadminController@view_asset');
    Route::post('/view_asset/{unique_id}', 'AlphaexadminController@view_asset');

    Route::post('/user_referral', 'AlphaexadminController@user_referral');
    Route::get('/user_referral/{page}', 'AlphaexadminController@user_referral');
    Route::post('/referral_bonus', 'AlphaexadminController@referral_bonus');
    Route::get('/view_referral_settings', 'AlphaexadminController@view_referral_settings');
    Route::post('/view_referral_settings', 'AlphaexadminController@view_referral_settings');
    Route::post('/edit_referral_settings/{currencyId}', 'AlphaexadminController@edit_referral_settings');


    Route::get('/admin_wallet/{page}', 'AlphaexadminController@admin_wallet');
    Route::get('/profit_wallet/{page}', 'AlphaexadminController@profit_wallet');
    Route::get('/brokerage_wallet/{page}', 'AlphaexadminController@brokerage_wallet');

    Route::get('/buy_package', 'AlphaexadminController@buy_package');
    Route::get('/package_price', 'AlphaexadminController@package_price');

    Route::get('/trade_orders/{page}', 'AlphaexadminController@trade_orders');
    Route::get('/partial_orders', 'AlphaexadminController@partial_orders');
    Route::get('/pending_orders', 'AlphaexadminController@pending_orders');
    Route::get('/cancel_orders', 'AlphaexadminController@cancel_orders');

    Route::get('/pair_request/{page}', 'AlphaexadminController@pair_request');
    Route::get('/trading_status', 'AlphaexadminController@trading_status');
    Route::post('/trading_status', 'AlphaexadminController@trading_status');

    Route::get('/send_balance_email', 'AlphaexadminController@send_balance_email');
});

// Cron update
Route::group(['prefix' => 'cron', 'middleware' => ['web', 'XSS']], function () {

    Route::get('/', 'CronController@index');
    Route::get('/update_prices', 'CronController@update_prices');
    Route::get('/update_bitfinex_bal', 'CronController@update_bitfinex_bal');
    Route::get('/eth_deposit_process', 'CronController@eth_deposit_process');
    Route::get('/eth_deposit_process_2', 'CronController@eth_deposit_process_2');
    Route::get('/eth_deposit_process_user/{id}', 'CronController@eth_deposit_process_user');
    Route::get('/xdce_deposit_process_user/{id}', 'CronController@xdce_deposit_process_user');
    Route::get('/xdce_deposit_process', 'CronController@xdce_deposit_process');
    Route::get('/xdc_withdrawal_process', 'CronController@xdc_withdrawal_check');
    Route::get('/pending_ico_order', 'ICOController@pending_ico_order');
    Route::get('/old_pending_cancel', 'ICOController@old_pending_cancel');
    Route::get('/pending_ico_order', 'ICOController@pending_ico_order');
    Route::get('/bch_deposit_process', 'CronController@bch_deposit_process');
    Route::get('/bchsv_deposit_process', 'CronController@bchsv_deposit_process');
    Route::get('/eth_deposit_console_user', 'CronController@eth_deposit_console_user');
    Route::get('/btc_deposit_process', 'CronController@btc_deposit_process');
    Route::get('/usdt_deposit_process', 'CronController@usdt_deposit_process');
    Route::get('/ripple_deposit_process', 'CronController@ripple_deposit_process');
    Route::get('/xdc_deposit_process', 'CronController@xdc_deposit_process');
    Route::get('/et_deposit_process', 'CronController@et_deposit_process');
    Route::get('/xrp_deposit_process', 'CronController@xrp_deposit_process');
    Route::get('/opening_balance', 'CronController@opening_balance');
    Route::get('/closing_balance', 'CronController@closing_balance');
    Route::get('/duplicate_record', 'CronController@duplicate_record');
    Route::get('/btc_records', 'CronController@btc_records');
    Route::get('/blocksync', 'CronController@last_mined_block_difference');
    Route::get('/koinok', 'CronController@koinok');
    Route::post('/getdata', 'CronController@getdata');
    Route::get('/bitfinex_ticker', 'CronController@bitfinex_ticker');
    Route::get('/liquid_order_ticker', 'CronController@liquid_ticker');
    Route::get('/bitfinex_order_status', 'CronController@bitfinex_order_status');
    Route::get('/m_xdc_deposit_process', 'CronController@m_xdc_deposit_process');
    Route::get('/send_indodax_mail', 'CronController@send_indodax_mail');
    Route::get('/check_admin_status', 'CronController@check_admin_status');

    //for alphaex v3 btc and usdt deposit listener
    Route::get('/btc_v3deposit_process', 'CronController@alphaexV3_btc_deposit_process');
    Route::get('/usdt_v3deposit_process', 'CronController@alphaexV3_usdt_deposit_process');
    Route::get('/v3deposit_process', 'CronController@test');
    Route::get('/update_v3_balances', 'CronController@update_v3_balances');

});

// Admin wallet
Route::group(['prefix' => 'walletjey', 'middleware' => ['web', 'XSS']], function () {

    Route::get('/', 'AdminwalletController@index');
    Route::post('/', 'AdminwalletController@index');
    Route::post('/checkpattern', 'AdminwalletController@checkpattern');
    Route::get('/home', 'AdminwalletController@home');
    Route::get('/logout', 'AdminwalletController@logout');
    Route::get('/walletdeposit/{currency?}', 'AdminwalletController@walletdeposit');
    Route::get('/walletwithdraw/{currency?}', 'AdminwalletController@walletwithdraw');
    Route::post('/walletwithdraw/{currency?}', 'AdminwalletController@walletwithdraw');
    Route::post('/generate_otp', 'AdminwalletController@generate_otp');
    Route::post('/profile', 'AdminwalletController@profile');
    Route::get('/profile', 'AdminwalletController@profile');
    Route::get('/change_pattern', 'AdminwalletController@change_pattern');
    Route::post('/set_pattern', 'AdminwalletController@set_pattern');
    Route::get('/profit', 'AdminwalletController@profit');

});


//for Alphaex V3 
// Admin wallet
Route::group(['prefix' => 'api', 'middleware' => ['web', 'XSS']], function () {
    Route::post('/transfer', 'SiteadminController@AlphaExV3Transfer');
});
